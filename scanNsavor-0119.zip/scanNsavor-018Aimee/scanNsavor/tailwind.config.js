/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./src/**/*.{html,js,php}"],
  theme: {
    extend: {
      colors: {
        primary: {
          50: '#548776',
          70: '#e6e8dd',
          90: '#808b53',
          110: '#ebf7f3'
        }
      }
    },

    screens: {
      'xs': {'min': '280px', 'max': '639px'},
      'sm': {'min': '640px', 'max': '767px'},
      'md': {'min': '768px', 'max': '1024px'},
      'lg': {'min': '1025px', 'max': '1366px'},
      'xl':{'min': '1367px'}, 
    },
  },

  colors: {
    'myColor': '##22C55E'
  },
  plugins: [],
}

