<?php

include('../class/Orders.php');
$order = new Order();
// /// Handle button click for confirming orders (assuming you have a form)
// if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['confirm_order'])) {
//   // Assuming you have a form input named 'order_id' to identify the order
//   $orderID = $_POST['order_id'];

//   // Update order status to "InProgress"
//   $confirmMessage = $order->updateOrderStatusToPending($orderID);
// }
// /// Handle button click for confirming orders (assuming you have a form)

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['process_order'])) {
    // Assuming you have a form input named 'order_id' to identify the order
    $orderID = $_POST['order_id'];

    // Update order status to "InProgress"
    $confirmMessage = $order->updateOrderStatusToInProgress($orderID);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['order_complete'])) {
    // Assuming you have a form input named 'order_id' to identify the order
    $orderID = $_POST['order_id'];

    // Update order status to "Completed"
    $confirmMessage = $order->updateOrderStatusToCompleted($orderID);
}

// // Inside served.php or wherever you handle the button click
// if (isset($_POST['archive']) && $_POST['archive'] == 1) {
//   $result = $order->archiveCompletedOrders($_POST['order_id']);
//   echo $result; // You can handle the result as needed (e.g., display a message)
// }

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['orderDetailsID'])) {
    $orderDetailsID = $_POST['orderDetailsID'];

    // Call the function to decrease the quantity
    $result = $order->decreaseQtyInServeQtyTemp($orderDetailsID);

    if ($result === true) {
        // Success
        echo '<script>';
        echo 'console.log("Serve Successfully. Quantity decreased successfully.");';
        echo 'window.location.href = "progress.php";';  // Redirect back to progress.php
        echo '</script>';
        exit();
    } else {
        // Handle error
        echo '<script>alert("Error: ' . $result . '");</script>';
    }
}

$pendingOrders = $order->getPendingOrders();
$InProgressOrders = $order->getInProgressOrders();
$CompleteOrders = $order->getCompleteOrders();


?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="refresh" content="40">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="../../dist/output.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/flowbite/1.8.0/flowbite.min.css" rel="stylesheet" />
    <script src="https://cdn.tailwindcss.com"></script>
    <title>View Orders | Scan N' Savor</title>
</head>

<body>
    <?php
    include '../view/navbar.php';
    ?>

    <div class="mx-auto my-5">
        <div class="mb-4 border-b border-gray-200">
            <ul class="flex flex-wrap -mb-px text-sm font-medium text-center justify-between mx-64" id="default-tab" data-tabs-toggle="#default-tab-content" role="tablist">
                <!-- Pending -->
                <li class="me-2" role="presentation">
                    <button class="inline-block p-4 border-b-2 rounded-t-lg hover:text-teal-400 hover:border-teal-400" id="profile-tab" data-tabs-target="#profile" type="button" role="tab" aria-controls="profile" aria-selected="false">
                        Pending Orders
                    </button>
                </li>

                <!-- Progress -->
                <li class="me-2" role="presentation">
                    <button class="inline-block p-4 border-b-2 rounded-t-lg hover:text-teal-400 hover:border-teal-400" id="dashboard-tab" data-tabs-target="#dashboard" type="button" role="tab" aria-controls="dashboard" aria-selected="false">In Progress Orders</button>
                </li>

            </ul>
        </div>

        <!-- pendingorders -->
        <div id="default-tab-content">
            <div class="hidden p-4 rounded-lg bg-gray-50 dark:bg-gray-800" id="profile" role="tabpanel" aria-labelledby="profile-tab">
                <section>
                    <div class="max-w-5xl py-10 pl-10 mx-auto ">
                        <div>
                            <div class="flex justify-between col-span-1 pt-5 pb-10 pl-5 md:col-span-2 lg:col-span-4">
                                <h2 class="text-lg font-bold tracking-wide text-gray-700 md:text-xl md:tracking-wider">
                                    Pending Orders
                                </h2>
                            </div>
                        </div>
                    </div>
                    <div class='grid max-w-5xl grid-cols-2 gap-4 px-5 mx-auto mt-5 mb-5 pl-11 xl:p-0 xl:gap-6'>
                        <?php if ($pendingOrders) : ?>
                            <?php
                            // Initialize an array to store orders grouped by table
                            $ordersByTable = array();

                            // Group orders by table
                            foreach ($pendingOrders as $order) {
                                $tableNo = $order['tableNo'];

                                if (!isset($ordersByTable[$tableNo])) {
                                    $ordersByTable[$tableNo] = array();
                                }

                                $ordersByTable[$tableNo][] = $order;
                            }

                            // Display orders grouped by table
                            foreach ($ordersByTable as $tableNo => $orders) :
                            ?>
                                <div class='max-w-md p-4 bg-white border rounded-lg shadow-md sm:p-8 dark:bg-gray-800 dark:border-gray-700'>
                                    <div class='flex items-center justify-between mb-4'>
                                        <?php
                                        // Assuming you have a loop to process orders
                                        // Initialize a variable to check if the table number has been displayed
                                        $tableNoDisplayed = false;
                                        foreach ($orders as $order) {
                                            // Get order information

                                            // Check if it's a dine-in order
                                            if ($order['isDineIn'] == 1 && !$tableNoDisplayed) {
                                                $tableNo = $order['tableNo'];
                                                echo "<h3 class='text-xl font-bold leading-none text-gray-900 dark:text-white'>Table $tableNo (Order #{$order['orderID']})</h3>";
                                                $tableNoDisplayed = true; // Set to true once the table number is displayed
                                            }
                                        }
                                        // If it's a takeout order and the table number has not been displayed yet
                                        if (!$tableNoDisplayed) {
                                            echo "<h3 class='text-xl font-bold leading-none text-gray-900 dark:text-white'>Take Out (Order #{$order['orderID']})</h3>";
                                        }
                                        ?>
                                        <!-- Display ⓘ icon if special request is not empty
                            <?php if (!empty($order['specialRequest'])) : ?>
                                <span class='text-2xl text-red-500 mr-2 cursor-pointer cursor-help' title='<?= htmlspecialchars($order['specialRequest']) ?>'>ⓘ </span>
                            <?php endif; ?> -->
                                    </div>
                                    <div class='flow-root'>
                                        <ul role='list' class='overflow-y-auto divide-y divide-gray-200 order-list dark:divide-gray-700 max-h-72' style='padding-right: 30px;'>
                                            <li class='py-3 sm:py-4'>
                                                <div class='flex items-center space-x-4'>
                                                    <div class='flex-1 min-w-0'>
                                                        <p class='text-base font-semibold text-gray-900 truncate dark:text-white'>
                                                            Dish
                                                        </p>
                                                    </div>
                                                    <div class='inline-flex items-center text-base font-semibold text-gray-900 dark:text-white'>
                                                        Quantity
                                                    </div>
                                                </div>
                                            </li>
                                            <?php
                                            $packages = array();

                                            foreach ($orders as $order) : ?>
                                                <li class='py-3 sm:py-4'>
                                                    <?php
                                                    $isProcessed = isset($packages[$order['packageID']]);
                                                    ?>

                                                    <?php if (!$isProcessed) : ?>
                                                        <div class='flex items-center space-x-4'>
                                                            <div class='flex-1 min-w-0'>
                                                                <p class='text-sm font-medium text-gray-900 truncate dark:text-white'>
                                                                    <?php
                                                                    if (!empty($order['itemID'])) {
                                                                        echo $order['itemName'];
                                                                    } elseif (!empty($order['packageID'])) {
                                                                        echo $order['packageName'];
                                                                    }

                                                                    if (isset($order['preferences']) && $order['preferences'] === "Take-out") {
                                                                        echo " (Take-out)";
                                                                    }
                                                                    ?>
                                                                </p>
                                                            </div>
                                                            <div class='inline-flex items-center text-base font-semibold text-gray-900 dark:text-white'>
                                                                <?= $order['itemQuantity'] ?><span>x</span>
                                                            </div>
                                                        </div>
                                                    <?php endif; ?>

                                                    <!-- Additional information section -->
                                                    <div>
                                                        <?php if (!empty($order['packageID'])) : ?>
                                                            <!-- Display itemName of the packageName as additional information -->
                                                            <?php
                                                            if (!$isProcessed) {
                                                                $packageID = $order['packageID'];
                                                                $packageItemsQuery = "SELECT itemName FROM tblmenupackageitems WHERE packageID = '$packageID'";
                                                                $packageItemsResult = mysqli_query($conn, $packageItemsQuery);

                                                                if ($packageItemsResult) {
                                                                    $packageItems = mysqli_fetch_all($packageItemsResult, MYSQLI_ASSOC);

                                                                    if (!empty($packageItems)) {
                                                                        echo "<ul class='text-sm text-gray-500 pl-4'>";
                                                                        foreach ($packageItems as $item) {
                                                                            echo "<li>{$item['itemName']}</li>";
                                                                        }
                                                                        echo "</ul>";
                                                                    }
                                                                }
                                                                $packages[$order['packageID']] = true;
                                                            }
                                                            ?>
                                                        <?php endif; ?>
                                                    </div>
                                                </li>
                                            <?php endforeach; ?>

                                            <li class='pt-3 pb-0 sm:pt-4'>
                                                <div class='flex items-center space-x-4'>
                                                    <div class='flex-1 min-w-0'>
                                                    </div>
                                                </div>
                                            </li>
                                        </ul>
                                        <!-- Display specialRequest -->
                                        <?php if (!empty($order['specialRequest'])) : ?>
                                                            <div class='text-sm text-gray-500 pl-4'>
                                                                <strong>Special Request:</strong> <?= htmlspecialchars($order['specialRequest']) ?>
                                                            </div>
                                                        <?php endif; ?>
                                        <form method='POST' class='block w-full px-4 py-3 mt-10 font-medium tracking-wide text-center capitalize transition-colors bg-gray-700 border border-teal-900 focus:outline-none focus:ring'>
                                            <input type='hidden' name='order_id' value='<?= $tableNo ?>'>
                                            <button class='px-2 py-1 text-xs text-white bg-gray-700 border-teal-900 focus:outline-none focus:ring' type='submit' name='process_order' value='1'>Process Order</button>
                                        </form>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php else : ?>
                            <span class='mt-5 text-xs text-gray-500'>No Pending Orders.</span>
                        <?php endif; ?>
                    </div>
                </section>

            </div>


            <!-- inprogress -->
            <?php
            include '../forms/serveOrders.php';
            ?>
            <div class="hidden p-4 rounded-lg bg-gray-50 dark:bg-gray-800" id="dashboard" role="tabpanel" aria-labelledby="dashboard-tab">
                <section>
                    <div class="mx-auto max-w-5xl py-10 pl-10">
                        <div>
                            <div class="pt-5 pl-5 pb-10 col-span-1 md:col-span-2 lg:col-span-4 flex justify-between">
                                <h2 class="text-lg md:text-xl text-gray-700 font-bold tracking-wide md:tracking-wider">
                                    In Progress Orders
                                </h2>
                            </div>
                        </div>
                    </div>
                    <div class='mt-5 mb-5 max-w-5xl mx-auto grid grid-cols-2 px-5 pl-11 xl:p-0 gap-4 xl:gap-6'>
                        <?php if ($InProgressOrders) : ?>
                            <?php
                            // Initialize an array to store orders grouped by table
                            $ordersByTable = array();

                            // Group orders by table
                            foreach ($InProgressOrders as $order) {
                                $tableNo = $order['tableNo'];

                                if (!isset($ordersByTable[$tableNo])) {
                                    $ordersByTable[$tableNo] = array();
                                }

                                $ordersByTable[$tableNo][] = $order;
                            }

                            // Display orders grouped by table
                            foreach ($ordersByTable as $tableNo => $orders) :
                            ?>
                                <div class='max-w-md p-4 bg-white border rounded-lg shadow-md sm:p-8 dark:bg-gray-800 dark:border-gray-700'>
                                    <div class='flex items-center justify-between mb-4'>
                                        <?php
                                        // Assuming you have a loop to process orders
                                        // Initialize a variable to check if the table number has been displayed
                                        $tableNoDisplayed = false;
                                        foreach ($orders as $order) {
                                            // Get order information

                                            // Check if it's a dine-in order
                                            if ($order['isDineIn'] == 1 && !$tableNoDisplayed) {
                                                $tableNo = $order['tableNo'];
                                                echo "<h3 class='text-xl font-bold leading-none text-gray-900 dark:text-white'>Table $tableNo (Order #{$order['orderID']})</h3>";
                                                $tableNoDisplayed = true; // Set to true once the table number is displayed
                                            }
                                        }
                                        // If it's a takeout order and the table number has not been displayed yet
                                        if (!$tableNoDisplayed) {
                                            echo "<h3 class='text-xl font-bold leading-none text-gray-900 dark:text-white'>Take Out (Order #{$order['orderID']})</h3>";
                                        }
                                        ?>
                                        <!-- Display ⓘ icon if special request is not empty
                            <?php if (!empty($order['specialRequest'])) : ?>
                                <span class='text-2xl text-red-500 mr-2 cursor-pointer cursor-help' title='<?= htmlspecialchars($order['specialRequest']) ?>'>ⓘ </span>
                            <?php endif; ?> -->
                                    </div>
                                    <div class='flow-root'>
                                        <ul role='list' class='order-list divide-y divide-gray-200 dark:divide-gray-700 overflow-y-auto max-h-72' style='padding-right: 30px;'>
                                            <li class='py-3 sm:py-4'>
                                                <div class='flex items-center space-x-4'>
                                                    <div class='flex-1 min-w-0'>
                                                        <p class='text-base font-semibold text-gray-900 truncate dark:text-white'>
                                                            Dish
                                                        </p>
                                                    </div>
                                                    <div class='inline-flex items-center text-base font-semibold text-gray-900 dark:text-white'>
                                                        Serve(No.)
                                                    </div>
                                                    <div class='inline-flex items-center text-base font-semibold text-gray-900 dark:text-white'>
                                                        Serve Order
                                                    </div>
                                                </div>
                                            </li>
                                            <?php
                                            $packages = array();

                                            foreach ($orders as $order) : ?>
                                                <li class='py-3 sm:py-4'>
                                                    <?php
                                                    $isProcessed = isset($packages[$order['packageID']]);
                                                    ?>

                                                    <?php if (!$isProcessed) : ?>
                                                        <div class='flex items-center space-x-4'>
                                                            <div class='flex-1 min-w-0'>
                                                                <p class='text-sm font-medium text-gray-900 truncate dark:text-white'>
                                                                    <?= $order['itemQuantity'] ?><span>x</span>
                                                                    <?php
                                                                    if (!empty($order['itemID'])) {
                                                                        echo $order['itemName'];
                                                                    } elseif (!empty($order['packageID'])) {
                                                                        echo $order['packageName'];
                                                                    }

                                                                    if (isset($order['preferences']) && $order['preferences'] === "Take-out") {
                                                                        echo " (Take-out)";
                                                                    }
                                                                    ?>
                                                                </p>
                                                            </div>
                                                            <div class='inline-flex items-center text-base font-semibold text-gray-900 dark:text-white'>
                                                                <?= $order['Qty'] ?>
                                                            </div>
                                                            <?php
                                                            $orderDetailsID = isset($order['orderDetailsID']) ? $order['orderDetailsID'] : '';
                                                            ?>
                                                            <form method='POST' action='sidenavkitchen.php' class='inline-flex items-center text-base font-semibold text-gray-900 dark:text-white'>
                                                                <input type='hidden' name='serve_order' value='<?= $tableNo ?>'>
                                                                <input type='hidden' name='orderDetailsID' value='<?= $orderDetailsID ?>'>
                                                                <?php
                                                                $status = isset($order['status']) ? $order['status'] : 'Serve Order';
                                                                ?>
                                                                <button class='serve-button bg-gray-700 hover:bg-gray-800 border-teal-900 rounded-xl transition-colors duration-300 transform focus:outline-none focus:ring text-xs text-white px-2 py-1 serve-button' type='submit' data-status='<?= $status ?>'>Serve Order</button>
                                                            </form>
                                                        </div>
                                                    <?php endif; ?>

                                                    <!-- Additional information section -->
                                                    <div>
                                                        <?php if (!empty($order['packageID'])) : ?>
                                                            <!-- Display itemName of the packageName as additional information -->
                                                            <?php
                                                            if (!$isProcessed) {
                                                                $packageID = $order['packageID'];
                                                                $packageItemsQuery = "SELECT itemName FROM tblmenupackageitems WHERE packageID = '$packageID'";
                                                                $packageItemsResult = mysqli_query($conn, $packageItemsQuery);

                                                                if ($packageItemsResult) {
                                                                    $packageItems = mysqli_fetch_all($packageItemsResult, MYSQLI_ASSOC);

                                                                    if (!empty($packageItems)) {
                                                                        echo "<ul class='text-sm text-gray-500 pl-4'>";
                                                                        foreach ($packageItems as $item) {
                                                                            echo "<li>{$item['itemName']}</li>";
                                                                        }
                                                                        echo "</ul>";
                                                                    }
                                                                }
                                                                $packages[$order['packageID']] = true;
                                                            }
                                                            ?>
                                                        <?php endif; ?>
                                                    </div>
                                                </li>
                                            <?php endforeach; ?>

                                            <li class='pt-3 pb-0 sm:pt-4'>
                                                <div class='flex items-center space-x-4'>
                                                    <div class='flex-1 min-w-0'>
                                                    </div>
                                                </div>
                                            </li>
                                        </ul>
                                        <!-- Display specialRequest -->
                                        <?php if (!empty($order['specialRequest'])) : ?>
                                                            <div class='text-sm text-gray-500 pl-4'>
                                                                <strong>Special Request:</strong> <?= htmlspecialchars($order['specialRequest']) ?>
                                                            </div>
                                                        <?php endif; ?>
                                        <form method='POST' class='bg-gray-700 border-teal-900 transition-colors focus:outline-none focus:ring block mt-10 w-full px-4 py-3 font-medium tracking-wide text-center capitalize border'>
                                            <input type='hidden' name='order_id' value='<?= $tableNo ?>'>
                                            <button class='bg-gray-700 border-teal-900 focus:outline-none focus:ring text-xs text-white px-2 py-1' type='submit' name='order_complete' value='1'>(All) Serve Order</button>
                                        </form>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php else : ?>
                            <span class='mt-5 text-xs text-gray-500'>No In Progress Orders.</span>
                        <?php endif; ?>
                    </div>
                </section>

            </div>

        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const tabs = document.querySelectorAll('[data-tabs-target]');

            tabs.forEach(tab => {
                tab.addEventListener('click', function() {
                    const target = this.getAttribute('data-tabs-target');
                    showTab(target);
                    localStorage.setItem('selectedTab', target);
                });
            });

            // Retrieve the selected tab from local storage
            const selectedTab = localStorage.getItem('selectedTab');
            if (selectedTab) {
                showTab(selectedTab);
            }
        });

        function showTab(target) {
            const tabsContent = document.getElementById('default-tab-content');
            const tabs = document.querySelectorAll('[data-tabs-target]');

            tabsContent.querySelectorAll('[role="tabpanel"]').forEach(tab => {
                tab.classList.add('hidden');
            });

            tabs.forEach(tab => {
                tab.setAttribute('aria-selected', 'false');
            });

            document.getElementById(target).classList.remove('hidden');
            document.querySelector(`[data-tabs-target="${target}"]`).setAttribute('aria-selected', 'true');
        }
    </script>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const selectedTab = "<?php echo $selectedTab; ?>";
            showTab(selectedTab);
        });
    </script>

    <script>
        // Function to reload the page after 10 seconds
        function reloadPage() {
            location.reload();
        }

        // Set the timeout for the first reload
        setTimeout(reloadPage, 40000);
    </script>

</body>
<script src="https://cdnjs.cloudflare.com/ajax/libs/flowbite/1.8.0/flowbite.min.js"></script>

</html>