
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="../../dist/output.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/flowbite/1.8.1/flowbite.min.css" rel="stylesheet">
    <title>In Progress Orders | Scan N' Savor</title>
</head>

<?php
include '../viewKitchen/sidenavkitchen.php';
include '../forms/serveOrders.php';
?>

<body>
    <section>
        <div class="mx-auto max-w-5xl py-10 pl-10">
            <div>
                <div class="pt-5 pl-5 pb-10 col-span-1 md:col-span-2 lg:col-span-4 flex justify-between">
                    <h2 class="text-lg md:text-xl text-gray-700 font-bold tracking-wide md:tracking-wider">
                        In Progress Orders
                    </h2>
                </div>
            </div>
        </div>
        <div class='mt-5 mb-5 max-w-5xl mx-auto grid grid-cols-2 px-5 pl-11 xl:p-0 gap-4 xl:gap-6'>
            <?php if ($InProgressOrders) : ?>
                <?php
                // Initialize an array to store orders grouped by table
                $ordersByTable = array();

                // Group orders by table
                foreach ($InProgressOrders as $order) {
                    $tableNo = $order['tableNo'];

                    if (!isset($ordersByTable[$tableNo])) {
                        $ordersByTable[$tableNo] = array();
                    }

                    $ordersByTable[$tableNo][] = $order;
                }

                // Display orders grouped by table
                foreach ($ordersByTable as $tableNo => $orders) :
                    ?>
                        <div class='max-w-md p-4 bg-white border rounded-lg shadow-md sm:p-8 dark:bg-gray-800 dark:border-gray-700'>
                            <div class='flex items-center justify-between mb-4'>
                            <?php
                            // Assuming you have a loop to process orders
                            // Initialize a variable to check if the table number has been displayed
                            $tableNoDisplayed = false;
                            foreach ($orders as $order) {
                                // Get order information
    
                                // Check if it's a dine-in order
                                if ($order['isDineIn'] == 1 && !$tableNoDisplayed) {
                                    $tableNo = $order['tableNo'];
                                    echo "<h3 class='text-xl font-bold leading-none text-gray-900 dark:text-white'>Table $tableNo (Order #{$order['orderID']})</h3>";
                                    $tableNoDisplayed = true; // Set to true once the table number is displayed
                                }
                            }
                            // If it's a takeout order and the table number has not been displayed yet
                            if (!$tableNoDisplayed) {
                                echo "<h3 class='text-xl font-bold leading-none text-gray-900 dark:text-white'>Take Out (Order #{$order['orderID']})</h3>";
                            }
                            ?>
                            <!-- Display ⓘ icon if special request is not empty
                            <?php if (!empty($order['specialRequest'])) : ?>
                                <span class='text-2xl text-red-500 mr-2 cursor-pointer cursor-help' title='<?= htmlspecialchars($order['specialRequest']) ?>'>ⓘ </span>
                            <?php endif; ?> -->
                        </div>
                        <div class='flow-root'>
                            <ul role='list' class='order-list divide-y divide-gray-200 dark:divide-gray-700 overflow-y-auto max-h-72' style='padding-right: 30px;'>
                                <li class='py-3 sm:py-4'>
                                    <div class='flex items-center space-x-4'>
                                        <div class='flex-1 min-w-0'>
                                            <p class='text-base font-semibold text-gray-900 truncate dark:text-white'>
                                                Dish
                                            </p>
                                        </div>
                                        <div class='inline-flex items-center text-base font-semibold text-gray-900 dark:text-white'>
                                            Serve(No.)
                                        </div>
                                        <div class='inline-flex items-center text-base font-semibold text-gray-900 dark:text-white'>
                                            Serve Order
                                        </div>
                                    </div>
                                </li>
                                <?php
                        $packages = array();

                        foreach ($orders as $order) : ?>
                            <li class='py-3 sm:py-4'>
                                <?php
                                $isProcessed = isset($packages[$order['packageID']]);
                                ?>

                                <?php if (!$isProcessed) : ?>
                                    <div class='flex items-center space-x-4'>
                                        <div class='flex-1 min-w-0'>
                                            <p class='text-sm font-medium text-gray-900 truncate dark:text-white'>
                                            <?= $order['itemQuantity'] ?><span>x</span>
                                                <?php
                                                if (!empty($order['itemID'])) {
                                                    echo $order['itemName'];
                                                } elseif (!empty($order['packageID'])) {
                                                    echo $order['packageName'];
                                                }

                                                if (isset($order['preferences']) && $order['preferences'] === "Take-out") {
                                                    echo " (Take-out)";
                                                }
                                                ?>
                                            </p>
                                        </div>
                                            <div class='inline-flex items-center text-base font-semibold text-gray-900 dark:text-white'>
                                                <?= $order['Qty'] ?>
                                            </div>
                                            <?php
                                            $orderDetailsID = isset($order['orderDetailsID']) ? $order['orderDetailsID'] : '';
                                            ?>
                                            <form method='POST' action='sidenavkitchen.php' class='inline-flex items-center text-base font-semibold text-gray-900 dark:text-white'>
                                                <input type='hidden' name='serve_order' value='<?= $tableNo ?>'>
                                                <input type='hidden' name='orderDetailsID' value='<?= $orderDetailsID ?>'>
                                                <?php
                                                $status = isset($order['status']) ? $order['status'] : 'Serve Order';
                                                ?>
                                                <button class='serve-button bg-gray-700 hover:bg-gray-800 border-teal-900 rounded-xl transition-colors duration-300 transform focus:outline-none focus:ring text-xs text-white px-2 py-1 serve-button' type='submit' data-status='<?= $status ?>'>Serve Order</button>
                                            </form>
                                            </div>
                                <?php endif; ?>

                                <!-- Additional information section -->
                                <div>
                                    <?php if (!empty($order['packageID'])) : ?>
                                        <!-- Display itemName of the packageName as additional information -->
                                        <?php
                                        if (!$isProcessed) {
                                            $packageID = $order['packageID'];
                                            $packageItemsQuery = "SELECT itemName FROM tblmenupackageitems WHERE packageID = '$packageID'";
                                            $packageItemsResult = mysqli_query($conn, $packageItemsQuery);

                                            if ($packageItemsResult) {
                                                $packageItems = mysqli_fetch_all($packageItemsResult, MYSQLI_ASSOC);

                                                if (!empty($packageItems)) {
                                                    echo "<ul class='text-sm text-gray-500 pl-4'>";
                                                    foreach ($packageItems as $item) {
                                                        echo "<li>{$item['itemName']}</li>";
                                                    }
                                                    echo "</ul>";
                                                }
                                            }
                                            $packages[$order['packageID']] = true;
                                        }
                                        ?>
                                    <?php endif; ?>
                                </div>
                            </li>
                        <?php endforeach; ?>

                                <li class='pt-3 pb-0 sm:pt-4'>
                                    <div class='flex items-center space-x-4'>
                                        <div class='flex-1 min-w-0'>
                                        </div>
                                    </div>
                                </li>
                            </ul>
                            <!-- Display specialRequest -->
                            <?php if (!empty($order['specialRequest'])) : ?>
                                                <div class='text-sm text-gray-500 pl-4'>
                                                    <strong>Special Request:</strong> <?= htmlspecialchars($order['specialRequest']) ?>
                                                </div>
                                            <?php endif; ?>
                            <form method='POST' class='bg-gray-700 border-teal-900 transition-colors focus:outline-none focus:ring block mt-10 w-full px-4 py-3 font-medium tracking-wide text-center capitalize border'>
                                <input type='hidden' name='order_id' value='<?= $tableNo ?>'>
                                <button class='bg-gray-700 border-teal-900 focus:outline-none focus:ring text-xs text-white px-2 py-1' type='submit' name='order_complete' value='1'>(All) Serve Order</button>
                            </form>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php else : ?>
                <span class='mt-5 text-xs text-gray-500'>No In Progress Orders.</span>
            <?php endif; ?>
        </div>
    </section>
</body>

</html>
<script src="https://cdnjs.cloudflare.com/ajax/libs/flowbite/1.8.0/flowbite.min.js"></script>