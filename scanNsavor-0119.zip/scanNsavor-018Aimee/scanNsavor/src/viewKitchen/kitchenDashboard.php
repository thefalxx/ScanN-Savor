

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="../../dist/output.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/apexcharts"></script>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/flowbite/1.8.0/flowbite.min.css" rel="stylesheet" />
    <title>Kitchen | Scan N' Savor</title>
</head>

<?php
include '../viewKitchen/sidenavkitchen.php';
?>

<body>
    <div class="mx-auto max-w-5xl py-10 pl-10">
        <!-- Start Second Row -->
        <div class="col-span-1 md:col-span-2 lg:col-span-4 flex justify-between">
            <h2 class="text-xs md:text-sm text-gray-700 font-bold tracking-wide md:tracking-wider pb-10">
                Kitchen Dashboard</h2>
            <!-- <a href="#" class="text-xs text-gray-800 font-semibold uppercase">More</a> -->
        </div>
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 px-4 xl:p-0 gap-4 xl:gap-6">
            <div class="bg-white p-6 rounded-xl border border-gray-200 shadow">
                <div class="flex justify-between items-start">
                    <div class="flex flex-col">
                        <p class="text-xs text-gray-600 tracking-wide">Pending Orders</p>
                        <h3 class="mt-1 text-lg text-yellow-300 font-bold"> <?php echo $order->getOrdersCount("Pending"); ?></h3>
                    </div>
                    <div class="bg-yellow-300 p-2 md:p-1 xl:p-2 rounded-md">
                    </div>
                </div>
            </div>
            <div class="bg-white p-6 rounded-xl border border-gray-200 shadow">
                <div class="flex justify-between items-start">
                    <div class="flex flex-col">
                        <p class="text-xs text-gray-600 tracking-wide">In Progress Orders</p>
                        <h3 class="mt-1 text-lg text-green-400 font-bold"><?php echo $order->getOrdersCount("In Progress"); ?></h3>
                    </div>
                    <div class="bg-green-400 p-2 md:p-1 xl:p-2 rounded-md">
                        <!-- <img src="https://atom.dzulfarizan.com/assets/grocery.png" alt="icon" class="w-auto h-8 md:h-6 xl:h-8 object-cover"> -->
                    </div>
                </div>
            </div>
            <div class="bg-white p-6 rounded-xl border border-gray-200 shadow">
                <div class="flex justify-between items-start">
                    <div class="flex flex-col">
                        <p class="text-xs text-gray-600 tracking-wide">Completed</p>
                        <h3 class="mt-1 text-lg text-indigo-500 font-bold"><?php echo $order->getOrdersCount("Completed"); ?></h3>
                    </div>
                    <div class="bg-indigo-500 p-2 md:p-1 xl:p-2 rounded-md">
                        <!-- <img src="https://atom.dzulfarizan.com/assets/holiday.png" alt="icon" class="w-auto h-8 md:h-6 xl:h-8 object-cover"> -->
                    </div>
                </div>
            </div>
        </div>
    </div>


</body>

</html>