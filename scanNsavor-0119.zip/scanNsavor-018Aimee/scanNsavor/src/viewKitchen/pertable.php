<?php
include '../viewKitchen/sidenavkitchen.php';
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="../../dist/output.css" rel="stylesheet">
    <title>Orders Per Table | Scan N' Savor</title>
</head>
<body>
    <section>
        <div class="mx-auto max-w-5xl py-10 pl-10">
            <div>
                <div class="pt-5 pl-5 pb-10 col-span-1 md:col-span-2 lg:col-span-4 flex justify-between">
                    <h2 class="text-lg md:text-xl text-gray-700 font-bold tracking-wide md:tracking-wider">
                        Orders Per Table</h2>

                </div>
            </div>
            <div>
                <div class="pt-10 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 px-4 xl:p-0 gap-4 xl:gap-6">

                    <div class="h-80 bg-white p-6 rounded-xl border border-gray-200 shadow">
                        <div class="flex justify-between items-start">
                            <div class="flex flex-col">
                                <p class="text-xs text-gray-600 tracking-wide">Pending Orders</p>
                                <h3 class="mt-1 text-lg text-blue-500 font-bold"> Table 11</h3>
                                <span class="mt-4 text-xs text-gray-500">Pending 2 minutes</span>
                            </div>
                            <div class="bg-blue-500 p-2 md:p-1 xl:p-2 rounded-md">
                            </div>
                        </div>
                    </div>
                    <div class="h-80 bg-white p-6 rounded-xl border border-gray-200 shadow">
                        <div class="flex justify-between items-start">
                            <div class="flex flex-col">
                                <p class="text-xs text-gray-600 tracking-wide">In Progress Orders</p>
                                <h3 class="mt-1 text-lg text-green-500 font-bold">Table 4</h3>
                                <span class="mt-4 text-xs text-gray-500">Progress 10 minutes</span>
                            </div>
                            <div class="bg-green-500 p-2 md:p-1 xl:p-2 rounded-md">
                            </div>
                        </div>
                    </div>
                    <div class="h-80 bg-white p-6 rounded-xl border border-gray-200 shadow">
                        <div class="flex justify-between items-start">
                            <div class="flex flex-col">
                                <p class="text-xs text-gray-600 tracking-wide">Ready To Be Served</p>
                                <h3 class="mt-1 text-lg text-yellow-500 font-bold">Table 5</h3>
                                <span class="mt-4 text-xs text-gray-600">Out in the kitchen</span>
                            </div>
                            <div class="bg-yellow-500 p-2 md:p-1 xl:p-2 rounded-md">
                            </div>
                        </div>
                    </div>
                    <div class="bg-white p-6 rounded-xl border border-gray-200 shadow">
                        <div class="flex justify-between items-start">
                            <div class="flex flex-col">
                                <p class="text-xs text-gray-600 tracking-wide">Completed</p>
                                <h3 class="mt-1 text-lg text-indigo-500 font-bold">Table 2</h3>
                                <span class="mt-4 text-xs text-gray-500">Just Now</span>
                            </div>
                            <div class="bg-indigo-500 p-2 md:p-1 xl:p-2 rounded-md">
                            </div>

                        </div>
                    </div>
                    <div class="h-80 bg-white p-6 rounded-xl border border-gray-200 shadow">
                        <div class="flex justify-between items-start">
                            <div class="flex flex-col">
                                <p class="text-xs text-gray-600 tracking-wide">Pending Orders</p>
                                <h3 class="mt-1 text-lg text-blue-500 font-bold"> Table 11</h3>
                                <span class="mt-4 text-xs text-gray-500">Pending 2 minutes</span>
                            </div>
                            <div class="bg-blue-500 p-2 md:p-1 xl:p-2 rounded-md">
                            </div>
                        </div>
                    </div>
                    <div class="h-80 bg-white p-6 rounded-xl border border-gray-200 shadow">
                        <div class="flex justify-between items-start">
                            <div class="flex flex-col">
                                <p class="text-xs text-gray-600 tracking-wide">In Progress Orders</p>
                                <h3 class="mt-1 text-lg text-green-500 font-bold">Table 4</h3>
                                <span class="mt-4 text-xs text-gray-500">Progress 10 minutes</span>
                            </div>
                            <div class="bg-green-500 p-2 md:p-1 xl:p-2 rounded-md">
                            </div>
                        </div>
                    </div>
                    <div class="h-80 bg-white p-6 rounded-xl border border-gray-200 shadow">
                        <div class="flex justify-between items-start">
                            <div class="flex flex-col">
                                <p class="text-xs text-gray-600 tracking-wide">Ready To Be Served</p>
                                <h3 class="mt-1 text-lg text-yellow-500 font-bold">Table 5</h3>
                                <span class="mt-4 text-xs text-gray-600">Out in the kitchen</span>
                            </div>
                            <div class="bg-yellow-500 p-2 md:p-1 xl:p-2 rounded-md">
                            </div>
                        </div>
                    </div>
                    <div class="bg-white p-6 rounded-xl border border-gray-200 shadow">
                        <div class="flex justify-between items-start">
                            <div class="flex flex-col">
                                <p class="text-xs text-gray-600 tracking-wide">Completed</p>
                                <h3 class="mt-1 text-lg text-indigo-500 font-bold">Table 2</h3>
                                <span class="mt-4 text-xs text-gray-500">Just Now</span>
                            </div>
                            <div class="bg-indigo-500 p-2 md:p-1 xl:p-2 rounded-md">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

</body>
</html>
<script src="https://cdn.jsdelivr.net/npm/apexcharts"></script>