<?php
include('../class/User.php');
include('../class/Orders.php');
$order = new Order();
// /// Handle button click for confirming orders (assuming you have a form)
// if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['confirm_order'])) {
//   // Assuming you have a form input named 'order_id' to identify the order
//   $orderID = $_POST['order_id'];

//   // Update order status to "InProgress"
//   $confirmMessage = $order->updateOrderStatusToPending($orderID);
// }
// /// Handle button click for confirming orders (assuming you have a form)

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['process_order'])) {
    // Assuming you have a form input named 'order_id' to identify the order
    $orderID = $_POST['order_id'];

    // Update order status to "InProgress"
    $confirmMessage = $order->updateOrderStatusToInProgress($orderID);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['order_complete'])) {
    // Assuming you have a form input named 'order_id' to identify the order
    $orderID = $_POST['order_id'];

    // Update order status to "Completed"
    $confirmMessage = $order->updateOrderStatusToCompleted($orderID);
}

// // Inside served.php or wherever you handle the button click
// if (isset($_POST['archive']) && $_POST['archive'] == 1) {
//   $result = $order->archiveCompletedOrders($_POST['order_id']);
//   echo $result; // You can handle the result as needed (e.g., display a message)
// }

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['orderDetailsID'])) {
    $orderDetailsID = $_POST['orderDetailsID'];

    // Call the function to decrease the quantity
    $result = $order->decreaseQtyInServeQtyTemp($orderDetailsID);

    if ($result === true) {
        // Success
        echo '<script>';
        echo 'console.log("Serve Successfully. Quantity decreased successfully.");';
        echo 'window.location.href = "progress.php";';  // Redirect back to progress.php
        echo '</script>';
        exit();
    } else {
        // Handle error
        echo '<script>alert("Error: ' . $result . '");</script>';
    }
}

$pendingOrders = $order->getPendingOrders();
$InProgressOrders = $order->getInProgressOrders();
$CompleteOrders = $order->getCompleteOrders();


$user = new User();
$user->loginStatus();
$user->reload();
$userDetail = $user->userDetails();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="../../dist/output.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/flowbite/2.2.0/flowbite.min.css" rel="stylesheet" />
    <title>Document</title>
    <style>
        /* @media screen and (max-width: 1024px) {
            #default-sidebar {
                display: none;
            }

            #default-sidebar.open {
                display: block;
            }
        } */

        @media screen and (min-width: 1025px) {
            #default-sidebar {
                display: block;
            }
        }

        @media screen and (max-width: 1024px) {
            #default-sidebar {
                display: none;
            }

            #default-sidebar.open {
                display: block;
            }
        }
    </style>
</head>

<body>

    <!-- hamburger -->
    <!-- <button data-drawer-target="default-sidebar" data-drawer-toggle="default-sidebar" aria-controls="default-sidebar" type="button" class="inline-flex items-center p-2 mt-2 ml-3 text-sm text-gray-500 rounded-lg sm:hidden hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-gray-200">
        <span class="sr-only">Open sidebar</span>
        <svg class="w-6 h-6" aria-hidden="true" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
            <path clip-rule="evenodd" fill-rule="evenodd" d="M2 4.75A.75.75 0 012.75 4h14.5a.75.75 0 010 1.5H2.75A.75.75 0 012 4.75zm0 10.5a.75.75 0 01.75-.75h7.5a.75.75 0 010 1.5h-7.5a.75.75 0 01-.75-.75zM2 10a.75.75 0 01.75-.75h14.5a.75.75 0 010 1.5H2.75A.75.75 0 012 10z"></path>
        </svg>
    </button> -->

    <button data-drawer-target="default-sidebar" data-drawer-toggle="default-sidebar" aria-controls="default-sidebar" type="button" class="inline-flex items-center p-2 mt-2 ml-3 text-sm text-gray-500 rounded-lg sm:hidden hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-gray-200">
        <span class="sr-only">Open sidebar</span>
        <svg class="w-6 h-6" aria-hidden="true" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
            <path clip-rule="evenodd" fill-rule="evenodd" d="M2 4.75A.75.75 0 012.75 4h14.5a.75.75 0 010 1.5H2.75A.75.75 0 012 4.75zm0 10.5a.75.75 0 01.75-.75h7.5a.75.75 0 010 1.5h-7.5a.75.75 0 01-.75-.75zM2 10a.75.75 0 01.75-.75h14.5a.75.75 0 010 1.5H2.75A.75.75 0 012 10z"></path>
        </svg>
    </button>

    <aside id="default-sidebar" class="fixed top-0 left-0 z-40 w-64 h-screen transition-transform -translate-x-full sm:translate-x-0" aria-label="Sidenav">

        <div class="overflow-y-auto py-5 px-3 h-full bg-white border-r border-gray-200">

            <div class="space-y-6 md:space-y-10 mt-10">

                <h1 class="md:block font-bold text-sm md:text-xl text-center">
                    <span class="text-teal-800 text-3xl">Scan N' Savor</span>
                </h1>

                <div id="profile" class="space-y-3">
                    <img src="../../images/green scansavor logo.png" alt="logo" class="w-14 h-14 md:w-16 rounded-full mx-auto" />
                    <div>
                        <h2 class="font-medium text-s md:text-sm text-center text-teal-500">
                            <?php echo strtoupper($_SESSION['name']); ?>
                        </h2>
                        <p class="pb-10 text-xs text-gray-500 text-center">Kitchen Staff</p>
                    </div>
                </div>
            </div>

            <!-- dashboard -->
            <ul class="space-y-2">
                <li>
                    <a href="../../src/viewKitchen/kitchenDashboard.php" class="flex items-center p-2 text-base font-normal text-gray-900 rounded-lg hover:bg-teal-800 group">
                        <svg class="w-6 h-6 text-gray-400 transition duration-75 group-hover:text-white" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                            <path d="M5 3a2 2 0 00-2 2v2a2 2 0 002 2h2a2 2 0 002-2V5a2 2 0 00-2-2H5zM5 11a2 2 0 00-2 2v2a2 2 0 002 2h2a2 2 0 002-2v-2a2 2 0 00-2-2H5zM11 5a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V5zM11 13a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z"></path>
                        </svg>
                        <span class="ml-3 group-hover:text-white">Dashboard</span>
                    </a>
                </li>

                <!-- Dishes -->
                <li>
                    <a href="../viewKitchen/dishStatus.php" class="flex items-center p-2 text-base font-normal text-gray-900 rounded-lg hover:bg-teal-800 group">
                        <svg aria-hidden="true" class="w-6 h-6 text-gray-400 transition duration-75 group-hover:text-white" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                            <path d="M2 10a8 8 0 018-8v8h8a8 8 0 11-16 0z"></path>
                            <path d="M12 2.252A8.014 8.014 0 0117.748 8H12V2.252z"></path>
                        </svg>
                        <span class="ml-3 group-hover:text-white">Dishes</span>
                    </a>
                </li>

                <li>
                    <a href="../viewKitchen/viewOrders.php" class="flex items-center p-2 text-base font-normal text-gray-900 rounded-lg hover:bg-teal-800 group">
                        <svg aria-hidden="true" class="w-6 h-6 text-gray-400 transition duration-75 group-hover:text-white" fill="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                            <path fill="currentColor" d="M12 22q-2.075 0-3.9-.788t-3.175-2.137q-1.35-1.35-2.137-3.175T2 12q0-2.075.788-3.9t2.137-3.175q1.35-1.35 3.175-2.137T12 2q2.075 0 3.9.788t3.175 2.137q1.35 1.35 2.138 3.175T22 12q0 2.075-.788 3.9t-2.137 3.175q-1.35 1.35-3.175 2.138T12 22m0-2q3.35 0 5.675-2.325T20 12q0-3.35-2.325-5.675T12 4Q8.65 4 6.325 6.325T4 12q0 3.35 2.325 5.675T12 20m-4-4v-3.075l5.525-5.5q.225-.225.5-.325t.55-.1q.3 0 .575.113t.5.337l.925.925q.2.225.313.5t.112.55q0 .275-.1.563t-.325.512l-5.5 5.5zm6.575-5.6l.925-.975l-.925-.925l-.95.95z" />
                        </svg>
                        <span class="ml-3 group-hover:text-white">Order Tabs</span>
                    </a>
                </li>

                <!-- orders -->
                <li>
                    <button type="button" class="flex items-center p-2 w-full text-base font-normal text-gray-900 rounded-lg transition duration-75 group hover:bg-teal-800" aria-controls="dropdown-sales" data-collapse-toggle="dropdown-sales">
                        <svg aria-hidden="true" class="flex-shrink-0 w-6 h-6 text-gray-400 transition duration-75 group-hover:text-white " fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                            <path fill-rule="evenodd" d="M10 2a4 4 0 00-4 4v1H5a1 1 0 00-.994.89l-1 9A1 1 0 004 18h12a1 1 0 00.994-1.11l-1-9A1 1 0 0015 7h-1V6a4 4 0 00-4-4zm2 5V6a2 2 0 10-4 0v1h4zm-6 3a1 1 0 112 0 1 1 0 01-2 0zm7-1a1 1 0 100 2 1 1 0 000-2z" clip-rule="evenodd"></path>
                        </svg>
                        <span class="flex-1 ml-3 text-left whitespace-nowrap  group-hover:text-white">Orders</span>
                        <svg aria-hidden="true" class="w-6 h-6" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                            <path fill-rule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clip-rule="evenodd"></path>
                        </svg>
                    </button>
                    <ul id="dropdown-sales" class="hidden py-2 space-y-2">
                        <li>
                            <a href="../viewKitchen/pending.php" class="flex items-center p-2 pl-11 w-full text-base font-normal text-gray-900 rounded-lg transition duration-75 group hover:bg-teal-800 hover:text-white">Pending Orders</a>
                        </li>
                        <li>
                            <a href="../viewKitchen/progress.php" class="flex items-center p-2 pl-11 w-full text-base font-normal text-gray-900 rounded-lg transition duration-75 group hover:bg-teal-800 hover:text-white">In Progress Orders</a>
                        </li>
                        <li>
                            <a href="../viewKitchen/complete.php" class="flex items-center p-2 pl-11 w-full text-base font-normal text-gray-900 rounded-lg transition duration-75 group hover:bg-teal-800 hover:text-white">Complete Order</a>
                        </li>
                    </ul>
                </li>
            </ul>

            <ul class="pt-5 mt-5 space-y-2 border-t border-gray-200">

                <!-- settings -->
                <li>
                    <a href="../viewKitchen/kitchensetting.php" class="flex items-center p-2 text-base font-normal text-gray-900 rounded-lg transition duration-75 hover:bg-teal-800 group">
                        <svg aria-hidden="true" class="flex-shrink-0 w-6 h-6 text-gray-400 transition duration-75 group-hover:text-white" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                            <path fill-rule="evenodd" d="M11.49 3.17c-.38-1.56-2.6-1.56-2.98 0a1.532 1.532 0 01-2.286.948c-1.372-.836-2.942.734-2.106 2.106.54.886.061 2.042-.947 2.287-1.561.379-1.561 2.6 0 2.978a1.532 1.532 0 01.947 2.287c-.836 1.372.734 2.942 2.106 2.106a1.532 1.532 0 012.287.947c.379 1.561 2.6 1.561 2.978 0a1.533 1.533 0 012.287-.947c1.372.836 2.942-.734 2.106-2.106a1.533 1.533 0 01.947-2.287c1.561-.379 1.561-2.6 0-2.978a1.532 1.532 0 01-.947-2.287c.836-1.372-.734-2.942-2.106-2.106a1.532 1.532 0 01-2.287-.947zM10 13a3 3 0 100-6 3 3 0 000 6z" clip-rule="evenodd"></path>
                        </svg>
                        <span class="ml-3 group-hover:text-white">Settings</span>
                    </a>
                </li>

                <!-- logout -->
                <li>
                    <a href="../../src/index.php" class="flex items-center p-2 text-base font-normal text-gray-900 rounded-lg transition duration-75 hover:bg-teal-800 group">
                        <svg aria-hidden="true" class="flex-shrink-0 w-6 h-6 text-gray-400 transition duration-75 group-hover:text-white" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                            <path fill-rule="evenodd" d="M5 9V7a5 5 0 0110 0v2a2 2 0 012 2v5a2 2 0 01-2 2H5a2 2 0 01-2-2v-5a2 2 0 012-2zm8-2v2H7V7a3 3 0 016 0z" clip-rule="evenodd"></path>
                        </svg>
                        <span class="ml-3 group-hover:text-white">Log Out</span>
                    </a>
                </li>
            </ul>
        </div>
    </aside>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/flowbite/2.2.0/flowbite.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const sidebar = document.getElementById('default-sidebar');
            const hamburgerButton = document.querySelector('[data-drawer-target="default-sidebar"]');

            hamburgerButton.addEventListener('click', function() {
                sidebar.classList.toggle('open');
            });

            // Close the sidebar when clicking outside of it
            document.addEventListener('click', function(event) {
                if (!sidebar.contains(event.target) && !hamburgerButton.contains(event.target)) {
                    sidebar.classList.remove('open');
                }
            });
        });
    </script>
</body>

</html>