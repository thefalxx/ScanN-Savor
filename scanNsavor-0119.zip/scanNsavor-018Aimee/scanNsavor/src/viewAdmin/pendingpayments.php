<?php
include '../connection/config.php';
include '../viewAdmin/sidenav.php';
include('../forms/processPaymentModal.php');

global $conn;


if (isset($_SESSION["userid"]) && isset($_SESSION["name"])) {
    $userid = $_SESSION["userid"];
    $username = $_SESSION["name"];
}

$data = array(); // create an empty array


$sql = "SELECT tblpayment.paymentID, tblpayment.customerName, tblpayment.paymentMethod, tblpayment.amount, tblpayment.status, tblpaymentdetails.orderID, tblpaymentdetails.paymentDateTime, tblpayment.processedBy, tblOrders.tableNo FROM tblpayment INNER JOIN tblpaymentdetails ON tblpayment.paymentID = tblpaymentdetails.paymentID INNER JOIN tblOrders ON tblpaymentdetails.orderID = tblOrders.orderID WHERE tblpayment.status = 'pending'";


$stmt = $conn->prepare($sql);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    // output data of each row
    while ($row = $result->fetch_assoc()) {
        $data[] = array(
            'paymentID' => $row['paymentID'],
            'customerName' => $row['customerName'],
            'paymentMethod' => $row['paymentMethod'],
            'totalAmount' => $row['amount'],
            'status' => $row['status'],
            'orderID' => $row['orderID'],
            'paymentDateTime' => $row['paymentDateTime'],
            'processedBy' => $row['processedBy'],
            'tableNo' => $row['tableNo'] // add this line
        );
    }
} else {
   // echo "0 results";
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="../../dist/output.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/flowbite/1.8.1/flowbite.min.css" rel="stylesheet" />
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <script src="https://cdn.tailwindcss.com"></script>
    <title>Pending Payments</title>
</head>

<body>
    <section>
        <form action="" method="post">
            <div class=" mx-auto max-w-5xl py-10 pl-10">
                <div class="pt-5 pl-5 pb-10 col-span-1 md:col-span-2 lg:col-span-4 flex justify-between">
                    <h2 class="text-lg md:text-xl text-gray-700 font-bold tracking-wide md:tracking-wider">
                        Pending Payments</h2>
                </div>
            </div>
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-2 gap-4 mx-auto max-w-5xl">
                <?php foreach ($data as $orderDetails) : ?>
                    <div class="mt-5 max-w-2xl mx-auto">
                        <div class="p-4 max-w-md bg-white rounded-lg border shadow-md sm:p-8 dark:bg-gray-800 dark:border-gray-700">

                            <div class="flex justify-between items-center mb-4">
                                <h3 class="text-xl font-bold leading-none text-gray-900 dark:text-white">Order # <span><?php echo $orderDetails['orderID'] ?></span></h3>
                                <h3 class="text-lg font-normal leading-none text-gray-900 dark:text-white">Table <span class="underline"><?php echo $orderDetails['tableNo'] ?></span></h3>
                                <input type="hidden" name="tableNum" value="<?php echo $orderDetails['tableNo']; ?>">
                            </div>

                            <div class="grid place-items-center">
                                <div class="lg:p-5 md:p-5 lg:mx-3">
                                    <div class="sm:p-5 pt-3">
                                        <label for="" class="mb-3 block text-base font-medium text-gray-900 my-5">
                                            Customer Name
                                        </label>
                                        <label for="" class="mb-3 block text-base text-center font-small text-gray-900 mx-16">
                                            <?php echo $orderDetails['customerName'] ?>
                                        </label>

                                        <label for="" class="mb-3 block text-base font-medium text-gray-900 my-5">
                                            Amount
                                        </label>
                                        <label for="" class="mb-3 block text-base text-center font-small text-gray-900 mx-1">
                                            <?php echo $orderDetails['totalAmount'] ?>
                                        </label>
                                        <input type="hidden" name="paymentID" value="<?php echo $orderDetails['paymentID'] ?>">
                                        <div class="mt-20">
                                            <button type="button" data-modal-toggle="processPaymentModal" class="hover:shadow-form w-72 rounded-md bg-gray-800 py-3 px-8 text-center text-base font-semibold text-white outline-none" id="processPayment" name="processPayment" onclick="showpendingPaymentMessageModal('<?php echo $orderDetails['orderID']; ?>', '<?php echo $orderDetails['tableNo']; ?>', '<?php echo $orderDetails['customerName']; ?>', '<?php echo $orderDetails['totalAmount']; ?>', '<?php echo $orderDetails['paymentID']; ?>', '<?php echo $userid; ?>', '<?php echo $username; ?>')">
                                                Process Payment
                                            </button>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach ?>
            </div>
        </form>
    </section>

    <?php if ($message != '') { ?>
        <div id="pendingPaymentMessageModal" class="bg-white border-2 border-black text-black w-80 h-32 px-4 py-14 rounded-lg relative justify-center items-center text-center" role="alert" style="position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%); z-index: 999;">
            <strong class="font-bold"> <?php echo $message; ?></strong>
            <span class="absolute top-0 bottom-0 right-0 px-4 py-3" onclick="closependingPaymentMessageModal()">
                <svg class="fill-current h-6 w-6 text-teal-800" role="button" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20">
                    <title>Close</title>
                    <path d="M14.348 14.849a1.2 1.2 0 0 1-1.697 0L10 11.819l-2.651 3.029a1.2 1.2 0 1 1-1.697-1.697l2.758-3.15-2.759-3.152a1.2 1.2 0 1 1 1.697-1.697L10 8.183l2.651-3.031a1.2 1.2 0 1 1 1.697 1.697l-2.758 3.152 2.758 3.15a1.2 1.2 0 0 1 0 1.698z" />
                </svg>
            </span>
        </div>
    <?php } ?>



    <script>
        function showpendingPaymentMessageModal(orderID, tableNo, customerName, totalAmount, paymentID, userID, userName) {
            // var modal = document.getElementById('processPaymentModal');

            var confirmID = document.getElementById('orderID');
            var confirmTableDisplay = document.getElementById('tableNoDisplay');
            var confirmTable = document.getElementById('tableNo');
            var confirmName = document.getElementById('customerName');
            var confirmTotalAmount = document.getElementById('totalAmount');
            var confirmPaymentID = document.getElementById('paymentID');

            var confirmUserID = document.getElementById('userID');
            var confirmUserName = document.getElementById('userName');

            confirmID.textContent = orderID;
            confirmTable.value = tableNo;
            confirmTableDisplay.textContent = tableNo;
            confirmName.value = customerName;
            confirmTotalAmount.value = totalAmount;
            confirmPaymentID.value = paymentID;
            confirmPaymentID.textContent = paymentID;

            confirmUserID.value = userID;
            confirmUserName.value = userName;

            console.log(orderID, tableNo, customerName, totalAmount, paymentID, processedBy, userID, userName);

            // modal.style.display = 'block';
        }
        // function showpendingPaymentMessageModal() {
        //     var modal = document.getElementById('ItemAddedMessageModal');
        //     modal.style.display = 'block';
        // }
    </script>

    <script>
        function closependingPaymentMessageModal() {
            var modal = document.getElementById('pendingPaymentMessageModal');
            modal.style.display = 'none';
        }
    </script>

</body>

</html>


<script src="https://cdnjs.cloudflare.com/ajax/libs/flowbite/1.8.0/flowbite.min.js"></script>