Update modal
<div id="updateUserModal" aria-hidden="true" class="hidden overflow-y-auto overflow-x-hidden fixed top-0 right-0 left-0 z-50 justify-center items-center w-full md:inset-0 h-[calc(100%-1rem)] max-h-full">
    <div class="relative p-4 w-full max-w-2xl max-h-full">
        <!-- Modal content -->
        <div class="relative p-4 bg-white rounded-lg shadow ">
            <!-- Modal header -->
            <div class="flex justify-between items-center pb-4 mb-4 rounded-t border-b sm:mb-5">
                <h3 class="text-lg font-semibold text-gray-900">Update User</h3>
                <button type="button" class="text-gray-400 bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm p-1.5 ml-auto inline-flex items-center" data-modal-toggle="updateUserModal">
                    <svg aria-hidden="true" class="w-5 h-5" fill="currentColor" viewbox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                        <path fill-rule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clip-rule="evenodd" />
                    </svg>
                    <span class="sr-only">Close modal</span>
                </button>
            </div>
            <!-- Modal body -->

            <form method="post">
                <div class="grid gap-4 mb-4 sm:grid-cols-2">
                    <input type="hidden" name="userID" value="<?php echo $userID; ?>">
                    <div>
                        <label for="editFirstName" class="block mb-2 text-sm font-medium text-gray-900">First Name</label>
                        <input type="text" name="editFirstName" id="editFirstName" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5" placeholder="" value="<?php if (!empty($_POST["editFirstName"])) {
                                                                                                                                                                                                                                                            echo $_POST["editFirstName"];
                                                                                                                                                                                                                                                        } ?>" required>
                    </div>
                    <div>
                        <label for="editLastName" class="block mb-2 text-sm font-medium text-gray-900">Last Name</label>
                        <input type="text" name="editLastName" id="editLastName" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5" placeholder="" value="<?php if (!empty($_POST["editLastName"])) {
                                                                                                                                                                                                                                                            echo $_POST["editLastName"];
                                                                                                                                                                                                                                                        } ?>" required>
                    </div>
                    <div>
                        <label for="editEmail" class="block mb-2 text-sm font-medium text-gray-900">Email</label>
                        <input type="email" name="editEmail" id="editEmail" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5" placeholder="" autocomplete="off" value="<?php if (!empty($_POST["editEmail"])) {
                                                                                                                                                                                                                                                                        echo $_POST["editEmail"];
                                                                                                                                                                                                                                                                    } ?>" required>
                    </div>
                    <div>
                        <label for="editPassword" class="block mb-2 text-sm font-medium text-gray-900">Password</label>
                        <input type="password" name="editPassword" id="editPassword" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5" placeholder="" autocomplete="off" value="<?php if (!empty($_POST["editPassword"])) {
                                                                                                                                                                                                                                                                                echo $_POST["editPassword"];
                                                                                                                                                                                                                                                                            } ?>" required>
                    </div>
                    <div><label for="editPosition" class="block mb-2 text-sm font-medium text-gray-900">Position</label>
                        <select id="editPosition" name="editPosition" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-500 focus:border-primary-500 block w-full p-2.5">
                            <option selected=""></option>
                            <option value="Chef">Chef</option>
                            <option value="Kitchen">Kitchen Staff</option>
                            <option value="Manager">Restaurant Manager</option>
                            <option value="Waiter">Waiter</option>
                        </select>
                    </div>
                    <div><label for="editType" class="block mb-2 text-sm font-medium text-gray-900">User Type</label>
                        <select id="editType" name="editType" placeholder="User Type" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-500 focus:border-primary-500 block w-full p-2.5">
                            <option selected=""></option>
                            <option value="Admin">Administrator</option>
                            <option value="General">General User</option>
                        </select>
                    </div>
                    <div><label class="block mb-2 text-sm font-medium text-gray-900">Status</label>
                        <div class="flex flex-wrap">
                            <div class="flex items-center mr-4">
                                <input type="radio" value="inactive" id="editStatus" name="editStatus" class="w-4 h-4 text-red-600 bg-gray-100 border-gray-300 focus:ring-red-500">
                                <label for="red-radio" class="ml-2 text-sm font-medium text-gray-900">Inactive</label>
                            </div>
                            <div class="flex items-center mr-4">
                                <input type="radio" value="pending" id="editStatus" name="editStatus" class="w-4 h-4 text-yellow-400 bg-gray-100 border-gray-300 focus:ring-yellow-500">
                                <label for="yellow-radio" class="ml-2 text-sm font-medium text-gray-900">Pending</label>
                            </div>
                            <div class="flex items-center mr-4">
                                <input type="radio" value="active" id="editStatus" name="editStatus" class="w-4 h-4 text-green-600 bg-gray-100 border-gray-300 focus:ring-green-500">
                                <label for="green-radio" class="ml-2 text-sm font-medium text-gray-900">Active</label>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="flex items-center space-x-4 ">
                    <!-- <button type="submit" class="bg-teal-700 hover:bg-primary-800 text-teal-800 focus:ring-2 focus:outline-none focus:ring-teal-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center">Update User</button> -->
                    <button type="submit" class="text-teal-800 inline-flex items-center hover:text-white border border-teal-800 hover:bg-teal-800 focus:ring-4 focus:outline-none focus:ring-teal-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center">Update User</button>
                </div>
            </form>
        </div>
    </div>
</div>