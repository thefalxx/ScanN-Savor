<?php
include('../viewAdmin/sidenav.php');
include('../forms/addWaitingList.php');
// include('../class/Customer.php');
// $customer = new Customer();

$searchTerm = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $searchTerm = isset($_POST['simple-search']) ? $_POST['simple-search'] : '';
}

$waitCustomer = $customer->getAllCustomer($searchTerm);


// $query = "SELECT * FROM tblemployeeacc";
// $result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="../../dist/output.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/flowbite/1.8.0/flowbite.min.css" rel="stylesheet" />
    <title>Scan N Savor | QR Code Generator</title>
</head>

<body>
<section class="pl-10 px-18 ml-10 py-6">
<div class="py-10 pl-20 mx-auto">
    <!-- <section class="py-3"> -->
        <div class="mx-auto pl-20 ml-20">
            <div class="mx-auto max-w-screen-xl max-h-screen-xl px-4 lg:px-12  xl:px-14">
                <div class="bg-white relative shadow-md sm:rounded-lg overflow-hidden">
                    <div class="flex flex-col md:flex-row items-stretch md:items-center md:space-x-3 space-y-3 md:space-y-0 mx-4 py-4 border-t">
                        <div class="w-full">
                        <form class="flex items-center" method="post">
                                <label for="simple-search" class="sr-only">Search</label>
                                <div class="relative w-full">
                                    <div class="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                                        <svg aria-hidden="true" class="w-5 h-5 text-gray-500" fill="currentColor" viewbox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                                            <path fill-rule="evenodd" clip-rule="evenodd" d="M8 4a4 4 0 100 8 4 4 0 000-8zM2 8a6 6 0 1110.89 3.476l4.817 4.817a1 1 0 01-1.414 1.414l-4.816-4.816A6 6 0 012 8z" />
                                        </svg>
                                    </div>
                                    <input type="text" id="simple-search" name="simple-search" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-teal-800 block w-full pl-10 p-2" placeholder="Search" value="<?php echo htmlspecialchars($searchTerm); ?>">
                                </div>
                            </form>
                        </div>
                        <div class="w-full md:w-auto flex flex-col md:flex-row space-y-2 md:space-y-0 items-stretch md:items-center justify-end md:space-x-3 flex-shrink-0">
                            <!-- <button type="button" id="createWaitList" data-modal-toggle="createWaitListModal" class="flex items-center justify-center text-teal-800 bg-primary-700 hover:bg-teal-800 hover:text-white focus:ring-4 focus:ring-primary-300 border border-gray-200 font-medium rounded-lg text-sm px-4 py-2">
                                <svg class="h-3.5 w-3.5 mr-1.5 -ml-1" fill="currentColor" viewbox="0 0 20 20" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
                                    <path clip-rule="evenodd" fill-rule="evenodd" d="M10 3a1 1 0 011 1v5h5a1 1 0 110 2h-5v5a1 1 0 11-2 0v-5H4a1 1 0 110-2h5V4a1 1 0 011-1z" />
                                </svg>
                                Add Waiting List
                            </button> -->
                            <div id="filterDropdown" class="z-10 hidden px-3 pt-1 bg-white rounded-lg shadow w-80 right-0">
                                <div class="flex items-center justify-between pt-2">
                                    <h6 class="text-sm font-medium text-black">Filters</h6>
                                    <div class="flex items-center space-x-3">
                                        <a href="#" class="flex items-center text-sm font-medium text-primary-600 hover:underline">Save view</a>
                                        <a href="#" class="flex items-center text-sm font-medium text-primary-600 hover:underline">Clear all</a>
                                    </div>
                                </div>
                                <div class="pt-3 pb-2">
                                    <label for="input-group-search" class="sr-only">Search</label>
                                    <div class="relative">
                                        <div class="absolute inset-y-0 left-0 flex items-center pl-4 pointer-events-none">
                                            <svg class="w-4 h-4 text-gray-500" aria-hidden="true" fill="currentColor" viewbox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                                                <path fill-rule="evenodd" d="M8 4a4 4 0 100 8 4 4 0 000-8zM2 8a6 6 0 1110.89 3.476l4.817 4.817a1 1 0 01-1.414 1.414l-4.816-4.816A6 6 0 012 8z" clip-rule="evenodd" />
                                            </svg>
                                        </div>
                                        <input type="text" id="input-group-search" class="block w-full p-2 pl-10 text-sm text-gray-900 border border-gray-300 rounded-lg bg-gray-50 focus:ring-primary-500 focus:border-primary-500" placeholder="Search keywords...">
                                    </div>
                                </div>
                                <div id="accordion-flush" data-accordion="collapse" data-active-classes="text-black" data-inactive-classes="text-gray-500">
                                    <!-- Category -->
                                    <h2 id="category-heading">
                                        <button type="button" class="flex items-center justify-between w-full py-2 px-1.5 text-sm font-medium text-left text-gray-500 border-b border-gray-200" data-accordion-target="#category-body" aria-expanded="true" aria-controls="category-body">
                                            <span>Category</span>
                                            <svg aria-hidden="true" data-accordion-icon="" class="w-5 h-5 rotate-180 shrink-0" fill="currentColor" viewbox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                                                <path fill-rule="evenodd" clip-rule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" />
                                            </svg>
                                        </button>
                                    </h2>
                                    <div id="category-body" class="hidden" aria-labelledby="category-heading">
                                        <div class="py-2 font-light border-b border-gray-200">
                                            <ul class="space-y-2">
                                                <li class="flex items-center">
                                                    <input id="apple" type="checkbox" value="" class="w-4 h-4 bg-gray-100 border-gray-300 rounded text-primary-600 focus:ring-primary-500">
                                                    <label for="apple" class="ml-2 text-sm font-medium text-gray-900">Table Number</label>
                                                </li>
                                                <a href="#" class="flex items-center text-sm font-medium text-primary-600 hover:underline">View all</a>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="overflow-x-auto ">
                        <table class="w-full text-sm text-left text-gray-500 ">
                            <thead class="text-xs text-gray-700 uppercase bg-gray-50">
                                <tr>
                                    <th scope="col" class="px-4 py-4 text-center">Name</th>
                                    <th scope="col" class="px-4 py-4 text-center">Contact Number</th>
                                    <th scope="col" class="px-4 py-4 text-center">No. of Seats</th>
                                    <th scope="col" class="px-4 py-4 text-center">Status</th>
                                    <!-- <th scope="col" class="px-4 py-4 text-center">Action</th> -->
                                    <!-- <th scope="col" class="px-4 py-3"></th> -->
                                    <!-- <th scope="col" class="px-8 py-4"></th> -->
                                    <!-- <th scope="col" class="px-8 py-4"></th>
                                    <th scope="col" class="px-8 py-4"></th> -->
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($waitCustomer as $customer) { ?>
                                    <tr class="border-b">
                                        <!-- <td class="px-6 py-3"></td> -->
                                        <td class="px-6 py-3 text-center"> <?php echo $customer['name'] ?> </td>
                                        <td class="px-6 py-3 text-center"> <?php echo $customer['contactNo']; ?> </td>
                                        <td class="px-6 py-3 text-center"> <?php echo $customer['noOfSeats']; ?> </td>
                                        <td class="px-6 py-3 text-center"> <?php echo $customer['status']; ?> </td>
                                        <!-- <td class="px-6 py-3"></td> -->
                                        <!-- <td class="px-6 py-3 font-medium text-gray-900 whitespace-nowrap text-center">
                                            <form method="post" class="flex justify-center">
                                                <input type="hidden" name="waiting_id" value="<?php echo $customer['waitingID']; ?>">
                                                <button type="submit" name="delete_customer" class="flex items-center text-red-700 hover:text-white border hover:bg-red-800 focus:ring-4 focus:outline-none focus:ring-red-300 font-medium rounded-lg text-sm px-3 py-2">
                                                    <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 mr-2 -ml-0.5" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                                                        <path fill-rule="evenodd" d="M9 2a1 1 0 00-.894.553L7.382 4H4a1 1 0 000 2v10a2 2 0 002 2h8a2 2 0 002-2V6a1 1 0 100-2h-3.382l-.724-1.447A1 1 0 0011 2H9zM7 8a1 1 0 012 0v6a1 1 0 11-2 0V8zm5-1a1 1 0 00-1 1v6a1 1 0 102 0V8a1 1 0 00-1-1z" clip-rule="evenodd" />
                                                    </svg>
                                                    Delete
                                                </button>
                                            </form>
                                        </td> -->
                                    </tr>
                                <?php } ?>
                            </tbody>
                        </table>
                    </div>
                    <?php
                    include '../view/pagination/waitPagination.php';
                    ?>
                </div>
            </div>
        </div>
    </section>
</div>
</body>

</html>

<script src="https://cdnjs.cloudflare.com/ajax/libs/flowbite/1.8.0/flowbite.min.js"></script>