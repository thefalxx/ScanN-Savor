<?php
include '../viewAdmin/sidenav.php';

$users = $user->getAllUsers();

$queryAvgRating = " SELECT AVG(ratingNo) AS avg_Rating FROM tblratings;";

$resultAvgRating = mysqli_query($conn, $queryAvgRating);

if ($resultAvgRating && $rowAvgRating = $resultAvgRating->fetch_assoc()) {
    $averageRating = number_format($rowAvgRating['avg_Rating'], 1); // Format with one decimal place
} else {
    $averageRating = '0.0'; // Default value if there are no reviews yet or other issues
}

$selectedFilter = isset($_GET['filter']) ? $_GET['filter'] : 'daily';

// Construct the SQL query based on the selected filter
// Construct the SQL date filter based on the selected filter for total sales
switch ($selectedFilter) {
    case 'weekly':
        $dateFilterSales = "AND pd.paymentDateTime >= DATE(NOW()) - INTERVAL 7 DAY";
        break;
    case 'monthly':
        $dateFilterSales = "AND pd.paymentDateTime >= DATE(NOW()) - INTERVAL 1 MONTH";
        break;
    case 'quarterly':
        $dateFilterSales = "AND pd.paymentDateTime >= DATE(NOW()) - INTERVAL 3 MONTH";
        break;
    case 'annually':
        $dateFilterSales = "AND pd.paymentDateTime >= DATE(NOW()) - INTERVAL 1 YEAR";
        break;
    default:
        // For 'daily' or any unknown filter, use today's date
        $dateFilterSales = "AND DATE(pd.paymentDateTime) = CURDATE()";
}

// Construct the SQL date filter for total orders
switch ($selectedFilter) {
    case 'weekly':
        $dateFilterOrders = "AND o.orderDateTime >= DATE(NOW()) - INTERVAL 7 DAY";
        break;
    case 'monthly':
        $dateFilterOrders = "AND o.orderDateTime >= DATE(NOW()) - INTERVAL 1 MONTH";
        break;
    case 'quarterly':
        $dateFilterOrders = "AND o.orderDateTime >= DATE(NOW()) - INTERVAL 3 MONTH";
        break;
    case 'annually':
        $dateFilterOrders = "AND o.orderDateTime >= DATE(NOW()) - INTERVAL 1 YEAR";
        break;
    default:
        // For 'daily' or any unknown filter, use today's date
        $dateFilterOrders = "AND DATE(o.orderDateTime) = CURDATE()";
}

// Construct the SQL query for total sales
$queryTotalSales = "SELECT SUM(p.amount) AS totalSales 
                   FROM tblpayment p
                   JOIN tblpaymentdetails pd ON p.paymentID = pd.paymentID
                   WHERE pd.paymentDateTime IS NOT NULL AND p.status = 'confirmed' $dateFilterSales;";

$result = mysqli_query($conn, $queryTotalSales);

if ($result) {
    $row = mysqli_fetch_assoc($result);
    $overAllTotalSales = $row['totalSales'];
} else {
    // Handle the error if the query fails
    $overAllTotalSales = 0;
}

// Construct the SQL query for total orders
$queryTotalOrders = "SELECT COUNT(orderID) AS totalOrders
                     FROM tblorders o
                     WHERE o.orderDateTime IS NOT NULL $dateFilterOrders;";

$resultOrders = mysqli_query($conn, $queryTotalOrders);

if ($resultOrders) {
    $rowOrders = mysqli_fetch_assoc($resultOrders);
    $totalOrders = $rowOrders['totalOrders'];
} else {
    // Handle the error if the query fails
    $totalOrders = 0;
}

$sqlbestseller = "SELECT f.itemID, f.itemName, SUM(od.itemQuantity) AS totalOrdered 
                  FROM tblorderdetails od 
                  INNER JOIN tblfooditems f ON od.itemID = f.itemID 
                  WHERE od.status = 'Done' 
                  GROUP BY f.itemID, f.itemName 
                  ORDER BY totalOrdered DESC 
                  LIMIT 1";

$resultbest = $conn->query($sqlbestseller);

// Check for query success
if ($resultbest) {
    if ($resultbest->num_rows > 0) {
        $bestSeller = $resultbest->fetch_assoc();
    } else {
        // No best sellers yet
        $bestSeller = null;
    }
} else {
    // Handle the case where the query fails
    echo 'Error: ' . mysqli_error($conn);
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="../../dist/output.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/apexcharts"></script>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/flowbite/1.8.0/flowbite.min.css" rel="stylesheet" />
    <title>Admin | Scan N' Savor</title>
</head>

<!-- <div class="mx-auto max-w-5xl py-10 pl-10"> -->

<body>
    <div class="pt-2 pb-14">
        <div class="lg:pl-40 lg:pt-10 pt-2">
            <div class="mx-auto max-w-5xl pt-10 pb-2 pl-2">
                <!-- Start Second Row -->
                <div class="col-span-1 md:col-span-2 lg:col-span-4 flex justify-between">
                    <h2 class="xl:text-lg md:text-sm text-gray-700 font-bold">
                        Admin Dashboard</h2>
                </div>
                <div class="flex justify-end m-5">
                    <form method="get">
                        <select id="filterSelect" name="filter" onchange="this.form.submit()" class="mb-3 md:mb-0 text-teal-600 focus:ring-1 focus:outline-none focus:ring-teal-200 focus:border-teal-200 font-normal text-xs py-1.5 text-center items-center inline-flex bg-white focus:ring- rounded-lg border border-gray-200 shadow px-1">
                            <option value="daily" <?php echo ($selectedFilter === 'daily') ? 'selected' : ''; ?>>Daily</option>
                            <option value="weekly" <?php echo ($selectedFilter === 'weekly') ? 'selected' : ''; ?>>Weekly</option>
                            <option value="monthly" <?php echo ($selectedFilter === 'monthly') ? 'selected' : ''; ?>>Monthly</option>
                            <option value="quarterly" <?php echo ($selectedFilter === 'quarterly') ? 'selected' : ''; ?>>Quarterly</option>
                            <option value="annually" <?php echo ($selectedFilter === 'annually') ? 'selected' : ''; ?>>Annually</option>
                        </select>
                    </form>
                </div>

                <script>
                    function selectFilter(filter) {
                        // You can perform actions based on the selected filter here
                        console.log('Selected filter:', filter);

                        // Close the dropdown (optional)
                        document.getElementById('dropdownLeft').classList.add('hidden');
                    }

                    // Toggle dropdown visibility
                    document.getElementById('dropdownLeftButton').addEventListener('click', function() {
                        var dropdown = document.getElementById('dropdownLeft');
                        dropdown.classList.toggle('hidden');
                    });
                </script>
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 px-4 xl:p-0 gap-4 xl:gap-6">
                    <div class="bg-white p-6 rounded-xl border border-gray-200 shadow hidden">
                        <div class="flex justify-between items-start">
                            <div class="flex flex-col">
                                <p class="text-xs text-gray-600 tracking-wide">Users</p>
                                <h3 class="mt-1 text-lg text-green-400 font-bold"><?php echo $user->totalUsers('active'); ?></h3>
                            </div>
                            <div class="bg-green-400 p-2 md:p-1 xl:p-2 rounded-md">
                            </div>
                        </div>
                    </div>
                    <div class="bg-white p-6 rounded-xl border border-gray-200 shadow">
                        <div class="flex justify-between items-start">
                            <div class="flex flex-col">
                                <p class="text-xs text-gray-600 tracking-wide">Best Seller </p>
                                <?php if ($bestSeller) : ?>
                                    <h3 class="mt-1 text-lg text-red-300 font-bold"><?php echo $bestSeller['itemName']; ?></h3>
                                <?php else : ?>
                                    <p class="mt-1 text-lg text-red-300 font-bold">No best sellers yet</p>
                                <?php endif; ?>
                            </div>
                            <div class="bg-red-300 p-2 md:p-1 xl:p-2 rounded-md">
                              
                            </div>
                        </div>
                    </div>
                    <div class="bg-white p-6 rounded-xl border border-gray-200 shadow">
                        <div class="flex justify-between items-start">
                            <div class="flex flex-col">
                                <p class="text-xs text-gray-600 tracking-wide">Orders</p>
                                <h3 class="mt-1 text-lg text-green-400 font-bold"><?php echo $totalOrders; ?></h3>
                            </div>
                            <div class="bg-green-400 p-2 md:p-1 xl:p-2 rounded-md">
                            </div>
                        </div>
                    </div>
                    <div class="bg-white p-6 rounded-xl border border-gray-200 shadow">
                        <div class="flex justify-between items-start">
                            <div class="flex flex-col">
                                <p class="text-xs text-gray-600 tracking-wide">Overall Ratings</p>
                                <h3 class="mt-1 text-lg text-yellow-300 font-bold"><?php echo $averageRating; ?></h3>
                            </div>
                            <div class="bg-yellow-300 p-2 md:p-1 xl:p-2 rounded-md">
                            </div>
                        </div>
                    </div>
                    <div class="bg-white p-6 rounded-xl border border-gray-200 shadow">
                        <div class="flex justify-between items-start">
                            <div class="flex flex-col">
                                <p class="text-xs text-gray-600 tracking-wide">Sales</p>
                                <h3 class="mt-1 text-lg text-indigo-500 font-bold">₱ <?php echo number_format($overAllTotalSales, 2); ?></h3>
                            </div>
                            <div class="bg-indigo-500 p-2 md:p-1 xl:p-2 rounded-md">
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Start Third Row -->
                <div class="grid grid-cols-1 md:grid-cols-5 items-start px-4 xl:p-0 gap-y-4 md:gap-6">
                    <div class="col-start-1 col-end-5">
                        <h2 class="pt-10 text-xs md:text-sm text-gray-800 font-bold tracking-wide">Active Employees</h2>
                    </div>

                    <div class="col-span-3 bg-white p-6 rounded-xl border border-gray-200 flex flex-col space-y-6 shadow">

                        <div class="overflow-x-auto">
                            <table class="w-full text-sm text-left text-gray-500 ">
                                <thead class="text-xs text-gray-700 uppercase bg-gray-50">
                                    <tr>
                                        <!-- <th scope="col" class="px-4 py-4">ID</th> -->
                                        <th scope="col" class="px-4 py-4">Name</th>
                                        <th scope="col" class="px-4 py-3">Username</th>
                                        <th scope="col" class="px-4 py-3">User Type</th>
                                        <th scope="col" class="px-4 py-3">Position</th>
                                    </tr>
                                </thead>
                                <tbody class="">
                                    <?php foreach ($users as $user) { ?>
                                        <tr class="border-b">
                                            <!-- <td class="px-4 py-3"> <?php echo $user['empAccID']; ?> </td> -->
                                            <td class="px-4 py-3"> <?php echo $user['firstName'] . ' ' . $user['lastName']; ?> </td>
                                            <td class="px-4 py-3"> <?php echo $user['username']; ?> </td>
                                            <td class="px-4 py-3"> <?php echo $user['type']; ?> </td>

                                            <td class="px-4 py-3">
                                                <?php
                                                $roleid = $user['roleID'];
                                                $position = isset($roleMappings[$roleid]) ? $roleMappings[$roleid] : "undefined";
                                                echo $position;
                                                ?>
                                            </td>

                                        </tr>
                                        <?php
                                        include '../forms/userformdelete.php';
                                        ?>
                                    <?php } ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <!-- ratings -->
                <div>
                    <div class="grid grid-cols-1 md:grid-cols-5 items-start px-4 xl:p-0 gap-y-4 md:gap-6">
                        <div class="col-start-1 col-end-5">
                            <h2 class="pt-10 text-xs md:text-sm text-gray-800 font-bold tracking-wide">Ratings and Feedback</h2>
                        </div>

                        <div class="col-span-3 bg-white p-6 rounded-xl border border-gray-200 flex flex-col space-y-6 shadow">
                            <div class="overflow-x-auto">
                                <table class="w-full text-sm text-left text-gray-500 ">
                                    <thead class="text-xs text-gray-700 uppercase bg-gray-50">
                                        <tr>
                                            <!-- <th scope="col" class="px-4 py-4">ID</th> -->
                                            <th scope="col" class="px-4 py-4">Ratings</th>
                                            <th scope="col" class="px-4 py-3">Rating Feedback</th>
                                        </tr>
                                    </thead>
                                    <tbody class="">
                                        <?php
                                        // Check if $ratings is set and not null
                                        if (isset($ratings) && is_array($ratings)) {
                                            foreach ($ratings as $rate) { ?>
                                                <tr class="border-b">
                                                    <!-- <td class="px-4 py-3"> <?php echo $rate['ratingID']; ?> </td> -->
                                                    <td class="px-4 py-3"> <?php echo displayStars($rate['ratingNo']); ?> </td>
                                                    <td class="px-4 py-3"> <?php echo $rate['ratingFeedback']; ?> </td>
                                                </tr>
                                        <?php

                                            }
                                        } else {
                                            // Handle the case when $ratings is not set or is null
                                            echo '<tr><td colspan="3">No ratings available</td></tr>';
                                        }
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

</body>

</html>