<?php
include('../forms/menucategoryformcreate.php');
include('../viewAdmin/sidenav.php');
include('../forms/mealpackageformcreate.php');
include('../forms/mealpackageformupdate.php');
include '../forms/DeletePackagesModal.php';

$searchTerm = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $searchTerm = isset($_POST['simple-search']) ? $_POST['simple-search'] : '';
}

$packageData = $menu->getmenuPackage($searchTerm);
// $packagedata = $menu->getmenuPackage();
$catMappings = $menu->fetchCategoryMappings();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="../../dist/output.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/flowbite/1.8.0/flowbite.min.css" rel="stylesheet" />
    <script src="https://cdn.tailwindcss.com"></script>
    <title>Scan N Savor | Menu Management</title>
</head>

<body>
    <div class="max-w-5xl mx-auto">
        <!-- Start block -->
        <section class="py-3">
            <div class="flex flex-col gap-10 py-3 mb-4 md:grid-cols-2">
                <div class="max-w-screen-xl px-4 mx-auto max-h-screen-xl lg:px-12 xl:px-20">
                    <div class="relative mr-10 overflow-hidden bg-white shadow-md sm:rounded-lg">
                        <div class="flex flex-col items-stretch justify-between py-4 mx-4 space-y-3 border-t md:flex-row md:items-center md:space-x-3 md:space-y-0">
                            <div class="w-full">
                                <form class="flex items-center" method="post">
                                    <label for="simple-search" class="sr-only">Search</label>
                                    <div class="relative w-full">
                                        <div class="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                                            <svg aria-hidden="true" class="w-5 h-5 text-gray-500" fill="currentColor" viewbox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                                                <path fill-rule="evenodd" clip-rule="evenodd" d="M8 4a4 4 0 100 8 4 4 0 000-8zM2 8a6 6 0 1110.89 3.476l4.817 4.817a1 1 0 01-1.414 1.414l-4.816-4.816A6 6 0 012 8z" />
                                            </svg>
                                        </div>
                                        <input type="text" id="simple-search" name="simple-search" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-teal-800 block w-full pl-10 p-2" placeholder="Search" value="<?php echo htmlspecialchars($searchTerm); ?>">
                                    </div>
                                </form>
                            </div>
                            <div class="flex flex-col items-stretch justify-end flex-shrink-0 w-full space-y-2 md:w-auto md:flex-row md:space-y-0 md:items-center md:space-x-3">

                                <button type="button" id="createPackageButton" data-modal-toggle="createPackageModal" class="flex items-center justify-center px-4 py-2 text-sm font-medium text-teal-800 border border-gray-200 rounded-lg bg-primary-700 hover:bg-teal-800 hover:text-white focus:ring-4 focus:ring-green-200">
                                    <svg class="h-3.5 w-3.5 mr-1.5 -ml-1" fill="currentColor" viewbox="0 0 20 20" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
                                        <path clip-rule="evenodd" fill-rule="evenodd" d="M10 3a1 1 0 011 1v5h5a1 1 0 110 2h-5v5a1 1 0 11-2 0v-5H4a1 1 0 110-2h5V4a1 1 0 011-1z" />
                                    </svg>
                                    Add Menu Package
                                </button>

                                <button data-modal-target="deletePackage-modal" data-modal-toggle="deletePackage-modal" class="w-full md:w-auto flex items-center justify-center py-2 px-4 text-sm font-medium text-red-400 bg-white rounded-lg border border-red-500 hover:bg-red-700 hover:text-white focus:z-10 focus:ring-2 focus:ring-red-400" type="submit" name="deletebtn">
                                    Delete All Packages
                                </button>
                            </div>
                        </div>

                        <div class="overflow-x-auto ">
                            <table class="w-full text-sm text-left text-gray-500">
                                <thead class="text-xs text-gray-700 uppercase bg-gray-50">
                                    <tr>
                                        <!-- <th scope="col" class="p-4 bg-gray-50"></th> -->
                                        <th scope="col" class="px-8 py-4">Image</th>
                                        <th scope="col" class="px-8 py-4">Package Name</th>
                                        <th scope="col" class="px-8 py-4"></th>
                                        <th scope="col" class="px-8 py-4">Price</th>
                                        <th scope="col" class="py-4 px-7">Status</th>
                                        <th scope="col" class="px-8 py-4"></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($packageData as $item) { ?>
                                        <tr class="border-b hover:bg-gray-100">
                                            <td class="px-8 py-3">
                                                <div class="flex items-center h-20 w-44"> <img src="<?php echo $item['packageImage']; ?>" alt="" class="h-20 w-44">
                                                </div>
                                            </td>
                                            <!-- name -->
                                            <td class="px-8 py-3 font-medium text-gray-500 whitespace-nowrap">
                                                <?php echo $item['packageName']; ?>
                                            </td>
                                            <!-- category -->
                                            <td class="px-8 py-3"></td>
                                            <!-- price -->
                                            <td class="px-8 py-3"><?php echo $item['packagePrice']; ?></td>

                                            <td class="px-8 py-3"><?php echo $item['availability']; ?></td>

                                            <td class="py-3 font-medium text-gray-900 pl-14 pr-7 whitespace-nowrap ">
                                                <div class="flex items-center justify-end space-x-4">
                                                    <button type="button" data-modal-toggle="updatePackageModal" onclick="openUpdateModal('<?php echo $item['packageID']; ?>','<?php echo $item['packageName']; ?>','<?php echo $item['packagePrice']; ?>','<?php echo $item['availability']; ?>','<?php echo $item['packageDescription']; ?>', '<?php echo $item['packageImage']; ?>', '<?php echo $item['itemIDs']; ?>')" class="flex items-center px-3 py-2 text-sm font-medium text-center text-teal-800 bg-white border border-gray-200 rounded-lg focus:outline-none hover:bg-teal-800 hover:text-white focus:z-10 focus:ring-4 focus:ring-green-200">
                                                        <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 mr-2 -ml-0.5" viewbox="0 0 20 20" fill="currentColor" aria-hidden="true">
                                                            <path d="M17.414 2.586a2 2 0 00-2.828 0L7 10.172V13h2.828l7.586-7.586a2 2 0 000-2.828z" />
                                                            <path fill-rule="evenodd" d="M2 6a2 2 0 012-2h4a1 1 0 010 2H4v10h10v-4a1 1 0 112 0v4a2 2 0 01-2 2H4a2 2 0 01-2-2V6z" clip-rule="evenodd" />
                                                        </svg>
                                                        Edit
                                                    </button>

                                                    <button type="button" data-drawer-target="" data-drawer-show="" aria-controls="" class="flex items-center px-3 py-2 mr-10 text-sm font-medium text-center text-teal-800 bg-white border border-gray-200 rounded-lg focus:outline-none hover:bg-teal-800 hover:text-white focus:z-10 focus:ring-4 focus:ring-gray-200">
                                                        <svg xmlns="http://www.w3.org/2000/svg" viewbox="0 0 24 24" fill="currentColor" class="w-4 h-4 mr-2 -ml-0.5">
                                                            <path d="M12 15a3 3 0 100-6 3 3 0 000 6z" />
                                                            <path fill-rule="evenodd" clip-rule="evenodd" d="M1.323 11.447C2.811 6.976 7.028 3.75 12.001 3.75c4.97 0 9.185 3.223 10.675 7.69.12.362.12.752 0 1.113-1.487 4.471-5.705 7.697-10.677 7.697-4.97 0-9.186-3.223-10.675-7.69a1.762 1.762 0 010-1.113zM17.25 12a5.25 5.25 0 11-10.5 0 5.25 5.25 0 0110.5 0z" />
                                                        </svg>
                                                        Preview
                                                    </button>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php } ?>
                                </tbody>
                            </table>
                        </div>
                        <?php
                        include '../view/pagination/adminPackagePagination.php';
                        ?>
                    </div>
                </div>
            </div>
        </section>
    </div>
</body>

<script>
    function openUpdateModal(packageID, packageName, packagePrice, availability, description, packageImage, itemIDs) {
        var modal = document.getElementById("updatePackageModal");
        var overlay = document.getElementById("overlay");

        var updatePackageID = document.getElementById("packageID");
        var updatePackageName = document.getElementById("updatePackageName");
        var updatePrice = document.getElementById("updateprice");
        var updateAvailability = document.getElementById("updatePackageAvailability");
        var updatePackDescription = document.getElementById("updatePackageDescription");
        var updatePackImage = document.getElementById("upPackageImg");
        var updateItemID = document.getElementById("upPackageItems");
        //var updateItemID = document.getElementsByName("upPackageItems");

        // Update form fields with the selected menu package data
        updatePackageID.value = packageID;
        updatePackageName.value = packageName;
        updatePrice.value = packagePrice;
        updateAvailability.value = availability;
        updatePackDescription.value = description;
        updatePackImage.src = packageImage;

        // Check if itemIDs is a string and convert it to an array
        var itemIDsArray = Array.isArray(itemIDs) ? itemIDs : itemIDs.split(',');

        // Convert the array to a comma-separated string
        var itemIDString = itemIDsArray.join(',');

        console.log("itemIDs:", itemIDsArray);
        console.log("itemIDString:", itemIDString);

        // Set the value of the updateItemID input
        updateItemID.value = itemIDString;

        var checkboxes = document.querySelectorAll('input[name="selectedItems[]"]');
        checkboxes.forEach(function(checkbox) {
            console.log("Checkbox Value:", checkbox.value);
            console.log("Is Checkbox Value in itemIDsArray:", itemIDsArray.includes(checkbox.value));

            checkbox.checked = itemIDsArray.includes(checkbox.value);
            console.log("Checkbox Checked State:", checkbox.checked);
        });

        console.log("updateItemID.value:", updateItemID.value);

        // Display the updatePackageModal
        // modal.style.display = "block";
        // overlay.style.display = "block";
    }



    function closeModalUpdate() {
        var modal = document.getElementById('updatePackageModal');
        modal.style.display = 'none';
    }
</script>

</html>

<script src="https://cdnjs.cloudflare.com/ajax/libs/flowbite/1.8.0/flowbite.min.js"></script>