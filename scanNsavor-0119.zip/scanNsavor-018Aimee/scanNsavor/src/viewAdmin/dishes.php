<?php
include '../viewAdmin/sidenav.php';
include '../class/Menu.php';

$menu = new Menu();

$message = ''; // Initialize $message variable

function updateFoodItemDetails($itemID, $serving, $dishStatus)
{
    global $conn; // Use the existing global connection

    // Determine availability based on dishStatus
    $availability = ($dishStatus == 'In Stock') ? 'Available' : 'Unavailable';

    // Update the values in the database
    $query = "UPDATE tblfooditems 
              SET serving = ?, dishStatus = ?, availability = ? 
              WHERE itemID = ?";

    $statement = $conn->prepare($query);

    $statement->bind_param('issi', $serving, $dishStatus, $availability, $itemID);

    try {
        $statement->execute();
        return true;  // Successful update
    } catch (Exception $e) {
        // Handle the error
        return "Error updating item details: " . $e->getMessage();
    }
}

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get user inputs from the form
    $itemID = isset($_POST['itemID']) ? intval($_POST['itemID']) : 0;
    $serving = isset($_POST['serving']) ? intval($_POST['serving']) : 0;
    $dishStatus = isset($_POST['dishStatus']) ? $_POST['dishStatus'] : '';

    // Call the function to update the food item details
    $result = updateFoodItemDetails($itemID, $serving, $dishStatus);

    if ($result === true) {
        $message = "Item details updated successfully."; // Added the missing assignment operator
    } else {
        $message = "Error: " . $result; // Added the missing assignment operator
    }
}

$searchTerm = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $searchTerm = isset($_POST['simple-search']) ? $_POST['simple-search'] : '';
}

$fooditems = $menu->getAllItems($searchTerm);
$catMappings = $menu->fetchCategoryMappings();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="../../dist/output.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/flowbite/1.8.1/flowbite.min.css" rel="stylesheet" />
    <title>Scan N Savor | Menu Management</title>
</head>

<body>
    <!-- Start block -->
    <section class="pl-20 px-18 ml-20 py-6">
        <div class="mx-auto pl-20 lg:ml-20 sm:px-18">
            <div class="mx-auto max-w-screen-xl max-h-screen-xl px-4 lg:px-12  xl:px-14">
                <div class="bg-white relative shadow-md sm:rounded-lg overflow-hidden">
                    <div class="flex flex-col md:flex-row items-stretch md:items-center md:space-x-3 space-y-3 md:space-y-0 justify-between mx-4 py-4 border-t">
                        <div class="w-full">
                            <form class="flex items-center" method="post">
                                <label for="simple-search" class="sr-only">Search</label>
                                <div class="relative w-full">
                                    <div class="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                                        <svg aria-hidden="true" class="w-5 h-5 text-gray-500" fill="currentColor" viewbox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                                            <path fill-rule="evenodd" clip-rule="evenodd" d="M8 4a4 4 0 100 8 4 4 0 000-8zM2 8a6 6 0 1110.89 3.476l4.817 4.817a1 1 0 01-1.414 1.414l-4.816-4.816A6 6 0 012 8z" />
                                        </svg>
                                    </div>
                                    <input type="text" id="simple-search" name="simple-search" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-teal-800 block w-full pl-10 p-2" placeholder="Search" value="<?php echo htmlspecialchars($searchTerm); ?>">
                                </div>
                            </form>
                        </div>
                        <div class="w-full md:w-auto flex flex-col md:flex-row space-y-2 md:space-y-0 items-stretch md:items-center justify-end md:space-x-3 flex-shrink-0">
                            <button data-modal-target="deleteItems-modal" data-modal-toggle="deleteItems-modal" class="w-full md:w-auto flex items-center justify-center py-2 px-4 text-sm font-medium text-red-400 bg-white rounded-lg border border-red-500 hover:bg-red-700 hover:text-white focus:z-10 focus:ring-2 focus:ring-red-400" type="submit" name="deletebtn">
                                Delete All Servings
                            </button>
                        </div>
                    </div>

                    <div class="overflow-x-auto ">
                        <table class="w-full text-sm text-left text-gray-500 ">
                            <thead class="text-xs text-gray-700 uppercase bg-gray-50">
                                <tr>
                                    <!-- <th scope="col" class="p-4 bg-gray-50"></th> -->
                                    <th scope="col" class="px-8 py-4 text-center">Dish Name</th>
                                    <th scope="col" class="px-8 py-4 text-center">Category</th>
                                    <th scope="col" class="px-8 py-4 text-center">Servings</th>
                                    <th scope="col" class="px-8 py-4 text-center">Status</th>
                                    <th scope="col" class="px-8 py-4 text-center"></th>

                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($fooditems as $item) { ?>
                                    <tr class="border-b hover:bg-gray-100 text-center">
                                        <!-- name -->
                                        <td class="px-5 py-3 font-medium text-gray-500 whitespace-nowrap">
                                            <?php echo $item['itemName']; ?>
                                        </td>

                                        <!-- category -->
                                        <td class="px-5 py-3 text-center"><?php
                                                                            $categoryid = $item['categoryID'];
                                                                            $category = isset($catMappings[$categoryid]) ? $catMappings[$categoryid] : "undefined";
                                                                            echo $category;
                                                                            ?></td>

                                        <td class="px-5 py-3 text-center">
                                            <div class="flex items-center">
                                                <span class="flex-grow text-center"><?php echo $item['serving']; ?></span>
                                            </div>
                                        </td>

                                        <td class="px-5 py-3 font-medium text-gray-500 whitespace-nowrap">
                                            <?php echo $item['dishStatus']; ?>
                                        </td>

                                        <td class="px-5 py-3 text-center">
                                        </td>
                                    </tr>
                                <?php } ?>
                            </tbody>
                        </table>
                    </div>
                    <?php
                    include '../view/pagination/dishPagination.php';
                    ?>
                </div>
            </div>
        </div>
    </section>
    <!-- JavaScript to set the itemID before submitting the form -->
    <script>
        function prepareForm(itemID) {
            document.getElementById('itemID').value = itemID;
        }
    </script>

    <div id="updateServingModal" tabindex="-1" aria-hidden="true" class="hidden overflow-y-auto overflow-x-hidden fixed top-0 right-0 left-0 z-50 justify-center items-center w-full md:inset-0 h-[calc(100%-1rem)] md:h-full">
        <div id="overlay"></div>
        <div class="relative p-4 w-full max-w-2xl h-full md:h-auto">
            <!-- Modal content -->
            <div class="relative p-4 bg-white rounded-lg shadow">
                <!-- Modal header -->
                <form method="post">
                    <label name="menuID" id="menuID" hidden> ID </label>
                    <input type="text" name="itemID" id="itemID" hidden>
                    <div class="flex justify-between items-center pb-4 mb-4 rounded-t border-b sm:mb-5">
                        <h3 class="text-lg font-semibold text-gray-900">Servings</h3>
                        <button type="button" class="text-gray-400 bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm p-1.5 ml-auto inline-flex items-center" data-modal-toggle="updateServingModal">
                            <svg aria-hidden="true" class="w-5 h-5" fill="currentColor" viewbox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                                <path fill-rule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clip-rule="evenodd" />
                            </svg>
                            <span class="sr-only">Close modal</span>
                        </button>
                    </div>
                    <!-- Modal body -->
                    <form method="post" action="dishStatus.php" id="updateServingForm">
                        <div class="grid gap-4 mb-4 sm:grid-cols-2">
                            <div>
                                <label for="ItemName" class="block mb-2 text-sm font-medium text-gray-900">Dish Name</label>
                                <input type="text" name="ItemName" id="ItemName" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-green-200 focus:border-green-200 block w-full p-2.5" placeholder="Type dish name" required="" disabled>
                            </div>

                            <div>
                                <label for="categoryID" class="block mb-2 text-sm font-medium text-gray-900">Category</label>
                                <input id="categoryID" name="categoryID" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-green-200 focus:border-green-200 block w-full p-2.5" placeholder="Type dish name" required="" disabled>
                                </select>
                            </div>
                            <div>
                                <label for="serving" class="block mb-2 text-sm font-medium text-gray-900">No. Of Serving</label>
                                <input type="number" name="serving" id="serving" value="1" min="0" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-green-200 focus:border-green-200 block w-full p-2.5" placeholder="Enter Serving" required="">
                            </div>
                            <!-- <div>
                                <label for="dishStatus" class="block mb-2 text-sm font-medium text-gray-900">Status</label>
                                <input type="text" name="dishStatus" id="dishStatus" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-green-200 focus:border-green-200 block w-full p-2.5" placeholder="Enter Status" required="">
                            </div> -->
                            <div>
                                <label for="dishStatus" class="block mb-2 text-sm font-medium text-gray-900">Status</label>
                                <select id="dishStatus" name="dishStatus" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-green-200 focus:border-green-200 block w-full p-2.5" placeholder="" required="">
                                    <option selected=""></option>
                                    <option value="In Stock">In Stock</option>
                                    <option value="Out of Stock">Out of Stock</option>
                                </select>
                            </div>
                        </div>
                        <div class="items-center space-y-4 sm:flex sm:space-y-4 sm:space-x-4">
                            <button type="submit" name="updateItemDetails" value="updateItemDetails" id="updateItemDetails" class="w-full sm:w-auto justify-center text-teal-800 inline-flex border border-gray-300 bg-teal-700 hover:bg-teal-800 hover:text-white focus:ring-4 focus:outline-none focus:ring-green-200 font-medium rounded-lg text-sm px-5 py-2.5 text-center">
                                Submit
                            </button>
                        </div>
                    </form>
            </div>
        </div>
    </div>
    <?php if ($message != '') { ?>
        <div id="MessageModal" class="bg-white border-2 border-black text-black w-80 h-32 px-4 py-14 rounded-lg relative justify-center items-center text-center" role="alert" style="position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%); z-index: 999;">
            <strong class="font-bold"> <?php echo $message; ?></strong>
            <span class="absolute top-0 bottom-0 right-0 px-4 py-3" onclick="return closeconfirmPaymentModal()">
                <svg class="fill-current h-6 w-6 text-teal-800" role="button" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20">
                    <title>Close</title>
                    <path d="M14.348 14.849a1.2 1.2 0 0 1-1.697 0L10 11.819l-2.651 3.029a1.2 1.2 0 1 1-1.697-1.697l2.758-3.15-2.759-3.152a1.2 1.2 0 1 1 1.697-1.697L10 8.183l2.651-3.031a1.2 1.2 0 1 1 1.697 1.697l-2.758 3.152 2.758 3.15a1.2 1.2 0 0 1 0 1.698z" />
                </svg>
            </span>
        </div>
        <script>
            function showMessageModal() {
                var modal = document.getElementById('MessageModal');
                modal.style.display = 'block';
                setTimeout(function() {
                    modal.style.display = 'none';
                }, 2000); // Adjust the duration (in milliseconds) as needed
            }
            // Call the function to show the modal
            showMessageModal();
        </script>
    <?php } ?>

    <!-- <script>
        function showMessageModal() {
            var modal = document.getElementById('MessageModal');
            modal.style.display = 'block';
        }
    </script> -->

    <script>
        function closeMessageModal() {
            var modal = document.getElementById('MessageModal');
            modal.style.display = 'none';
        }
    </script>

    <!-- ... Your HTML code ... -->

    <script>
        function prepareForm(itemID, itemName, categoryID, categoryName, serving, dishStatus) {
            document.getElementById('itemID').value = itemID;
            document.getElementById('ItemName').value = itemName;
            document.getElementById('categoryID').value = categoryName;
            document.getElementById('serving').value = serving;
            document.getElementById('dishStatus').value = dishStatus; // Set the dishStatus value

            // Use AJAX to submit the form
            var formData = new FormData(document.getElementById('updateServingForm'));

            fetch('dishStatus.php', {
                    method: 'POST',
                    body: formData
                })
                .then(response => response.json())
                .then(data => {
                    // Handle the response as needed
                    console.log(data);
                })
                .catch(error => {
                    console.error('Error:', error);
                });

            // Log the values for verification
            console.log(itemID, itemName, categoryID, categoryName, serving, dishStatus);
        }
    </script>

</body>

</html>

<script src="https://cdnjs.cloudflare.com/ajax/libs/flowbite/1.8.0/flowbite.min.js"></script>