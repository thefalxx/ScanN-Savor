<?php
// include ('./layouts/usersidebar.php');
include('../class/User.php');
include '../forms/deleteUserPromptModal.php';

$user = new User();
$message =  $user->addUser();
$roleData = $user->getRoles();
$roleMappings = $user->fetchRoleMappings();
// $users =  $user->getAllUsers();

$query = "SELECT * FROM tblemployees";
$result = mysqli_query($conn, $query);

// Handle form submission
$searchTerm = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $searchTerm = isset($_POST['simple-search']) ? $_POST['simple-search'] : '';
}

// Fetch users with the updated search term
$users = $user->getAllUsers($searchTerm);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="../../dist/output.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/flowbite/2.2.1/flowbite.min.css" rel="stylesheet" />
    <script src="https://cdn.tailwindcss.com"></script>
    <title>Scan N' Savor | User Management</title>
</head>

<body>
    <?php
    include('../viewAdmin/usersidenav.php');
    ?>

    <section class="pl-40 pt-10">
        <div class="px-20">
            <div class="mx-auto pl-20 ml-20 pt-5">
                <div class="mx-auto max-w-screen-xl max-h-screen-xl px-4 lg:px-12">
                    <div class="bg-wite relative shadow-md sm:rounded-lg overflow-hidden">
                        <div class="flex flex-col md:flex-row items-center justify-between space-y-3 md:space-y-0 md:space-x-4 p-4">
                            <div class="w-full md:w-1/2">
                                <form class="flex items-center" method="post">
                                    <label for="simple-search" class="sr-only">Search</label>
                                    <div class="relative w-full">
                                        <div class="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                                            <svg aria-hidden="true" class="w-5 h-5 text-gray-500" fill="currentColor" viewbox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                                                <path fill-rule="evenodd" d="M8 4a4 4 0 100 8 4 4 0 000-8zM2 8a6 6 0 1110.89 3.476l4.817 4.817a1 1 0 01-1.414 1.414l-4.816-4.816A6 6 0 012 8z" clip-rule="evenodd" />
                                            </svg>
                                        </div>
                                        <input type="text" id="simple-search" name="simple-search" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-teal-800 block w-full pl-10 p-2" placeholder="Search" value="<?php echo htmlspecialchars($searchTerm); ?>">
                                    </div>
                                </form>
                            </div>
                            <div class="w-full md:w-auto flex flex-col md:flex-row space-y-2 md:space-y-0 items-stretch md:items-center justify-end md:space-x-3 flex-shrink-0">
                                <button type="button" id="createUserModalButton" data-modal-target="createUserModal" data-modal-toggle="createUserModal" class="flex items-center justify-center text-teal-800 bg-white hover:bg-teal-800 hover:text-white focus:ring-2 focus:ring-teal-500 font-medium rounded-lg border border-teal-800 text-sm px-4 py-2">
                                    Add Users
                                </button>

                                <button data-modal-target="deleteUser-modal" data-modal-toggle="deleteUser-modal" class="w-full md:w-auto flex items-center justify-center py-2 px-4 text-sm font-medium text-red-400 bg-white rounded-lg border border-red-500 hover:bg-red-700 hover:text-white focus:z-10 focus:ring-2 focus:ring-red-400" type="submit" name="deletebtn">
                                    Remove All Users
                                </button>
                            </div>
                        </div>

                        <div class="overflow-x-auto">
                            <table class="w-full text-sm text-left text-gray-500 ">
                                <thead class="text-xs text-gray-700 uppercase bg-gray-50">
                                    <tr>
                                        <!-- <th scope="col" class="px-4 py-4">ID</th> -->
                                        <th scope="col" class="px-4 py-4">Name</th>
                                        <th scope="col" class="px-4 py-3">Username</th>
                                        <th scope="col" class="px-4 py-3">User Type</th>
                                        <th scope="col" class="px-4 py-3">Position</th>
                                        <th scope="col" class="px-4 py-3">Status</th>
                                        <th scope="col" class="px-4 py-3">
                                            Actions
                                        </th>
                                    </tr>
                                </thead>
                                <tbody class="">
                                    <?php foreach ($users as $user) { ?>
                                        <tr class="border-b">
                                            <!-- <td class="px-4 py-3"> <?php echo $user['empAccID']; ?> </td> -->
                                            <td class="px-4 py-3"> <?php echo $user['firstName'] . ' ' . $user['lastName']; ?> </td>
                                            <td class="px-4 py-3"> <?php echo $user['username']; ?> </td>
                                            <td class="px-4 py-3"> <?php echo $user['type']; ?> </td>

                                            <!-- to change, needs it to be retrieved from tblRoles then set position -->

                                            <!-- $roleid = $user['roleID'];
                                        if ($roleid == 1) {
                                            $position = "Administrator";
                                        } elseif ($roleid == 2) {
                                            $position = "Chef";
                                        } elseif ($roleid == 3) {
                                            $position = "Kitchen Staff";
                                        } elseif ($roleid == 4) {
                                            $position = "Restaurant Manager";
                                        } elseif ($roleid == 5) {
                                            $position = "Waiter";
                                        } else {
                                            $position = "undefined";
                                        } -->

                                            <td class="px-4 py-3">
                                                <?php
                                                $roleid = $user['roleID'];
                                                $position = isset($roleMappings[$roleid]) ? $roleMappings[$roleid] : "undefined";
                                                echo $position;
                                                ?>
                                            </td>

                                            <?php
                                            $status = $user['status'];
                                            $statusColorClass = '';

                                            if ($status === 'active') {
                                                $statusColorClass = 'bg-green-500';
                                            } elseif ($status === 'pending') {
                                                $statusColorClass = 'bg-yellow-500';
                                            } elseif ($status === 'inactive') {
                                                $statusColorClass = 'bg-red-500';
                                            }
                                            ?>
                                            <td class="px-4 py-3">
                                                <div class="flex items-center">
                                                    <div class="h-2.5 w-2.5 rounded-full <?php echo $statusColorClass; ?> mr-2 mt-1"></div>
                                                    <?php echo $status; ?>
                                                </div>
                                            </td>
                                            <td class="px-4 py-3 font-medium text-gray-900 whitespace-nowrap">
                                                <div class="flex items-center">
                                                    <!-- edit button -->
                                                    <button id="getEditButton" data-modal-target="updateUserModal" data-modal-toggle="updateUserModal" class="py-2 px-3 flex items-center text-sm font-medium text-center text-teal-800 focus:outline-none bg-white rounded-lg border border-gray-200 hover:bg-teal-800 hover:text-white focus:z-10 focus:ring-4 focus:ring-green-200 getEditButton" onclick="openSesame('<?php echo $user['empAccID']; ?>', '<?php echo $user['firstName']; ?>', '<?php echo $user['lastName']; ?>', '<?php echo $user['username']; ?>' , '<?php echo $user['password']; ?>', '<?php echo $user['type']; ?>', '<?php echo $user['roleID']; ?>', '<?php echo $user['status']; ?>')">
                                                        <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 mr-2 -ml-0.5" viewbox="0 0 20 20" fill="currentColor" aria-hidden="true">
                                                            <path d="M17.414 2.586a2 2 0 00-2.828 0L7 10.172V13h2.828l7.586-7.586a2 2 0 000-2.828z" />
                                                            <path fill-rule="evenodd" d="M2 6a2 2 0 012-2h4a1 1 0 010 2H4v10h10v-4a1 1 0 112 0v4a2 2 0 01-2 2H4a2 2 0 01-2-2V6z" clip-rule="evenodd" />
                                                        </svg>
                                                        Edit
                                                    </button>
                                                </div>
                                            </td>
                                        </tr>
                                        <?php
                                        include '../forms/userformdelete.php';
                                        ?>
                                    <?php } ?>
                                </tbody>
                            </table>
                        </div>
                        <?php
                        include '../view/pagination/userPagination.php';
                        ?>
                    </div>
                </div>
            </div>
    </section>

    <!-- Create modal -->
    <?php
    include '../forms/userformcreate.php';
    ?>

    <!-- Update modal -->
    <?php
    include '../forms/userformupdate.php';
    ?>

    </div>

</body>

</html>
<script src="https://cdnjs.cloudflare.com/ajax/libs/flowbite/2.2.1/flowbite.min.js"></script>

<script>
    function openSesame(empAccID, firstName, lastName, Username, password,
        type, roleID, status) {

        var updateId = document.getElementById("empAccID");
        var updatefName = document.getElementById("firstName");
        var updatelName = document.getElementById("lastName");
        var updateUsername = document.getElementById("updateusername");
        var updatePassword = document.getElementById("updatepassword");
        var updateType = document.getElementById("updatetype");
        var updateRoleID = document.getElementById("updateroleID");
        var updateStatus = document.getElementById("status");

        // Set the value of the input fields
        updateId.value = empAccID;
        updatefName.value = firstName;
        updatelName.value = lastName;
        updateUsername.value = Username;
        updatePassword.value = password;
        updateType.value = type;
        updateRoleID.value = roleID;
        updateStatus.value = status;


        console.log(empAccID, firstName, lastName, Username, password,
            type, roleID, status);

    }


    //     var updateID = document.getElementById("userID");

    //     editButton.forEach((edit) => {
    //         edit.addEventListener("click", () => {

    //             const tableRow = edit.closest("tr");
    //             const id = tableRow.cells[0].innerText;
    //             const email = tableRow.cells[2].innerText;

    //             updateID.value = id;
    //             editForm.email.value = editEmail;

    //         });
    //     });
    //
</script>