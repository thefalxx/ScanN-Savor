<?php
include(__DIR__ . '/../connection/config.php');


class Menu
{
    private $menuTable = 'tblfooditems';

    public function addCategories()
    {

        global $conn;
        $message = '';


        if (!empty($_POST['addCategory']) && $_POST['addCategoryName'] != '') {
            // Check if the category already exists
            $catName = $_POST['addCategoryName'];
            $sqlQuery = "SELECT * FROM  tblcategories WHERE categoryName = '" . $catName . "'";
            $result = mysqli_query($conn, $sqlQuery);
            $isCategoryExist = mysqli_num_rows($result);

            if ($isCategoryExist) {
                $message = "Category already exists.";
            } else {
                //Insert the category into table for categories
                $insertQuery = "INSERT INTO tblcategories (categoryName) 
                VALUES ('" . $_POST['addCategoryName'] . "')";
                $categorySaved = mysqli_query($conn, $insertQuery);
                $message = "Category saved.";
            }
            return $message;
        }
    }

    public function getCategories()
    {
        global $conn;
        $categoryData = array();

        $catQuery = "SELECT categoryID, categoryName FROM tblcategories";
        $catResult = mysqli_query($conn, $catQuery);

        if ($catResult) {
            while ($row = mysqli_fetch_assoc($catResult)) {
                $categoryData[] = $row;
            }
        }

        return $categoryData;
    }

    public function fetchCategoryMappings()
    {
        global $conn;
        $catMappings = array();

        $catQuery = "SELECT categoryID, categoryName FROM tblcategories";
        $catResult = mysqli_query($conn, $catQuery);

        if ($catResult) {
            while ($row = mysqli_fetch_assoc($catResult)) {
                $catMappings[$row['categoryID']] = $row['categoryName'];
            }
        }

        return $catMappings;
    }


    public function addMenuItems()
    {
        global $conn;
        $uploadOk = 1;
        $message = '';
        $filename = ""; // Define $filename here

        if (!empty($_POST["addMenuItem"]) && $_POST["addItemName"] != '') {
            // Check if the user already exists
            $sqlQuery = "SELECT * FROM tblfooditems WHERE itemName='" . $_POST["addItemName"] . "'";
            $result = mysqli_query($conn, $sqlQuery);
            $itemExist = mysqli_num_rows($result);

            $target_dir = "../../images/foodItemsImages/";

            // Use a unique name for the uploaded file to avoid overwriting existing files
            $filename = uniqid() . "_" . basename($_FILES["fileToUpload"]["name"]);
            $target_file = $target_dir . $filename;
            $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

            $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
            if ($check !== false) {
                echo '<script> alert("File is an image - " . $check["mime"] . ".") </script>';
                //echo "File is an image - " . $check["mime"] . ".";
            } else {
                echo '<script> alert("File is not an image.") </script>';
               // echo "File is not an image.";
                $uploadOk = 0;
            }

            // Check if file already exists
            if (file_exists($target_file)) {
                echo "Sorry, file already exists.";
                $uploadOk = 0;
            }

            // Check file size
            if ($_FILES["fileToUpload"]["size"] > 500000) {
                echo '<script> alert("Sorry, your file is too large.") </script>';
               // echo "Sorry, your file is too large.";
                $uploadOk = 0;
            }

            if (
                $imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
                && $imageFileType != "gif"
            ) {
                echo '<script> alert("Sorry, only JPG, JPEG, PNG & GIF files are allowed.") </script>';
               // echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
                $uploadOk = 0;
            }

            // Check if $uploadOk is set to 0 by an error
            if ($uploadOk == 0) {
                echo '<script> alert("Sorry, your file was not uploaded.") </script>';
               // echo "Sorry, your file was not uploaded.";
                // if everything is ok, try to upload file
            } else {
                if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
                    //echo "The file " . htmlspecialchars(basename($_FILES["fileToUpload"]["name"])) . " has been uploaded.";

                    // set parameters and execute
                    $filename = basename($_FILES["fileToUpload"]["name"]); // Change $filename here
                    $filepath = $target_file;
                }
            }
            if ($itemExist) {
                $message = "Item already exists.";
            } elseif ($uploadOk == 1) { // Only insert into the database if the image was uploaded successfully
                // Hash the password using password_hash

                $selectedCategoryID = $_POST['addItemCategory'];
                $dishStatus = "In Stock";
                $status = "Available";

                // Insert the user into table for user/employee
                $insertItemQuery = "INSERT INTO tblfooditems (menuID, itemName, categoryID, description, pax, availability, price, dishStatus, itemImage) 
                 VALUES (1, '" . $_POST["addItemName"] . "', '" . $selectedCategoryID . "', '" . $_POST["addItemDescription"] . "', '" . $_POST["addPax"] . "', '" . $status . "', '" . $_POST["addItemPrice"] . "', '" . $dishStatus . "', '" . $filepath . "')";
                $userSaved = mysqli_query($conn, $insertItemQuery);
                $message = "Food item saved";
                // header('Location: menu.php');

            }
            return $message;
        }
    }


    public function getAllItemsDetails()
    {
        global $conn;
        $sqlQuery = "SELECT * FROM tblfooditems";
        $result = mysqli_query($conn, $sqlQuery);

        $items = array();
        if ($result) {
            while ($row = $result->fetch_assoc()) {
                $items[] = $row;
            }
        }
        return $items;
    }

    // public function getAllItems()
    // {
    //     global $conn;
    //     $sqlQuery = "SELECT * FROM tblfooditems";
    //     $result = mysqli_query($conn, $sqlQuery);

    //     $items = array();
    //     if ($result) {
    //         while ($row = $result->fetch_assoc()) {
    //             $items[] = $row;
    //         }
    //     }
    //     return $items;
    // }

    public function getAllItems($searchTerm = "")
    {
        global $conn;
        $row_per_page = 10;
        $page = 1;

        if (isset($_GET['page-nr']) && is_numeric($_GET['page-nr'])) {
            $page = intval($_GET['page-nr']);
        }

        // Reset page to 1 when there is a search term
        if (!empty($searchTerm)) {
            $page = 1;
        }

        $start = ($page - 1) * $row_per_page;

        // If there is a search term, modify the query to include it
        $searchCondition = "";
        if (!empty($searchTerm)) {
            $searchCondition = "WHERE itemName LIKE '%$searchTerm%' OR description LIKE '%$searchTerm%'";
        }

        // Fetch the total number of rows
        $sqlCount = "SELECT COUNT(*) as count FROM " . $this->menuTable . " $searchCondition";
        $countResult = mysqli_query($conn, $sqlCount);
        $rowCount = $countResult->fetch_assoc()['count'];

        // Calculate total number of pages
        $totalPages = ceil($rowCount / $row_per_page);

        // Pass the total number of pages to the HTML using a hidden input
        echo "<input type='hidden' id='totalPages' value='$totalPages'>";

        // Include the search condition in the main query
        $sqlQuery = "SELECT * FROM " . $this->menuTable . " $searchCondition LIMIT $start, $row_per_page";
        $result = mysqli_query($conn, $sqlQuery);

        $items = array();
        if ($result) {
            while ($row = $result->fetch_assoc()) {
                $items[] = $row;
            }
        }

        return $items;
    }


    public function getmenuPackageDetails()
    {
        global $conn;
        $packageData = array();

        $catQuery = "SELECT
        mp.packageID,
        mp.packageName,
        mp.packagePrice,
        mp.availability,
        mp.packageImage,
        mp.packageDescription,
        GROUP_CONCAT(mpi.itemID) AS itemIDs,
        GROUP_CONCAT(mpi.itemName) AS itemNames
    FROM
        tblmenupackage mp
    JOIN
        tblmenupackageitems mpi ON mp.packageID = mpi.packageID
    WHERE
        mp.packageID = mpi.packageID -- Replace with the desired packageID
    GROUP BY
        mp.packageID;
        ";
        $catResult = mysqli_query($conn, $catQuery);

        if ($catResult) {
            while ($row = mysqli_fetch_assoc($catResult)) {
                $packageData[] = $row;
            }
        }

        return $packageData;
    }

    public function getmenuPackage($searchTerm = "")
    {
        global $conn;
        $packageData = array();

        $row_per_page = 10;
        $page = 1;

        if (isset($_GET['page-nr']) && is_numeric($_GET['page-nr'])) {
            $page = intval($_GET['page-nr']);
        }

        // Reset page to 1 when there is a search term
        if (!empty($searchTerm)) {
            $page = 1;
        }

        $start = ($page - 1) * $row_per_page;

        // If there is a search term, modify the query to include it
        $searchCondition = "";
        if (!empty($searchTerm)) {
            $searchCondition = "WHERE mp.packageName LIKE '%$searchTerm%'";
        }

        // Fetch the total number of rows matching the search condition
        $sqlCount = "SELECT COUNT(DISTINCT mp.packageID) as count 
                 FROM tblmenupackage mp
                 JOIN tblmenupackageitems mpi ON mp.packageID = mpi.packageID
                 $searchCondition";
        $countResult = mysqli_query($conn, $sqlCount);
        $rowCount = $countResult->fetch_assoc()['count'];

        // Calculate the total number of pages needed for pagination
        $totalPages = ceil($rowCount / $row_per_page);

        // Pass the total number of pages to the HTML using a hidden input
        echo "<input type='hidden' id='totalPages' value='$totalPages'>";

        // Include the search condition in the main query and fetch the packages for the current page
        $catQuery = "SELECT
                    mp.packageID,
                    mp.packageName,
                    mp.packagePrice,
                    mp.availability,
                    mp.packageImage,
                    mp.packageDescription,
                    GROUP_CONCAT(mpi.itemID) AS itemIDs,
                    GROUP_CONCAT(mpi.itemName) AS itemNames
                 FROM tblmenupackage mp
                 JOIN tblmenupackageitems mpi ON mp.packageID = mpi.packageID
                 $searchCondition
                 GROUP BY mp.packageID
                 LIMIT $start, $row_per_page";
        $catResult = mysqli_query($conn, $catQuery);

        if ($catResult) {
            while ($row = mysqli_fetch_assoc($catResult)) {
                $packageData[] = $row;
            }
        }

        return $packageData;
    }

    // public function getPackages()
    // {
    //     global $conn;
    //     $packageData = array();

    //     $catQuery = "SELECT
    //     tblmenupackage.packageID,
    //     GROUP_CONCAT(DISTINCT tblmenupackage.packageName) AS packageName,
    //     GROUP_CONCAT(DISTINCT tblmenupackage.packagePrice) AS packagePrice,
    //     tblmenupackage.availability, tblmenupackage.packageImage, tblmenupackage.packageDescription,
    //     GROUP_CONCAT(DISTINCT tblmenupackageitems.itemID) AS itemID,
    //     GROUP_CONCAT(DISTINCT tblmenupackageitems.itemName) AS itemNames
    // FROM tblmenupackage 
    // INNER JOIN tblmenupackageitems ON tblmenupackage.packageID = tblmenupackageitems.packageID
    // GROUP BY tblmenupackage.packageID, tblmenupackage.availability";

    //     $catResult = mysqli_query($conn, $catQuery);

    //     if ($catResult) {
    //         while ($row = mysqli_fetch_assoc($catResult)) {
    //             $packageData[] = $row;
    //         }
    //     }

    //     return $packageData;
    // }


    public function updateDishStatus($itemID, $newStatus)
    {
        global $conn;

        $escapedItemID = mysqli_real_escape_string($conn, $itemID);
        $escapedNewStatus = mysqli_real_escape_string($conn, $newStatus);

        $sql = "UPDATE tblfooditems SET dishStatus = '$escapedNewStatus' WHERE itemID = '$escapedItemID'";

        if (mysqli_query($conn, $sql)) {
            return "Dish status updated successfully.";
        } else {
            return "Error updating dish status: " . mysqli_error($conn);
        }
    }

    public function getDishStatus($itemID)
    {
        global $conn;

        $escapedItemID = mysqli_real_escape_string($conn, $itemID);

        $sql = "SELECT dishStatus FROM tblfooditems WHERE itemID = '$escapedItemID'";
        $result = mysqli_query($conn, $sql);

        if ($result && mysqli_num_rows($result) > 0) {
            $row = mysqli_fetch_assoc($result);
            return $row['dishStatus'];
        } else {
            return "Error fetching dish status: " . mysqli_error($conn);
        }
    }

    public function updateServing($itemID, $newServing)
    {
        global $conn;

        try {
            $query = "UPDATE tblfooditems SET serving = ? WHERE itemID = ?";
            $stmt = $conn->prepare($query);
            $stmt->bind_param('ii', $newServing, $itemID); // 'ii' indicates integer types
            $stmt->execute();

            // Check if any rows were affected
            $rowsAffected = $stmt->affected_rows;

            if ($rowsAffected > 0) {
                // Serving updated successfully
                return true;
            } else {
                // No rows were affected, serving may not have changed
                return false;
            }
        } catch (Exception $e) {
            // Log the full exception information
            error_log("Exception in updateServing: " . $e);

            // Return the error message for debugging
            return "Exception: " . $e->getMessage();
        }
    }
}
