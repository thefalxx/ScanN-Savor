<?php

session_start();
include('../connection/config.php');
class User 
{
    // protected $hostName;
    // protected $userName;
    // protected $password;
    // protected $dbName;

    // private $dbConnect = false;
    private $userTable = 'tblemployees';

    //database connection
    // public function __construct()
    // {
    //     $database = new dbConfig();

    //     if (!$this->dbConnect) {
    //         $this->hostName = $database->host;
    //         $this->userName = $database->user;
    //         $this->password = $database->pwd;
    //         $this->dbName = $database->dbname;
    //         $conn = new mysqli($this->hostName, $this->userName, $this->password, $this->dbName);
    //         if ($conn->connect_error) {
    //             die("Error failed to connect to MySQL: " . $conn->connect_error);
    //         } else {
    //             $this->dbConnect = $conn;
    //         }
    //     }
    // }

    public function register()
    {
        global $conn;
        $message = '';
        if (!empty($_POST["register"]) && $_POST["username"] != '') {
          $sqlQuery = "SELECT * FROM " . $this->userTable . " 
          WHERE username='" . $_POST["username"] . "'";
            $result = mysqli_query($conn,$sqlQuery);
            $isUserExist = mysqli_num_rows($result);
            if ($isUserExist) {
                $message = "User already exist with this username.";
            } else {
                $hashedPassword = password_hash($_POST["password"], PASSWORD_BCRYPT);
                $insertQuery = "INSERT INTO " . $this->userTable . "(firstName, lastName, username, password) 
				VALUES ('" . $_POST["firstName"] . "', '" . $_POST["lastName"] . "', '" . $_POST["username"] . "', '" . $hashedPassword . "')";
                $userSaved = mysqli_query($conn, $insertQuery);
                $message = "User saved";
            }
        }
        return $message;
    }

    // public function getAuthtoken($email)
    // {
    //     $code = md5(889966);
    //     $authtoken = $code . "" . md5($email);
    //     return $authtoken;
    // }

    // public function login(){		
    //     $errorMessage = '';
    //     if(!empty($_POST["login"]) && $_POST["loginusername"]!=''&& $_POST["loginPass"]!='') {	
    //         $loginEmail = $_POST['loginEmail'];
    //         $password = $_POST['loginPass'];
    //         if(isset($_COOKIE["loginPass"]) && $_COOKIE["loginPass"] == $password) {
    //             $password = $_COOKIE["loginPass"];
    //         } else {
    //             $password = md5($password);
    //         }	
    //         $sqlQuery = "SELECT * FROM ".$this->userTable." 
    //             WHERE email='".$loginEmail."' AND password='".$password."' AND status = 'active'";
    //         $resultSet = mysqli_query($this->dbConnect, $sqlQuery);
    //         $isValidLogin = mysqli_num_rows($resultSet);	
    //         if($isValidLogin){
    //             if(!empty($_POST["remember"]) && $_POST["remember"] != '') {
    //                 setcookie ("loginEmail", $loginEmail, time()+ (10 * 365 * 24 * 60 * 60));  
    //                 setcookie ("loginPass",	$password,	time()+ (10 * 365 * 24 * 60 * 60));
    //             } else {
    //                 $_COOKIE['loginEmail' ]='';
    //                 $_COOKIE['loginPass'] = '';
    //             }
    //             $userDetails = mysqli_fetch_assoc($resultSet);
    //             $_SESSION["userid"] = $userDetails['id'];
    //             $_SESSION["name"] = $userDetails['firstName']." ".$userDetails['lastName'];
    //             header("location: ../src/userDashboard.php"); 		
    //         } else {		
    //             $errorMessage = "Invalid login!";		 
    //         }
    //     } 
    //     // else if(empty($_POST["loginEmail"]) ){
    //     //     $errorMessage = "Enter username";	
    //     // } elseif(empty($_POST["loginPass"])) {
    //     //     $errorMessage = "Enter password";	
    //     // }
    //     return $errorMessage; 		
    // }

    public function login()
    {
        global $conn;
        $errorMessage = '';
        if (!empty($_POST["login"]) && $_POST["loginUsername"] != '' && $_POST["loginPass"] != '') {
            $loginUsername = $_POST['loginUsername'];
            $password = $_POST['loginPass'];

            $sqlQuery = "SELECT * FROM " . $this->userTable . " 
                WHERE username='" . $loginUsername . "' AND status = 'active'";
            $resultSet = mysqli_query($conn, $sqlQuery);

            if (mysqli_num_rows($resultSet) == 1) {
                $userDet = mysqli_fetch_assoc($resultSet);

                // Use password_verify to check the entered password
                if (password_verify($password, $userDet['password'])) {
                    $_SESSION["userid"] = $userDet['empAccID'];
                    $_SESSION["name"] = $userDet['firstName'] . " " . $userDet['lastName'];

                    if ($userDet['roleID'] == 1) {
                        header("location: ../viewAdmin/adminDashboard.php");
                    } elseif ($userDet['roleID'] == 2) {
                        header("location: ../viewKitchen/kitchenDashboard.php");
                    } elseif ($userDet['roleID'] == 3) {
                        header("location: ../viewKitchen/kitchenDashboard.php");
                    } elseif ($userDet['roleID'] == 4) {
                        header("location: ../viewManager/managerDashboard.php");
                    } elseif ($userDet['roleID'] == 5) {
                        header("location: ../viewWaiter/ordersDashboard.php");
                    } elseif ($userDet['roleID'] == 6) {
                        header("location: ../viewCashier/cashierDashboard.php");
                    } 
                    else {
                        $errorMessage = "Invalid user type!";
                    }
                } else {
                    $errorMessage = "Invalid password!";
                }
            } else {
                $errorMessage = "Invalid username or user not active!";
            }
        }

        return $errorMessage;
    }

    public function reload()
    {
        header("Cache-Control: no-cache, no-store, must-revalidate"); // HTTP 1.1.
        header("Pragma: no-cache"); // HTTP 1.0.
        header("Expires: 0");
    }

    public function loginStatus()
    {
        if (empty($_SESSION["userid"])) {
            header("Location: login.php");
        }
    }
    public function userDetails()
    {
        global $conn;
        $sqlQuery = "SELECT * FROM " . $this->userTable . " 
			WHERE empAccID ='" . $_SESSION["userid"] . "'";
        $result = mysqli_query($conn, $sqlQuery);
        $userDetails = mysqli_fetch_assoc($result);
        return $userDetails;
    }

    // Modify the function to include a search term
    public function getAllUsers($searchTerm = "") {
        global $conn;
        $row_per_page = 10;
        $page = 1;
    
        if (isset($_GET['page-nr']) && is_numeric($_GET['page-nr'])) {
            $page = intval($_GET['page-nr']);
        }
    
        // Reset page to 1 when there is a search term
        if (!empty($searchTerm)) {
            $page = 1;
        }
    
        $start = ($page - 1) * $row_per_page;
    
        // If there is a search term, modify the query to include it
        $searchCondition = "";
        if (!empty($searchTerm)) {
            $searchCondition = "WHERE firstName LIKE '%$searchTerm%' OR lastName LIKE '%$searchTerm%'";
        }
    
        // Fetch the total number of rows
        $sqlCount = "SELECT COUNT(*) as count FROM " . $this->userTable . " $searchCondition";
        $countResult = mysqli_query($conn, $sqlCount);
        $rowCount = $countResult->fetch_assoc()['count'];
    
        // Calculate total number of pages
        $totalPages = ceil($rowCount / $row_per_page);
    
        // Pass the total number of pages to the HTML using a hidden input
        echo "<input type='hidden' id='totalPages' value='$totalPages'>";
    
        // Include the search condition in the main query
        $sqlQuery = "SELECT * FROM " . $this->userTable . " $searchCondition LIMIT $start, $row_per_page";
        $result = mysqli_query($conn, $sqlQuery);
    
        $users = array();
        if ($result) {
            while ($row = $result->fetch_assoc()) {
                $users[] = $row;
            }
        }
    
        return $users;
    }

    // public function addUser()
    // {
    //     $message = '';
    //     if (!empty($_POST["addUser"]) && $_POST["addEmail"] != '') {
    //         $sqlQuery = "SELECT * FROM " . $this->userTable . " 
    // 			WHERE email='" . $_POST["addEmail"] . "'";
    //         $result = mysqli_query($this->dbConnect, $sqlQuery);
    //         $isUserExist = mysqli_num_rows($result);
    //         if ($isUserExist) {
    //             $message = "User already exist with this email address.";
    //         } else {
    //             $authtoken = $this->getAuthtoken($_POST["addEmail"]);
    //             $insertQuery = "INSERT INTO " . $this->userTable . "(firstName, lastName, email, password, type, position, status, authtoken) 
    // 			VALUES ('" . $_POST["addFirstName"] . "', '" . $_POST["addLastName"] . "', '" . $_POST["addEmail"] . "', '" . md5($_POST["addPassword"]) . "', '" . $_POST["addType"] . "', '" . $_POST["addPosition"] . "', '" . "active" . "', '" . $authtoken . "''" . $authtoken . "')";
    //             $userSaved = mysqli_query($this->dbConnect, $insertQuery);
    //             $message = "User saved";
    //         }
    //     }
    //     return $message;
    // }


    public function getRoles() {
        global $conn;
        $roleData = array(); 

        $rolesQuery = "SELECT roleID, position FROM tblRoles";
        $rolesResult = mysqli_query($conn, $rolesQuery);
    
        if ($rolesResult) {
            while ($row = mysqli_fetch_assoc($rolesResult)) {
                $roleData[] = $row; 
            }
        }
    
        return $roleData;
    }

    public function fetchRoleMappings()
    {
        global $conn;
        $roleMappings = array();

        $rolesQuery = "SELECT roleID, position FROM tblRoles";
        $rolesResult = mysqli_query($conn, $rolesQuery);

        if ($rolesResult) {
            while ($row = mysqli_fetch_assoc($rolesResult)) {
                $roleMappings[$row['roleID']] = $row['position'];
            }
        }

        return $roleMappings;
    }

    public function addUser()
    {
        global $conn;
        $message = '';
        if (!empty($_POST["addUser"]) && $_POST["addUsername"] != '') {
            // Check if the user already exists
            $sqlQuery = "SELECT * FROM " . $this->userTable . " WHERE username='" . $_POST["addUsername"] . "'";
            $result = mysqli_query($conn, $sqlQuery);
            $isUserExist = mysqli_num_rows($result);

            if ($isUserExist) {
                $message = "User already exists with this username address.";
            } else {
                // Hash the password using password_hash
                $hashedPassword = password_hash($_POST["addPassword"], PASSWORD_BCRYPT);
                //$authtoken = $this->getAuthtoken($_POST["addusername"]);
                $selectedRoleID = $_POST['addPosition'];


                //set the value of the roles/position into id
                // if ($_POST["addType"] === "Admin") {
                //     $roleID = 1;
                // } else if ($_POST["addPosition"] === "Chef") {
                //     $roleID = 2;
                // } else if ($_POST["addPosition"] === "Kitchen") {
                //     $roleID = 3;
                // } else if ($_POST["addPosition"] === "Manager") {
                //     $roleID = 4;
                // } else if ($_POST["addPosition"] === "Waiter") {
                //     $roleID = 5;
                // } else {
                //     echo "Undefined.";
                // }

                // Insert the user into table for user/employee
                $insertUserQuery = "INSERT INTO " . $this->userTable . " (firstName, lastName, username, password, status, type, roleID) 
                VALUES ('" . $_POST["addFirstName"] . "', '" . $_POST["addLastName"] . "', '" . $_POST["addUsername"] . "', '" . $hashedPassword . "', '" . $_POST["addStatus"] . "', '" . $_POST["addType"] . "', '" . $selectedRoleID . "')";
                $userSaved = mysqli_query($conn, $insertUserQuery);
                $message = "User saved";
                header('Location: usercrud.php');
                
            }
            return $message;
        }
        
    }

    public function totalUsers($status)
    {
        global $conn;
        $query = '';
        if ($status) {
            $query = " AND status = '" . $status . "'";
        }
        $sqlQuery = "SELECT * FROM " . $this->userTable . " 
		WHERE empAccID !='" . $_SESSION["userid"] . "' $query";
        $result = mysqli_query($conn, $sqlQuery);
        $numRows = mysqli_num_rows($result);
        return $numRows;

    }

    
    public function totalUserPagination()
    {
        global $conn;
        $query = '';
        $sqlQuery = "SELECT * FROM " . $this->userTable . " $query";
        $result = mysqli_query($conn, $sqlQuery);
        $numRows = mysqli_num_rows($result);
        return $numRows;

    }

    public function updateUser()
    {
        global $conn;
        $message = '';

        // Check if useracc_id is set in the GET request
        if (isset($_GET['empAccID']) && is_numeric($_GET['empAccID'])) {
            $accID = $_GET['empAccID'];

            // Fetch the user data based on useracc_id
            $sql = "SELECT * FROM tblemployees WHERE empAccID=?";
            $stmt = mysqli_prepare($conn, $sql);

            if (!$stmt) {
                $message = "Failed to prepare select statement.";
            }

            mysqli_stmt_bind_param($stmt, "i", $useracc_id);
            mysqli_stmt_execute($stmt);

            // Get the result 
            $result = mysqli_stmt_get_result($stmt);
            $row = mysqli_fetch_assoc($result);

            // Ensure that the user data is found
            if (!$row) {
                $message = "User not found.";
            }
        } else {
            $message = "Invalid useracc_id provided.";
        }

        // Get POST data
        if ($_SERVER["REQUEST_METHOD"] === "POST") {
            $firstName = $_POST['editFirstName'];
            $lastName = $_POST['editLastName'];
            $username = $_POST['editUsername'];
            $password = $_POST['editPassword'];
            $status = $_POST['editStatus'];
            $type = $_POST['editType'];
            // $role = $_POST['editPosition'];
        }

        // Determine the roleID based on 'editPosition'
        // $roleID = null;
        // if ($_POST["editType"] === "Admin") {
        //     $roleID = 1;
        // } else if ($_POST["editPosition"] === "Chef") {
        //     $roleID = 2;
        // } else if ($_POST["editPosition"] === "Kitchen") {
        //     $roleID = 3;
        // } else if ($_POST["editPosition"] === "Manager") {
        //     $roleID = 4;
        // } else if ($_POST["editPosition"] === "Waiter") {
        //     $roleID = 5;
        // } else {
        //     return "Undefined position.";
        // }

        // Update user information using prepared statement
        $sqlQuery = "UPDATE tblemployees SET firstName=?, lastName=?, username=?, password=?, status=?, type=?, roleID=? WHERE empAccID=?";
        $stmt = mysqli_prepare($conn, $sqlQuery);

        if (!$stmt) {
            $message = "Failed to prepare update statement.";
        }

        mysqli_stmt_bind_param($stmt, "ssssssii", $firstName, $lastName, $username, $password, $status, $type, $roleID, $accID);
        $result = mysqli_stmt_execute($stmt);

        if ($result) {
            $message = "User updated.";
        } else {
            $message = "Failed to update user.";
        }

        return $message;
    }
}
