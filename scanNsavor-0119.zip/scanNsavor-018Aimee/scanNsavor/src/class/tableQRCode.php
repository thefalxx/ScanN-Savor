<?php

include('../connection/config.php');
include("../phpqrcode/qrlib.php");


class tableQRCode
{
    public function QrGenerate()
    {
        global $conn;
        $message = '';

        if (isset($_POST['saveQR'])) {
            // After decoding the base64 data
            $dataURL = $_POST['saveQR'];
            $imageData = base64_decode(preg_replace('#^data:image/\w+;base64,#i', '', $dataURL));

            // Generate a unique name for the image with PNG extension
            $imageName = uniqid() . '.png'; // Save it as PNG
            $path = '../../images/QRimages/' . $imageName;

            // Check if the image directory exists; if not, create it
            if (!file_exists('../../images/QRimages/')) {
                mkdir('../../images/QRimages/', 0777, true);
            }

            // Now you can save the path of the image to your database
            $qrNum = mysqli_real_escape_string($conn, $_POST['tableNumber']);
            $seats = mysqli_real_escape_string($conn, $_POST['seats']); // Retrieve the number of seats from the form

            // Check if a record with the same table number already exists
            $checkQuery = mysqli_query($conn, "SELECT * FROM tbltable WHERE tableNo = '$qrNum'");
            if (mysqli_num_rows($checkQuery) > 0) {
                $message = "A record with this table number already exists.";
            } else {
                // Save the image to the server
                if (file_put_contents($path, $imageData) === false) {
                    $message = 'Error saving image!';
                } else {
                    $query = mysqli_query($conn, "INSERT INTO tbltable SET tableNo = '$qrNum', tableQRCode = '$path', noOfSeats = '$seats'");
                    if ($query) {
                        $message = "Data saved successfully";
                    } else {
                        $message = "Error: " . mysqli_error($conn);
                    }
                }
            }
        }
        return $message;
    }


    public function getAllTableQRDetails()
    {
        global $conn;
        $sqlQuery = "SELECT * FROM tbltable";
        $result = mysqli_query($conn, $sqlQuery);

        $tableqr = array();
        if ($result) {
            while ($row = $result->fetch_assoc()) {
                $tableqr[] = $row;
            }
        }
        return $tableqr;
    }

    // Include this function in tableQRCode.php
    public function getAllTableQR($searchTerm = "")
    {
        global $conn;
        $tableqr = array();

        $row_per_page = 10;
        $page = 1;

        if (isset($_GET['page-nr']) && is_numeric($_GET['page-nr'])) {
            $page = intval($_GET['page-nr']);
        }

        // Reset page to 1 when there is a search term
        if (!empty($searchTerm)) {
            $page = 1;
        }

        $start = ($page - 1) * $row_per_page;

        // If there is a search term, modify the query to include it
        $searchCondition = "";
        if (!empty($searchTerm)) {
            $searchCondition = "WHERE tableNo LIKE '%$searchTerm'";
        }

        // Fetch the total number of rows
        $sqlCount = "SELECT COUNT(*) as count FROM tbltable $searchCondition";
        $countResult = mysqli_query($conn, $sqlCount);
        $rowCount = $countResult->fetch_assoc()['count'];

        // Calculate total number of pages
        $totalPages = ceil($rowCount / $row_per_page);

        // Pass the total number of pages to the HTML using a hidden input
        echo "<input type='hidden' id='totalPages' value='$totalPages'>";

        // Include the search condition in the main query
        $sqlQuery = "SELECT * FROM tbltable $searchCondition LIMIT $start, $row_per_page";
        $result = mysqli_query($conn, $sqlQuery);

        if ($result) {
            while ($row = $result->fetch_assoc()) {
                $tableqr[] = $row;
            }
        }

        return $tableqr;
    }

    // public function getOccupiedTables()
    // {
    //     global $conn;

    //     $sqlQuery = "SELECT * FROM tbltable WHERE isOccupied = 1";
    //     $result = mysqli_query($conn, $sqlQuery);

    //     $occupiedTables = array();

    //     if ($result) {
    //         while ($row = $result->fetch_assoc()) {
    //             $occupiedTables[] = $row;
    //         }
    //     } else {
    //         // Handle the error here
    //         die("Error: " . mysqli_error($conn));
    //     }

    //     return $occupiedTables;
    // }

    public function getOccupiedTables($excludeTableNo)
    {
        global $conn;

        $sqlQuery = "SELECT * FROM tbltable WHERE isOccupied = 1 AND tableNo != ?";
        $stmt = mysqli_prepare($conn, $sqlQuery);
        mysqli_stmt_bind_param($stmt, 'i', $excludeTableNo);
        $occupiedTables = array();

        if (mysqli_stmt_execute($stmt)) {
            $result = mysqli_stmt_get_result($stmt);
            while ($row = $result->fetch_assoc()) {
                $occupiedTables[] = $row;
            }
        } else {
            // Handle the error here
            die("Error: " . mysqli_error($conn));
        }

        return $occupiedTables;
    }



    public function countOccupiedTables()
    {
        global $conn;

        $sqlQuery = "SELECT COUNT(*) as occupiedTables FROM tbltable WHERE isOccupied = 1";
        $result = mysqli_query($conn, $sqlQuery);

        if (!$result) {
            // Handle the error here
            die("Error: " . mysqli_error($conn));
        }

        $row = mysqli_fetch_assoc($result);
        $occupiedTables = $row['occupiedTables'];

        return $occupiedTables;
    }
}