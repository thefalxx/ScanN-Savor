
<?php


function generateSidenav($userRole)
{
    // Define the sidenav content based on the user's role
    $sidenavContent = '';

    switch ($userRole) {
        case 'Admin':
            $sidenavContent = '<?php include \'../viewAdmin/sidenav.php\'; ?>';
            break;

        case 'Cashier':
            $sidenavContent = '<?php include \'../viewCashier/sidenavCashier.php\'; ?>';
            break;

        case 'Kitchen Staff':
            $sidenavContent = '<?php include \'../viewKitchen/sidenavkitchen.php\'; ?>';
            break;

        case 'Manager':
            $sidenavContent = '<?php include \'../viewManager/sidenavmanager.php\'; ?>';
            break;

        case 'Waiter':
            $sidenavContent = '<?php include \'../viewWaiter/sidenavwaiter.php\'; ?>';
            break;

            // Add more cases for other roles as needed

        default:
            // Default sidenav for unknown roles
            $sidenavContent = '<p>No sidenav options available for this role.</p>';
            break;
    }

    return $sidenavContent;
}

?>
