<?php
include('../connection/config.php');

if (isset($_POST['ratingsAdd'])) {
    RatingsAdd();
}

function RatingsAdd()
{
    global $conn;

    $ratingNo = $_POST['ratingNo'];
    $ratingFeedback = $_POST['ratingFeedback'];

    $sql = "INSERT INTO tblratings (ratingNo, ratingFeedback) VALUES ('$ratingNo', '$ratingFeedback')";
    $result = mysqli_query($conn, $sql);

    if ($result) {
        redirectToRatingWithSuccess("You have successfully rate!",);
    } else {
        redirectToRatingWithError("Unknown error occurred!");
    }
}

function redirectToRatingWithError($error)
{
    header("Location: ../viewCustomer/landingpage.php?error=$error");
    exit();
}

function redirectToRatingWithSuccess($success)
{
    header("Location: ../viewCustomer/landingpage.php?success=$success");
    exit();
}

function getRatings()
{
    global $conn;

    $sql = "SELECT * FROM tblratings";
    $result = mysqli_query($conn, $sql);

    if ($result) {
        $ratings = mysqli_fetch_all($result, MYSQLI_ASSOC);
        return $ratings;
    } else {
        // Handle the error, you might want to log or display an error message
        return null;
    }
}

function displayStars($ratingNumber)
{
    // Assuming $ratingNumber is a number between 1 and 5
    $fullStars = floor($ratingNumber);
    $halfStar = round($ratingNumber - $fullStars, 1) == 0.5;

    $stars = str_repeat('<span class="text-yellow-400">&#9733;</span>', $fullStars);

    if ($halfStar) {
        $stars .= '<span class="text-yellow-400">&#9734;</span>';
    }

    return $stars;
}