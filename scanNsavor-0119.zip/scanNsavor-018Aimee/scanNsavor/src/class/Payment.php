<?php 
include("../connection/config.php");

class Payment {

    public function totalSales()
    {
        global $conn; // Assuming $conn is your database connection

        $sqlQuery = "SELECT SUM(amountPaid) as totalSales FROM tblpayment";
        $result = mysqli_query($conn, $sqlQuery);

        if (!$result) {
            // Handle the error here
            die("Error: " . mysqli_error($conn));
        }

        $row = mysqli_fetch_assoc($result);
        $totalSales = $row['totalSales'];

        return $totalSales;
    }

    public function overallTotalSales()
    {
        global $conn; // Assuming $conn is your database connection

        $sqlQuery = "SELECT SUM(totalAmount) as ordersTotal FROM tblorders";
        $resultOrders = mysqli_query($conn, $sqlQuery);

        if (!$resultOrders) {
            // Handle the error here
            die("Error: " . mysqli_error($conn));
        }

        $rowOrders = mysqli_fetch_assoc($resultOrders);
        $ordersTotal = $rowOrders['ordersTotal'];

        $sqlQuery = "SELECT SUM(amountPaid) as paymentsTotal FROM tblpayment";
        $resultPayments = mysqli_query($conn, $sqlQuery);

        if (!$resultPayments) {
            // Handle the error here
            die("Error: " . mysqli_error($conn));
        }

        $rowPayments = mysqli_fetch_assoc($resultPayments);
        $paymentsTotal = $rowPayments['paymentsTotal'];

        // Calculate the overall total sales
        $overallTotalSales = $ordersTotal + $paymentsTotal;

        return $overallTotalSales;
    }

    public function totalPayments($status)
    {
        global $conn; 

        $query = '';
        if ($status) {
            $query = " WHERE status = '" . $status . "'";
        }


        $sqlQuery = "SELECT COUNT(*) as totalPayments FROM tblpayment" . $query;
        $result = mysqli_query($conn, $sqlQuery);

        if (!$result) {
            // Handle the error here
            die("Error: " . mysqli_error($conn));
        }

        $row = mysqli_fetch_assoc($result);
        $totalPayments = $row['totalPayments'];

        return $totalPayments;
    }

}




?>
