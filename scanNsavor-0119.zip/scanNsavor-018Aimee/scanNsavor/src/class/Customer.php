<?php
include('../connection/config.php');

class Customer
{

    private $customerTable = "tblwaitingcustomer";

    //     public function getAllCustomer()
    // {
    //     // Include your database configuration file if not already included
    //     include('../connection/config.php');

    //     // Check the connection
    //     if ($conn->connect_error) {
    //         die("Connection failed: " . $conn->connect_error);
    //     }

    //     $sqlQuery = "SELECT * FROM tblwaitingcustomer";
    //     $result = mysqli_query($conn, $sqlQuery);

    //     if (!$result) {
    //         die("Query failed: " . mysqli_error($conn));
    //     }

    //     $waitCustomer = array();

    //     while ($row = $result->fetch_assoc()) {
    //         $waitCustomer[] = $row;
    //     }

    //     // Close the connection after fetching data
    //     $conn->close();

    //     return $waitCustomer;
    // }

    public function getAllCustomer($searchTerm = "")
    {
        // Include your database configuration file if not already included
        include('../connection/config.php');

        // Check the connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // Delete records where waiting_time has passed 15 minutes
        $deleteQuery = "DELETE FROM " . $this->customerTable . " WHERE waiting_time < DATE_SUB(NOW(), INTERVAL 15 MINUTE)";
        $deleteResult = mysqli_query($conn, $deleteQuery);

        if (!$deleteResult) {
            // Handle the error here
            die("Deletion query failed: " . mysqli_error($conn));
        }

        $row_per_page = 10;
        $page = 1;

        if (isset($_GET['page-nr']) && is_numeric($_GET['page-nr'])) {
            $page = intval($_GET['page-nr']);
        }

        $start = ($page - 1) * $row_per_page;

        // If there is a search term, modify the query to include it
        $searchCondition = "";
        if (!empty($searchTerm)) {
            $searchCondition = " AND name LIKE '%" . mysqli_real_escape_string($conn, $searchTerm) . "%'"; // Replace name with the actual column you want to search
        }

        // Fetch the total number of rows
        $sqlCount = "SELECT COUNT(*) as count FROM " . $this->customerTable . " WHERE waiting_time >= DATE_SUB(NOW(), INTERVAL 15 MINUTE) $searchCondition";
        $countResult = mysqli_query($conn, $sqlCount);
        $rowCount = $countResult->fetch_assoc()['count'];

        // Calculate total number of pages
        $totalPages = ceil($rowCount / $row_per_page);

        // Pass the total number of pages to the HTML using a hidden input
        echo "<input type='hidden' id='totalPages' value='$totalPages'>";

        // Include the search condition in the main query
        $sqlQuery = "SELECT * FROM " . $this->customerTable . " WHERE waiting_time >= DATE_SUB(NOW(), INTERVAL 15 MINUTE) $searchCondition LIMIT $start, $row_per_page";
        $result = mysqli_query($conn, $sqlQuery);

        $waitCustomer = array();

        if ($result) {
            while ($row = $result->fetch_assoc()) {
                $waitCustomer[] = $row;
            }
        } else {
            // Handle the error here
            die("Query failed: " . mysqli_error($conn));
        }

        // Close the connection after fetching data
        $conn->close();

        return $waitCustomer;
    }

    public function deleteCustomer($waitingID)
    {
        global $conn;

        // Assuming waitingID is an integer, you may need to sanitize/validate it further
        $waitingID = (int)$waitingID;

        $sqlQuery = "DELETE FROM " . $this->customerTable . " WHERE waitingID = ?";
        $stmt = $conn->prepare($sqlQuery);
        $stmt->bind_param("i", $waitingID);

        if ($stmt->execute()) {
            return true; // Deletion successful
        } else {
            return false; // Deletion failed
        }
    }

    public function totalWaitingCustomers($status)
    {
        global $conn;

        $query = '';
        if ($status) {
            $query = " WHERE status = '" . $status . "'";
        }

        $sqlQuery = "SELECT COUNT(*) as totalWaitingCustomers FROM tblwaitingcustomer" . $query;
        $result = mysqli_query($conn, $sqlQuery);

        if (!$result) {
            // Handle the error here
            die("Error: " . mysqli_error($conn));
        }

        $row = mysqli_fetch_assoc($result);
        $totalWaitingCustomers = $row['totalWaitingCustomers'];

        return $totalWaitingCustomers;
    }
}
