<?php

$lastName = isset($_GET['lastName']) ? $_GET['lastName'] : '';

// Generate the password
$password = generateRandomPassword($lastName);

// Echo the password
echo $password;



function generateRandomPassword($lastName)
{
    // Generate a random string of characters
    $randomChars = generateRandomChars(6); // You can adjust the length as needed

    // Combine the last name and random characters
    $password = $lastName . $randomChars;

    return $password;
}

function generateRandomChars($length)
{
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charLength = strlen($characters);
    $randomString = '';

    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charLength - 1)];
    }

    return $randomString;
}
