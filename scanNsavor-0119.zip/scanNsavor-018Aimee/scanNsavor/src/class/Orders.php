<?php
include("../connection/config.php");

class Order
{

    private $orderTable = 'tblorders';
    private $orderDetailsTable = 'tblorderdetails';
    private $foodItemTable = 'tblfooditems';
    private $packageTable = 'tblmenupackage';
    private $packageItems = 'tblmenupackageitems';
    private $serveQtyTable = 'tblserveqty_temp';

    // public function order() {

    //     global $conn;

    //     $orderID = $_GET['orderID'];

    //     $sql = "SELECT * FROM tblOrders WHERE orderID = :orderID";
    //     $stmt = $conn->prepare($sql);
    //     $stmt->bindParam(':orderID', $orderID);
    //     $stmt->execute();
    //     $order = $stmt->fetch();

    // }

    // //to retrieve pending orders
    // public function getPendingOrders($conn) {

    //     $sql = "SELECT * FROM tblOrders WHERE orderStatus ='pending'";
    //     $result = $conn->$query($sql);

    //     if($result->num_rows > 0 ) {
    //         return $result-> fetch_all(MYSQLI_ASSOC);
    //     }
    //     else{
    //         return [];
    //     }
    // }

    // //to handle order confirmations 
    // if(isset($_POST['confirm_order'])) {

    //     $orderID = $_POST['order_ID'];
    //     $sql = "UPDATE tblOrders SET orderStatus = 'confirmed' WHERE id = $orderID";
    //     $conn->$query($sql);

    // }

    // //getpendingorders

    // $pendingOrders = getPendingOrders($sql); 

    // public function order() {
    //     global $conn;

    //     $orderID = $_GET['orderID'];

    //     $sqlQuery = "SELECT * FROM " . $this->orderTable . " WHERE orderID = :orderID";
    //     $stmt = $conn->prepare($sql);
    //     $stmt->bindParam(':orderID', $orderID);
    //     $stmt->execute();
    //     $order = $stmt->fetch();
    // }


    public function getOrders()
    {
        global $conn;
        $sql = "SELECT * FROM tblOrders WHERE orderStatus = 'Pending' OR 'Pending-W', tableNo = '?'";
        $result = mysqli_query($conn, $sql);
        $pendingOrders = mysqli_fetch_assoc($result);
        return $pendingOrders;
    }


    public function getTableNo()
    {
        global $conn;

        $sql = "SELECT tableNo FROM tblTable";
        $result = mysqli_query($conn, $sql);
        $tableNoOrders = mysqli_fetch_assoc($result);
        return $tableNoOrders;
    }

    public function getTotalAmount($orderID)
    {
        global $conn;
        $total = null;
        $query = "SELECT totalAmount FROM tblOrders WHERE orderID = " . $orderID;
        if ($result = $conn->query($query)) {

            if ($res = $result->fetch_assoc()) {
                $total = $res["0"];
                return $total;
            }
            return $total;
        } else {
            echo $conn->error;
            return null;
        }
    }

    public function getorderCart()
    {
        global $conn;
    }


    function placeOrder($tableNo, $waiterID, $itemID, $quantity)
    {
        global $conn;

        // Insert the order into the `tblorders` table
        $orderStatus = "Pending"; // You can change this to another status
        $isDineIn = 1; // Set to 1 for dine-in orders

        $orderInsertSQL = "INSERT INTO tblorders (isDineIn, orderDate, orderStatus, totalAmount, tableNo, processedBy)
                           VALUES ($isDineIn, NOW(), '$orderStatus', 0, $tableNo, $waiterID)";

        if ($conn->query($orderInsertSQL) === TRUE) {
            $orderID = $conn->insert_id; // Get the order ID

            // Insert order details into the `tblorderdetails` table
            $foodItem = $this->getItemDetails($itemID);

            if ($foodItem) {
                $amount = $foodItem['price'] * $quantity;

                $orderDetailsInsertSQL = "INSERT INTO tblorderdetails (orderID, itemID, packageID, noOfItems, Amount)
                                         VALUES ($orderID, $itemID, 0, $quantity, $amount)";

                if ($conn->query($orderDetailsInsertSQL) === TRUE) {
                    echo "Order placed successfully!";
                } else {
                    echo "Error inserting order details: " . $conn->error;
                }
            } else {
                echo "Food item not found!";
            }
        } else {
            echo "Error inserting order: " . $conn->error;
        }
    }

    public function getItemDetails($itemID)
    {
        global $conn;

        $sql = "SELECT * FROM tblfooditems WHERE itemID = $itemID";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            return $result->fetch_assoc();
        }

        return null;
    }


    public function addToCart($orderID, $itemID, $packageID, $noOfItems, $amount)
    {

        global $conn;

        // Prepare and execute the SQL statement to insert the order
        $query = "INSERT INTO tblorderdetails (orderID, itemID, packageID, noOfItems, Amount) VALUES (?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($query);

        // Bind parameters and execute the query
        $stmt->bind_param("iiidd", $orderID, $itemID, $packageID, $noOfItems, $amount);

        if ($stmt->execute()) {
            // Order saved successfully
            $stmt->close();
            $conn->close();
            return true;
        } else {
            // Error saving the order
            $stmt->close();
            $conn->close();
            return false;
        }
    }

    public function getforApprovalOrders()
    {
        global $conn;

        $sql = "SELECT o.*, od.*, fi.*, pt.* FROM $this->orderTable o
            INNER JOIN $this->orderDetailsTable od ON o.orderID = od.orderID
            LEFT JOIN $this->foodItemTable fi ON fi.itemID = od.itemID
            LEFT JOIN $this->packageTable pt ON pt.packageID = od.packageID
            WHERE od.status = 'ForApproval'";

        $result = mysqli_query($conn, $sql);

        if ($result) {
            return mysqli_fetch_all($result, MYSQLI_ASSOC);
        } else {
            return array();
        }
    }

    public function getPendingOrders()
    {
        global $conn;

        $sql = "SELECT o.*, od.*, fi.*, pt.* FROM $this->orderTable o
        INNER JOIN $this->orderDetailsTable od ON o.orderID = od.orderID
        LEFT JOIN $this->foodItemTable fi ON fi.itemID = od.itemID
        LEFT JOIN $this->packageTable pt ON pt.packageID = od.packageID
            WHERE od.status = 'Pending'";

        $result = mysqli_query($conn, $sql);

        if ($result) {
            return mysqli_fetch_all($result, MYSQLI_ASSOC);
        } else {
            return array();
        }
    }

    public function getInProgressOrders()
    {
        global $conn;

        $sql = "SELECT o.*, od.*, fi.*, pt.*, sq.Qty FROM $this->orderTable o
        INNER JOIN $this->orderDetailsTable od ON o.orderID = od.orderID
        LEFT JOIN $this->foodItemTable fi ON fi.itemID = od.itemID
        LEFT JOIN $this->packageTable pt ON pt.packageID = od.packageID
        LEFT JOIN $this->serveQtyTable sq ON od.orderDetailsID = sq.orderDetailsID
            WHERE  od.status = 'InProgress'";

        $result = mysqli_query($conn, $sql);

        if ($result) {
            return mysqli_fetch_all($result, MYSQLI_ASSOC);
        } else {
            return array();
        }
    }

    public function getCompleteOrders()
    {
        global $conn;

        

        $sql = "SELECT o.*, od.*, fi.*, pt.* FROM $this->orderTable o
        INNER JOIN $this->orderDetailsTable od ON o.orderID = od.orderID
        LEFT JOIN $this->foodItemTable fi ON fi.itemID = od.itemID
        LEFT JOIN $this->packageTable pt ON pt.packageID = od.packageID
        WHERE od.status = 'Completed'";

        $result = mysqli_query($conn, $sql);

        if ($result) {
            return mysqli_fetch_all($result, MYSQLI_ASSOC);
        } else {
            return array();
        }
    }

    public function cancelOrder($tableNo)
    {
        global $conn;

        try {
            mysqli_begin_transaction($conn);

            $escapedTableID = mysqli_real_escape_string($conn, $tableNo);

            // Get order details IDs and pending amount in a single query
            $orderDetailsQuery = "SELECT orderDetailsID, Amount
                              FROM tblorderdetails
                              WHERE orderID IN (
                                  SELECT tblorders.orderID
                                  FROM tblorders
                                  INNER JOIN tblorderdetails ON tblorders.orderID = tblorderdetails.orderID
                                  WHERE tblorders.tableNo = '$escapedTableID' AND tblorderdetails.status = 'Pending'
                              ) AND status = 'Pending'";

            $orderDetailsResult = mysqli_query($conn, $orderDetailsQuery);

            if (!$orderDetailsResult) {
                throw new Exception("Error getting order details: " . mysqli_error($conn));
            }

            $orderDetailsIDs = [];
            $pendingAmount = 0;

            while ($row = mysqli_fetch_assoc($orderDetailsResult)) {
                $orderDetailsIDs[] = $row['orderDetailsID'];
                $pendingAmount += $row['Amount'];
            }

            // Update totalAmount in tblorders
            $sqlUpdateTotalAmount = "UPDATE tblorders
                                 SET totalAmount = totalAmount - $pendingAmount
                                 WHERE tableNo = '$escapedTableID'";

            $resultUpdateTotalAmount = mysqli_query($conn, $sqlUpdateTotalAmount);

            if (!$resultUpdateTotalAmount) {
                throw new Exception("Error updating totalAmount: " . mysqli_error($conn));
            }

            // Delete pending orders from tblorderdetails
            $orderDetailsIDsString = implode(', ', $orderDetailsIDs);
            $sqlDeleteOrderDetails = "DELETE FROM tblorderdetails
                              WHERE orderDetailsID IN ($orderDetailsIDsString)";

            $resultDeleteOrderDetails = mysqli_query($conn, $sqlDeleteOrderDetails);

            if (!$resultDeleteOrderDetails) {
                throw new Exception("Error canceling order: " . mysqli_error($conn));
            }

            $sqlDeletePendingOrders = "DELETE FROM tblorders
            WHERE orderStatus = 'Pending'";
            $resultDeletePendingOrders = mysqli_query($conn, $sqlDeletePendingOrders);

            if (!$resultDeletePendingOrders) {
                throw new Exception("Error deleting pending order in tblorders: " . mysqli_error($conn));
            }

            // Commit the transaction if everything was successful
            mysqli_commit($conn);
        } catch (Exception $e) {
            mysqli_rollback($conn);
            return " " . $e->getMessage();
        }
    }


    public function updateOrderStatusToPending($tableNo)
    {
        global $conn;

        $escapedTableID = mysqli_real_escape_string($conn, $tableNo);

        // Initialize a flag to check the success of the transaction
        $success = true;

        // Start a database transaction
        mysqli_begin_transaction($conn);

        // Update the status of related orders in tblOrders and tblOrderDetails using INNER JOIN
        $sqlUpdate = "UPDATE tblOrders
                  INNER JOIN tblOrderDetails ON tblOrders.orderID = tblOrderDetails.orderID
                  SET tblOrders.orderStatus = 'Pending', tblOrderDetails.status = 'Pending'
                  WHERE tblOrders.tableNo = '$escapedTableID' AND tblOrderDetails.status = 'forApproval'";

        $resultUpdate = mysqli_query($conn, $sqlUpdate);

        if (!$resultUpdate) {
            $success = false;
        }

        // Commit the transaction if the update was successful, or roll back if it failed
        if ($success) {
            mysqli_commit($conn);
            return "Order Confirmed Successfully";
        } else {
            mysqli_rollback($conn);
            return "Error updating status: " . mysqli_error($conn);
        }
    }


    public function updateOrderStatusToInProgress($tableNo)
    {
        global $conn;

        $escapedTableID = mysqli_real_escape_string($conn, $tableNo);

        // Initialize a flag to check the success of the transaction
        $success = true;

        // Start a database transaction
        mysqli_begin_transaction($conn);

        // Update the status of related orders in tblOrders and tblOrderDetails using INNER JOIN
        $sqlUpdate = "UPDATE tblOrders
                      INNER JOIN tblOrderDetails ON tblOrders.orderID = tblOrderDetails.orderID
                      SET tblOrders.orderStatus = 'InProgress', tblOrderDetails.status = 'InProgress'
                      WHERE tblOrders.tableNo = '$escapedTableID' AND tblOrders.orderStatus = 'pending' AND tblOrderDetails.status = 'pending'";

        $resultUpdate = mysqli_query($conn, $sqlUpdate);

        if (!$resultUpdate) {
            $success = false;
        }

        $sqlInsertServeQtyTemp = "
                                INSERT INTO tblserveqty_temp (orderDetailsID, orderID, itemID, Qty)
                                SELECT od.orderDetailsID, od.orderID, od.itemID, od.itemQuantity
                                FROM tblOrderDetails od
                                INNER JOIN tblOrders o ON od.orderID = o.orderID
                                LEFT JOIN tblserveqty_temp sq ON od.orderDetailsID = sq.orderDetailsID
                                WHERE o.tableNo = '$escapedTableID' AND od.status = 'InProgress' AND sq.orderDetailsID IS NULL
                            ";

        $resultInsertServeQtyTemp = mysqli_query($conn, $sqlInsertServeQtyTemp);

        if (!$resultInsertServeQtyTemp) {
            $success = false;
        }

        // Commit the transaction if the update and insert were successful, or roll back if they failed
        if ($success) {
            mysqli_commit($conn);
            return "Order Confirm Successfully";
        } else {
            mysqli_rollback($conn);
            return "Error updating status or inserting into tblserveqty_temp: " . mysqli_error($conn);
        }
    }

    public function updateOrderStatusToCompleted($tableNo)
    {
        global $conn;

        $escapedTableID = mysqli_real_escape_string($conn, $tableNo);

        // Initialize a flag to check the success of the transaction
        $success = true;

        // Start a database transaction
        mysqli_begin_transaction($conn);

        // Update the status of related orders in tblOrders and tblOrderDetails using INNER JOIN
        $sqlUpdate = "UPDATE tblOrders
              INNER JOIN tblOrderDetails ON tblOrders.orderID = tblOrderDetails.orderID
              SET tblOrders.orderStatus = 'Completed', tblOrderDetails.status = 'Completed'
              WHERE tblOrders.tableNo = '$escapedTableID' AND tblOrders.orderStatus = 'InProgress' 
              AND tblOrderDetails.status = 'InProgress'";

        $resultUpdate = mysqli_query($conn, $sqlUpdate);

        if (!$resultUpdate) {
            $success = false;
        }

        // Delete all data from tblserveqty_temp for the specific orderID
        $sqlDeleteServeQtyTemp = "DELETE FROM tblserveqty_temp WHERE orderID IN (
        SELECT orderID FROM tblOrders WHERE tableNo = '$escapedTableID' AND orderStatus = 'Completed'
    )";
        $resultDeleteServeQtyTemp = mysqli_query($conn, $sqlDeleteServeQtyTemp);

        if (!$resultDeleteServeQtyTemp) {
            $success = false;
        }

        // Commit the transaction if the update and deletion were successful, or roll back if they failed
        if ($success) {
            mysqli_commit($conn);
            return "Order Confirm Successfully";
        } else {
            mysqli_rollback($conn);
            return "Error updating status or deleting serveqty_temp: " . mysqli_error($conn);
        }
    }

    public function updateOrderStatusToServed($tableNo)
    {
        global $conn;

        $escapedTableID = mysqli_real_escape_string($conn, $tableNo);

        // Initialize a flag to check the success of the transaction
        $success = true;

        // Start a database transaction
        mysqli_begin_transaction($conn);

        // Update the status of related orders in tblOrders and tblOrderDetails using INNER JOIN
        $sqlUpdate = "UPDATE tblOrders
                  INNER JOIN tblOrderDetails ON tblOrders.orderID = tblOrderDetails.orderID
                  SET tblOrders.orderStatus = 'Served', tblOrderDetails.status = 'Served'
                  WHERE tblOrders.tableNo = '$escapedTableID' AND tblOrders.orderStatus = 'Completed' AND tblOrderDetails.status = 'Completed'";

        $resultUpdate = mysqli_query($conn, $sqlUpdate);

        if (!$resultUpdate) {
            $success = false;
        }

        // Commit the transaction if the update was successful, or roll back if it failed
        if ($success) {
            mysqli_commit($conn);
            return "Order Served Successfully";
        } else {
            mysqli_rollback($conn);
            return "Error updating status: " . mysqli_error($conn);
        }
    }

    public function archiveCompletedOrders($tableNo)
    {
        global $conn;

        $escapedTableID = mysqli_real_escape_string($conn, $tableNo);

        // Start a database transaction
        mysqli_begin_transaction($conn);

        // Move completed orders to tblorderhistory
        $sqlMoveToHistory = "INSERT INTO tblorderhistory (orderID, tableNo, itemID, packageID, itemQuantity) 
                     SELECT o.orderID, o.tableNo, od.itemID, od.packageID, od.itemQuantity
                     FROM tblorders o
                     INNER JOIN tblorderdetails od ON o.orderID = od.orderID
                     WHERE o.orderStatus = 'Completed' AND od.status = 'Completed' AND o.tableNo = '$escapedTableID'";
        $resultMoveToHistory = mysqli_query($conn, $sqlMoveToHistory);

        // Check if the move to history was successful
        if (!$resultMoveToHistory) {
            mysqli_rollback($conn);
            return "Error moving orders to history: " . mysqli_error($conn);
        }

        $sqlMovePaymentToHistory = "INSERT INTO tblpaymenthistory (paymentID, orderID, totalAmount, paymentDateTime)
                            SELECT p.paymentID, pd.orderID, p.amount, pd.paymentDateTime
                            FROM tblpayment p
                            INNER JOIN tblpaymentdetails pd ON p.paymentID = pd.paymentID
                            WHERE p.status = 'confirmed'";
        $resultMovePaymentToHistory = mysqli_query($conn, $sqlMovePaymentToHistory);

        // Check if the move to payment history was successful
        if (!$resultMovePaymentToHistory) {
            mysqli_rollback($conn);
            return "Error moving payment data to history: " . mysqli_error($conn);
        }

        // Delete completed orders from tblorders and tblorderdetails using INNER JOIN
        $sqlDelete = "DELETE tblorders, tblorderdetails, tblpaymentdetails, tblpayment
              FROM tblorders
              INNER JOIN tblorderdetails ON tblorders.orderID = tblorderdetails.orderID
              INNER JOIN tblpaymentdetails ON tblorders.orderID = tblpaymentdetails.orderID
              INNER JOIN tblpayment ON tblpayment.paymentID = tblpaymentdetails.paymentID
              WHERE tblorders.orderStatus = 'Completed' AND tblorders.tableNo = '$escapedTableID' AND tblorderdetails.status = 'Completed'
              AND tblpayment.status = 'confirmed'";

        $resultDelete = mysqli_query($conn, $sqlDelete);

        // Check if the deletion from tblorders and tblorderdetails was successful
        if (!$resultDelete) {
            mysqli_rollback($conn);
            return "Error deleting orders: " . mysqli_error($conn);
        }

        // Commit the transaction if everything was successful
        mysqli_commit($conn);
        return "Orders archived successfully";
    }

    public function decreaseQtyInServeQtyTemp($orderDetailsID)
    {
        global $conn;

        // Start a database transaction
        mysqli_begin_transaction($conn);

        // Decrease the Qty in tblserveqty_temp
        $escapedOrderDetailsID = mysqli_real_escape_string($conn, $orderDetailsID);
        $sqlDecreaseQty = "UPDATE tblserveqty_temp SET Qty = Qty - 1 WHERE orderDetailsID = '$escapedOrderDetailsID' AND Qty > 0";
        $resultDecreaseQty = mysqli_query($conn, $sqlDecreaseQty);

        // Check for errors and affected rows
        if ($resultDecreaseQty === false) {
            mysqli_rollback($conn);
            return "Error decreasing quantity: " . mysqli_error($conn);
        }

        // Check if the quantity became 0
        $sqlCheckQty = "SELECT Qty FROM tblserveqty_temp WHERE orderDetailsID = '$escapedOrderDetailsID'";
        $resultCheckQty = mysqli_query($conn, $sqlCheckQty);

        if ($resultCheckQty === false) {
            mysqli_rollback($conn);
            return "Error checking quantity: " . mysqli_error($conn);
        }

        $row = mysqli_fetch_assoc($resultCheckQty);
        $currentQty = $row['Qty'];

        // If the quantity is 0, delete from tblserveqty_temp and update status to 'Completed'
        if ($currentQty == 0) {
            $sqlDeleteRow = "DELETE FROM tblserveqty_temp WHERE orderDetailsID = '$escapedOrderDetailsID'";
            $resultDeleteRow = mysqli_query($conn, $sqlDeleteRow);

            if ($resultDeleteRow === false) {
                mysqli_rollback($conn);
                return "Error deleting row: " . mysqli_error($conn);
            }

            // Update status in tblorderdetails to 'Completed'
            $sqlUpdateStatus = "UPDATE tblorderdetails SET status = 'Completed' WHERE orderDetailsID = '$escapedOrderDetailsID'";
            $resultUpdateStatus = mysqli_query($conn, $sqlUpdateStatus);

            if ($resultUpdateStatus === false) {
                mysqli_rollback($conn);
                return "Error updating status: " . mysqli_error($conn);
            }

            // Check if all items in the order are completed
            $orderID = $this->getOrderIDFromOrderDetailsID($escapedOrderDetailsID);

            $sqlCheckAllCompleted = "SELECT COUNT(*) AS cnt FROM tblorderdetails WHERE orderID = '$orderID' AND status != 'Completed'";
            $resultCheckAllCompleted = mysqli_query($conn, $sqlCheckAllCompleted);

            if ($resultCheckAllCompleted === false) {
                mysqli_rollback($conn);
                return "Error checking all items completed: " . mysqli_error($conn);
            }

            $rowCheckAllCompleted = mysqli_fetch_assoc($resultCheckAllCompleted);
            $countNotCompleted = $rowCheckAllCompleted['cnt'];

            if ($countNotCompleted == 0) {
                // All items in the order are completed, update orderStatus in tblorders to 'Completed'
                $sqlUpdateOrderStatus = "UPDATE tblorders SET orderStatus = 'Completed' WHERE orderID = '$orderID'";
                $resultUpdateOrderStatus = mysqli_query($conn, $sqlUpdateOrderStatus);

                if ($resultUpdateOrderStatus === false) {
                    mysqli_rollback($conn);
                    return "Error updating order status: " . mysqli_error($conn);
                }
            }
        }

        // Commit the transaction if everything was successful
        mysqli_commit($conn);
        return true;
    }

    // Function to get orderID from orderDetailsID
    private function getOrderIDFromOrderDetailsID($orderDetailsID)
    {
        global $conn;

        $escapedOrderDetailsID = mysqli_real_escape_string($conn, $orderDetailsID);

        $sqlGetOrderID = "SELECT orderID FROM tblorderdetails WHERE orderDetailsID = '$escapedOrderDetailsID'";
        $resultGetOrderID = mysqli_query($conn, $sqlGetOrderID);

        if ($resultGetOrderID === false) {
            return null; // Handle error appropriately
        }

        $rowGetOrderID = mysqli_fetch_assoc($resultGetOrderID);
        return $rowGetOrderID['orderID'];
    }

    public function cancelOrderItem($orderDetailsID)
{
    global $conn;

    // Escape the orderDetailsID to prevent SQL injection
    $escapedOrderDetailsID = mysqli_real_escape_string($conn, $orderDetailsID);

    // Start a database transaction
    mysqli_begin_transaction($conn);

    try {
        // Fetch the amount, order ID, and itemQuantity from tblorderdetails
        $sqlGetDetails = "SELECT Amount, orderID, itemQuantity, itemID FROM tblorderdetails WHERE orderDetailsID = '$escapedOrderDetailsID'";
        $resultGetDetails = mysqli_query($conn, $sqlGetDetails);

        if (!$resultGetDetails) {
            throw new Exception();
        }

        $row = mysqli_fetch_assoc($resultGetDetails);
        $orderItemAmount = $row['Amount'];
        $orderID = $row['orderID'];
        $itemQuantity = $row['itemQuantity'];
        $itemID = $row['itemID'];

        // Calculate the new quantity and amount after cancellation
        $newQuantity = $itemQuantity - 1;
        $newAmount = $orderItemAmount * ($newQuantity / $itemQuantity);

        // Update the itemQuantity and Amount in tblorderdetails
        $sqlUpdateOrderItem = "UPDATE tblorderdetails SET itemQuantity = '$newQuantity', Amount = '$newAmount' WHERE orderDetailsID = '$escapedOrderDetailsID'";
        $resultUpdateOrderItem = mysqli_query($conn, $sqlUpdateOrderItem);

        if (!$resultUpdateOrderItem) {
            throw new Exception();
        }

        // Check if serving needs to be updated
        if ($itemID) {
            // Increment serving in tblfooditems
            $sqlUpdateServing = "UPDATE tblfooditems SET serving = serving + 1 WHERE itemID = '$itemID'";
            $resultUpdateServing = mysqli_query($conn, $sqlUpdateServing);

            if (!$resultUpdateServing) {
                throw new Exception();
            }

            // Check if serving is greater than 0, set availability and dishStatus
            $sqlCheckServing = "SELECT serving FROM tblfooditems WHERE itemID = '$itemID'";
            $resultCheckServing = mysqli_query($conn, $sqlCheckServing);

            if (!$resultCheckServing) {
                throw new Exception();
            }

            $currentServing = mysqli_fetch_assoc($resultCheckServing)['serving'];

            if ($currentServing > 0) {
                // Set availability to Available and dishStatus to In Stock
                $sqlUpdateStatus = "UPDATE tblfooditems SET availability = 'Available', dishStatus = 'In Stock' WHERE itemID = '$itemID'";
                $resultUpdateStatus = mysqli_query($conn, $sqlUpdateStatus);

                if (!$resultUpdateStatus) {
                    throw new Exception();
                }

                // Check if the item is part of any menu package
                $sqlCheckMenuPackageItem = "SELECT packageID FROM tblmenupackageitems WHERE itemID = '$itemID'";
                $resultCheckMenuPackageItem = mysqli_query($conn, $sqlCheckMenuPackageItem);

                if ($resultCheckMenuPackageItem) {
                    while ($packageRow = mysqli_fetch_assoc($resultCheckMenuPackageItem)) {
                        // Check the total number of items in the package
                        $sqlCountPackageItems = "SELECT COUNT(*) AS total_items FROM tblmenupackageitems WHERE packageID = '{$packageRow['packageID']}'";
                        $resultCountPackageItems = mysqli_query($conn, $sqlCountPackageItems);
                
                        if ($resultCountPackageItems) {
                            $totalItemsCount = mysqli_fetch_assoc($resultCountPackageItems)['total_items'];
                
                            // Check if all items in the package are 'Available'
                            $sqlCheckPackageAvailability = "SELECT COUNT(fi.itemID) AS available_items
                                                          FROM tblfooditems fi
                                                          INNER JOIN tblmenupackageitems mpi ON fi.itemID = mpi.itemID
                                                          WHERE mpi.packageID = '{$packageRow['packageID']}' AND fi.availability = 'Available'";
                            $resultCheckPackageAvailability = mysqli_query($conn, $sqlCheckPackageAvailability);
                
                            if ($resultCheckPackageAvailability) {
                                $availableItemsCount = mysqli_fetch_assoc($resultCheckPackageAvailability)['available_items'];
                
                                if ($availableItemsCount === $totalItemsCount) {
                                    // If all items in the package are 'Available', set the menu package availability to 'Available'
                                    $sqlUpdateMenuPackageAvailability = "UPDATE tblmenupackage SET availability = 'Available' WHERE packageID = '{$packageRow['packageID']}'";
                                    $resultUpdateMenuPackageAvailability = mysqli_query($conn, $sqlUpdateMenuPackageAvailability);
                
                                    if (!$resultUpdateMenuPackageAvailability) {
                                        throw new Exception();
                                    }
                                }
                            }
                        }
                    }
                }                
            }
        }

        // Check if newQuantity is 0, and delete the row
        if ($newQuantity === 0) {
            $sqlDeleteOrderItem = "DELETE FROM tblorderdetails WHERE orderDetailsID = '$escapedOrderDetailsID'";
            $resultDeleteOrderItem = mysqli_query($conn, $sqlDeleteOrderItem);

            if (!$resultDeleteOrderItem) {
                throw new Exception();
            }
        }

        // Check if all items with the same orderID are canceled
        $sqlCheckAllCanceled = "SELECT COUNT(*) AS itemCount FROM tblorderdetails WHERE orderID = '$orderID'";
        $resultCheckAllCanceled = mysqli_query($conn, $sqlCheckAllCanceled);

        if (!$resultCheckAllCanceled) {
            throw new Exception();
        }

        $rowItemCount = mysqli_fetch_assoc($resultCheckAllCanceled)['itemCount'];

        if ($rowItemCount === 0) {
            // If all items are canceled, set isOccupied to 0 in tbltable
            $sqlUpdateTable = "UPDATE tbltable SET isOccupied = 0 WHERE orderID = '$orderID'";
            $resultUpdateTable = mysqli_query($conn, $sqlUpdateTable);

            if (!$resultUpdateTable) {
                throw new Exception();
            }

            // Delete the corresponding row in tblorders
            $sqlDeleteOrder = "DELETE FROM tblorders WHERE orderID = '$orderID'";
            $resultDeleteOrder = mysqli_query($conn, $sqlDeleteOrder);

            if (!$resultDeleteOrder) {
                throw new Exception();
            }
        }

        // Update the totalAmount in tblorders
        $sqlUpdateTotalAmount = "UPDATE tblorders SET totalAmount = (SELECT SUM(Amount) FROM tblorderdetails WHERE orderID = '$orderID') WHERE orderID = '$orderID'";
        $resultUpdateTotalAmount = mysqli_query($conn, $sqlUpdateTotalAmount);

        if (!$resultUpdateTotalAmount) {
            throw new Exception();
        }

        // Commit the transaction if everything was successful
        mysqli_commit($conn);

        // Return an empty string to indicate success
        return "";
    } catch (Exception $e) {
        // Rollback the transaction on exception
        mysqli_rollback($conn);

        // Return a generic error message
        return "Error cancelling order item.";
    }
}

    public function totalOrders()
    {
        global $conn; // Assuming $conn is your database connection

        $sqlQuery = "SELECT COUNT(*) as totalOrders FROM tblorders";
        $result = mysqli_query($conn, $sqlQuery);

        if (!$result) {
            // Handle the error here
            die("Error: " . mysqli_error($conn));
        }

        $row = mysqli_fetch_assoc($result);
        $totalOrders = $row['totalOrders'];

        return $totalOrders;
    }

    public function getOrdersCount($status)
    {
        global $conn; // Assuming $conn is your database connection

        $query = '';
        if ($status) {
            $query = " WHERE orderStatus = '" . $status . "'";
        }

        $sqlQuery = "SELECT COUNT(*) as ordersCount FROM tblorders" . $query;
        $result = mysqli_query($conn, $sqlQuery);

        if (!$result) {
            // Handle the error here
            die("Error: " . mysqli_error($conn));
        }

        $row = mysqli_fetch_assoc($result);
        $ordersCount = $row['ordersCount'];

        return $ordersCount;
    }
}
