<?php
if (isset($_POST['sendSMS'])) {
    $apiKey = 'b777acf5366b88c52f3ea56938ece85b';
    $name = $_POST["retName"];
    $message = "Hi, $name!
    We now have a table ready for you! Feel free to visit our restaurant, and we'll be delighted to serve you! Kindly note that the reservation is valid for a maximum of 15 minutes. 
    Thank you.";
    $contactNumber = $_POST["retcontactNumber"];

    // Validate and send SMS
    if (!empty($message) && !empty($contactNumber)) {
        sendSemaphoreMessage($apiKey, $message, $contactNumber);
    } else {
        echo "Please fill in both Message and Contact Number fields.";
    }
}

// Function to send SMS using Semaphore API
function sendSemaphoreMessage($apiKey, $message, $contactNumber)
{
    $ch = curl_init();
    $apiUrl = "https://semaphore.co/api/v4/messages";
    $parameters = array(
        'apikey' => $apiKey,
        'number' => $contactNumber,
        'message' => $message,
        'sendername' => 'SCANNSAVOR'
    );

    curl_setopt($ch, CURLOPT_URL, $apiUrl);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($parameters));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

    $output = curl_exec($ch);

    if ($output === false) {
        echo "cURL error: " . curl_error($ch);
    } else {
        //echo "Server Response: " . $output;
        echo "<script>alert('Message successfully sent.');</script>";
    }

    curl_close($ch);
}
?>



<div id="retrieveWaitListModal" tabindex="-1" aria-hidden="true" class="hidden overflow-y-auto overflow-x-hidden fixed top-0 right-0 left-0 z-50 justify-center items-center w-full md:inset-0 h-[calc(100%-1rem)] max-h-full flex">
    <div class="relative p-4 w-full max-w-2xl max-h-full">
        <form method="post" action="">
            <!-- Modal content -->
            <div class="relative p-4 bg-white rounded-lg shadow sm:p-5">
                <!-- Modal header -->
                <div class="flex justify-between items-center pb-4 mb-4 rounded-t border-b sm:mb-5">
                    <h3 class="text-lg font-semibold text-gray-900">Add Waiting List</h3>
                    <button type="button" class="text-teal-400 bg-transparent hover:bg-teal-200 hover:text-teal-900 rounded-lg text-sm p-1.5 ml-auto inline-flex items-center" data-modal-target="retrieveWaitListModal" data-modal-hide="retrieveWaitListModal">
                        <svg aria-hidden="true" class="w-5 h-5" fill="currentColor" viewbox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                            <path fill-rule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clip-rule="evenodd" />
                        </svg>
                        <span class="sr-only">Close modal</span>
                    </button>
                </div>
                <!-- Modal body -->
                <div class="grid gap-4 mb-4 sm:grid-cols-1">
                    <div>
                        <label for="retName" class="block mb-2 text-sm font-medium text-gray-900">Name</label>
                        <input type="text" name="retName" id="retName" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5" placeholder="" autocomplete="off" value="" readonly>
                    </div>
                    <div>
                        <label for="retcontactNumber" class="block mb-2 text-sm font-medium text-gray-900">Contact Number</label>
                        <input type="text" name="retcontactNumber" id="retcontactNumber" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5" placeholder="" autocomplete="off" value="" readonly>
                    </div>
                    <div>
                        <label for="retnoOfSeats" class="block mb-2 text-sm font-medium text-gray-900">No. of Seats</label>
                        <input type="text" name="retnoOfSeats" id="retnoOfSeats" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5" placeholder="" autocomplete="off" value="" readonly>
                    </div>
                </div>
                <div class="display flex justify-content flex-end">
                    <button type="submit" class="text-teal-800 inline-flex items-end justify-end hover:text-white border border-teal-800 hover:bg-teal-800 focus:ring-4 focus:outline-none focus:ring-teal-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center" name="sendSMS" value="sendSMS">
                        Send Message
                    </button>
                </div>
            </div>
        </form>
    </div>
</div>



<script>
    // function retrieveWaitListModal(button) {
    //     // Retrieve data from the clicked button
    //     var waitingId = button.getAttribute("data-waiting-id");
    //     var name = button.getAttribute("data-name");
    //     var contactNo = button.getAttribute("data-contact-no");
    //     var noOfSeats = button.getAttribute("data-no-of-seats");
    //     var status = button.getAttribute("data-status");

    //     // Show the modal
    //     var modal = document.getElementById("retrieveWaitListModal");
    //     modal.classList.remove("hidden");

    //     // Populate the input fields in the modal with the retrieved data
    //     document.getElementById("retName").value = name;
    //     document.getElementById("retcontactNumber").value = contactNo;
    //     document.getElementById("retnoOfSeats").value = noOfSeats;

    //     // Additional actions if needed
    //     // ...

    //     // You can customize this part based on your modal implementation
    // }
</script>