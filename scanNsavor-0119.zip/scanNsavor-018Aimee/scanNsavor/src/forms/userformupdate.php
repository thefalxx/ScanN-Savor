<?php

if (isset($_POST['updateUserDetails'])) {
    // Get the form data
    $empAccID = $_POST['empAccID'];
    $firstName = $_POST['firstName'];
    $lastName = $_POST['lastName'];
    $username = $_POST['updateusername'];
    $type = $_POST['updatetype'];
    $roleID = $_POST['updateroleID'];
    $status = $_POST['updatestatus'];

    // Check if a new password has been provided
    if (!empty($_POST['updatepassword'])) {
        $password = $_POST['updatepassword'];
        // Hash the password
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
    }

    // Check if a new username is provided
    if (!empty($username)) {
        // Check if the username already exists
        $checkUsernameQuery = "SELECT empAccID FROM tblemployees WHERE username = ? AND empAccID != ?";
        $checkUsernameStmt = $conn->prepare($checkUsernameQuery);
        $checkUsernameStmt->bind_param("si", $username, $empAccID);
        $checkUsernameStmt->execute();
        $checkUsernameResult = $checkUsernameStmt->get_result();

        if ($checkUsernameResult->num_rows > 0) {
            echo "<script>alert('Username already exists. Please choose a different username.');</script>";
            exit; // Stop execution if the username already exists
        }
    }

    // Prepare and execute the update statement
    if (isset($hashedPassword)) {
        // Update the user data including the hashed password
        $updateQuery = "UPDATE tblemployees SET firstName=?, lastName=?, username=?, password=?, type=?, roleID=?, status=? WHERE empAccID=?";
        $updateStmt = $conn->prepare($updateQuery);

        if ($updateStmt === false) {
            die('Error preparing update statement: ' . $conn->error);
        }

        $updateStmt->bind_param("sssssssi", $firstName, $lastName, $username, $hashedPassword, $type, $roleID, $status, $empAccID);
    } else {
        // Update the user data without changing the password
        $updateQuery = "UPDATE tblemployees SET firstName=?, lastName=?, username=?, type=?, roleID=?, status=? WHERE empAccID=?";
        $updateStmt = $conn->prepare($updateQuery);

        if ($updateStmt === false) {
            die('Error preparing update statement: ' . $conn->error);
        }

        $updateStmt->bind_param("ssssssi", $firstName, $lastName, $username, $type, $roleID, $status, $empAccID);
    }

    // Execute the update statement
    if ($updateStmt->execute()) {
        echo "<script>alert('Record updated successfully');</script>";
    } else {
        echo "<script>alert('Error updating record: " . $updateStmt->error . "');</script>";
    }

    // Close the statements
    $checkUsernameStmt->close();
    $updateStmt->close();

    // Close the connection
    $conn->close();
} else {
    echo "No POST request detected.";
}
?>






<div id="updateUserModal" aria-hidden="true" class="hidden overflow-y-auto overflow-x-hidden fixed top-0 right-0 left-0 z-50 justify-center items-center w-full md:inset-0 h-[calc(100%-1rem)] max-h-full">
    <div class="relative p-4 w-full max-w-2xl max-h-full">
        <!-- Modal content -->
        <div class="relative p-4 bg-white rounded-lg shadow ">
            <!-- Modal header -->
            <div class="flex justify-between items-center pb-4 mb-4 rounded-t border-b sm:mb-5">
                <h3 class="text-lg font-semibold text-gray-900">Update User</h3>
                <button type="button" class="text-gray-400 bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm p-1.5 ml-auto inline-flex items-center" data-modal-toggle="updateUserModal">
                    <svg aria-hidden="true" class="w-5 h-5" fill="currentColor" viewbox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                        <path fill-rule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clip-rule="evenodd" />
                    </svg>
                    <span class="sr-only" onclick="closeModalUpdate()">Close modal</span>
                </button>
            </div>
            <!-- Modal body -->
            <form method="post" id="">
                <?php if ($message != '') { ?>
                    <div class="mb-4 rounded-lg bg-success-100 px-6 py-5 text-base text-success-700" role="alert">
                        <?php echo $message; ?></div>
                <?php } ?>
                <!-- <label name="userID" id="userID"> ID </label> -->
                <input type="text" name="empAccID" id="empAccID" class="hidden">
                <div class="grid gap-4 mb-4 sm:grid-cols-2">
                    <div>
                        <label for="firstName" class="block mb-2 text-sm font-medium text-gray-900">First Name</label>
                        <input type="text" name="firstName" id="firstName" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5" placeholder="" value="">
                    </div>
                    <div>
                        <label for="editLastName" class="block mb-2 text-sm font-medium text-gray-900">Last Name</label>
                        <input type="text" name="lastName" id="lastName" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5" placeholder="" value="">
                    </div>
                    <div>
                        <label for="editUsername" class="block mb-2 text-sm font-medium text-gray-900">Username</label>
                        <input type="text" name="updateusername" id="updateusername" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5" placeholder="" value="">
                    </div>
                    <div>
                        <label for="editPassword" class="block mb-2 text-sm font-medium text-gray-900">Password</label>
                        <input type="password" name="updatepassword" id="updatepassword" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5" placeholder="" autocomplete="off" value="">
                    </div>

                    <div><label for="editType" class="block mb-2 text-sm font-medium text-gray-900">User Type</label>
                        <select id="updatetype" name="updatetype" placeholder="User Type" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-500 focus:border-primary-500 block w-full p-2.5">
                            <option selected=""></option>
                            <option value="Admin">Administrator</option>
                            <option value="General">General User</option>
                        </select>
                    </div>

                    <div><label for="updateroleID" class="block mb-2 text-sm font-medium text-gray-900">Position</label>
                        <select id="updateroleID" name="updateroleID" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-500 focus:border-primary-500 block w-full p-2.5">
                            <option selected></option>
                            <?php
                            foreach ($roleData as $role) {
                                echo "<option value='{$role['roleID']}'>{$role['position']}</option>";
                            }
                            ?>
                        </select>
                    </div>

                    <div><label class="block mb-2 text-sm font-medium text-gray-900">Status</label>
                        <div class="flex flex-wrap">
                            <div class="flex items-center mr-4">
                                <input type="radio" value="inactive" id="updatestatus" name="updatestatus" class="w-4 h-4 text-red-600 bg-gray-100 border-gray-300 focus:ring-red-500">
                                <label for="red-radio" class="ml-2 text-sm font-medium text-gray-900">Inactive</label>
                            </div>
                            <div class="flex items-center mr-4">
                                <input type="radio" value="pending" id="updatestatus" name="updatestatus" class="w-4 h-4 text-yellow-400 bg-gray-100 border-gray-300 focus:ring-yellow-500">
                                <label for="yellow-radio" class="ml-2 text-sm font-medium text-gray-900">Pending</label>
                            </div>
                            <div class="flex items-center mr-4">
                                <input type="radio" value="active" id="updatestatus" name="updatestatus" class="w-4 h-4 text-green-600 bg-gray-100 border-gray-300 focus:ring-green-500">
                                <label for="green-radio" class="ml-2 text-sm font-medium text-gray-900">Active</label>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="flex items-center space-x-4 ">
                    <!-- <button type="submit" class="bg-teal-700 hover:bg-primary-800 text-teal-800 focus:ring-2 focus:outline-none focus:ring-teal-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center">Update User</button> -->
                    <button type="submit" name="updateUserDetails" id="updateUserDetails" class="text-teal-800 inline-flex items-center hover:text-white border border-teal-800 hover:bg-teal-800 focus:ring-4 focus:outline-none focus:ring-teal-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center" onclick="showUpdateUserMessageModal()">Update User</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php if ($message != '') { ?>
    <div id="UpdateUserMessageModal" class="bg-white border-2 border-black text-black w-80 h-32 px-4 py-14 rounded-lg relative justify-center items-center text-center" role="alert" style="position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%); z-index: 999;">
        <strong class="font-bold"> <?php echo $message; ?></strong>
        <span class="absolute top-0 bottom-0 right-0 px-4 py-3" onclick="closeUpdateUserMessageModal()">
            <svg class="fill-current h-6 w-6 text-teal-800" role="button" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20">
                <title>Close</title>
                <path d="M14.348 14.849a1.2 1.2 0 0 1-1.697 0L10 11.819l-2.651 3.029a1.2 1.2 0 1 1-1.697-1.697l2.758-3.15-2.759-3.152a1.2 1.2 0 1 1 1.697-1.697L10 8.183l2.651-3.031a1.2 1.2 0 1 1 1.697 1.697l-2.758 3.152 2.758 3.15a1.2 1.2 0 0 1 0 1.698z" />
            </svg>
        </span>
    </div>
<?php } ?>



<script>
    function showUpdateUserMessageModal() {
        var modal = document.getElementById('UpdateUserMessageModal');
        modal.style.display = 'block';
    }
</script>

<script>
    UpdateUseryMessageModal

    function closeUpdateUserMessageModal() {
        var modal = document.getElementById('UpdateUserMessageModal');
        modal.style.display = 'none';
    }
</script>