<?php
global $conn;

if (isset($_POST['updateItemDetails'])) {
    $itemID = $_POST['itemID'];
    $itemName = $_POST['updateItemName'];
    $updatecategoryID = $_POST['updatecategoryID'];
    $updateprice = $_POST['updateprice'];
    $updateDescription = $_POST['updateItemDescription'];
    $updatePax = $_POST['updatePax'];
    $updateAvailability = $_POST['updateItemAvailability'];

    // Retrieve existing item details
    $query = "SELECT * FROM tblfooditems WHERE itemID='$itemID'";
    $result = mysqli_query($conn, $query);

    if ($result) {
        $item = mysqli_fetch_assoc($result);
    }

    // Display the existing image in the form
    $existingImageSrc = isset($item['itemImage']) ? $item['itemImage'] : '';

    // Check if a new image is provided
    if (isset($_FILES['updateItemImage']) && $_FILES['updateItemImage']['size'] > 0) {
        // Handle the file upload
        $errors = array();
        $file_name = $_FILES['updateItemImage']['name'];
        $file_size = $_FILES['updateItemImage']['size'];
        $file_tmp = $_FILES['updateItemImage']['tmp_name'];
        $file_type = $_FILES['updateItemImage']['type'];
        $file_parts = explode('.', $_FILES['updateItemImage']['name']);
        $file_ext = strtolower(end($file_parts));

        $extensions = array("jpeg", "jpg", "png");

        if (in_array($file_ext, $extensions) === false) {
            $errors[] = "Extension not allowed, please choose a JPEG or PNG file.";
        }

        if ($file_size > 2097152) {
            $errors[] = 'File size must be exactly 2 MB';
        }

        if (empty($errors) == true) {
            $image_path = "../../images/foodItemsImages/" . $file_name;
            if (move_uploaded_file($file_tmp, $image_path)) {
                // Update query with the new image path
                $query = "UPDATE tblfooditems SET itemName='$itemName', categoryID='$updatecategoryID', price='$updateprice', pax = '$updatePax', description = '$updateDescription', availability = '$updateAvailability', itemImage = '$image_path' WHERE itemID='$itemID'";
            } else {
                echo "Failed to move uploaded file.";
            }
        } else {
            print_r($errors);
        }
    } else {
        // Update query without changing the image
        $query = "UPDATE tblfooditems SET itemName='$itemName', categoryID='$updatecategoryID', price='$updateprice', pax = '$updatePax', description = '$updateDescription', availability = '$updateAvailability' WHERE itemID='$itemID'";
    }

    // Execute the update query
    $result = mysqli_query($conn, $query);

    if ($result) {
        // echo "Successfully updated data.";
    } else {
        echo "Failed to update data.";
    }
}
?>

<div id="updateMenuModal" tabindex="-1" aria-hidden="true" class="hidden overflow-y-auto overflow-x-hidden fixed top-0 right-0 left-0 z-50 justify-center items-center w-full md:inset-0 h-[calc(100%-1rem)] md:h-full">
    <div id="overlay"></div>
    <div class="relative p-4 w-full max-w-2xl h-full md:h-auto">
        <!-- Modal content -->
        <div class="relative p-4 bg-white rounded-lg shadow">
            <!-- Modal header -->
            <form method="post" enctype="multipart/form-data">
                <?php if ($message != '') { ?>
                    <div class="mb-4 rounded-lg bg-success-100 px-6 py-5 text-base text-success-700" role="alert">
                        <?php echo $message; ?></div>
                <?php } ?>
                <label name="menuID" id="menuID" hidden> ID </label>
                <input type="text" name="itemID" id="itemID" hidden>
                <div class="flex justify-between items-center pb-4 mb-4 rounded-t border-b sm:mb-5">
                    <h3 class="text-lg font-semibold text-gray-900">Update Menu</h3>
                    <button type="button" class="text-gray-400 bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm p-1.5 ml-auto inline-flex items-center" data-modal-toggle="updateMenuModal">
                        <svg aria-hidden="true" class="w-5 h-5" fill="currentColor" viewbox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                            <path fill-rule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clip-rule="evenodd" />
                        </svg>
                        <span class="sr-only">Close modal</span>
                    </button>
                </div>


                <!-- Modal body -->
                <form method="post">
                    <div class="grid gap-4 mb-4 sm:grid-cols-2">
                        <div>
                            <label for="updateItemName" class="block mb-2 text-sm font-medium text-gray-900">Dish Name</label>
                            <input type="text" name="updateItemName" id="updateItemName" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-green-200 focus:border-green-200 block w-full p-2.5" placeholder="Type dish name" required="">
                        </div>

                        <div><label for="updatecategoryID" class="block mb-2 text-sm font-medium text-gray-900">Category</label>
                            <select id="updatecategoryID" name="updatecategoryID" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-green-200 focus:border-green-200 block w-full p-2.5">
                                <option value="" disabled selected></option>
                                <?php

                                foreach ($categoryData as $category) {
                                    echo "<option value='{$category['categoryID']}'>{$category['categoryName']}</option>";
                                }
                                ?>

                            </select>
                        </div>

                        <div>
                            <label for="updateprice" class="block mb-2 text-sm font-medium text-gray-900">Price</label>
                            <input type="number" name="updateprice" id="updateprice" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-green-200 focus:border-green-200 block w-full p-2.5" placeholder="" required="">
                        </div>

                        <div>
                            <label for="updatePax" class="block mb-2 text-sm font-medium text-gray-900">Good for</label>
                            <select id="updatePax" name="updatePax" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-green-200 focus:border-green-200 block w-full p-2.5" placeholder="" required="">
                                <option selected=""></option>
                                <option value="1">1 person</option>
                                <option value="2">2 persons</option>
                                <option value="3">3 persons</option>
                                <option value="4">4 persons</option>
                                <option value="5">5 persons</option>
                                <option value="Family">Family</option>
                            </select>
                        </div>

                        <div class=""><label for="updateItemDescription" class="block mb-2 text-sm font-medium text-gray-900">Description</label>
                            <textarea id="updateItemDescription" name="updateItemDescription" rows="4" class="block p-2.5 w-full text-sm text-gray-900 bg-gray-50 rounded-lg border border-gray-300 focus:ring-green-200 focus:border-green-200" placeholder="Write dish description here"></textarea>
                        </div>

                        <div>
                            <label for="updateItemAvailability" class="block mb-2 text-sm font-medium text-gray-900">Availability</label>
                            <!-- <div class="pt-4">
                                <label for="toggle-avail" class="flex items-center cursor-pointer relative mb-4">
                                    <input type="checkbox" id="toggle-avail" class="sr-only">
                                    <div class="toggle-bg bg-gray-200 border-2 border-gray-200 h-6 w-11 rounded-full transition duration-300"></div>
                                    <span class="status-label ml-2 text-gray-900 text-sm">Unavailable</span>
                                </label>
                            </div> -->
                            <select id="updateItemAvailability" name="updateItemAvailability" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-green-200 focus:border-green-200 block w-full p-2.5 mb-4" placeholder="" required="">
                                <option selected=""></option>
                                <option value="Available">Available</option>
                                <option value="Unavailable">Unavailable</option>
                            </select>
                        </div>

                    </div>
                    <!-- <div class="mb-4 max-w-2xl mx-auto">
                        <span class="block mb-3 text-sm font-medium text-gray-900">Dish Image<span class="font-light pl-3">(Click the existing image to replace and upload new image)</span></span>
                        <div class="flex items-center justify-center w-full">
                            <label for="updateItemImage" class="flex flex-col justify-center items-center w-full h-80 bg-gray-50 rounded-lg border-2 border-gray-300 border-dashed cursor-pointer" id="imagePreview">
                                <img id="upItemImage" class="object-contain min-w-full min-h-full max-w-full max-h-full p-2" name="upItemImage" src="<?php echo $item['itemImage']; ?>" alt="Existing Image" class="w-44 h-20 mb-3" />
                                <input id="updateItemImage" name="updateItemImage" type="file" accept="image/*" onchange="previewImage()" />
                            </label>
                        </div>
                    </div> -->

                    <div class="mb-4 max-w-2xl mx-auto">
                        <span class="block mb-2 text-sm font-medium text-gray-900">Dish Image</span>
                        <div class="flex items-center justify-center w-full">
                            <label for="updateItemImage" class="flex flex-col items-center justify-center w-full h-64 border-2 border-gray-300 border-dashed rounded-lg cursor-pointer bg-gray-50 dark:hover:bg-bray-800 dark:bg-gray-700 hover:bg-gray-100 dark:border-gray-600 dark:hover:border-gray-500 dark:hover:bg-gray-600">
                                <div class="flex flex-col items-center justify-center pt-5 pb-5">
                                    <img id="upItemImage" name="upItemImage" src="<?php echo $item['itemImage']; ?>" alt="Existing Image" class="w-48 h-28 mb-3" />
                                    <p class="mb-2 text-sm text-gray-500 dark:text-gray-400"><span class="font-semibold">Click to upload</span> or drag and drop</p>
                                    <p class="text-xs text-gray-500 dark:text-gray-400">SVG, PNG, JPG, or GIF (MAX. 800x400px)</p>
                                </div>
                                <div class="pb-5 pl-16">
                                    <input id="updateItemImage" name="updateItemImage" type="file" class="" accept="image/*" />
                                </div>
                            </label>
                        </div>
                    </div>

                    <div class="items-center space-y-4 sm:flex sm:space-y-4 sm:space-x-4">
                        <button type="submit" name="updateItemDetails" value="updateItemDetails" id="updateItemDetails" class="w-full sm:w-auto justify-center text-teal-800 inline-flex border border-gray-300 bg-teal-700 hover:bg-teal-800 hover:text-white focus:ring-4 focus:outline-none focus:ring-green-200 font-medium rounded-lg text-sm px-5 py-2.5 text-center" onclick="showmenuUpdateMessageModal()">
                            Update Menu
                        </button>
                        <!-- <button data-modal-toggle="createMenuModal" type="submit" class="w-full justify-center sm:w-auto text-gray-500 inline-flex items-center bg-white hover:bg-gray-100 focus:ring-green-200ring-4 focus:ring-green-200outline-none focus:ring-green-200ring-primary-300 rounded-lg border border-gray-200 text-sm font-medium px-5 py-2.5 hover:text-gray-900 focus:ring-green-200z-10">
                        <svg class="mr-1 -ml-1 w-5 h-5" fill="currentColor" viewbox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                            <path fill-rule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clip-rule="evenodd" />
                        </svg>
                        Discard
                    </button> -->
                    </div>
                </form>
        </div>
    </div>
</div>

<?php if ($message != '') { ?>
    <div id="menuUpdateMessageModal" class="bg-white border-2 border-black text-black w-80 h-32 px-4 py-14 rounded-lg relative justify-center items-center text-center" role="alert" style="position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%); z-index: 999;">
        <strong class="font-bold"> <?php echo $message; ?></strong>
        <span class="absolute top-0 bottom-0 right-0 px-4 py-3" onclick="closemenuUpdateMessageModal()">
            <svg class="fill-current h-6 w-6 text-teal-800" role="button" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20">
                <title>Close</title>
                <path d="M14.348 14.849a1.2 1.2 0 0 1-1.697 0L10 11.819l-2.651 3.029a1.2 1.2 0 1 1-1.697-1.697l2.758-3.15-2.759-3.152a1.2 1.2 0 1 1 1.697-1.697L10 8.183l2.651-3.031a1.2 1.2 0 1 1 1.697 1.697l-2.758 3.152 2.758 3.15a1.2 1.2 0 0 1 0 1.698z" />
            </svg>
        </span>
    </div>
<?php } ?>

<script>
    const toggleSwitch = document.getElementById('toggle-avail');
    const toggleBg = document.querySelector('.toggle-bg');
    const statusLabel = document.querySelector('.status-label');

    toggleSwitch.addEventListener('change', function() {
        if (toggleSwitch.checked) {
            toggleBg.classList.add('bg-teal-700');
            statusLabel.textContent = 'Available';
            statusLabel.classList.add('text-teal-700');
        } else {
            toggleBg.classList.remove('bg-teal-700');
            statusLabel.textContent = 'Unavailable';
            statusLabel.classList.remove('text-teal-700');
        }
    });
</script>

<script>
    function showmenuUpdateMessageModal() {
        var modal = document.getElementById('menuUpdateMessageModal');
        modal.style.display = 'block';
    }
</script>

<script>
    function closemenuUpdateMessageModal() {
        var modal = document.getElementById('menuUpdateMessageModal');
        modal.style.display = 'none';
    }
</script>

<script>
    function previewImage() {
        var fileInput = document.getElementById('fileToUpload');
        var imagePreview = document.getElementById('imagePreview');
        var previewImage = document.getElementById('upItemImage');

        if (fileInput.files && fileInput.files[0]) {
            var reader = new FileReader();

            reader.onload = function(e) {
                // Show image preview
                imagePreview.classList.remove('hidden');
                previewImage.src = e.target.result;
            };

            // Read the image file
            reader.readAsDataURL(fileInput.files[0]);
        }
    }
</script>