<?php
// Assuming you have a database connection established
global $conn;

// Check if the form was submitted
if (isset($_POST['deleteUserButton'])) {

    // Delete specific records from tblemployees
    $sqlDeleteEmployees = "DELETE FROM tblemployees WHERE empAccID != 1";

    if ($conn->query($sqlDeleteEmployees) === TRUE) {
        // Reset the auto-increment counter to start with 2
        $sqlResetAutoIncrement = "ALTER TABLE tblemployees AUTO_INCREMENT = 2";
        $conn->query($sqlResetAutoIncrement);

        $message = "Data deleted successfully";
    } else {
        $message = "Error deleting data: " . $conn->error;
    }
}

?>

<?php //if ($message != '') { 
?>
<!-- <div class="mb-4 rounded-lg bg-success-100 px-6 py-5 text-base text-success-700" role="alert"> -->
<?php //echo $message; 
?></div>
<?php //} 
?>

<div id="deleteUser-modal" tabindex="-1" class="fixed top-0 left-0 right-0 bottom-0 flex justify-center items-center z-50 hidden p-4 overflow-x-hidden overflow-y-auto">
    <div class="relative w-full h-auto max-w-md max-h-full">
        <div class="relative bg-white rounded-lg shadow">
            <button type="button" class="absolute top-3 right-2.5 text-gray-400 bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm p-1.5 ml-auto inline-flex items-center" data-modal-toggle="deleteUser-modal">
                <svg aria-hidden="true" class="w-5 h-5" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                    <path fill-rule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clip-rule="evenodd" />
                </svg>
                <span class="sr-only">Close modal</span>
            </button>
            <div class="p-6 text-center">
                <svg aria-hidden="true" class="mx-auto mb-4 text-gray-400 w-14 h-14" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                <h3 class="mb-5 text-lg font-normal text-gray-500">Are you sure you want to remove all the existing users?</h3>

                <form id="deleteForm" action="" method="POST">
                    <button id="deleteUserButton" name="deleteUserButton" type="submit" class="text-green-700 hover:text-white border hover:bg-teal-800 focus:ring-4 focus:outline-none focus:ring-teal-300 font-medium rounded-lg text-sm inline-flex items-center px-5 py-2.5 text-center mr-2" data-modal-hide="deleteUser-modal" onclick="showDeleteUpdateModal()">Delete</button>

                    <button class="text-red-700 hover:text-white hover:bg-red-800 focus-ring-4 focus-outline-none focus-ring-gray-200 rounded-lg border-gray-200 text-sm font-medium px-5 py-2.5 hover-text-gray-900 focus-z-10">Cancel</button>
                </form>


            </div>
        </div>
    </div>
</div>

<!-- <?php //if ($message != '') { 
        ?>
    <div id="delMessageModal" class="bg-white border-2 border-black text-black w-80 h-32 px-4 py-14 rounded-lg relative justify-center items-center text-center" role="alert" style="position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%); z-index: 999;">
        <strong class="font-bold"> <?php //echo $message; 
                                    ?></strong>
        <span class="absolute top-0 bottom-0 right-0 px-4 py-3" onclick="closeDeleteMessageModal()">
            <svg class="fill-current h-6 w-6 text-teal-800" role="button" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20">
                <title>Close</title>
                <path d="M14.348 14.849a1.2 1.2 0 0 1-1.697 0L10 11.819l-2.651 3.029a1.2 1.2 0 1 1-1.697-1.697l2.758-3.15-2.759-3.152a1.2 1.2 0 1 1 1.697-1.697L10 8.183l2.651-3.031a1.2 1.2 0 1 1 1.697 1.697l-2.758 3.152 2.758 3.15a1.2 1.2 0 0 1 0 1.698z" />
            </svg>
        </span>
    </div>
<?php //} 
?> -->



<script>
    function showDeleteUpdateModal() {
        var modal = document.getElementById('delMessageModal');
        modal.style.display = 'block';
    }
</script>

<script>
    UpdateUseryMessageModal

    function closeDeleteMessageModal() {
        var modal = document.getElementById('delMessageModal');
        modal.style.display = 'none';
    }
</script>