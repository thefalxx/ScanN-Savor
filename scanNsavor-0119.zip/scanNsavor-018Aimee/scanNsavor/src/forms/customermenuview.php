<?php
require '../class/Menu.php';
$menu = new Menu();
$message = $menu->addCategories();
$items = $menu->getAllItems();
$catMappings = $menu->fetchCategoryMappings();

?>

<div id="view-modal" tabindex="-1" class="fixed top-0 left-0 right-0 z-50 hidden w-full p-4 overflow-x-hidden overflow-y-auto md:inset-0 h-[calc(100%-1rem)] max-h-full">
    <div class="relative w-full max-w-md max-h-full">
        <!-- Modal content -->
        <div class="relative bg-white rounded-lg shadow">
            <!-- Modal header -->
            <div class="flex items-center justify-between p-5 border-b rounded-t">
                <h3 class="text-xl font-medium text-gray-900">
                    <?php
                    // name dapat sa order ang naa diri  
                    ?>
                </h3>
            </div>
            <!-- Modal body -->
            <div>
                <?php foreach ($items as $item) : ?>
                    <div class="w-full col-span-4 max-w-sm bg-white border border-gray-200 rounded-lg shadow">
                        <a href=" #">
                            <img class="p-8 rounded-t-lg" src="" alt="product image" />
                        </a>
                        <div class="px-5 pb-5">
                            <a href="#">
                                <h5 class="itemName pt-10 pb-10 text-xl font-semibold tracking-tight text-gray-900 "><?php echo $item['itemName']; ?></h5>
                            </a>
                            <div class="px-5 pb-5">
                                <a href="#">
                                    <h5 class="itemName pt-10 pb-10 text-sm font-semibold tracking-tight text-gray-900 "><?php echo $item['description']; ?></h5>
                                </a>
                                <div class="pb-2 flex items-center justify-between">
                                    <span class="text-3xl font-bold text-gray-900 ">₱<?php echo $item['price']; ?></span>
                                    <div class="flex flex-row self-center gap-1">
                                        <form method="POST" action="<?php echo $_SERVER["PHP_SELF"]; ?>">
                                            <button class="w-5 h-5 self-center border border-gray-300" name="decrement">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="#d1d5db" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                                    <path d="M5 12h14" />
                                                </svg>
                                            </button>
                                            <input type="text" readonly="readonly" value="<?php echo $noOfItems; ?>" class="w-8 h-8 text-center text-gray-900 text-sm outline-none border border-gray-300 rounded-sm">
                                            <button class="w-5 h-5 self-center border border-gray-300" name="increment">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="" stroke="#9ca3af" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                                    <path d="M12 5v14M5 12h14" />
                                                </svg>
                                            </button>
                                        </form>
                                        <?php
                                        // Initialize the item quantity if it doesn't exist in the session
                                        if (!isset($_SESSION["noOfItems"])) {
                                            $_SESSION["noOfItems"] = 0;
                                        }

                                        if ($_SERVER["REQUEST_METHOD"] == "POST") {
                                            if (isset($_POST["increment"])) {
                                                $_SESSION["noOfItems"]++;
                                            } elseif (isset($_POST["decrement"]) && $_SESSION["noOfItems"] > 0) {
                                                $_SESSION["noOfItems"]--;
                                            }
                                        }

                                        // Retrieve the item quantity from the session
                                        $noOfItems = $_SESSION["noOfItems"];
                                        ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>



            <!-- Modal footer -->
            <div class="flex items-center p-6 space-x-2 border-t border-gray-200 rounded-b dark:border-gray-600">
                <button data-modal-hide="view-modal" type="button" class="block w-full md:w-auto text-teal border border-gray-200 bg-teal-700 hover:bg-teal-800 hover:text-white focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center">Add to Cart</button>
                <button data-modal-hide="view-modal" type="button" class="text-gray-500 bg-white hover:bg-gray-100 focus:ring-4 focus:outline-none focus:ring-gray-200 rounded-lg border border-gray-200 text-sm font-medium px-5 py-2.5 hover:text-gray-900 focus:z-10 dark:bg-gray-700 dark:text-gray-300 dark:border-gray-500 dark:hover:text-white dark:hover:bg-gray-600 dark:focus:ring-gray-600">Cancel</button>
            </div>
        </div>
    </div>
</div>