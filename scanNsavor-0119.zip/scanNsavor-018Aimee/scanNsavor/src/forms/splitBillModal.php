<?php
global $conn;

$tableNo = '';
$orderID = '';
$totalSeats = 0;
$result = '';

if (isset($_GET['orderID'])) {
    $currentOrderID = $_GET['orderID'];

    // Your SQL query
    $sql = "SELECT * FROM tblorderdetails 
    INNER JOIN tblOrders ON tblOrders.orderID = tblorderdetails.orderID 
    LEFT JOIN tblfooditems ON tblfooditems.itemID = tblorderdetails.itemID 
    LEFT JOIN tblmenupackage ON tblmenupackage.packageID = tblorderdetails.packageID
    LEFT JOIN tbltable ON tbltable.tableNo = tblOrders.tableNo
    WHERE tblorderdetails.orderID = $currentOrderID";

    // Prepare and execute the query
    $result = $conn->query($sql);

    // Check if there are any results
    if ($result && $result->num_rows > 0) {
        foreach ($result as $data) {
            $tableNo = $data['tableNo'];
            $orderID = $data['orderID'];
            $totalAmount = $data['totalAmount'];
            $orderStatus = $data['orderStatus'];
            $totalSeats = $data['noOfSeats'];
        }
    } else {

        // echo "No data found for orderID: $currentOrderID";
    }
} else {

    echo "OrderID is not set.";
}
?>

<div id="splitBillModal" tabindex="-1" class="fixed top-0 left-0 right-0 bottom-0 flex justify-center items-center z-50 hidden p-4 overflow-x-hidden overflow-y-auto">
    <div class="relative w-full h-auto max-w-md max-h-full">
        <div class="relative bg-white rounded-lg shadow">
            <button type="button" onclick="toggleModal('splitBillModal')" class="absolute top-3 right-2.5 text-gray-400 bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm p-1.5 ml-auto inline-flex items-center" data-modal-toggle="splitBillModal">
                <svg aria-hidden="true" class="w-5 h-5" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                    <path fill-rule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clip-rule="evenodd" />
                </svg>
                <span class="sr-only">Close modal</span>
            </button>
            <div class="p-6 text-center">
                <svg aria-hidden="true" class="mx-auto mb-4 text-teal-800 w-14 h-14" stroke="currentColor" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <g id="SVGRepo_bgCarrier" stroke-width="0"></g>
                    <g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g>
                    <g id="SVGRepo_iconCarrier">
                        <path d="M17.625 21.0002C18.2666 20.4299 19.2334 20.4299 19.875 21.0002C20.3109 21.3876 21 21.0782 21 20.495V3.50519C21 2.92196 20.3109 2.61251 19.875 2.99999C19.2334 3.57029 18.2666 3.57029 17.625 2.99999C16.9834 2.42969 16.0166 2.42969 15.375 2.99999C14.7334 3.57029 13.7666 3.57029 13.125 2.99999C12.4834 2.42969 11.5166 2.42969 10.875 2.99999C10.2334 3.57029 9.26659 3.57029 8.625 2.99999C7.98341 2.42969 7.01659 2.42969 6.375 2.99999C5.73341 3.57029 4.76659 3.57029 4.125 2.99999C3.68909 2.61251 3 2.92196 3 3.50519V20.495C3 21.0782 3.68909 21.3876 4.125 21.0002C4.76659 20.4299 5.73341 20.4299 6.375 21.0002C7.01659 21.5705 7.98341 21.5705 8.625 21.0002C9.26659 20.4299 10.2334 20.4299 10.875 21.0002C11.5166 21.5705 12.4834 21.5705 13.125 21.0002C13.7666 20.4299 14.7334 20.4299 15.375 21.0002C16.0166 21.5705 16.9834 21.5705 17.625 21.0002Z" stroke-width="1.2"></path>
                        <path d="M7.5 15.5H16.5" stroke-width="1.2" stroke-linecap="round"></path>
                        <path d="M7.5 12H16.5" stroke-width="1.2" stroke-linecap="round"></path>
                        <path d="M7.5 8.5H16.5" stroke-width="1.2" stroke-linecap="round"></path>
                    </g>
                </svg>
                <!-- <svg aria-hidden="true" class="mx-auto mb-4 text-gray-400 w-14 h-14" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg> -->
                <h3 class="mb-5 text-lg font-normal text-gray-500">Do you want to split your bill?</h3>


                <button class="text-green-700 hover:text-white border hover:bg-teal-800 focus:ring-4 focus:outline-none focus:ring-teal-300 font-medium rounded-lg text-sm inline-flex items-center px-5 py-2.5 text-center mr-2" id="vieworderSummaryButton" data-modal-toggle="noOfPeopleModal" data-modal-hide="splitBillModal">Yes</button>
                <a href="../viewCustomer/nameForPayment.php?tableNo=<?php echo $tableNo; ?>" id="billOutButton">
                    <button class="text-gray-700 hover:text-white  hover:bg-gray-400 focus-ring-4 focus-outline-none focus-ring-gray-200 rounded-lg  border-gray-200 text-sm font-medium px-5 py-2.5 hover-text-gray-900 focus-z-10">No</button>
                </a>
            </div>
        </div>
    </div>
</div>


<div id="noOfPeopleModal" tabindex="-1" class="fixed top-0 left-0 right-0 bottom-0 flex justify-center items-center z-50 hidden p-4 overflow-x-hidden overflow-y-auto">
    <div class="relative w-full h-auto max-w-md max-h-full">
        <div class="relative bg-white rounded-lg shadow">
            <button type="button" onclick="toggleModal('noOfPeopleModal')" class="absolute top-3 right-2.5 text-gray-400 bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm p-1.5 ml-auto inline-flex items-center" data-modal-toggle="noOfPeopleModal">
                <svg aria-hidden="true" class="w-5 h-5" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                    <path fill-rule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clip-rule="evenodd" />
                </svg>
                <span class="sr-only">Close modal</span>
            </button>
            <div class="p-6 text-center justify-center">
                <h1 class="mt-5 mb-3 text-lg font-normal text-gray-500">Enter number of people to split the bill. </h1>
                <div class="justify-center items-center my-5 mx-36">
                    <input type="number" name="noOfPeople" id="noOfPeople" class="bg-gray-50 border border-teal-700 text-teal-700 text-md font-medium rounded-lg focus:ring-teal-200 focus:border-teal-600 block w-full p-2.5 placeholder-teal-700 text-center" placeholder="" autocomplete="off" value="1" min="1" max="<?php echo $totalSeats; ?>" required>
                </div>

                <button class="text-green-700 hover:text-white border hover:bg-teal-800 focus:ring-4 focus:outline-none focus:ring-teal-300 font-medium rounded-lg text-sm inline-flex items-center px-5 py-2.5 text-center mr-2" id="buttonOKSplitBill" onclick="submitForm()">OK</button>
            </div>
        </div>
    </div>
</div>

<script>
    var totalSeats = <?php echo $totalSeats; ?>;

    document.getElementById('noOfPeople').addEventListener('input', function(event) {
        var inputValue = event.target.value;

        inputValue = inputValue.replace(/^0+/, '') || '0';
        event.target.value = inputValue;

        // Check for negative or decimal values
        if (inputValue < 0 || inputValue % 1 !== 0) {
            alert("Please enter a non-negative integer value.");
            event.target.value = '';
        }

        // Check if the input exceeds the number of seats
        if (inputValue > totalSeats) {
            alert("Number of people cannot exceed the available seats.");
            event.target.value = totalSeats; // Reset to the maximum available seats
        }
    });
</script>

<script>
    function submitForm() {
        // Get the value of noOfPeople
        var noOfPeople = document.getElementById('noOfPeople').value;

        // Redirect to nameForPayment.php with the noOfPeople parameter
        window.location.href = '../viewCustomer/nameForPayment.php?tableNo=<?php echo $tableNo; ?>&noOfPeople=' + noOfPeople;
    }
</script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/flowbite/1.8.0/flowbite.min.js"></script>