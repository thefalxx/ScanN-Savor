<?php
include '../class/GeneratePassword.php';
?>


<div id="createUserModal" tabindex="-1" aria-hidden="true" class="hidden overflow-y-auto overflow-x-hidden fixed top-0 right-0 left-0 z-50 justify-center items-center w-full md:inset-0 h-[calc(100%-1rem)] max-h-full">
    <div class="relative p-4 w-full max-w-2xl max-h-full">
        <!-- Modal content -->
        <div class="relative p-4 bg-white rounded-lg shadow sm:p-5">
            <!-- Modal header -->
            <div class="flex justify-between items-center pb-4 mb-4 rounded-t border-b sm:mb-5">
                <h3 class="text-lg font-semibold text-gray-900">Add User</h3>
                <button type="button" class="text-teal-400 bg-transparent hover:bg-teal-200 hover:text-teal-900 rounded-lg text-sm p-1.5 ml-auto inline-flex items-center" data-modal-target="createUserModal" data-modal-toggle="createUserModal">
                    <svg aria-hidden="true" class="w-5 h-5" fill="currentColor" viewbox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                        <path fill-rule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clip-rule="evenodd" />
                    </svg>
                    <span class="sr-only">Close modal</span>
                </button>
            </div>
            <!-- Modal body -->
            <form method="post">
                <?php if ($message != '') { ?>
                    <div class="mb-4 rounded-lg bg-success-100 px-6 py-5 text-base text-success-700" role="alert">
                        <?php echo $message; ?></div>
                <?php } ?>
                <div class="grid gap-4 mb-4 sm:grid-cols-2">
                    <div>
                        <label for="name" class="block mb-2 text-sm font-medium text-gray-900">First Name</label>
                        <input type="text" name="addFirstName" id="addFirstName" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5" placeholder="" autocomplete="off" value="" required>
                    </div>
                    <div>
                        <label for="name" class="block mb-2 text-sm font-medium text-gray-900">Last Name</label>
                        <input type="text" name="addLastName" id="addLastName" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5" placeholder="" autocomplete="off" value="" required>
                    </div>
                    <div>
                        <label for="username" class="block mb-2 text-sm font-medium text-gray-900">Username</label>
                        <input type="text" name="addUsername" id="username" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5" placeholder="" autocomplete="off" value="" required>
                    </div>
                    <div>
                        <label for="password" class="block mb-2 text-sm font-medium text-gray-900">Password</label>
                        <!-- Modified line: Added the readonly attribute and an ID for easy identification in JavaScript -->
                        <input type="text" name="addPassword" id="addPassword" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5" placeholder="" autocomplete="off" value="" required readonly>
                        <!-- Modified line: Added a button to trigger the password generation -->
                        <button type="button" class="bg-teal-200 text-teal-800 px-2 py-1 rounded-lg text-sm ml-2" onclick="generatePassword()">Generate Password</button>
                    </div>
                    <div>
                        <label for="type" class="block mb-2 text-sm font-medium text-gray-900">User Type</label>
                        <select id="type" name="addType" placeholder="User Type" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-500 focus:border-primary-500 block w-full p-2.5" autocomplete="off" value="" required>
                            <option selected=""></option>
                            <option value="Admin">Administrator</option>
                            <option value="General">General User</option>
                        </select>
                    </div>
                    <div>
                        <label for="Position" class="block mb-2 text-sm font-medium text-gray-900">Position</label>
                        <select id="Position" name="addPosition" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-500 focus:border-primary-500 block w-full p-2.5" autocomplete="off" value="" required>
                            <option value="" disabled selected></option>
                            <?php
                            foreach ($roleData as $role) {
                                echo "<option value='{$role['roleID']}'>{$role['position']}</option>";
                            }
                            ?>
                        </select>
                    </div>

                    <div><label class="block mb-2 text-sm font-medium text-gray-900">Status</label>
                        <div class="flex flex-wrap">
                            <div class="flex items-center mr-4">
                                <input id="addStatus" type="radio" value="inactive" name="addStatus" class="w-4 h-4 text-red-600 bg-gray-100 border-gray-300 focus:ring-red-500">
                                <label for="addInactive" class="ml-2 text-sm font-medium text-gray-900">Inactive</label>
                            </div>
                            <div class="flex items-center mr-4">
                                <input id="addStatus" type="radio" value="pending" name="addStatus" class="w-4 h-4 text-yellow-400 bg-gray-100 border-gray-300 focus:ring-yellow-500">
                                <label for="addPending" class="ml-2 text-sm font-medium text-gray-900">Pending</label>
                            </div>
                            <div class="flex items-center mr-4">
                                <input id="green-radio" type="radio" value="active" name="addStatus" class="w-4 h-4 text-green-600 bg-gray-100 border-gray-300 focus:ring-green-500">
                                <label for="addActive" class="ml-2 text-sm font-medium text-gray-900">Active</label>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="display flex justify-content flex-end">
                    <button type="submit" class="text-teal-800 inline-flex items-end justify-end hover:text-white border border-teal-800 hover:bg-teal-800 focus:ring-4 focus:outline-none focus:ring-teal-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center" name="addUser" value="addUser" onclick="showaddUserMessageModal()">
                        Add User
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php if ($message != '') { ?>
    <div id="addUserMessageModal" class="bg-white border-2 border-black text-black w-80 h-32 px-4 py-14 rounded-lg relative justify-center items-center text-center" role="alert" style="position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%); z-index: 999;">
        <strong class="font-bold"> <?php echo $message; ?></strong>
        <span class="absolute top-0 bottom-0 right-0 px-4 py-3" onclick="closeaddUserMessageModal()">
            <svg class="fill-current h-6 w-6 text-teal-800" role="button" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20">
                <title>Close</title>
                <path d="M14.348 14.849a1.2 1.2 0 0 1-1.697 0L10 11.819l-2.651 3.029a1.2 1.2 0 1 1-1.697-1.697l2.758-3.15-2.759-3.152a1.2 1.2 0 1 1 1.697-1.697L10 8.183l2.651-3.031a1.2 1.2 0 1 1 1.697 1.697l-2.758 3.152 2.758 3.15a1.2 1.2 0 0 1 0 1.698z" />
            </svg>
        </span>
    </div>
<?php } ?>



<script>
    function showaddUserMessageModal() {
        var modal = document.getElementById('addUserMessageModal');
        modal.style.display = 'block';
    }

    function generatePassword() {
        // Fetch the last name value from the input field
        var lastName = document.getElementById('addLastName').value;

        // Check if the last name is not empty
        if (lastName.trim() !== '') {
            // Make an Ajax request to generate the password
            var xhr = new XMLHttpRequest();
            xhr.open('GET', '../class/GeneratePassword.php?lastName=' + lastName, true);

            xhr.onload = function() {
                if (xhr.status === 200) {
                    // Update the password input field
                    var passwordField = document.getElementById('addPassword');
                    passwordField.value = xhr.responseText;
                    console.log(xhr.responseText);
                } else {
                    // Handle errors
                    console.error('Error generating password:', xhr.statusText);
                    console.log(xhr.responseText);
                }
            };

            xhr.send();
        } else {
            // Handle the case where the last name is empty
            alert('Please enter the last name before generating the password.');
        }
    }


    function closeaddUserMessageModal() {
        var modal = document.getElementById('addUserMessageModal');
        modal.style.display = 'none';
    }
</script>