<?php
$fooditems = $menu->getAllItemsDetails();
$catMappings = $menu->fetchCategoryMappings();
// $message = $menu->addPackageItems();
?>

<?php
global $conn;

if (isset($_POST['savePackageItems'])) {
    // Get the form data
    $packageName = $_POST['packageName'];
    $packagePrice = $_POST['packagePrice'];
    $selectedItemsJSON = $_POST['selectedItems'];
    $availability = $_POST['availability'];
    $packageDescription = $_POST['packageDescription'];

    if (isset($_FILES['packageImage'])) {
        $fileTmpName = $_FILES['packageImage']['tmp_name'];
        $fileName = $_FILES['packageImage']['name'];
        $fileType = $_FILES['packageImage']['type'];
        $fileSize = $_FILES['packageImage']['size'];

        // Customize the file upload path as per your requirements
        $uploadPath = '../../images/foodItemsImages/'; // Adjust the path as needed
        $targetFilePath = $uploadPath . $fileName;

        // Move the uploaded file to the desired location
        if (move_uploaded_file($fileTmpName, $targetFilePath)) {
            // File uploaded successfully, you can now save $targetFilePath in your database or perform other actions
            echo "File uploaded successfully.";
        } else {
            echo "Error uploading file.";
        }
    }

    // Decode the JSON data
    $selectedItems = json_decode($selectedItemsJSON, true);

    // Insert the package information into the database
    $sql = "INSERT INTO tblmenupackage (packageName, packagePrice, availability, packageImage, packageDescription) VALUES ('$packageName', '$packagePrice', '$availability', '$targetFilePath','$packageDescription')";


    if ($conn->query($sql) === TRUE) {

        $packageID = $conn->insert_id;

        // Insert selected items into the package_items table
        foreach ($selectedItems as $item) {
            if (isset($item['itemID']) && isset($item['itemName']) && !empty($item['itemID']) && !empty($item['itemName'])) {
                $packageitemID = $item['itemID'];
                $packageitemName = $item['itemName'];

                $sql = "INSERT INTO tblmenupackageitems (packageID, itemID, itemName) VALUES ('$packageID', ' $packageitemID', ' $packageitemName')";

                if ($conn->query($sql) !== TRUE) {
                    echo "Error: " . $sql . "<br>" . $conn->error;
                }
            } else {
                echo "Warning: Missing or empty itemID or itemName for one of the items.";
            }
        }

        // echo '<script language="javascript">';
        // echo 'alert("Package and selected items have been saved to the database.")';
        // echo '</script>';
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    function getUserRoleById($userId)
    {
        global $conn;

        // Assuming you have a table named 'users' with columns 'empAccID' and 'roleID'
        $query = "SELECT roleID FROM tblemployees WHERE empAccID = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $userInfo = $result->fetch_assoc();
            $stmt->close();
            return $userInfo;
        } else {
            $stmt->close();
            return null; // User not found
        }
    }

    // Get the user ID from the session
    $userId = isset($_SESSION['userid']) ? $_SESSION['userid'] : null;

    // Get user information, including role ID
    $userInfo = getUserRoleById($userId);

    // Assuming $userInfo is an associative array with a 'roleID' key
    $roleId = isset($userInfo['roleID']) ? $userInfo['roleID'] : null;

    // Redirect based on the role ID
    if ($roleId == 1) {
        echo '<script>window.location.href = "packages.php";</script>';
    } elseif ($roleId == 4) {
        echo '<script>window.location.href = "menupackage.php";</script>';  // Redirect for role ID 4
    } else {
        // Add a default redirect or handle other cases if needed
        echo '<script>window.location.href = "defaultRedirect.php";</script>';
    }
}
?>


<div id="createPackageModal" tabindex="-1" aria-hidden="true" class="hidden overflow-y-auto overflow-x-hidden fixed top-0 right-0 left-0 z-50 justify-center items-center w-full md:inset-0 h-[calc(100%-1rem)] md:h-full">
    <div class="relative w-full h-full max-w-2xl p-4 md:h-auto">
        <!-- Modal content -->
        <div class="relative p-4 bg-white rounded-lg shadow">
            <!-- Modal header -->
            <div class="flex items-center justify-between pb-4 mb-4 border-b rounded-t sm:mb-5">
                <h3 class="text-lg font-semibold text-gray-900">Add Package</h3>
                <button type="button" class="text-gray-400 bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm p-1.5 ml-auto inline-flex items-center" data-modal-toggle="createPackageModal">
                    <svg aria-hidden="true" class="w-5 h-5" fill="currentColor" viewbox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                        <path fill-rule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clip-rule="evenodd" />
                    </svg>
                    <span class="sr-only">Close modal</span>
                </button>
            </div>

            <!-- Modal body -->
            <form method="post" enctype="multipart/form-data">
                <div class="grid gap-4 mb-4 sm:grid-cols-2">
                    <div>
                        <label for="text" class="block mb-2 text-sm font-medium text-gray-900">Package Name</label>
                        <input type="text" name="packageName" id="packageName" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5" placeholder="Enter package name" required="">
                    </div>
                    <div>
                        <label for="text" class="block mb-2 text-sm font-medium text-gray-900">Package Price</label>
                        <input type="text" name="packagePrice" id="packagePrice" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5" placeholder="0.00" required="">
                    </div>

                    <div class="flex-row">
                        <div class="mb-4">
                            <label for="availability" class="block mb-2 text-sm font-medium text-gray-900">Availability</label>
                            <select name="availability" id="availability" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-green-200 focus:border-green-200 block w-full p-2.5" required="">
                                <option value="Available">Available</option>
                                <option value="Unavailable">Unavailable</option>
                            </select>
                        </div>
                        <div class="flex-col">
                            <label for="packageDescription" class="block mb-2 text-sm font-medium text-gray-900">Description</label>
                            <textarea id="packageDescription" name="packageDescription" rows="3" class="block p-2.5 w-full text-sm text-gray-900 bg-gray-50 rounded-lg border border-gray-300 focus:ring-green-200 focus:border-green-200" placeholder="Write description here"></textarea>
                        </div>
                    </div>
                    <div>
                        <label for="packageImage" class="block mb-2 text-sm font-medium text-gray-900">Package Image</label>
                        <img id="packageImg" name="packageImg" src="<?php echo $packageImage ?>" alt="Existing Image" class="w-48 h-28 mb-3" />
                        <input type="file" name="packageImage" id="packageImage" accept="image/*">
                    </div>

                </div>

                <div class="max-w-screen-xl px-4 mx-auto max-h-screen-xl lg:px-12 xl:px-14" id="tableContainer">
                    <div class="relative overflow-hidden bg-white shadow-md sm:rounded-lg">

                        <div class="overflow-y-auto overflow-x-hidden max-h-[340px] pt-5">
                            <table class="w-full text-sm text-left text-gray-500 " id="itemsTable">
                                <thead class="text-xs text-gray-700 uppercase bg-gray-50">
                                    <tr>
                                        <!-- <th scope="col" class="p-4 bg-gray-50"></th> -->
                                        <th scope="col" class="px-8 py-4">Dish Name</th>
                                        <th scope="col" class="px-8 py-4">Category</th>
                                        <th scope="col" class="px-8 py-4">Price</th>
                                        <th scope="col" class="px-8 py-4"></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($fooditems as $item) { ?>
                                        <tr class="border-b hover:bg-gray-100">

                                            <!-- name -->
                                            <td class="px-8 py-3 text-gray-500 whitespace-nowrap">
                                                <?php echo $item['itemName']; ?>
                                            </td>

                                            <!-- category -->
                                            <td class="px-8 py-3"><?php
                                                                    $categoryid = $item['categoryID'];
                                                                    $category = isset($catMappings[$categoryid]) ? $catMappings[$categoryid] : "undefined";
                                                                    echo $category;
                                                                    ?></td>

                                            <!-- price -->
                                            <td class="px-8 py-3"><?php echo $item['price']; ?></td>
                                     
                                            <!-- <td class="px-4 py-3"></td> -->
                                            <td class="px-4 py-3 font-medium text-gray-900 whitespace-nowrap">
                                                <div class="flex items-center justify-end space-x-4">
                                                    <div class="flex items-center mr-4">
                                                        <input id="menuItemCheckbox" name="menuItemCheckbox" type="checkbox" value="" data-itemid="<?php echo $item['itemID']; ?>" data-itemname="<?php echo $item['itemName']; ?>" data-itemprice="<?php echo $item['price']; ?>" class="w-4 h-4 text-teal-600 bg-gray-100 border-gray-300 rounded focus:ring-teal-500 dark:focus:ring-teal-600 dark:ring-offset-gray-800 focus:ring-2 dark:bg-gray-700 dark:border-gray-600">
                                                    </div>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php } ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>


                <div class="mb-4">
                    <!-- <span class="block mb-2 text-sm font-medium text-gray-900">QR Code:</span> -->
                    <div class="flex items-center justify-center w-full">
                        <div id="qrCodeContainer" style="display: none;" class="flex flex-col items-center justify-center w-64 h-64 border-2 border-gray-300 rounded-lg bg-gray-50 qrCodeContainer">
                        </div>
                    </div>
                </div>

                <input type="hidden" name="selectedItems" id="selectedItems" value="">

                <div class="items-center space-y-4 sm:flex sm:space-y-4 sm:space-x-4">
                    <button type="submit" name="savePackageItems" id="savePackageItems" onclick="saveSelectedItems()" class="w-full sm:w-auto justify-center text-teal-800 inline-flex border border-gray-300 bg-teal-700 hover:bg-teal-800 hover:text-white focus:ring-4 focus:outline-none focus:ring-primary-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center">
                        Save
                    </button>
                </div>

            </form>
        </div>
    </div>
</div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js"></script>

<script>
    function saveSelectedItems() {
        // Find all checkboxes with the name "menuItemCheckbox"
        const checkboxElements = document.querySelectorAll('input[name="menuItemCheckbox"]');

        // Initialize an array to store the selected items
        const selectedItems = [];

        // Iterate through each checkbox
        checkboxElements.forEach(checkbox => {
            if (checkbox.checked) {

                const itemID = checkbox.getAttribute('data-itemid');
                const itemName = checkbox.getAttribute('data-itemName');
                const itemPrice = checkbox.getAttribute('data-itemprice');

                selectedItems.push({
                    itemID: itemID,
                    itemName: itemName,
                    itemPrice: itemPrice
                });
            }
        });

        // Set the value of the hidden input field
        document.getElementById('selectedItems').value = JSON.stringify(selectedItems);

        // You can also display the selected items for testing
        // alert('Selected Items: ' + JSON.stringify(selectedItems));
    }

    function previewImage() {
        var fileInput = document.getElementById('fileToUpload');
        var imagePreview = document.getElementById('imagePreview');
        var previewImage = document.getElementById('PackageImg');

        if (fileInput.files && fileInput.files[0]) {
            var reader = new FileReader();

            reader.onload = function(e) {
                // Show image preview
                imagePreview.classList.remove('hidden');
                previewImage.src = e.target.result;
            };

            // Read the image file
            reader.readAsDataURL(fileInput.files[0]);
        }
    }
</script>