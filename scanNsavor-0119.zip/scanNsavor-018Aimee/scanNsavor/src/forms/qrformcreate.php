<?php
include("../class/tableQRCode.php");

$tableQR = new tableQRCode();
$message = $tableQR->QrGenerate();

// $qrtable = new tableQRCode();
// $tableQR = $qrtable->QrGenerate();


// include("../phpqrcode/qrlib.php");

// if (isset($_POST['saveQR'])) {
//     // After decoding the base64 data
//     $dataURL = $_POST['saveQR'];
//     $imageData = base64_decode(preg_replace('#^data:image/\w+;base64,#i', '', $dataURL));

//     // Generate a unique name for the image with PNG extension
//     $imageName = uniqid() . '.png'; // Save it as PNG
//     $path = '../../images/' . $imageName;

//     // Check if the image directory exists; if not, create it
//     if (!file_exists('../../images/')) {
//         mkdir('../../images/', 0777, true);
//     }

//     // Now you can save the path of the image to your database
//     $qrNum = mysqli_real_escape_string($conn, $_POST['tableNumber']);
//     $seats = mysqli_real_escape_string($conn, $_POST['seats']); // Retrieve the number of seats from the form

//     // Check if a record with the same table number already exists
//     $checkQuery = mysqli_query($conn, "SELECT * FROM tbltable WHERE tableNo = '$qrNum'");
//     if (mysqli_num_rows($checkQuery) > 0) {
//         // echo "<script>alert('A record with this table number already exists.');</script>";
//     } else {
//         // Save the image to the server
//         if (file_put_contents($path, $imageData) === false) {
//             die('Error saving image!');
//         }

//         $query = mysqli_query($conn, "INSERT INTO tbltable SET tableNo = '$qrNum', tableQRCode = '$path', noOfSeats = '$seats'");
//         if ($query) {
//             echo "<script>alert('Data saved successfully');</script>";
//         } else {
//             echo "Error: " . mysqli_error($conn);
//         }
//     }
// }
?>


<div id="createQRModal" tabindex="-1" aria-hidden="true" class="hidden overflow-y-auto overflow-x-hidden fixed top-0 right-0 left-0 z-50 justify-center items-center w-full md:inset-0 h-[calc(100%-1rem)] md:h-full">
    <div class="relative p-4 w-full max-w-2xl h-full md:h-auto">
        <!-- Modal content -->
        <div class="relative p-4 bg-white rounded-lg shadow">
            <!-- Modal header -->
            <div class="flex justify-between items-center pb-4 mb-4 rounded-t border-b sm:mb-5">
                <h3 class="text-lg font-semibold text-gray-900">Generate QR Code</h3>
                <button type="button" class="text-gray-400 bg-transparent hover-bg-gray-200 hover-text-gray-900 rounded-lg text-sm p-1.5 ml-auto inline-flex items-center" data-modal-toggle="createQRModal">
                    <svg aria-hidden="true" class="w-5 h-5" fill="currentColor" viewbox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                        <path fill-rule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clip-rule="evenodd" />
                    </svg>
                    <span class="sr-only">Close modal</span>
                </button>
            </div>
            <!-- Modal body -->
            <form method="post" id="qrForm">
                <div class="grid gap-4 mb-4 sm:grid-cols-2">
                    <div>
                        <label for="tableNumber" class="block mb-2 text-sm font-medium text-gray-900">Table Number</label>
                        <input type="text" name="tableNumber" id="tableNumber" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5" placeholder="Enter table number" required="">
                    </div>
                    <div>
                        <label for="seats" class="block mb-2 text-sm font-medium text-gray-900">Number of Seats</label>
                        <input type="text" name="seats" id="seats" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5" placeholder="" required="">
                    </div>
                </div>
                <div class="mb-4">
                    <span class="block mb-2 text-sm font-medium text-gray-900">QR Code:</span>
                    <div class="flex justify-center items-center w-full">
                        <div id="qrCodeContainer" class="flex flex-col justify-center items-center w-64 h-64 bg-gray-50 border-2 border-gray-300 qrCodeContainer">
                            <!-- This is where the QR code will be displayed -->
                        </div>
                    </div>
                </div>
                <div class="items-center space-y-4 sm:flex sm:space-y-4 sm:space-x-4 mt-8">
                    <button type="button" name="generateQR" id="generateQR" value="submit" onclick="generateQRCode()" class="text-teal-800 inline-flex items-center hover:text-white border border-teal-800 hover:bg-teal-800 focus:ring-4 focus:outline-none focus:ring-teal-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center justify-center w-full">Generate QR Code</button>
                </div>
                <div class="items-center space-y-4 sm:flex sm:space-y-4 sm:space-x-4 py-2">
                    <button type="submit" id="saveQR" name="saveQR" value="saveQR" class=" justify-center text-teal-800 items-center hover:text-white border border-teal-800 hover:bg-teal-800 focus:ring-4 focus:outline-none focus:ring-teal-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center w-full hidden">Save</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js"></script>
<script>
    function generateQRCode() {
        var qrText = document.getElementById('tableNumber').value;
        var seats = document.getElementById('seats').value;
        var qrData = qrText;
        var size = 300;

        // Check if the table number is already in the existing table QR records
        var existingTableNumbers = <?php echo json_encode($tableQR->getAllTableQRDetails()); ?>;
        var tableNumberExists = existingTableNumbers.some(function(table) {
            return table.tableNo === qrText;
        });

        if (tableNumberExists) {
            // Show an alert and return from the function
            alert('Table number already exists! Please choose a different table number.');
            return;
        }

        if (qrData) {
            var qrCodeContainer = document.getElementById("qrCodeContainer");
            qrCodeContainer.innerHTML = ""; // Clear the container if it contains a previous QR code.

            var qrcode = new QRCode(qrCodeContainer, {
                text: qrData,
                width: size,
                height: size,
                colorDark: "#000",
                colorLight: "#fff",
            });

            qrCodeContainer.style.display = "block"; // Show the QR code container

            var canvas = qrCodeContainer.getElementsByTagName('canvas')[0]; // Retrieving canvas
            var dataURL = canvas.toDataURL();

            var save = document.getElementById('saveQR');
            save.onclick = function() {
                var xhr = new XMLHttpRequest();
                xhr.open("POST", "", true); // Make sure this is the correct path to your PHP script
                xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

                var formData = "saveQR=" + encodeURIComponent(dataURL) + "&tableNumber=" + qrText + "&seats=" + seats;
                console.log(formData); // Check in the browser console if the data matches the form

                xhr.send(formData);
            }

            save.style.display = "block"; // Show the save button

            // Reset the form fields if needed
        } else {
            alert("Enter the text or URL to generate your QR code");
        }
    }
</script>
