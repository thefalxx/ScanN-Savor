<?php
// Include necessary files and initialize objects
include '../class/tableQRCode.php';
include '../connection/config.php';
$tables = new tableQRCode();

$currentTable = isset($_POST['modalTableNo']) ? $_POST['modalTableNo'] : '';



// Global database connection
global $conn;

// Retrieve order IDs and table numbers from the form
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve the selected tables from the form
    $selectedTables = isset($_POST['selectedTables']) ? $_POST['selectedTables'] : [];

    // Check if any tables are selected
    if (!empty($selectedTables)) {
        // Use prepared statements to prevent SQL injection
        $placeholders = str_repeat("?, ", count($selectedTables) - 1) . "?";
        $stmt = $conn->prepare("SELECT * FROM tblorders WHERE tableNo IN ($placeholders) AND orderStatus = 'Completed'");

        // Check if the prepare statement was successful
        if ($stmt === false) {
            die('Error in prepare statement: ' . $conn->error);
        }

        // Dynamically bind parameters based on the number of selected tables
        $types = str_repeat("i", count($selectedTables));
        $stmt->bind_param($types, ...$selectedTables);

        $stmt->execute();
        $orderDetailsResult = $stmt->get_result();

        // Fetch and process order details
        $orderIDs = [];
        while ($orderDetail = $orderDetailsResult->fetch_assoc()) {
            $orderIDs[] = $orderDetail['orderID'];
        }

        // Close statements
        $stmt->close();
    } else {
        // echo "No tables selected.";
    }
}


// Function to retrieve order information
function getOrderDetails($orderID)
{
    global $conn;

    // Initialize the result array
    $result = array();

    // Retrieve order details from tblOrders
    $orderQuery = "SELECT * FROM tblorders WHERE orderID = ? AND orderStatus = 'Completed' ";
    $orderStmt = $conn->prepare($orderQuery);
    $orderStmt->bind_param("i", $orderID);
    $orderStmt->execute();
    $orderResult = $orderStmt->get_result();

    if ($orderResult->num_rows > 0) {
        // Fetch order details
        $result['order'] = $orderResult->fetch_assoc();

        // Retrieve order details from tblOrderDetails
        $detailsQuery = "SELECT * FROM tblorderDetails WHERE orderID = ? AND status = 'Completed'";
        $detailsStmt = $conn->prepare($detailsQuery);
        $detailsStmt->bind_param("i", $orderID);
        $detailsStmt->execute();
        $detailsResult = $detailsStmt->get_result();

        if ($detailsResult->num_rows > 0) {
            // Fetch order details
            $result['orderDetails'] = array();

            while ($row = $detailsResult->fetch_assoc()) {
                $result['orderDetails'][] = $row;
            }
        } else {
            // No order details found
            $result['orderDetails'] = array();
        }

        // Close the details statement
        $detailsStmt->close();
    } else {
        // Invalid order ID
        $result['order'] = array();
        $result['orderDetails'] = array();
    }

    // Close the order statement
    $orderStmt->close();

    return $result;
}

// Function to merge orders
function mergeOrders($modalOrderID, $orderIDs)
{
    global $conn;

    // Step 1: Create a new merge request entry
    $orderIDsString = implode(',', $orderIDs); // Create a variable to store the result of implode
    $createMergeRequestQuery = "INSERT INTO tblmergeorder (orderIDs, status, currentOrderID , timestamp ) VALUES (?, 'Pending',? , NOW())";
    $createMergeRequestStmt = $conn->prepare($createMergeRequestQuery);

    // Pass the variable by reference to bind_param
    $createMergeRequestStmt->bind_param("ss", $orderIDsString, $modalOrderID);
    $createMergeRequestStmt->execute();

    // Get the merge request ID of the newly created merge request
    $mergeRequestID = $createMergeRequestStmt->insert_id;

    echo '<script>alert("Requested for merge.");</script>'; 

    // Close the merge request statement
    $createMergeRequestStmt->close();

    // Return the merge request ID
    return $mergeRequestID;
}


// Usage
$modalOrderID = isset($_POST['modalOrderID']) ? $_POST['modalOrderID'] : '';
$modalTableNo = isset($_POST['modalTableNo']) ? $_POST['modalTableNo'] : '';


// Display details for the current order
if (!empty($modalOrderID)) {
    $currentOrderDetails = getOrderDetails($modalOrderID);

    if (isset($currentOrderDetails['order'])) {
        // echo '<h3>Current Order Details</h3>';
        // echo '<p>Order ID: ' . $currentOrderDetails['order']['orderID'] . '</p>';
        // echo '<p>Order Date: ' . $currentOrderDetails['order']['orderDateTime'] . '</p>';
        // echo '<p>Total Amount: ₱' . $currentOrderDetails['order']['totalAmount'] . '</p>';

        // echo '<h4>Order Items</h4>';
        if (!empty($currentOrderDetails['orderDetails'])) {
            // echo '<ul>';
            // foreach ($currentOrderDetails['orderDetails'] as $item) {
            //     echo '<li>' . $item['itemID'] . ' - Quantity: ' . $item['itemQuantity'] . '</li>';
            // }
            // echo '</ul>';
        } else {
            // echo '<p>No items in the order.</p>';
        }
    } else {
        // echo '<p>Invalid order ID.</p>';
    }
}

// Display details for the selected tables
if (!empty($orderIDs)) {
    foreach ($orderIDs as $orderId) {
        $selectedOrderDetails = getOrderDetails($orderId);

        if (isset($selectedOrderDetails['order'])) {
            // echo '<h3>Selected Table Details</h3>';
            // echo '<p>Table No: ' . $orderId . '</p>';
            // echo '<p>Order ID: ' . $selectedOrderDetails['order']['orderID'] . '</p>';
            // echo '<p>Total Amount: ₱' . $selectedOrderDetails['order']['totalAmount'] . '</p>';

            // echo '<h4>Order Items</h4>';
            if (isset($selectedOrderDetails['orderDetails']) && !empty($selectedOrderDetails['orderDetails'])) {
                // echo '<ul>';
                foreach ($selectedOrderDetails['orderDetails'] as $item) {
                    // echo '<li>' . $item['itemID'] . ' - Quantity: ' . $item['itemQuantity'] . '</li>';
                }
                // echo '</ul>';
            } else {
                // echo '<p>No items in the order.</p>';
            }
        } else {
            // echo '<p>Invalid order ID for table ' . $orderId . '.</p>';
        }
    }

    // Merge orders and get the merge request ID
    $mergeRequestID = mergeOrders($modalOrderID, $orderIDs);

    // echo '<p>Merge request has been created with ID: ' . $mergeRequestID . '</p>';
} else {
    //echo "No tables selected.";
}
?>

<div id="tableForMergeModal" tabindex="-1" class="fixed top-0 left-0 right-0 bottom-0 flex justify-center items-center z-50 hidden p-4 overflow-x-hidden overflow-y-auto">
    <div class="relative w-full h-auto max-w-md max-h-full">
        <div class="relative bg-white rounded-lg shadow">
            <button type="button" onclick="toggleModal('tableForMergeModal')" class="absolute top-3 right-2.5 text-gray-400 bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm p-1.5 ml-auto inline-flex items-center" data-modal-toggle="tableForMergeModal">
                <svg aria-hidden="true" class="w-5 h-5" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                    <path fill-rule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clip-rule="evenodd" />
                </svg>
                <span class="sr-only">Close modal</span>
            </button>
            <div class="px-1 py-6 ">
                <h3 class="mb-5 text-lg font-bold text-gray-500 text-center">SELECT TABLES TO MERGE</h3>
                <form id="reqMergeOrdersForm" action="" method="post">
                    <div class="relative px-12 py-3">

                        <input type="hidden" name="selectedTablesInput" id="selectedTablesInput">
                        <input type="hidden" name="modalOrderID" id="modalOrderID">
                        <input type="text" name="modalTableNo" id="modalTableNo" class="hidden">

                        <label for="number" class="block mb-2 text-sm font-light text-gray-500">Enter how many tables you would like to merge your order with</label>
                        <div class="flex pt-2">
                            <input type="number" name="tablesToMerge" id="tablesToMerge" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-teal-600 focus:border-teal-700 block w-full p-2.5 mr-2" placeholder="1" required>
                            <button class="text-teal-600 hover:text-white border hover:bg-teal-800 focus:ring-4 focus:outline-none focus:ring-teal-300 font-medium rounded-lg text-sm inline-flex items-center px-5 py-2.5 text-center mr-2" onclick="toggleTableVisibility()" type="button">Continue</button>

                        </div>
                        <div class="overflow-y-auto overflow-x-hidden max-h-[340px] mt-7 hidden lg:px-10" id="tableContainer">
                            <table class="w-full text-sm text-left text-gray-500 border" id="tablesTable">
                                <thead class="text-xs text-gray-600 uppercase bg-gray-50">
                                    <tr>
                                        <th scope="col" class="px-4 py-4 text-center">Table No.</th>
                                        <!-- <th scope="col" class="px-4 py-4">Seats</th> -->
                                        <th scope="col" class="px-4 py-4"></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $currentTableNo = isset($_GET['tableNo']) ? $_GET['tableNo'] : '';
                                    $occupied = $tables->getOccupiedTables($currentTableNo);
                                    foreach ($occupied as $occupiedTables) :
                                    ?>
                                        <tr class="border-b hover:bg-gray-100">
                                            <td class="px-4 py-3 text-center text-gray-500 whitespace-nowrap"><?php echo $occupiedTables['tableNo']; ?></td>
                                            <!-- <td class="px-4 py-3"><?php echo $occupiedTables['noOfSeats']; ?></td> -->
                                            <td class="px-4 py-3 font-medium text-gray-900 whitespace-nowrap">
                                                <input type="checkbox" name="selectedTables[]" value="<?php echo $occupiedTables['tableNo']; ?>" class="w-4 h-4 text-teal-600 bg-gray-100 border-gray-300 rounded focus:ring-teal-500 dark:focus:ring-teal-600 dark:ring-offset-gray-800 focus:ring-2 dark:bg-gray-700 dark:border-gray-600 text-center">
                                            </td>
                                        </tr>
                                    <?php
                                    endforeach;
                                    ?>
                                </tbody>
                            </table>
                            <div class="flex justify-center pt-2">
                                <button type="button" class="text-teal-600 hover:text-white border hover:bg-teal-800 focus:ring-4 focus:outline-none focus:ring-teal-300 font-medium rounded-lg text-sm items-center px-5 py-2.5 text-center mt-3" onclick="mergeOrders()">Merge Orders</button>
                            </div>

                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', (event) => {
        const tablesToMergeInput = document.getElementById('tablesToMerge');
        const checkboxes = document.querySelectorAll('input[name="selectedTables[]"]');

        // Function to update the checkboxes' state based on the tablesToMerge input
        function updateCheckboxes() {
            const maxTables = parseInt(tablesToMergeInput.value, 10);
            const selectedCheckboxes = Array.from(checkboxes).filter(checkbox => checkbox.checked).length;

            checkboxes.forEach(checkbox => {
                if (selectedCheckboxes >= maxTables && !checkbox.checked) {
                    checkbox.disabled = true;
                } else {
                    checkbox.disabled = false;
                }
            });
        }

        // Event listener for changes in the tablesToMerge input
        tablesToMergeInput.addEventListener('change', updateCheckboxes);

        // Event listener for changes in the checkboxes
        checkboxes.forEach(checkbox => {
            checkbox.addEventListener('change', updateCheckboxes);
        });

        // Initial update in case the input is not empty
        updateCheckboxes();
    });

    function mergeOrders() {
        // Collect selected table numbers
        const selectedTables = Array.from(document.querySelectorAll('input[name="selectedTables[]"]:checked'))
            .map(checkbox => checkbox.value);

        // Find the hidden input field
        const selectedTablesInput = document.getElementById('selectedTablesInput');

        if (selectedTablesInput) {
            // Populate the hidden input field with selected table numbers
            selectedTablesInput.value = JSON.stringify(selectedTables);

            // Log selected tables to the console
            console.log('Selected Tables:', selectedTables);

            // Submit the form (you can remove this line if you want to only log the selected tables without submitting)

            document.getElementById('reqMergeOrdersForm').submit();
        } else {
            console.error('Selected tables input element not found.');
        }
    }


    function toggleTableVisibility() {
        var tableContainer = document.getElementById('tableContainer');
        tableContainer.classList.toggle('hidden');
    }
</script>