<?php

$message = '';
$stmtOrderStatus = null; // Initialize $stmtOrderStatus outside the if block


if (isset($_POST['confirmPayment'])) {

    $paymentID = $_POST['paymentID'];
    $tableNo = $_POST['tableNo'];
    $processedBy =  $_POST['userID'];
    $paymentMethod = $_POST['modeOfPayment'];
    $totalAmount = $_POST['totalAmount'];

    // Determine the amount paid based on the payment method
    if ($paymentMethod === 'Card' || $paymentMethod === 'E-wallet') {
        $amountPaid = $totalAmount;
    } elseif ($paymentMethod === 'Cash') {
        $amountPaid = $_POST['cashAmount'];
    } else {
        $amountPaid = 0;
    }


    // Update tblpayment with the payment status and details
    $updatePaymentQuery = "UPDATE tblpayment SET status = 'confirmed', processedBy = ?, paymentMethod = ?, amountPaid = ? WHERE paymentID = ?";
    $stmt = $conn->prepare($updatePaymentQuery);
    $stmt->bind_param("issi", $processedBy, $paymentMethod, $amountPaid, $paymentID);

    $selectOrderIDQuery = "SELECT orderID FROM tblpaymentdetails WHERE paymentID = ?";
    $stmtSelectOrderID = $conn->prepare($selectOrderIDQuery);
    $stmtSelectOrderID->bind_param("i", $paymentID);
    $stmtSelectOrderID->execute();
    $stmtSelectOrderID->bind_result($orderID);
    $stmtSelectOrderID->fetch();
    $stmtSelectOrderID->close();


    // Update order status in tblorders and tblorderdetails
    $currentOrderStatusQuery = "SELECT orderStatus FROM tblorders WHERE orderID = ?";
    $stmtCurrentOrderStatus = $conn->prepare($currentOrderStatusQuery);
    $stmtCurrentOrderStatus->bind_param("i", $orderID);
    $stmtCurrentOrderStatus->execute();
    $stmtCurrentOrderStatus->bind_result($currentOrderStatus);
    $stmtCurrentOrderStatus->fetch();
    $stmtCurrentOrderStatus->close();

    // Initialize $stmtOrderStatus here
    $stmtOrderStatus = null;

    if ($currentOrderStatus === "Completed") {
        $updateOrderStatusQuery = "UPDATE tblorders o
                                   JOIN tblorderdetails od ON o.orderID = od.orderID
                                   SET o.orderStatus = 'Done', od.status = 'Done'
                                   WHERE o.orderID = ?";
        $stmtOrderStatus = $conn->prepare($updateOrderStatusQuery);
        $stmtOrderStatus->bind_param("i", $orderID);
    } elseif ($currentOrderStatus === "ForTakeOut") {
        $updateOrderStatusQuery = "UPDATE tblorders o
                                   JOIN tblorderdetails od ON o.orderID = od.orderID
                                   SET o.orderStatus = 'Pending', od.status = 'Pending'
                                   WHERE o.orderID = ?";
        $stmtOrderStatus = $conn->prepare($updateOrderStatusQuery);
        $stmtOrderStatus->bind_param("i", $orderID);
    } else {
        // Handle other order statuses if needed
        $message = "Invalid order status.";
    }

    if ($stmtOrderStatus && $stmtOrderStatus->execute()) {
        // Additional code if needed after updating order status
    } else {
        $message = "Error updating order status: " . ($stmtOrderStatus ? $stmtOrderStatus->error : "stmtOrderStatus is null");
    }

    if ($stmt->execute()) {
        $message = "Payment confirmed.";

        // Update tbltable to mark the table as unoccupied
        $updateTableQuery = "UPDATE tbltable SET isOccupied = 0 WHERE tableNo = ?";
        $stmt = $conn->prepare($updateTableQuery);
        $stmt->bind_param("i", $tableNo);

        if ($stmt->execute()) {
            // var_dump($paymentID, $tableNo, $processedBy, $amountPaid);
        } else {
            $message = "Error updating table status: " . $stmt->error;
        }

        $stmt->close();
    } else {
        $message = "Error confirming payment: " . $stmt->error;
    }
} else {
    echo "Invalid request";
}

?>


<div id="processPaymentModal" tabindex="-1" aria-hidden="true" class="hidden overflow-y-auto overflow-x-hidden fixed top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 z-50 w-full md:w-auto md:max-w-lg">
    <div id="overlay"></div>
    <div class="relative p-4 w-full max-w-lg h-full md:h-auto">
        <!-- Modal content -->
        <div class="relative p-4 bg-white rounded-lg shadow">
            <!-- Modal header -->
            <input type="text" name="itemID" id="itemID" hidden>
            <div class="flex justify-between items-center pb-4 mb-4 rounded-t border-b sm:mb-5">
                <h3 class="text-lg font-semibold text-gray-900">Process Payment</h3>
                <button type="button" class="text-gray-400 bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm p-1.5 ml-auto inline-flex items-center" data-modal-toggle="processPaymentModal">
                    <svg aria-hidden="true" class="w-5 h-5" fill="currentColor" viewbox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                        <path fill-rule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clip-rule="evenodd" />
                    </svg>
                    <span class="sr-only">Close modal</span>
                </button>
            </div>


            <!-- Modal body -->
            <form method="post">
                <div class="mt-5 max-w-full mx-auto">

                    <input type="hidden" id="paymentID" name="paymentID">
                    <input type="hidden" id="tableNo" name="tableNo">

                    <input type="hidden" id="userID" name="userID">
                    <input type="hidden" id="userName" name="userName">

                    <div class="flex justify-center items-center mb-4 mx-10">
                        <h3 class="text-xl font-bold leading-none text-gray-900 dark:text-white">Order # <span id="orderID" name="orderID"></span></h3>

                        <h3 class="text-lg font-normal leading-none text-gray-900 dark:text-white lg:pr-6 hidden">Table <span id="tableNoDisplay" name="tableNoDisplay"></span></h3>

                    </div>
                    <div class="p-4 mx-10">
                        <div class="mb-4">
                            <label for="customerName" class="text-sm tracking-wide font-semibold text-grey-darker px-2">
                                Customer Name
                            </label>
                            <input type="text" id="customerName" name="customerName" class="no-appearance bg-grey-lighter w-full leading-normal py-2 px-3 rounded border-b border-red-light mt-2 focus:outline-none border-none text-center" readonly>
                        </div>

                        <div class="mb-4">
                            <label for="totalAmount" class="text-sm tracking-wide font-semibold text-grey-darker px-2">
                                Total Amount
                            </label>
                            <input type="text" id="totalAmount" name="totalAmount" class="no-appearance bg-grey-lighter w-full leading-normal py-2 px-3 rounded border-b border-red-light mt-2 focus:outline-none border-none text-center" readonly>
                        </div>

                        <div class="mb-4">
                            <div class="flex justify-between items-center px-2">
                                <label for="modeOfPayment" class="text-sm tracking-wide font-semibold text-grey-darker">
                                    Payment Method
                                </label>
                            </div>
                            <div class="relative mt-2">
                                <select class="block appearance-none w-full bg-grey-lighter border-b border-grey-light text-grey-darker py-3 px-4 pr-8 rounded leading-tight focus:outline-none border-none" id="modeOfPayment" name="modeOfPayment">
                                    <option selected="" disabled><span class="text-sm">Choose a Payment Method</span></option>
                                    <option value="Cash">Cash</option>
                                    <option value="Card">Card</option>
                                    <option value="E-Wallet">E-Wallet</option>
                                </select>

                            </div>
                        </div>

                        <!-- input field for cash -->
                        <div class="mb-4" id="cashAmountField" style="display: none;">
                            <label for="cashAmount" class="text-sm tracking-wide font-semibold text-grey-darker px-2">
                                Cash Amount
                            </label>
                            <input type="text" id="cashAmount" name="cashAmount" class="no-appearance bg-grey-lighter w-full leading-normal py-2 px-3 rounded border-b border-red-light mt-2 focus:outline-none border-none text-center" value="">
                        </div>
                        <input type="text" id="processedBy" name="processedBy" class="hidden">
                        <div class="mb-4" hidden>
                            <label for="orderStatus" class="uppercase text-sm tracking-wide font-semibold text-grey-darker px-2">
                                Status
                            </label>
                            <input type="text" id="orderStatus" class="no-appearance bg-grey-lighter w-full leading-normal py-2 px-3 rounded border-b border-red-light mt-2 focus:outline-none" value="<?php echo $orderStatus; ?>" readonly>
                        </div>

                    </div>

                    <div id="cashErrorMessage" class="ml-16 text-gray-500 text-sm"></div>

                    <div class="flex justify-center items-center my-8">
                        <button type="submit" name="confirmPayment" id="confirmPayment" value="confirmPayment" class="hover:shadow-form w-72 rounded-md bg-gray-800 py-3 px-8 text-center text-base font-semibold text-white outline-none" onclick="return showconfirmPaymentModal()">
                            Confirm
                        </button>
                    </div>
                </div>

            </form>
        </div>
    </div>
</div>


<?php if ($message != '') {
?>
    <div id="confirmPaymentModal" class="bg-white border-2 border-black text-black w-80 h-32 px-4 py-14 rounded-lg relative justify-center items-center text-center" role="alert" style="position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%); z-index: 999;">
        <strong class="font-bold"> <?php echo $message; ?></strong>
        <span class="absolute top-0 bottom-0 right-0 px-4 py-3" onclick="return closeconfirmPaymentModal()">
            <svg class="fill-current h-6 w-6 text-teal-800" role="button" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20">
                <title>Close</title>
                <path d="M14.348 14.849a1.2 1.2 0 0 1-1.697 0L10 11.819l-2.651 3.029a1.2 1.2 0 1 1-1.697-1.697l2.758-3.15-2.759-3.152a1.2 1.2 0 1 1 1.697-1.697L10 8.183l2.651-3.031a1.2 1.2 0 1 1 1.697 1.697l-2.758 3.152 2.758 3.15a1.2 1.2 0 0 1 0 1.698z" />
            </svg>
        </span>
    </div>
<?php }
?>

<script>
    document.getElementById('modeOfPayment').addEventListener('change', function() {
        var cashAmountField = document.getElementById('cashAmountField');
        if (this.value === 'Cash') {
            cashAmountField.style.display = 'block';
        } else {
            cashAmountField.style.display = 'none';
        }
    });

    function validateCashAmount() {
        var totalAmount = parseFloat(document.getElementById('totalAmount').value);
        var cashAmount = parseFloat(document.getElementById('cashAmount').value);
        var confirmPaymentButton = document.getElementById('confirmPayment');
        var cashErrorMessage = document.getElementById('cashErrorMessage'); // Assuming cashErrorMessage is the ID of the error message element

        if (cashAmount < totalAmount) {
            // Enable the confirmPayment button
            confirmPaymentButton.disabled = true;
            cashErrorMessage.innerHTML = 'Cash amount should not be less than the total bill.';
        } else if (cashAmount >= totalAmount) {
            // Disable the confirmPayment button
            confirmPaymentButton.disabled = false;
            cashErrorMessage.innerHTML = ''; // Remove the error message
        }
    }

    // Attach the validateCashAmount function to the input's "input" event
    document.getElementById('cashAmount').addEventListener('input', validateCashAmount);
</script>


<script>
    function showconfirmPaymentModal() {
        // Get form elements
        var customerNameInput = document.getElementById('customerName');
        var totalAmountInput = document.getElementById('totalAmount');
        var modeOfPaymentSelect = document.getElementById('modeOfPayment');
        var cashAmountInput = document.getElementById('cashAmount');

        // Validate customerName
        if (customerNameInput.value.trim() === '') {
            alert('Customer Name is required.');
            return false;
        }

        // Validate totalAmount
        if (totalAmountInput.value.trim() === '') {
            alert('Total Amount is required.');
            return false;
        }

        // Validate modeOfPayment
        if (modeOfPaymentSelect.value === '' || modeOfPaymentSelect.value === 'Choose a Payment Method') {
            alert('Please choose a valid Payment Method.');
            return false;
        }

        // If modeOfPayment is 'Cash', validate cashAmount
        if (modeOfPaymentSelect.value === 'Cash') {
            if (cashAmountInput.value.trim() === '') {
                alert('Cash Amount is required for Cash payment.');
                return false;
            }
        }

        // If all validations pass, submit the form
        return true;
    }

    function closeconfirmPaymentModal() {
        var modal = document.getElementById('confirmPaymentModal');
        modal.style.display = 'none';

        return true;
    }
</script>