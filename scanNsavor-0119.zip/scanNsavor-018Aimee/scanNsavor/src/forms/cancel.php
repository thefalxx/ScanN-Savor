<?php
$message = '';

if (isset($_POST['cancelOrder'])) {
    // Check if the session has started
    if (session_status() == PHP_SESSION_ACTIVE) {
        // Get the table number from POST data
        // Begin a database transaction
        $conn->begin_transaction();

        try {
            // Check if there is a cartID in the session
            if (isset($_SESSION['cartID'])) {
                $cartID = $_SESSION['cartID'];

                // Get the order details for the canceled items
                $getOrderDetailsQuery = "SELECT itemID, orderQuantity FROM tblcartdetails WHERE cartID = ?";
                $getOrderDetailsStmt = $conn->prepare($getOrderDetailsQuery);
                $getOrderDetailsStmt->bind_param("i", $cartID);

                $getOrderDetailsStmt->execute();
                $orderDetailsResult = $getOrderDetailsStmt->get_result();

                // Iterate through the canceled items and update tblfooditems
                while ($row = $orderDetailsResult->fetch_assoc()) {
                    $itemID = $row['itemID'];
                    $orderQuantity = $row['orderQuantity'];

                    // Update serving quantity in tblfooditems
                    $updateServingQuery = "UPDATE tblfooditems SET serving = serving + ? WHERE itemID = ?";
                    $updateServingStmt = $conn->prepare($updateServingQuery);
                    $updateServingStmt->bind_param("ii", $orderQuantity, $itemID);
                    $updateServingStmt->execute();

                    // Set availability to 'Available' and dishStatus to 'In Stock'
                    $setAvailabilityQuery = "UPDATE tblfooditems SET availability = 'Available', dishStatus = 'In Stock' WHERE itemID = ? AND serving > 0";
                    $setAvailabilityStmt = $conn->prepare($setAvailabilityQuery);
                    $setAvailabilityStmt->bind_param("i", $itemID);
                    $setAvailabilityStmt->execute();

                    // Check if the item is part of any menu package
                    $checkMenuPackageItemQuery = "SELECT packageID FROM tblmenupackageitems WHERE itemID = ?";
                    $checkMenuPackageItemStmt = $conn->prepare($checkMenuPackageItemQuery);
                    $checkMenuPackageItemStmt->bind_param("i", $itemID);
                    $checkMenuPackageItemStmt->execute();
                    $checkMenuPackageItemResult = $checkMenuPackageItemStmt->get_result();

                    while ($packageRow = $checkMenuPackageItemResult->fetch_assoc()) {
                        // Check if all items in the menu package are 'Available'
                        $checkPackageAvailabilityQuery = "SELECT COUNT(fi.itemID) AS unavailable_items
                                                          FROM tblfooditems fi
                                                          INNER JOIN tblmenupackageitems mpi ON fi.itemID = mpi.itemID
                                                          WHERE mpi.packageID = ? AND fi.availability = 'Unavailable'";
                        $checkPackageAvailabilityStmt = $conn->prepare($checkPackageAvailabilityQuery);
                        $checkPackageAvailabilityStmt->bind_param("i", $packageRow['packageID']);
                        $checkPackageAvailabilityStmt->execute();
                        $unavailableItemsCount = $checkPackageAvailabilityStmt->get_result()->fetch_assoc()['unavailable_items'];
                        $checkPackageAvailabilityStmt->close();

                        if ($unavailableItemsCount === 0) {
                            // If all items in the package are 'Available', set the package availability to 'Available'
                            $updateMenuPackageAvailabilityQuery = "UPDATE tblmenupackage SET availability = 'Available' WHERE packageID = ?";
                            $updateMenuPackageAvailabilityStmt = $conn->prepare($updateMenuPackageAvailabilityQuery);
                            $updateMenuPackageAvailabilityStmt->bind_param("i", $packageRow['packageID']);
                            $updateMenuPackageAvailabilityStmt->execute();
                            $updateMenuPackageAvailabilityStmt->close();
                        }
                    }

                    $checkMenuPackageItemStmt->close();
                }

                // User canceled the order from the cart
                $deleteCartDetailsQuery = "DELETE FROM tblcartdetails WHERE cartID = ?";
                $deleteCartDetailsStmt = $conn->prepare($deleteCartDetailsQuery);
                $deleteCartDetailsStmt->bind_param("i", $cartID);

                if ($deleteCartDetailsStmt->execute()) {
                    // Commit the transaction
                    $conn->commit();

                    // Clear the session cartID
                    unset($_SESSION['cartID']);

                    // Clear the session cart
                    $_SESSION['cart'] = [];

                    $message = "Order cancelled successfully!";
                    // echo "<script>alert('Order cancelled successfully!');</script>";
                } else {
                    throw new Exception("Failed to delete cart details: " . $conn->error);
                }
            } else {
                $tableNumber = $_POST['tableNum'];

                // User canceled a placed order
                $deleteOrderQuery = "DELETE FROM tblorders WHERE tableNo = ?";
                $deleteOrderStmt = $conn->prepare($deleteOrderQuery);
                $deleteOrderStmt->bind_param("i", $tableNumber);

                if ($deleteOrderStmt->execute()) {
                    // Delete all order details for the canceled orders
                    $deleteOrderDetailsQuery = "DELETE FROM tblorderdetails WHERE orderID IN (SELECT orderID FROM tblorders WHERE tableNo = ?)";
                    $deleteOrderDetailsStmt = $conn->prepare($deleteOrderDetailsQuery);
                    $deleteOrderDetailsStmt->bind_param("i", $tableNumber);

                    if ($deleteOrderDetailsStmt->execute()) {
                        // Commit the transaction
                        $conn->commit();

                        $message = "Order cancelled successfully!";
                        //echo "<script>alert('Order canceled successfully!');</script>";
                    } else {
                        throw new Exception("Failed to delete order details: " . $conn->error);
                    }
                } else {
                    throw new Exception("Failed to delete orders: " . $conn->error);
                }
            }
        } catch (Exception $e) {
            // Roll back the transaction in case of an error
            $conn->rollback();
            echo "Cancellation failed: " . $e->getMessage();
        }
    } else {
        echo "Session not active.";
    }
}  

?>

<div id="cancelModal" tabindex="-1" class="fixed top-0 left-0 right-0 bottom-0 flex justify-center items-center z-50 hidden p-4 overflow-x-hidden overflow-y-auto">
    <div class="relative w-full h-auto max-w-md max-h-full">
        <div class="relative bg-white rounded-lg shadow">
            <button type="button" onclick="toggleModal('update-status-modal')" class="absolute top-3 right-2.5 text-gray-400 bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm p-1.5 ml-auto inline-flex items-center" data-modal-toggle="continuemodal">
                <svg aria-hidden="true" class="w-5 h-5" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                    <path fill-rule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clip-rule="evenodd" />
                </svg>
                <span class="sr-only">Close modal</span>
            </button>
            
            <form id="cancelOrderForm"  method="POST" action="" onsubmit="cancelOrder(); return false;">
                <div class="p-6 text-center">
                    <svg aria-hidden="true" class="mx-auto mb-4 text-gray-400 w-14 h-14" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                    <h3 class="mb-5 text-lg font-normal text-gray-500">Are you sure you want to cancel your order?</h3>
            
                    
                    <button type="submit" name="cancelOrder" value="cancelOrder" class="text-green-700 hover:text-white border hover:bg-teal-800 focus:ring-4 focus:outline-none focus:ring-teal-300 font-medium rounded-lg text-sm inline-flex items-center px-5 py-2.5 text-center mr-2" id="cancelModal" data-modal-toggle="viewCartModal" data-modal-hide="cancelModal" onclick="showCancelMessageModal()">Yes</button>

                    <button class="text-red-700 hover:text-white  hover:bg-red-800 focus-ring-4 focus-outline-none focus-ring-gray-200 rounded-lg  border-gray-200 text-sm font-medium px-5 py-2.5 hover-text-gray-900 focus-z-10" data-modal-toggle="viewCartModal">Back to Menu</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php if ($message != '') { ?>
    <div id="cancelMessageModal" class="bg-white border-2 border-black text-black w-80 h-32 px-4 py-14 rounded-lg relative justify-center items-center text-center" role="alert" style="position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%); z-index: 999;">
        <strong class="font-bold"> <?php echo $message; ?></strong>
        <span class="absolute top-0 bottom-0 right-0 px-4 py-3" onclick="closeCancelMessageModal()">
            <svg class="fill-current h-6 w-6 text-teal-800" role="button" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20">
                <title>Close</title>
                <path d="M14.348 14.849a1.2 1.2 0 0 1-1.697 0L10 11.819l-2.651 3.029a1.2 1.2 0 1 1-1.697-1.697l2.758-3.15-2.759-3.152a1.2 1.2 0 1 1 1.697-1.697L10 8.183l2.651-3.031a1.2 1.2 0 1 1 1.697 1.697l-2.758 3.152 2.758 3.15a1.2 1.2 0 0 1 0 1.698z" />
            </svg>
        </span>
    </div>
    <script>
        function showMessageModal() {
            var modal = document.getElementById('cancelMessageModal');
            modal.style.display = 'block';
            setTimeout(function () {
                modal.style.display = 'none';
            }, 1000); // Adjust the duration (in milliseconds) as needed
        }
        // Call the function to show the modal
        showMessageModal();
    </script>
<?php } ?>


<script>
    function showCancelMessageModal() {
        var modal = document.getElementById('cancelMessageModal');
        modal.style.display = 'block';
    }
</script>

<script>
    function closeCancelMessageModal() {
        var modal = document.getElementById('cancelMessageModal');
        modal.style.display = 'none';
    }
</script>

<script>
    function cancelOrder() {
        var formData = $('#cancelOrderForm').serialize(); // Serialize the form data

        $.ajax({
            type: 'POST',
            url: "/additionalorders.php?tableNo=<?php echo $tableNo; ?>&orderID=<?php echo $orderID; ?>",
            data: formData,
            dataType: 'json',
            success: function(response) {
                if (response.status === 'success') {
                    alert(response.message);

                    // Optionally, update any UI elements on the page
                    // For example, you can update the displayed quantity without reloading the page
                    // $('.quantity-display').text(response.newQuantity);
                } else {
                    alert(response.message);
                }
            },
            error: function(xhr, status, error) {
                console.error('AJAX error: ' + status + ', ' + error);
            }

        });
    }
</script>

<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
<!-- <script>
    function cancelOrder() {
        $.ajax({
            url: "/additionalorders.php?tableNo=<?php echo $tableNo; ?>&orderID=<?php echo $orderID; ?>",
            type: "post",
            data: $("#cancel").serialize(), // Serialize form data
            success: function(data) {
                // Handle success response if needed
                alert("Item added to cart successfully!");
            },
            error: function(xhr, status, error) {
                // Handle error response if needed
                alert("Error adding item to cart: " + error);
            }
        });
    }
</script> -->