<?php
$categoryData = $menu->getCategories();
$message = $menu->addMenuItems();

?>

<div id="createMenuModal" tabindex="-1" aria-hidden="true" class="hidden overflow-y-auto overflow-x-hidden fixed top-0 right-0 left-0 z-50 justify-center items-center w-full md:inset-0 h-[calc(100%-1rem)] md:h-full">
    <div class="relative p-4 w-full max-w-2xl h-full md:h-auto">
        <!-- Modal content -->
        <div class="relative p-4 bg-white rounded-lg shadow">
            <!-- Modal header -->
            <div class="flex justify-between items-center pb-4 mb-4 rounded-t border-b sm:mb-5">
                <h3 class="text-lg font-semibold text-gray-900">Add Food Item</h3>
                <button type="button" class="text-gray-400 bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm p-1.5 ml-auto inline-flex items-center" data-modal-toggle="createMenuModal">
                    <svg aria-hidden="true" class="w-5 h-5" fill="currentColor" viewbox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                        <path fill-rule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clip-rule="evenodd" />
                    </svg>
                    <span class="sr-only">Close modal</span>
                </button>
            </div>
            <!-- Modal body -->
            <form method="post" enctype="multipart/form-data">
                <div class="grid gap-4 mb-4 sm:grid-cols-2">
                    <div>
                        <label for="addItemName" class="block mb-2 text-sm font-medium text-gray-900">Dish Name</label>
                        <input type="text" name="addItemName" id="addItemName" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-green-200 focus:border-green-200 block w-full p-2.5" placeholder="Type dish name" required="">
                    </div>

                    <div><label for="addItemCategory" class="block mb-2 text-sm font-medium text-gray-900">Category</label>
                        <select id="addItemCategory" name="addItemCategory" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-green-200 focus:border-green-200 block w-full p-2.5">
                            <option value="" disabled selected></option>
                            <?php
                            foreach ($categoryData as $category) {
                                echo "<option value='{$category['categoryID']}'>{$category['categoryName']}</option>";
                            }
                            ?>
                        </select>
                    </div>
                    <div>
                        <label for="addItemPrice" class="block mb-2 text-sm font-medium text-gray-900">Price</label>
                        <input type="text" name="addItemPrice" id="addItemPrice" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-green-200 focus:border-green-200 block w-full p-2.5" placeholder="" required="">
                    </div>
                    <div>
                        <label for="addPax" class="block mb-2 text-sm font-medium text-gray-900">Good for</label>
                        <select id="addPax" name="addPax" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-green-200 focus:border-green-200 block w-full p-2.5" placeholder="" required="">
                            <option selected=""></option>
                            <option value="1">1 person</option>
                            <option value="2">2 persons</option>
                            <option value="3">3 persons</option>
                            <option value="4">4 persons</option>
                            <option value="5">5 persons</option>
                            <option value="Family">Family</option>
                        </select>
                    </div>
                    <div class=""><label for="addItemDescription" class="block mb-2 text-sm font-medium text-gray-900">Description</label>
                        <textarea id="addItemDescription" name="addItemDescription" rows="4" class="block p-2.5 w-full text-sm text-gray-900 bg-gray-50 rounded-lg border border-gray-300 focus:ring-green-200 focus:border-green-200" placeholder="Write dish description here"></textarea>
                    </div>
                </div>
                <div>
                    <!-- <label for="addAvailability" class="block mb-2 text-sm font-medium text-gray-900">Availability</label>

                    <select id="addAvailability" name="addAvailability" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5" placeholder="" required="">
                        <option selected=""></option>
                        <option value="Available">Available</option>
                        <option value="Unvailable">Unavailable</option>
                    </select> -->
                </div>

                <div class="mb-4">
                    <span class="block mb-3 text-sm font-medium text-gray-900">Dish Image</span>
                    <div class="justify-center items-center w-full">
                        <label for="fileToUpload" class="flex flex-col justify-center items-center w-full h-80 bg-gray-50 rounded-lg border-2 border-gray-300 border-dashed cursor-pointer" id="imagePreview">
                            <img id="preview" class="object-contain min-w-full min-h-full max-w-full max-h-full p-2 hidden">
                            <svg aria-hidden="true" id="uploadIcon" class="mb-3 w-10 h-10 text-gray-400" fill="none" stroke="currentColor" viewbox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" />
                            </svg>
                            <p id="uploadText" class="mb-2 text-sm text-gray-500 ">
                                <span class="font-semibold">Click to upload</span>
                                or drag and drop
                            </p>
                            <p id="uploadText1" class="text-xs text-gray-500">SVG, PNG, JPG, or GIF (MAX. 800x400px)</p>
                            <input id="fileToUpload" name="fileToUpload" type="file" class="hidden" accept="image/*" onchange="previewImageHide()">
                        </label>
                    </div>
                </div>
                <div class="items-center space-y-4 sm:flex sm:space-y-4 sm:space-x-4">
                    <button type="submit" name="addMenuItem" value="addMenuItem" class="w-full sm:w-auto justify-center text-teal-800 inline-flex border border-gray-300 bg-teal-700 hover:bg-teal-800 hover:text-white focus:ring-4 focus:outline-none focus:ring-primary-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center" onclick="AddItemMessageModal()">
                        Add Menu
                    </button>

                </div>
            </form>
        </div>
    </div>
</div>


<?php if ($message != '') { ?>
    <div id="AddItemMessageModal" class="bg-white border-2 border-black text-black w-80 h-32 px-4 py-14 rounded-lg relative justify-center items-center text-center" role="alert" style="position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%); z-index: 999;">
        <strong class="font-bold"> <?php echo $message; ?></strong>
        <span class="absolute top-0 bottom-0 right-0 px-4 py-3" onclick="closeAddItemMessageModal()">
            <svg class="fill-current h-6 w-6 text-teal-800" role="button" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20">
                <title>Close</title>
                <path d="M14.348 14.849a1.2 1.2 0 0 1-1.697 0L10 11.819l-2.651 3.029a1.2 1.2 0 1 1-1.697-1.697l2.758-3.15-2.759-3.152a1.2 1.2 0 1 1 1.697-1.697L10 8.183l2.651-3.031a1.2 1.2 0 1 1 1.697 1.697l-2.758 3.152 2.758 3.15a1.2 1.2 0 0 1 0 1.698z" />
            </svg>
        </span>
    </div>
<?php } ?>


<script>
    function previewImageHide() {
        var preview = document.getElementById('preview');
        var uploadIcon = document.getElementById('uploadIcon');
        var uploadText = document.getElementById('uploadText');
        var uploadText1 = document.getElementById('uploadText1');

        var fileInput = document.getElementById('fileToUpload');
        var file = fileInput.files[0];

        if (file) {
            // If a file is selected, display the preview and hide the SVG and text
            preview.src = URL.createObjectURL(file);
            preview.classList.remove('hidden');
            uploadIcon.classList.add('hidden');
            uploadText.classList.add('hidden');
            uploadText1.classList.add('hidden');
        } else {
            // If no file is selected, hide the preview and show the SVG and text
            preview.src = '';
            preview.classList.add('hidden');
            uploadIcon.classList.remove('hidden');
            uploadText.classList.remove('hidden');
            uploadText1.classList.remove('hidden');
        }
    }
</script>

<script>
    function showAddItemMessageModal() {
        var modal = document.getElementById('AddItemMessageModal');
        modal.style.display = 'block';
    }


    function previewImage() {
        var fileInput = document.getElementById('fileToUpload');
        var imagePreview = document.getElementById('imagePreview');
        var previewImage = document.getElementById('preview');

        if (fileInput.files && fileInput.files[0]) {
            var reader = new FileReader();

            reader.onload = function(e) {
                // Show image preview
                imagePreview.classList.remove('hidden');
                previewImage.src = e.target.result;
            };

            // Read the image file
            reader.readAsDataURL(fileInput.files[0]);
        }
    }


    function closeAddItemMessageModal() {
        var modal = document.getElementById('AddItemMessageModal');
        modal.style.display = 'none';
    }
</script>