<?php
include('../forms/menucategoryformcreate.php');
include('../viewManager/tablesidebar.php');
include('../forms/menuformcreate.php');
include('../forms/menuformupdate.php');
include('../forms/mealpackageformcreate.php');

$fooditems = $menu->getAllItems();
$catMappings = $menu->fetchCategoryMappings();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="../../dist/output.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/flowbite/1.8.0/flowbite.min.css" rel="stylesheet" />
    <title>Scan N Savor | Menu Management</title>
</head>

<body>

    <!-- Start block -->
    <section class="py-3">
        <div class="mx-auto pl-20 ml-20">
            <div class="mx-auto max-w-screen-xl max-h-screen-xl px-4 lg:px-12  xl:px-14">
                <div class="bg-white relative shadow-md sm:rounded-lg overflow-hidden">
                    <div class="flex flex-col md:flex-row items-stretch md:items-center md:space-x-3 space-y-3 md:space-y-0 justify-between mx-4 py-4 border-t">
                        <div class="w-full">
                            <form class="flex items-center">
                                <label for="simple-search" class="sr-only">Search</label>
                                <div class="relative w-full">
                                    <div class="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                                        <svg aria-hidden="true" class="w-5 h-5 text-gray-500" fill="currentColor" viewbox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                                            <path fill-rule="evenodd" clip-rule="evenodd" d="M8 4a4 4 0 100 8 4 4 0 000-8zM2 8a6 6 0 1110.89 3.476l4.817 4.817a1 1 0 01-1.414 1.414l-4.816-4.816A6 6 0 012 8z" />
                                        </svg>
                                    </div>
                                    <input type="text" id="simple-search" placeholder="Search for food items" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-500 focus:border-primary-500 block w-full pl-10 p-2">
                                </div>
                            </form>
                        </div>
                        <div class="w-full md:w-auto flex flex-col md:flex-row space-y-2 md:space-y-0 items-stretch md:items-center justify-end md:space-x-3 flex-shrink-0">
                            <button type="button" id="createCategoriesButton" data-modal-toggle="createCategoriesButton" class="flex items-center justify-center text-teal-800 bg-primary-700 hover:bg-teal-800 hover:text-white focus:ring-4 focus:ring-primary-300 border border-gray-200 font-medium rounded-lg text-sm px-4 py-2">
                                <svg class="h-3.5 w-3.5 mr-1.5 -ml-1" fill="currentColor" viewbox="0 0 20 20" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
                                    <path clip-rule="evenodd" fill-rule="evenodd" d="M10 3a1 1 0 011 1v5h5a1 1 0 110 2h-5v5a1 1 0 11-2 0v-5H4a1 1 0 110-2h5V4a1 1 0 011-1z" />
                                </svg>
                                Add Categories
                            </button>

                            <button type="button" id="createMenuButton" data-modal-toggle="createMenuModal" class="flex items-center justify-center text-teal-800 bg-primary-700 hover:bg-teal-800 hover:text-white focus:ring-4 focus:ring-primary-300 border border-gray-200 font-medium rounded-lg text-sm px-4 py-2">
                                <svg class="h-3.5 w-3.5 mr-1.5 -ml-1" fill="currentColor" viewbox="0 0 20 20" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
                                    <path clip-rule="evenodd" fill-rule="evenodd" d="M10 3a1 1 0 011 1v5h5a1 1 0 110 2h-5v5a1 1 0 11-2 0v-5H4a1 1 0 110-2h5V4a1 1 0 011-1z" />
                                </svg>
                                Add Food Item
                            </button>

                            <button type="button" id="createPackageButton" data-modal-toggle="createPackageModal" class="flex items-center justify-center text-teal-800 bg-primary-700 hover:bg-teal-800 hover:text-white focus:ring-4 focus:ring-primary-300 border border-gray-200 font-medium rounded-lg text-sm px-4 py-2">
                                <svg class="h-3.5 w-3.5 mr-1.5 -ml-1" fill="currentColor" viewbox="0 0 20 20" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
                                    <path clip-rule="evenodd" fill-rule="evenodd" d="M10 3a1 1 0 011 1v5h5a1 1 0 110 2h-5v5a1 1 0 11-2 0v-5H4a1 1 0 110-2h5V4a1 1 0 011-1z" />
                                </svg>
                                Add Menu Package
                            </button>
                        </div>
                    </div>

                    <div class="overflow-x-auto ">
                        <table class="w-full text-sm text-left text-gray-500 ">
                            <thead class="text-xs text-gray-700 uppercase bg-gray-50">
                                <tr>
                                    <!-- <th scope="col" class="p-4 bg-gray-50"></th> -->
                                    <th scope="col" class="px-8 py-4">Dish Name</th>
                                    <th scope="col" class="px-8 py-4">Category</th>
                                    <th scope="col" class="px-8 py-4">Price</th>
                                    <th scope="col" class="px-8 py-4">Status</th>
                                    <th scope="col" class="px-8 py-4"></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($fooditems as $item) { ?>
                                    <tr class="border-b hover:bg-gray-100">
                                        <!-- <td class="p-4 w-4">
                                        <div class="flex items-center">
                                            <input id="checkbox-table-search-1" type="checkbox" onclick="event.stopPropagation()" class="w-4 h-4 text-primary-600 bg-gray-100 rounded border-gray-300 focus:ring-primary-500">
                                            <label for="checkbox-table-search-1" class="sr-only">checkbox</label>
                                        </div>
                                    </td> -->

                                        <!-- name -->
                                        <td class="px-8 py-3 font-medium text-gray-500 whitespace-nowrap">
                                            <?php echo $item['itemName']; ?>
                                        </td>

                                        <!-- category -->
                                        <td class="px-8 py-3"><?php
                                                                $categoryid = $item['categoryID'];
                                                                $category = isset($catMappings[$categoryid]) ? $catMappings[$categoryid] : "undefined";
                                                                echo $category;
                                                                ?></td>

                                        <!-- price -->
                                        <td class="px-8 py-3"><?php echo $item['price']; ?></td>

                                        <!-- status -->
                                        <td class="px-8 py-3">
                                            <div class="flex items-center">
                                                <span class="text-gray-500 ml-1">AVAILABLE</span>
                                            </div>
                                        </td>

                                        <!-- description -->
                                        <!-- <td class="px-4 py-3 font-medium text-gray-900 whitespace-nowrap">
                                        <div class="flex items-center">
                                           
                                        </div>
                                    </td> -->

                                        <!-- <td class="px-4 py-3"></td> -->
                                        <td class="px-4 py-3 font-medium text-gray-900 whitespace-nowrap">
                                            <div class="flex items-center justify-end space-x-4">
                                                <button type="button" data-modal-toggle="updateMenuModal" onclick="openUpdateModal('<?php echo $item['itemID']; ?>','<?php echo $item['itemName']; ?>','<?php echo $item['categoryID']; ?>','<?php echo $item['price']; ?>')" class="py-2 px-3 flex items-center text-sm font-medium text-center text-teal-800 focus:outline-none bg-white rounded-lg border border-gray-200 hover:bg-teal-800 hover:text-white focus:z-10 focus:ring-4 focus:ring-green-200">
                                                    <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 mr-2 -ml-0.5" viewbox="0 0 20 20" fill="currentColor" aria-hidden="true">
                                                        <path d="M17.414 2.586a2 2 0 00-2.828 0L7 10.172V13h2.828l7.586-7.586a2 2 0 000-2.828z" />
                                                        <path fill-rule="evenodd" d="M2 6a2 2 0 012-2h4a1 1 0 010 2H4v10h10v-4a1 1 0 112 0v4a2 2 0 01-2 2H4a2 2 0 01-2-2V6z" clip-rule="evenodd" />
                                                    </svg>
                                                    Edit
                                                </button>
                                                <button type="button" data-drawer-target="" data-drawer-show="" aria-controls="" class="py-2 px-3 flex items-center text-sm font-medium text-center text-teal-800 focus:outline-none bg-white rounded-lg border border-gray-200 hover:bg-teal-800 hover:text-white focus:z-10 focus:ring-4 focus:ring-gray-200">
                                                    <svg xmlns="http://www.w3.org/2000/svg" viewbox="0 0 24 24" fill="currentColor" class="w-4 h-4 mr-2 -ml-0.5">
                                                        <path d="M12 15a3 3 0 100-6 3 3 0 000 6z" />
                                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M1.323 11.447C2.811 6.976 7.028 3.75 12.001 3.75c4.97 0 9.185 3.223 10.675 7.69.12.362.12.752 0 1.113-1.487 4.471-5.705 7.697-10.677 7.697-4.97 0-9.186-3.223-10.675-7.69a1.762 1.762 0 010-1.113zM17.25 12a5.25 5.25 0 11-10.5 0 5.25 5.25 0 0110.5 0z" />
                                                    </svg>
                                                    Preview
                                                </button>
                                                <button type="button" data-modal-target="delete-modal" data-modal-toggle="delete-modal" class="flex items-center text-red-700 hover:text-white border hover:bg-red-800 focus:ring-4 focus:outline-none focus:ring-red-300 font-medium rounded-lg text-sm px-3 py-2 text-center">
                                                    <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 mr-2 -ml-0.5" viewbox="0 0 20 20" fill="currentColor" aria-hidden="true">
                                                        <path fill-rule="evenodd" d="M9 2a1 1 0 00-.894.553L7.382 4H4a1 1 0 000 2v10a2 2 0 002 2h8a2 2 0 002-2V6a1 1 0 100-2h-3.382l-.724-1.447A1 1 0 0011 2H9zM7 8a1 1 0 012 0v6a1 1 0 11-2 0V8zm5-1a1 1 0 00-1 1v6a1 1 0 102 0V8a1 1 0 00-1-1z" clip-rule="evenodd" />
                                                    </svg>
                                                    Delete
                                                </button>
                                            </div>
                                        </td>
                                    </tr>
                                <?php } ?>
                            </tbody>
                        </table>
                    </div>

                    <nav class="flex flex-col md:flex-row justify-between items-start md:items-center space-y-3 md:space-y-0 p-4" aria-label="Table navigation">
                        <span class="text-sm font-normal text-gray-500">
                            Showing
                            <span class="font-semibold text-gray-900">1-10</span>
                            of
                            <span class="font-semibold text-gray-900">1000</span>
                        </span>
                        <ul class="inline-flex items-stretch -space-x-px">
                            <li>
                                <a href="#" class="flex items-center justify-center h-full py-1.5 px-3 ml-0 text-gray-500 bg-white rounded-l-lg border border-gray-300 hover:bg-gray-100 hover:text-gray-700">
                                    <span class="sr-only">Previous</span>
                                    <svg class="w-5 h-5" aria-hidden="true" fill="currentColor" viewbox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                                        <path fill-rule="evenodd" d="M12.707 5.293a1 1 0 010 1.414L9.414 10l3.293 3.293a1 1 0 01-1.414 1.414l-4-4a1 1 0 010-1.414l4-4a1 1 0 011.414 0z" clip-rule="evenodd" />
                                    </svg>
                                </a>
                            </li>
                            <li>
                                <a href="#" class="flex items-center justify-center text-sm py-2 px-3 leading-tight text-gray-500 bg-white border border-gray-300 hover:bg-gray-100 hover:text-gray-700">1</a>
                            </li>
                            <li>
                                <a href="#" class="flex items-center justify-center text-sm py-2 px-3 leading-tight text-gray-500 bg-white border border-gray-300 hover:bg-gray-100 hover:text-gray-700">2</a>
                            </li>
                            <li>
                                <a href="#" aria-current="page" class="flex items-center justify-center text-sm z-10 py-2 px-3 leading-tight text-primary-600 bg-primary-50 border border-primary-300 hover:bg-primary-100 hover:text-primary-700">3</a>
                            </li>
                            <li>
                                <a href="#" class="flex items-center justify-center text-sm py-2 px-3 leading-tight text-gray-500 bg-white border border-gray-300 hover:bg-gray-100 hover:text-gray-700">...</a>
                            </li>
                            <li>
                                <a href="#" class="flex items-center justify-center text-sm py-2 px-3 leading-tight text-gray-500 bg-white border border-gray-300 hover:bg-gray-100 hover:text-gray-700">100</a>
                            </li>
                            <li>
                                <a href="#" class="flex items-center justify-center h-full py-1.5 px-3 leading-tight text-gray-500 bg-white rounded-r-lg border border-gray-300 hover:bg-gray-100 hover:text-gray-700">
                                    <span class="sr-only">Next</span>
                                    <svg class="w-5 h-5" aria-hidden="true" fill="currentColor" viewbox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                                        <path fill-rule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clip-rule="evenodd" />
                                    </svg>
                                </a>
                            </li>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
    </section>
</body>

<script>
    function openUpdateModal(itemID, itemName, categoryID, price) {

        var modal = document.getElementById("updateMenuModal");
        var overlay = document.getElementById("overlay");

        var updateItemID = document.getElementById("itemID");
        var updateItemName = document.getElementById("itemName");
        var updateCategoryID = document.getElementById("updatecategoryID");
        var updatePrice = document.getElementById("updateprice");

        updateItemID.value = itemID;
        updateItemName.value = itemName;
        updateCategoryID.value = categoryID;
        updatePrice.value = price;

        modal.style.display = "block";
        overlay.style.display = "block";


    }

    function closeModalUpdate() {
        var modal = document.getElementById('updateMenuModal');
        modal.style.display = 'none';
    }

    function closeModalUpdate() {
        $('#updateMenuModal').hide();
    }
</script>

</html>

<script src="https://cdnjs.cloudflare.com/ajax/libs/flowbite/1.8.0/flowbite.min.js"></script>