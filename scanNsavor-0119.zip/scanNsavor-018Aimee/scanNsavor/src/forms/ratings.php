<div x-data="{ open: false }" x-init="open = true" id="diningChoice">
        <!-- Modal overlay -->
        <div x-show="open" class="fixed inset-0  bg-gray-500 bg-opacity-75 flex items-center justify-center">
            <!-- Modal content -->
            <div class="justify-center bg-white p-6 rounded-xl shadow-lg lg:w-[580px] lg:mx-0 mx-5">
                <header class=" text-center px-10 py-8">
                    <div class="flex items-center">
                        <div class="grow border-b border-teal-700"></div>
                        <span class="shrink px-1 pb-1 text-teal-700 font-bold lg:text-2xl text-xl">&nbsp; R A T I N G S &nbsp;</span>
                        <div class="grow border-b border-teal-700"></div>
                    </div>
                </header>
                <p class="text-center lg:px-24 px-8 text-xs text-gray-500">Scan N Savor <br> would like you to rate your dining experience.</p>
                <div class="justify-center px-14 pt-10">
                    <div class="rating rating-lg items-center justify-center flex">
                        <input type="radio" name="rating-8" class="mask mask-star-2 bg-orange-400" checked />
                        <input type="radio" name="rating-8" class="mask mask-star-2 bg-orange-400" />
                        <input type="radio" name="rating-8" class="mask mask-star-2 bg-orange-400" />
                        <input type="radio" name="rating-8" class="mask mask-star-2 bg-orange-400" />
                        <input type="radio" name="rating-8" class="mask mask-star-2 bg-orange-400" />
                    </div>
                    <div class="mb-6 pt-20">
                        <label for="feedback" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Feedback:</label>
                        <p class="visible mx-0 mb-0 text-sm leading-relaxed text-left text-slate-400">
                            We'd love to hear from you!
                        </p>
                        <textarea type="text" id="specialReqs" class="block w-full p-4 text-gray-900 border border-gray-300 rounded-lg bg-gray-50 sm:text-md focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" placeholder="Write feedback here"></textarea>
                    </div>
                    <div class="justify-center items-center text-center pt-5">
                        <button class=" border border-teal-700  text-teal-700 hover:text-white hover:border-none duration-300 relative group cursor-pointer overflow-hidden h-10 w-30 rounded-lg p-2 font-extrabold hover:bg-teal-700">
                            <!-- <div class="absolute group-hover:-top-1 group-hover:-right-2 z-10 w-16 h-16 rounded-full group-hover:scale-150  duration-700 right-12 top-12 bg-teal-500"></div>
                        <div class="absolute group-hover:-top-1 group-hover:-right-2 z-10 w-12 h-12 rounded-full group-hover:scale-150  duration-700 right-20 -top-6 bg-teal-300"></div>
                        <div class="absolute group-hover:-top-1 group-hover:-right-2 z-10 w-8 h-8   rounded-full group-hover:scale-150  duration-700 right-32 top-6 bg-teal-200"></div>
                        <div class="absolute group-hover:-top-1 group-hover:-right-2 z-10 w-4 h-4   rounded-full group-hover:scale-150  duration-700 right-2 top-12 bg-teal-100"></div> -->
                            <p class=" text-center">Submit</p>
                        </button>
                    </div>
                </div>
                <!-- Close button -->
                <button @click="open = false" class="mt-4 text-gray-400 px-4 py-2">Close</button>
            </div>
        </div>
    </div>
