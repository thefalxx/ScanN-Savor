<?php

global $conn;

$message='';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['updateUserDetails'])) {
    // Get the form data
    $username = $_POST['updateusername'];
    $password = $_POST['updatepassword'];

    // Assuming $_SESSION["userid"] contains the empAccID for the user
    $empAccID = $_SESSION["userid"];

    // Check if a new username is provided
    if (!empty($username)) {
        // Check if the username already exists
        $checkUsernameQuery = "SELECT empAccID FROM tblemployees WHERE username = ? AND empAccID != ?";
        $checkUsernameStmt = $conn->prepare($checkUsernameQuery);
        $checkUsernameStmt->bind_param("si", $username, $empAccID);
        $checkUsernameStmt->execute();
        $checkUsernameResult = $checkUsernameStmt->get_result();

        if ($checkUsernameResult->num_rows > 0) {
            echo "<script>alert('Username already exists. Please choose a different username.');</script>";
        } else {
            // Update the username in the database
            $updateUsernameQuery = "UPDATE tblemployees SET username=? WHERE empAccID=?";
            $updateUsernameStmt = $conn->prepare($updateUsernameQuery);
            $updateUsernameStmt->bind_param("si", $username, $empAccID);

            if ($updateUsernameStmt->execute()) {
                
                // echo "<script>alert('Username updated successfully');</script>";
            } else {
                echo "<script>alert('Error updating username: " . $updateUsernameStmt->error . "');</script>";
            }

            $updateUsernameStmt->close();
            $message = "Username and password updated successfully!";        }
    }

    // Check if a new password is provided
    if (!empty($password)) {
        // Hash the new password
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

        // Update the hashed password in the database
        $updatePasswordQuery = "UPDATE tblemployees SET password=? WHERE empAccID=?";
        $updatePasswordStmt = $conn->prepare($updatePasswordQuery);
        $updatePasswordStmt->bind_param("si", $hashedPassword, $empAccID);

        if ($updatePasswordStmt->execute()) {
            // echo "<script>alert('Password updated successfully');</script>";
        } else {
            echo "<script>alert('Error updating password: " . $updatePasswordStmt->error . "');</script>";
        }

        $updatePasswordStmt->close();
    }
}


?>

<div id="authentication-modal" tabindex="-1" aria-hidden="true" class="hidden overflow-y-auto overflow-x-hidden fixed top-0 right-0 left-0 z-50 justify-center items-center w-full md:inset-0 h-[calc(100%-1rem)] max-h-full">
    <div class="relative p-4 w-full max-w-md max-h-full">
        <!-- Modal content -->
        <div class="relative bg-white rounded-lg shadow dark:bg-gray-700">
            <!-- Modal header -->
            <div class="flex items-center justify-between p-4 md:p-5 border-b rounded-t dark:border-gray-600">
                <h3 class="text-xl font-semibold text-gray-900 dark:text-white">
                    Update Profile
                </h3>
                <button type="button" class="end-2.5 text-gray-400 bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm w-8 h-8 ms-auto inline-flex justify-center items-center dark:hover:bg-gray-600 dark:hover:text-white" data-modal-hide="authentication-modal">
                    <svg class="w-3 h-3" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 14 14">
                        <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m1 1 6 6m0 0 6 6M7 7l6-6M7 7l-6 6"/>
                    </svg>
                    <span class="sr-only">Close modal</span>
                </button>
            </div>
            <!-- Modal body -->
            <div class="p-4 md:p-5">
                <form class="space-y-4" action="" method="post">
                <?php if ($message != '') { ?>
                    <div class="mb-4 rounded-lg bg-success-100 px-6 py-5 text-base text-success-700" role="alert">
                        <?php echo $message; ?></div>
                <?php } ?>
                    <div>
                        <label for="editUsername" class="block mb-2 text-sm font-medium text-gray-900">Username</label>
                        <input type="text" name="updateusername" id="updateusername" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5" placeholder="" value="">
                    </div>
                    <div>
                        <label for="editPassword" class="block mb-2 text-sm font-medium text-gray-900">Password</label>
                        <input type="password" name="updatepassword" id="updatepassword" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5" placeholder="" autocomplete="off" value="">
                    </div>  
                    <button type="submit" class="w-full text-white bg-teal-700 hover:bg-teal-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800" name="updateUserDetails" onclick="showUpdateUserMessageModal()">Submit changes</button>
                </form>
            </div>
        </div>
    </div>
</div>

<?php if ($message != '') { ?>
    <div id="UpdateUserMessageModal" class="bg-white border-2 border-black text-black w-80 h-32 px-4 py-14 rounded-lg relative justify-center items-center text-center" role="alert" style="position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%); z-index: 999;">
        <strong class="font-bold"> <?php echo $message; ?></strong>
        <span class="absolute top-0 bottom-0 right-0 px-4 py-3" onclick="closeUpdateUserMessageModal()">
            <svg class="fill-current h-6 w-6 text-teal-800" role="button" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20">
                <title>Close</title>
                <path d="M14.348 14.849a1.2 1.2 0 0 1-1.697 0L10 11.819l-2.651 3.029a1.2 1.2 0 1 1-1.697-1.697l2.758-3.15-2.759-3.152a1.2 1.2 0 1 1 1.697-1.697L10 8.183l2.651-3.031a1.2 1.2 0 1 1 1.697 1.697l-2.758 3.152 2.758 3.15a1.2 1.2 0 0 1 0 1.698z" />
            </svg>
        </span>
    </div>
<?php } ?>



<script>
    function showUpdateUserMessageModal() {
        var modal = document.getElementById('UpdateUserMessageModal');
        modal.style.display = 'block';
    }
</script>

<script>
    UpdateUseryMessageModal

    function closeUpdateUserMessageModal() {
        var modal = document.getElementById('UpdateUserMessageModal');
        modal.style.display = 'none';
    }
</script>
