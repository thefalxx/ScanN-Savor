<?php
// Fetch food items and category mappings
$fooditems = $menu->getAllItemsDetails();
$catMappings = $menu->fetchCategoryMappings();

// Initialize message variable
$message = '';

// Initialize selected items array from POST data or set to an empty array
$selectedItems = isset($_POST['selectedItems']) ? $_POST['selectedItems'] : [];

// Check if 'upPackageItems' is set in the POST request
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['upPackageItems'])) {
    // If 'upPackageItems' is set, update $selectedItems accordingly
    $selectedItems = explode(',', $_POST['upPackageItems']);
}

// Check if form for updating package items is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['updatePackageItems'])) {
    // Validate if $selectedItems is not empty before proceeding
    if (!empty($selectedItems)) {
        // Initialize package image variable
        $packageImage = null;

        // Check if the 'packageImage' file is uploaded and has no errors
        if (isset($_FILES['packageImage']) && $_FILES['packageImage']['error'] == UPLOAD_ERR_OK) {
            // Check file type and size (you may need to customize these checks)
            $allowedTypes = ['image/jpeg', 'image/png', 'image/gif'];
            $maxFileSize = 5 * 1024 * 1024; // 5 MB

            if (in_array($_FILES['packageImage']['type'], $allowedTypes) && $_FILES['packageImage']['size'] <= $maxFileSize) {
                // Save the image to the local directory
                $uploadDir = '../../images/foodItemsImages/';
                $uploadPath = $uploadDir . basename($_FILES['packageImage']['name']);
                move_uploaded_file($_FILES['packageImage']['tmp_name'], $uploadPath);

                // Save the file path to be stored in the database
                $packageImage = $uploadPath;
            } else {
                // Handle the case of an invalid image format or size
                $message = "Invalid image format or size.";
                // You may want to handle the error appropriately
            }
        }

        // Get the form data and perform basic sanitization
        $packageID = isset($_POST['packageID']) ? intval($_POST['packageID']) : 0;
        $packageName = htmlspecialchars($_POST['updatePackageName'], ENT_QUOTES, 'UTF-8');
        $packagePrice = floatval($_POST['updateprice']);
        $availability = isset($_POST['updatePackageAvailability']) ? htmlspecialchars($_POST['updatePackageAvailability']) : '';
        $packageDescription = htmlspecialchars($_POST['updatePackageDescription']);

        // Start a transaction
        $conn->begin_transaction();

        // Initialize the prepared statement variable
        $updatePackageStmt = null;

        try {
            // Update the package information in the database 
            $updatePackageSql = "UPDATE tblmenupackage SET packageName=?, packagePrice=?, availability=?, packageImage=?, packageDescription=? WHERE packageID=?";
            $updatePackageStmt = $conn->prepare($updatePackageSql);

            // Check if preparing the statement was successful
            if (!$updatePackageStmt) {
                // Handle the error (output error details, log it, etc.)
                die('Error preparing update package statement: ' . $conn->error);
            }

            // Bind parameters to the prepared statement
            $updatePackageStmt->bind_param("sdsssi", $packageName, $packagePrice, $availability, $packageImage, $packageDescription, $packageID);

            // Execute the update package statement
            if (!$updatePackageStmt->execute()) {
                // Handle the error (output error details, log it, etc.)
                die('Error executing update package statement: ' . $updatePackageStmt->error);
            }

            // Fetch existing items associated with the package from the database
            $fetchExistingItemsSql = "SELECT itemID FROM tblmenupackageitems WHERE packageID = ?";
            $fetchExistingItemsStmt = $conn->prepare($fetchExistingItemsSql);
            $fetchExistingItemsStmt->bind_param("i", $packageID);

            if (!$fetchExistingItemsStmt) {
                // Handle the error
                die('Error preparing fetch existing items statement: ' . $conn->error);
            }

            $existingItems = [];
            $fetchExistingItemsStmt->execute();
            $fetchExistingItemsStmt->bind_result($existingItemID);

            while ($fetchExistingItemsStmt->fetch()) {
                $existingItems[] = $existingItemID;
            }

            $fetchExistingItemsStmt->close();

            // Identify items to be removed from the package
            $itemsToRemove = array_diff($existingItems, $selectedItems);

            // Remove items from tblmenupackageitems
            if (!empty($itemsToRemove)) {
                $removeItemsSql = "DELETE FROM tblmenupackageitems WHERE packageID = ? AND itemID IN (" . implode(',', array_fill(0, count($itemsToRemove), '?')) . ")";
                $removeItemsStmt = $conn->prepare($removeItemsSql);
                $removeItemsStmt->bind_param(str_repeat('i', count($itemsToRemove) + 1), $packageID, ...$itemsToRemove);

                if (!$removeItemsStmt) {
                    // Handle the error
                    die('Error preparing remove items statement: ' . $conn->error);
                }

                if (!$removeItemsStmt->execute()) {
                    // Handle the error
                    die('Error executing remove items statement: ' . $removeItemsStmt->error);
                }

                $removeItemsStmt->close();
            }

            // Insert selected items into tblmenupackageitems
            foreach ($selectedItems as $selectedItem) {
                // Separate itemID and itemName
                list($itemID) = explode(':', $selectedItem);

                // Fetch itemName from tblmenuitems based on itemID
                $fetchItemNameSql = "SELECT itemName FROM tblfooditems WHERE itemID = $selectedItem";
                $fetchItemNameStmt = $conn->prepare($fetchItemNameSql);


                if (!$fetchItemNameStmt) {
                    // Handle the error
                    die('Error preparing fetch item name statement: ' . $conn->error);
                }

                $fetchItemNameStmt->execute();
                $fetchItemNameStmt->bind_result($actualItemName);
                $fetchItemNameStmt->fetch();
                $fetchItemNameStmt->close();

                // Check if the item already exists in tblmenupackageitems
                $checkItemSql = "SELECT COUNT(*) FROM tblmenupackageitems WHERE packageID = ? AND itemID = ?";
                $checkItemStmt = $conn->prepare($checkItemSql);
                $checkItemStmt->bind_param("ii", $packageID, $itemID);
                $checkItemStmt->execute();
                $checkItemStmt->bind_result($itemCount);

                if (!$checkItemStmt) {
                    // Handle the error (output error details, log it, etc.)
                    die('Error preparing check item statement: ' . $conn->error);
                }

                // Fetch the result
                $checkItemStmt->fetch();
                $checkItemStmt->close();

                if ($itemCount == 0) {
                    // The item doesn't exist, so insert it
                    $insertItemSql = "INSERT INTO tblmenupackageitems (packageID, itemID, itemName) VALUES (?, ?, ?)";
                    $insertItemStmt = $conn->prepare($insertItemSql);
                    $insertItemStmt->bind_param("iis", $packageID, $itemID, $actualItemName);

                    if (!$insertItemStmt) {
                        // Handle the error (output error details, log it, etc.)
                        die('Error preparing insert item statement: ' . $conn->error);
                    }

                    if (!$insertItemStmt->execute()) {
                        // Handle the error (output error details, log it, etc.)
                        die('Error executing insert item statement: ' . $insertItemStmt->error);
                    }

                    $insertItemStmt->close();
                }
            }

            // Commit the transaction if all queries succeed
            $conn->commit();

            // Set success message
            $message = "Package and selected items have been updated in the database.";
        } catch (Exception $e) {
            // Rollback the transaction if any query fails
            $conn->rollback();

            // Output the error message
            echo "Error: " . $e->getMessage();
            exit;
        } finally {
            // Close the prepared statement if it's not null
            if ($updatePackageStmt) {
                $updatePackageStmt->close();
            }
        }
    } else {
        // Handle the case when no items are selected
        $message = "No items selected.";
    }
} // Rest of your code remains unchanged
?>



<div id="updatePackageModal" tabindex="-1" aria-hidden="true" class="hidden overflow-y-auto overflow-x-hidden fixed top-0 right-0 left-0 z-50 justify-center items-center w-full md:inset-0 h-[calc(100%-1rem)] md:h-full">
    <div class="relative w-full h-full max-w-2xl p-4 md:h-auto">
        <!-- Modal content -->
        <div class="relative p-4 bg-white rounded-lg shadow">
            <!-- Modal header -->
            <div class="flex items-center justify-between pb-4 mb-4 border-b rounded-t sm:mb-5">
                <h3 class="text-lg font-semibold text-gray-900">Update Package</h3>
                <button type="button" class="text-gray-400 bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm p-1.5 ml-auto inline-flex items-center" data-modal-toggle="updatePackageModal">
                    <svg aria-hidden="true" class="w-5 h-5" fill="currentColor" viewbox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                        <path fill-rule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clip-rule="evenodd" />
                    </svg>
                    <span class="sr-only">Close modal</span>
                </button>
            </div>

            <!-- Modal body -->
            <form method="post" enctype="multipart/form-data" action="<?php echo $_SERVER['PHP_SELF']; ?>">
                <!-- Add a hidden input field for packageID -->
                <input type="hidden" name="packageID" id="packageID" value="<?php echo $packageID; ?>">
                <input type="text" name="itemIDs" id="itemIDs" hidden>
                <input type="text" name="upPackageItems" id="upPackageItems" value="<?php echo implode(',', $selectedItems); ?>" hidden>


                <div class="grid gap-4 mb-4 sm:grid-cols-2">
                    <div>
                        <label for="number" class="block mb-2 text-sm font-medium text-gray-900">Package Name</label>
                        <input type="text" name="updatePackageName" id="updatePackageName" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5" placeholder="Enter package name" required="" value="<?php echo $packageName; ?>">
                    </div>
                    <div>
                        <label for="number" class="block mb-2 text-sm font-medium text-gray-900">Package Price</label>
                        <input type="number" name="updateprice" id="updateprice" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5" placeholder="0.00" required="">
                    </div>

                    <div class="flex-row">
                        <div class="mb-4">
                            <label for="updatePackageAvailability" class="block mb-2 text-sm font-medium text-gray-900">Availability</label>
                            <select name="updatePackageAvailability" id="updatePackageAvailability" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-green-200 focus:border-green-200 block w-full p-2.5" required="">
                                <option value="Available">Available</option>
                                <option value="Unavailable">Unavailable</option>
                            </select>
                        </div>
                        <div class="flex-col">
                            <label for="updatePackageDescription" class="block mb-2 text-sm font-medium text-gray-900">Description</label>
                            <textarea id="updatePackageDescription" name="updatePackageDescription" rows="3" class="block p-2.5 w-full text-sm text-gray-900 bg-gray-50 rounded-lg border border-gray-300 focus:ring-green-200 focus:border-green-200" placeholder="Write description here"></textarea>
                        </div>
                    </div>
                    <div>
                        <label for="packageImage" class="block mb-2 text-sm font-medium text-gray-900">Package Image</label>
                        <img id="upPackageImg" name="upPackageImg" src="<?php echo $packageImage ?>" alt="Existing Image" class="w-48 h-28 mb-3" />
                        <input type="file" name="packageImage" id="packageImage" accept="image/*">
                    </div>
                </div>

                <div class="max-w-screen-xl px-4 mx-auto max-h-screen-xl lg:px-8 xl:px-10" id="tableContainer">
                    <h3 class="text-md font-semibold text-gray-900 mb-1">Select Items</h3>
                    <div class="relative overflow-hidden bg-white shadow-md sm:rounded-lg">
                        <form class="flex items-center">
                            <label for="simple-search" class="sr-only">Search</label>
                            <div class="relative w-full mb-2">
                                <div class="absolute left-0 flex items-center pl-3 pointer-events-none inset-sy-0 mt-2">
                                    <svg aria-hidden="true" class="w-5 h-5 text-gray-500" fill="currentColor" viewbox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M8 4a4 4 0 100 8 4 4 0 000-8zM2 8a6 6 0 1110.89 3.476l4.817 4.817a1 1 0 01-1.414 1.414l-4.816-4.816A6 6 0 012 8z" />
                                    </svg>
                                </div>
                                <input type="text" id="simple-search" placeholder="Search for food items" class="block w-full p-2 pl-10 text-sm text-gray-900 border border-gray-300 rounded-lg focus:ring-green-200 focus:border-green-200 ">

                            </div>

                            <div class="overflow-y-auto overflow-x-hidden max-h-[340px]">

                                <table class="w-full text-sm text-left text-gray-500 " id="itemsTable">
                                    <thead class="text-xs text-gray-700 uppercase bg-gray-50">
                                        <tr>
                                            <th scope="col" class="px-8 py-4">Dish Name</th>
                                            <th scope="col" class="px-8 py-4">Category</th>
                                            <th scope="col" class="px-8 py-4">Price</th>
                                            <th scope="col" class="px-8 py-4"></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        $foodItemCount = count($fooditems);


                                        for ($i = 0; $i < $foodItemCount; $i++) {
                                            $item = $fooditems[$i];
                                            $itemID = $item['itemID'];
                                            $itemName = $item['itemName'];
                                            $categoryID = $item['categoryID'];
                                            $category = isset($catMappings[$categoryID]) ? $catMappings[$categoryID] : "undefined";
                                            $price = $item['price'];
                                            // Check if the item is in the selectedItems array
                                            $isChecked = in_array($itemID, $selectedItems);
                                        ?>
                                            <tr class="border-b hover:bg-gray-100">
                                                <td class="px-8 py-3 text-gray-500 whitespace-nowrap"><?php echo $itemName; ?></td>
                                                <td class="px-8 py-3"><?php echo $category; ?></td>
                                                <td class="px-8 py-3"><?php echo $price; ?></td>
                                                <td class="px-4 py-3 font-medium text-gray-900 whitespace-nowrap">
                                                    <input type="checkbox" name="selectedItems[]" value="<?php echo $itemID; ?>" onclick="updateSelectedItems(this)" class="w-4 h-4 text-teal-600 bg-gray-100 border-gray-300 rounded focus:ring-teal-500 dark:focus:ring-teal-600 dark:ring-offset-gray-800 focus:ring-2 dark:bg-gray-700 dark:border-gray-600" <?php echo in_array($itemID, $selectedItems) ? 'checked' : ''; ?>>

                                                </td>
                                            </tr>
                                        <?php } ?>
                                    </tbody>
                                </table>
                            </div>
                    </div>
                </div>

                <div class="mb-4">
                    <div class="flex items-center justify-center w-full">
                        <div id="qrCodeContainer" style="display: none;" class="flex flex-col items-center justify-center w-64 h-64 border-2 border-gray-300 rounded-lg bg-gray-50 qrCodeContainer">
                        </div>
                    </div>
                </div>

                <!-- Submit button for updating package items -->
                <div class="items-center space-y-4 sm:flex sm:space-y-4 sm:space-x-4">
                    <button type="submit" name="updatePackageItems" id="updatePackageItems" class="w-full sm:w-auto justify-center text-teal-800 inline-flex border border-gray-300 bg-teal-700 hover:bg-teal-800 hover:text-white focus:ring-4 focus:outline-none focus:ring-primary-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center">
                        Update
                    </button>
                </div>
            </form>

        </div>
    </div>
</div>
<?php if ($message != '') { ?>
    <div id="menuUpdateMessageModal" class="relative items-center justify-center h-32 px-4 text-center text-black bg-white border-2 border-black rounded-lg w-80 py-14" role="alert" style="position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%); z-index: 999;">
        <strong class="font-bold"> <?php echo $message; ?></strong>
        <span class="absolute top-0 bottom-0 right-0 px-4 py-3" onclick="closemenuUpdateMessageModal()">
            <svg class="w-6 h-6 text-teal-800 fill-current" role="button" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20">
                <title>Close</title>
                <path d="M14.348 14.849a1.2 1.2 0 0 1-1.697 0L10 11.819l-2.651 3.029a1.2 1.2 0 1 1-1.697-1.697l2.758-3.15-2.759-3.152a1.2 1.2 0 1 1 1.697-1.697L10 8.183l2.651-3.031a1.2 1.2 0 1 1 1.697 1.697l-2.758 3.152 2.758 3.15a1.2 1.2 0 0 1 0 1.698z" />
            </svg>
        </span>
    </div>
<?php } ?>

<script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js"></script>

<script>
    function updateSelectedItems(checkbox) {
        var itemID = parseInt(checkbox.value);
        var selectedItemsInput = document.querySelector('input[name="upPackageItems"]');
        var currentItems = selectedItemsInput.value.length > 0 ? selectedItemsInput.value.split(',') : [];

        if (checkbox.checked) {
            // Add itemID to selectedItems if checked
            if (!currentItems.includes(itemID.toString())) {
                currentItems.push(itemID.toString());
            }
        } else {
            // Remove itemID from selectedItems if unchecked
            var index = currentItems.indexOf(itemID.toString());
            if (index !== -1) {
                currentItems.splice(index, 1);
            }
        }

        // Update the hidden input with the updated selectedItems array
        selectedItemsInput.value = currentItems.join(',');

        // Uncomment the following line to debug and see the updated selectedItems
        console.log(currentItems);
    }

    function previewImage() {
        var fileInput = document.getElementById('fileToUpload');
        var imagePreview = document.getElementById('imagePreview');
        var previewImage = document.getElementById('upItemImage');

        if (fileInput.files && fileInput.files[0]) {
            var reader = new FileReader();

            reader.onload = function(e) {
                // Show image preview
                imagePreview.classList.remove('hidden');
                previewImage.src = e.target.result;
            };

            // Read the image file
            reader.readAsDataURL(fileInput.files[0]);
        }
    }

    function closemenuUpdateMessageModal() {
        var modal = document.getElementById('menuUpdateMessageModal');
        modal.style.display = 'none';

    }
</script>