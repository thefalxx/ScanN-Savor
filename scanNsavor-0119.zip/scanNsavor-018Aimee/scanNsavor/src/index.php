<?php
include './class/Menu.php';
$menu = new Menu();
$catMappings = $menu->fetchCategoryMappings();
$category = $menu->getCategories();

session_start();

global $conn;



// Check if it's an asynchronous request to set diningChoice
if (isset($_POST['setDiningChoice']) && $_POST['setDiningChoice'] === 'true') {
    // Set the diningChoice as a session variable
    $_SESSION['diningChoice'] = $_POST['diningChoice'];

    // You can send a response back to the JavaScript if needed
    echo json_encode(['success' => true]);

    exit;
}



// Fetch food items from the database
$sql = "SELECT * FROM tblfooditems";
$result = mysqli_query($conn, $sql);



// Check for query success
if ($result) {
    $fooditems = array();

    // Loop through the results and populate $fooditems array
    while ($item = mysqli_fetch_assoc($result)) {
        $fooditems[] = $item;
    }

    // Close the database connection
    mysqli_close($conn);
} else {
    // Handle the case where the query fails
    echo 'Error: ' . mysqli_error($conn);
}


?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="dist/output.css" rel="stylesheet">
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/flowbite/1.8.0/flowbite.min.css" rel="stylesheet" />
    <script src="https://cdn.jsdelivr.net/npm/alpinejs@2.8.2/dist/alpine.min.js" defer></script>
    <title>Scan N' Savor</title>
</head>

<body>
    <section>
        <nav class="bg-white border-gray-200">
            <div class="max-w-screen-xl flex flex-wrap items-center justify-between mx-auto p-4">
                <a href="#" class="flex items-center">
                    <img src="../images/green scansavor logo.png" class="h-12 mr-3" alt="scannsavorlogo" />
                    <span class="self-center text-2xl font-semibold whitespace-nowrap text-teal-700">Scan N' Savor</span>
                </a>
                <div class="flex md:order-2">
                    <a href="./view/login.php">
                        <button type="button" class="text-white bg-teal-700 hover:bg-teal-500 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-4 py-2 text-center mr-3 md:mr-0">
                            <svg class="w-6 h-6 fill-current inline-block" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                                <path d="M5 3a2 2 0 00-2 2v2a2 2 0 002 2h2a2 2 0 002-2V5a2 2 0 00-2-2H5zM5 11a2 2 0 00-2 2v2a2 2 0 002 2h2a2 2 0 002-2v-2a2 2 0 00-2-2H5zM11 5a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V5zM11 13a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z"></path>
                            </svg>

                        </button>
                    </a>
                </div>
                <div class="items-center justify-between hidden w-full md:flex md:w-auto md:order-1" id="navbar-cta">
                    <ul class="flex flex-col font-medium p-4 md:p-0 mt-4 border md:flex-row md:space-x-8 md:mt-0 md:border-0">
                        <li>
                            <a href="#home" class="block py-2 pl-3 pr-4 text-gray-800 rounded hover:bg-gray-100 md:hover:bg-transparent md:hover:text-teal-700 md:p-0" aria-current="page">Home</a>
                        </li>
                        <li>
                            <a href="#about" class="block py-2 pl-3 pr-4 text-gray-800 rounded hover:bg-gray-100 md:hover:bg-transparent md:hover:text-teal-700 md:p-0">About</a>
                        </li>
                        <li>
                            <a href="#contact" class="block py-2 pl-3 pr-4 text-gray-800 rounded hover:bg-gray-100 md:hover:bg-transparent md:hover:text-teal-700 md:p-0">Contact</a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    </section>

    <section class="lg:h-screen h-full lg:px-10 px-5 bg-[#e6e8dd] rounded-3xl lg:my-14 lg:mx-24 lg:mt-5 pb-20">
        <div class="flex flex-col items-center justify-center px-10 py-10 mx-auto space-y-6 lg:h-[32rem] lg:py-16 lg:flex-row lg:items-center">
            <div class="w-full lg:w-1/2">
                <div class="lg:max-w-2xl">
                    <h1 class="text-4xl lg:pl-24 font-bold tracking-normal text-gray-800 xs:text-center sm:text-center md:text-center sm:text-3xl md:text-4xl lg:text-7xl lg:mt-56 mt-12 text-center">
                        Dine with QR Technology:
                        <p class="mt-5"></p>
                        <span class="lg:text-6xl text-teal-800 leading-relaxed mt-"> Scan N' Savor
                        <svg class="mt-1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1418 125" fill="#548776"><path d="M1412.29 72.17c-11.04-5.78-20.07-14.33-85.46-25.24-22.37-3.63-44.69-7.56-67.07-11.04-167.11-22.06-181.65-21.24-304.94-30.56C888.78 1.39 822.57 1.1 756.44 0c-46.63-.11-93.27 1.56-139.89 2.5C365.5 13.55 452.86 7.68 277.94 23.15 202.57 33.32 127.38 45.01 52.07 55.69c-11.23 2.41-22.63 4.17-33.71 7.22C6.1 66.33 5.64 66.19 3.89 67.79c-7.99 5.78-2.98 20.14 8.72 17.5 33.99-9.47 32.28-8.57 178.06-29.66 4.26 4.48 7.29 3.38 18.42 3.11 13.19-.32 26.38-.53 39.56-1.12 53.51-3.81 106.88-9.62 160.36-13.95 18.41-1.3 36.8-3.12 55.21-4.7 23.21-1.16 46.43-2.29 69.65-3.4 120.28-2.16 85.46-3.13 234.65-1.52 23.42.99 1.57-.18 125.72 6.9 96.61 8.88 200.92 27.94 295.42 46.12 40.87 7.91 116.67 23.2 156.31 36.78 3.81 1.05 8.28-.27 10.51-3.58 3.17-3.72 2.66-9.7-.78-13.13-3.25-3.12-8.14-3.44-12.18-5.08-17.89-5.85-44.19-12.09-63.67-16.56l26.16 3.28c23.02 3.13 46.28 3.92 69.34 6.75 10.8.96 25.43 1.81 34.34-4.39 2.26-1.54 4.86-2.75 6.21-5.27 2.76-4.59 1.13-11.06-3.59-13.68ZM925.4 23.77c37.64 1.4 153.99 10.85 196.64 14.94 45.95 5.51 91.89 11.03 137.76 17.19 24.25 4.77 74.13 11.21 101.72 18.14-11.87-1.15-23.77-1.97-35.65-3.06-133.46-15.9-266.8-33.02-400.47-47.21Z"></path></svg>
                    </h1>

                    <p class="visible mx-0 mt-5 mb-0 text-xl leading-relaxed text-gray-600 lg:ml-32 text-center">
                        Incorporate our digital ordering system into your restaurant to seize the future. Our ordering software for restaurants is fully equipped to meet your needs with success.
                    </p>
                </div>
            </div>
            <div class="flex items-center justify-center lg:pt-96 pt-20 mt-1 w-full h-96 lg:w-1/2">
                <img src="../images/hero-bg.png" class="block max-w-full h-auto lg:pr-12 lg:h-auto md:h-96 align-middle lg:max-w-lg lg:pb-20">
            </div>
        </div>
    </section>

    <!-- <section id="">
        <div class="lg:h-screen h-full lg:px-10 px-5 bg-[#e6e8dd] rounded-3xl lg:my-14 lg:mx-10 lg:mt-5 pb-20">

            <div class="flex flex-wrap items-center font-sans px-4 mx-56 w-full lg:max-w-screen-lg sm:max-w-screen-sm md:max-w-screen-md pt-32 pb-40">
                <div class="px-3 w-full lg:w-2/5">
                    <div class="mx-auto mb-8  text-center lg:mx-0 lg:max-w-md lg:text-left">
                        <h2 class="mb-4 text-3xl font-bold text-left lg:text-6xl">
                            Dine with QR Technology:
                            <span class="text-5xl text-teal-800 leading-relaxeds">Scan N' Savor
                            </span>


                        </h2>

                        <p class="visible mx-0 mt-3 mb-0 text-lg leading-relaxed text-left text-gray-500">
                            Incorporate our digital ordering system into your restaurant to seize the future. Our ordering software for restaurants is fully equipped to meet your needs with success.
                        </p>
                    </div>
                </div>

                <div class="flex items-center justify-center lg:pt-96 pt-20 mt-1 w-full h-96 lg:w-1/2">
                    <img src="../images/hero-bg.png" class="block max-w-full h-auto lg:pr-12 lg:h-auto md:h-96 align-middle lg:max-w-lg lg:pb-20">
                </div>
          

            </div>
        </div>
    </section> -->

    <section id="about" class="flex flex-col md:flex-row justify-between items-center md:items-stretch h-screen">
        <div class="container mx-auto px-6 py-16 text-center">
            <div class="mx-auto max-w-lg">
                <h1 class="text-3xl font-bold text-gray-800 lg:text-4xl">How Scan N' Savor Works:</h1>
                <p class="mt-6 text-gray-500">Experience a new era of dining with our seamless QR technology. Ordering has never been this easy – simply scan the QR code on your table, browse our menu, and place your order right from your smartphone. No more waiting for a menu or trying to catch the waiter's attention. It's dining at your fingertips!</p>
            </div>

            <div class="mt-10 flex justify-center">
                <img class="h-96 w-full rounded-xl object-cover lg:w-4/5" src="../images/qr-code-restaurants.jpg" alt="image" />
            </div>
    </section>

    <section id="contact" class="flex flex-col md:flex-row justify-between items-center md:items-stretch bg-gray-100 py-16">
        <div class="container mx-auto px-6 text-center">
            <div class="mx-auto max-w-lg mb-8">
                <h1 class="text-3xl font-bold text-gray-800 lg:text-4xl">Deploy Your Restaurant Menu with our Awesome Components</h1>
                <p class="mt-4 text-gray-500">Our commitment to technology doesn’t end with ordering. Stay connected with high-speed Wi-Fi, share your dining experience on social media, and make your time with us even more memorable.</p>
            </div>

            <div class="flex flex-col md:flex-row justify-between items-center md:items-stretch space-y-4 md:space-y-0">
                <div class="max-w-md bg-white border border-gray-200 rounded-lg shadow p-6 mb-4 md:mb-0">
                    <h5 class="mb-2 text-2xl font-bold text-gray-900">Email</h5>
                    <p class="text-gray-700">Send us an email and our dedicated team will answer your inquiries.</p>
                    <button class="mt-6 rounded-lg bg-teal-800 px-6 py-2.5 text-center text-sm font-medium leading-5 text-white hover:bg-teal-700 focus:outline-none">contact@scannsavor.com</button>
                </div>

                <div class="max-w-md bg-white border border-gray-200 rounded-lg shadow p-6 mb-4 md:mb-0">
                    <h5 class="mb-2 text-2xl font-bold text-gray-900">Contact Us</h5>
                    <p class="text-gray-700">Call us for a system sample demo and tailor your restaurant ordering system.</p>
                    <button class="mt-6 rounded-lg bg-teal-800 px-6 py-2.5 text-center text-sm font-medium leading-5 text-white hover:bg-teal-700 focus:outline-none">+(63) 9 1734 9626</button>
                </div>

                <div class="max-w-md bg-white border border-gray-200 rounded-lg shadow p-6">
                    <h5 class="mb-2 text-2xl font-bold text-gray-900">Location</h5>
                    <p class="text-gray-700">Come and visit us in our office located at: B21 L11 CityDrive Davao City</p>
                    <button class="mt-6 rounded-lg bg-teal-800 px-6 py-2.5 text-center text-sm font-medium leading-5 text-white hover:bg-teal-700 focus:outline-none">Visit</button>
                </div>
            </div>
        </div>
    </section>





    <?php
    include './view/footer.php';
    ?>

    <script>
        function setChoice(choice) {
            // Use JavaScript to send an asynchronous request to the server
            fetch('index.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: 'setDiningChoice=true&diningChoice=' + encodeURIComponent(choice),
                })
                .then(response => response.json())
                .then(data => {
                    // Handle the response if needed
                    console.log(data);
                })
                .catch((error) => {
                    console.error('Error:', error);
                });

            // Close the modal
            document.getElementById('diningChoice').style.display = 'none';
        }
    </script>
</body>

</html>