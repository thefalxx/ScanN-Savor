<!DOCTYPE html>
<html lang="en">
<head>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="../../dist/output.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/flowbite/1.8.1/flowbite.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/daisyui@4.4.24/dist/full.min.css" rel="stylesheet" type="text/css" />
    <script src="https://cdn.jsdelivr.net/npm/alpinejs@2.8.2/dist/alpine.min.js" defer></script>
    <script src="https://cdn.tailwindcss.com"></script>
    <title>Ratings</title>
</head>
</head>
<body>
<div x-data="{ open: false }" x-init="open = true" id="diningChoice">
        <!-- Modal overlay -->
        <div x-show="open" class="fixed inset-0  bg-gray-500 bg-opacity-75 flex items-center justify-center">
            <!-- Modal content -->
            <div class="justify-center bg-white p-6 rounded-xl shadow-lg lg:w-[580px] lg:mx-0 mx-5">
                <header class=" text-center px-10 py-8">
                    <div class="flex items-center">
                        <div class="grow border-b border-teal-700"></div>
                        <span class="shrink px-1 pb-1 text-teal-700 font-bold lg:text-2xl text-xl">&nbsp; R A T I N G S &nbsp;</span>
                        <div class="grow border-b border-teal-700"></div>
                    </div>
                </header>
                <p class="text-center lg:px-24 px-8 text-xs text-gray-500">Scan N Savor <br> would like you to rate your dining experience.</p>
                <div class="justify-center px-14 pt-10">
                    <form action="../class/Ratings.php" method="post">
                        <div class="rating rating-lg items-center justify-center flex">
                            <button type="button" data-rating="1" class="text-7xl starButton" aria-label="Left Align">&#9733;</button>
                            <button type="button" data-rating="2" class="text-7xl starButton" aria-label="Left Align">&#9733;</button>
                            <button type="button" data-rating="3" class="text-7xl starButton" aria-label="Left Align">&#9733;</button>
                            <button type="button" data-rating="4" class="text-7xl starButton" aria-label="Left Align">&#9733;</button>
                            <button type="button" data-rating="5" class="text-7xl starButton" aria-label="Left Align">&#9733;</button>
                            <input type="hidden" id="ratingNo" name="ratingNo">
                        </div>
                        <div class="mb-6 pt-20">
                            <label for="feedback" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Feedback:</label>
                            <p class="visible mx-0 mb-0 text-sm leading-relaxed text-left text-slate-400">
                                We'd love to hear from you!
                            </p>
                            <textarea type="text" id="ratingFeedback" name="ratingFeedback" class="block w-full p-4 text-gray-900 border border-gray-300 rounded-lg bg-gray-50 sm:text-md focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" placeholder="Write feedback here"></textarea>
                        </div>
                        <div class="justify-center items-center text-center pt-5">
                            <button type="submit" name="ratingsAdd" class=" border border-teal-700  text-teal-700 hover:text-white hover:border-none duration-300 relative group cursor-pointer overflow-hidden h-10 w-30 rounded-lg p-2 font-extrabold hover:bg-teal-700">
                                <!-- <div class="absolute group-hover:-top-1 group-hover:-right-2 z-10 w-16 h-16 rounded-full group-hover:scale-150  duration-700 right-12 top-12 bg-teal-500"></div>
                        <div class="absolute group-hover:-top-1 group-hover:-right-2 z-10 w-12 h-12 rounded-full group-hover:scale-150  duration-700 right-20 -top-6 bg-teal-300"></div>
                        <div class="absolute group-hover:-top-1 group-hover:-right-2 z-10 w-8 h-8   rounded-full group-hover:scale-150  duration-700 right-32 top-6 bg-teal-200"></div>
                        <div class="absolute group-hover:-top-1 group-hover:-right-2 z-10 w-4 h-4   rounded-full group-hover:scale-150  duration-700 right-2 top-12 bg-teal-100"></div> -->
                                <p class="text-center">Submit</p>
                            </button>
                        </div>
                    </form>
                </div>
                <!-- Close button -->
                <button @click="open = false" class="mt-4 text-gray-400 px-4 py-2">Close</button>
            </div>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const ratingButtons = document.querySelectorAll('.starButton');
            const ratingInput = document.getElementById('ratingNo');
            let currentRating = parseInt(ratingInput.value);

            // Debugging
            console.log('Initial PHP Value:', ratingInput);

            // Set initial value based on the hidden input
            highlightStars(currentRating);

            ratingButtons.forEach(button => {
                button.addEventListener('click', function() {
                    const ratingValue = parseInt(this.getAttribute('data-rating'));

                    // Update the current rating
                    currentRating = ratingValue;

                    // Update the star buttons appearance based on the clicked button
                    highlightStars(currentRating);

                    // Update the hidden input value
                    ratingInput.value = currentRating;
                });
            });

            function highlightStars(value) {
                ratingButtons.forEach(btn => {
                    const btnRating = parseInt(btn.getAttribute('data-rating'));
                    btn.classList.toggle('text-teal-700', btnRating <= value);
                });
            }
        });
    </script>
    
</body>
</html>