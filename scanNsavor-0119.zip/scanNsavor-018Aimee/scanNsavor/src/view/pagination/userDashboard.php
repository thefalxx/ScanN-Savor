<?php 
include('class/User.php');
$user = new User();
$user->loginStatus();
$userDetail = $user->userDetails(); 
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body>

<div class="relative flex min-h-screen flex-col justify-center overflow-hidden bg-gray-50 py-6 sm:py-12">
    <div class="relative bg-white pt-10 pb-8 px-10 shadow-xl mx-auto rounded-lg">
        <div class="divide-y divide-gray-300/50 w-full">
            <div class="space-y-6 py-8 text-base text-gray-600">
                <p class="text-xl font-medium leading-7">Welcome <?php echo strtoupper($_SESSION['name']); ?> </p>
            </div>
            <button class="mt-5 w-full border p-2 bg-gradient-to-r from-teal-800 bg-teal-500 text-white rounded-[4px] hover:bg-teal-300 scale-105 duration-300" type="submit" name="logout" value="logout">
            <a href="../logout.php">
              Logout
            </a>
          </button>
        </div>
    </div>
</div>


</body>
</html>
</div>

