<?php 
    $menu = new Menu();
    $items =  $menu->getAllItems();
?>

<nav class="flex flex-col md:flex-row justify-between items-start md:items-center space-y-3 md:space-y-0 p-4" aria-label="Table navigation">
    <span class="text-sm font-normal text-gray-500">
        Showing
        <span class="font-semibold text-gray-900">1-10</span>
        of
        <span class="font-semibold text-gray-900"><?php echo count($items); ?></span>
    </span>
    <ul class="inline-flex items-stretch -space-x-px">
        <li>
            <a href="#" id="previousButton" class="flex items-center justify-center h-full py-1.5 px-3 ml-0 text-gray-500 bg-white rounded-l-lg border border-gray-300 hover:bg-teal-800 hover:text-white">
                <span class="sr-only">Previous</span>
                <svg class="w-5 h-5" aria-hidden="true" fill="currentColor" viewbox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                    <path fill-rule="evenodd" d="M12.707 5.293a1 1 0 010 1.414L9.414 10l3.293 3.293a1 1 0 01-1.414 1.414l-4-4a1 1 0 010-1.414l4-4a1 1 0 011.414 0z" clip-rule="evenodd" />
                </svg>
            </a>
        </li>
        <li>
            <ul id="paginationContainer" class="flex items-center justify-center text-sm"></ul>
        </li>
        <li>
            <a href="#" id="nextButton" class="flex items-center justify-center h-full py-1.5 px-3 leading-tight text-gray-500 bg-white rounded-r-lg border border-gray-300 hover:bg-teal-800 hover:text-white">
                <span class="sr-only">Next</span>
                <svg class="w-5 h-5" aria-hidden="true" fill="currentColor" viewbox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                    <path fill-rule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clip-rule="evenodd" />
                </svg>
            </a>
        </li>
    </ul>
</nav>

<script>
    document.getElementById('previousButton').addEventListener('click', function(event) {
        event.preventDefault();  // Prevent the default link behavior (navigating to #)

        // Get the current page number from the URL
        const urlParams = new URLSearchParams(window.location.search);
        let currentPage = parseInt(urlParams.get('page-nr')) || 1;

        // If we're on the first page, do nothing
        if (currentPage <= 1) {
            return;
        }

        // Navigate to the previous page by updating the page number in the URL
        currentPage -= 1;
        window.location.href = `menu.php?page-nr=${currentPage}`;
    });

    document.getElementById('nextButton').addEventListener('click', function(event) {
        event.preventDefault();  // Prevent the default link behavior (navigating to #)

        // Get the current page number from the URL
        const urlParams = new URLSearchParams(window.location.search);
        let currentPage = parseInt(urlParams.get('page-nr')) || 1;

        // Get the total number of pages from the hidden input
        const totalPages = parseInt(document.getElementById('totalPages').value);

        // Check if we're already on the last page
        if (currentPage >= totalPages) {
            // Handle reaching the end point (e.g., disable the button)
            return;
        }

        // Increment the page number and navigate to the next page
        currentPage += 1;
        window.location.href = `menu.php?page-nr=${currentPage}`;
    });

    function generatePaginationButtons() {
        const paginationContainer = document.getElementById('paginationContainer');
        paginationContainer.innerHTML = ''; // Clear existing pagination

        const maxDisplayedPages = 4; // Maximum displayed pages at a time

        // Get the total number of pages from the hidden input
        const totalPages = parseInt(document.getElementById('totalPages').value);
        
        // Get the current page number from the URL
        const urlParams = new URLSearchParams(window.location.search);
        let currentPage = parseInt(urlParams.get('page-nr')) || 1;

        let startPage = Math.max(1, currentPage - Math.floor(maxDisplayedPages / 2));
        let endPage = Math.min(totalPages, startPage + maxDisplayedPages - 1);

        if (endPage - startPage + 1 < maxDisplayedPages) {
            startPage = Math.max(1, endPage - maxDisplayedPages + 1);
        }

        for (let i = startPage; i <= endPage; i++) {
            const li = document.createElement('li');
            const a = document.createElement('a');
            a.href = `#`;
            a.classList.add('flex', 'items-center', 'justify-center', 'text-sm', 'py-2', 'px-3', 'leading-tight', 'text-gray-500', 'bg-white', 'border', 'border-gray-300', 'hover:bg-teal-800', 'hover:text-white');
            a.innerText = i;

            if (i === currentPage) {
                a.style.backgroundColor = '#10605A';  // Teal background color
                a.style.color = '#fff';  // White text color
                a.setAttribute('aria-current', 'page');
            }

            a.addEventListener('click', function(event) {
                event.preventDefault();

                // Remove previous highlighting
                const previousActive = paginationContainer.querySelector('.active-page');
                if (previousActive) {
                    previousActive.style.backgroundColor = '';
                    previousActive.style.color = '';
                    previousActive.classList.remove('active-page');
                }

                // Apply highlighting to the clicked page
                a.style.backgroundColor = '#008080';  // Teal background color
                a.style.color = '#fff';  // White text color
                a.classList.add('active-page');

                window.location.href = `menu.php?page-nr=${i}`;
            });

            li.appendChild(a);
            paginationContainer.appendChild(li);
        }

        if (endPage < totalPages) {
            const li = document.createElement('li');
            const a = document.createElement('a');
            a.href = `#`;
            a.classList.add('flex', 'items-center', 'justify-center', 'text-sm', 'py-2', 'px-3', 'leading-tight', 'text-gray-500', 'bg-white', 'border', 'border-gray-300', 'hover:bg-gray-100', 'hover:text-gray-700');
            a.innerText = '...';

            li.appendChild(a);
            paginationContainer.appendChild(li);

            const lastPageLi = document.createElement('li');
            const lastPageA = document.createElement('a');
            lastPageA.href = `menu.php?page-nr=${totalPages}`;
            lastPageA.classList.add('flex', 'items-center', 'justify-center', 'text-sm', 'py-2', 'px-3', 'leading-tight', 'text-gray-500', 'bg-white', 'border', 'border-gray-300', 'hover:bg-gray-100', 'hover:text-gray-700');
            lastPageA.innerText = totalPages;

            lastPageLi.appendChild(lastPageA);
            paginationContainer.appendChild(lastPageLi);
        }
    }

    // Usage example:
    generatePaginationButtons();
</script>
