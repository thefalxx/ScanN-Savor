<?php
include('../class/User.php');
$user = new User();
$errorMessage  =  $user->login();
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="../../dist/output.css" rel="stylesheet">
  <script src="https://cdn.tailwindcss.com"></script>


  <title>Scan N' Savor | Login</title>
</head>

<body>
<!-- 
  <section>
    <nav class="  bg-white border-gray-200 dark:bg-teal-900">
      <div class="max-w-screen-xl flex flex-wrap items-center justify-between mx-auto p-4">
        <a href="../index.php" class="flex items-center">
          <img src="../../images/Spoon___Fork_Logo-removebg-preview.png" class="h-10 mr-3" alt="Flowbite Logo" />
          <span class="self-center text-2xl font-semibold whitespace-nowrap dark:text-white">Scan N Savor</span>
        </a>
        <div class="flex md:order-2">
          <button type="button" class="text-white bg-teal-700 hover:bg-teal-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-4 py-2 text-center mr-3 md:mr-0 dark:bg-teal-600 dark:hover:bg-teal-700 dark:focus:ring-teal-800">Login</button>
          <button data-collapse-toggle="navbar-cta" type="button" class="inline-flex items-center p-2 w-10 h-10 justify-center text-sm text-gray-500 rounded-lg md:hidden hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-gray-200 dark:text-gray-400 dark:hover:bg-gray-700 dark:focus:ring-gray-600" aria-controls="navbar-cta" aria-expanded="false">
            <span class="sr-only">Open main menu</span>
            <svg class="w-5 h-5" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 17 14">
              <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M1 1h15M1 7h15M1 13h15" />
            </svg>
          </button>
        </div>
        <div class="items-center justify-between hidden w-full md:flex md:w-auto md:order-1" id="navbar-cta">
          <ul class="flex flex-col font-medium p-4 md:p-0 mt-4 border md:flex-row md:space-x-8 md:mt-0 md:border-0">
            <li>
              <a href="../index.php" class="block py-2 pl-3 pr-4 text-white bg-teal-700 rounded md:bg-transparent md:text-teal-700 md:p-0 md:dark:text-teal-500" aria-current="page">Home</a>
            </li>
            <li>
              <a href="../index.php" class="block py-2 pl-3 pr-4 text-gray-900 rounded hover:bg-gray-100 md:hover:bg-transparent md:hover:text-teal-700 md:p-0 md:dark:hover:text-teal-500 dark:text-white dark:hover:bg-gray-700 dark:hover:text-white md:dark:hover:bg-transparent dark:border-gray-700">About</a>
            </li>
            <li>
              <a href="../index.php" class="block py-2 pl-3 pr-4 text-gray-900 rounded hover:bg-gray-100 md:hover:bg-transparent md:hover:text-teal-700 md:p-0 md:dark:hover:text-teal-500 dark:text-white dark:hover:bg-gray-700 dark:hover:text-white md:dark:hover:bg-transparent dark:border-gray-700">Services</a>
            </li>
          </ul>
        </div>
      </div>
    </nav>
  </section> -->

  <section>
        <nav class="bg-white border-gray-200">
            <div class="max-w-screen-xl flex flex-wrap items-center justify-between mx-auto p-4">
                <a href="../index.php" class="flex items-center">
                    <img src="../../images/green scansavor logo.png" class="h-12 mr-3" alt="scannsavorlogo" />
                    <span class="self-center text-2xl font-semibold whitespace-nowrap text-teal-700">Scan N' Savor</span>
                </a>
                <div class="flex md:order-2">
                    <a href="../index.php">
                        <button type="button" class="text-white bg-teal-700 hover:bg-teal-500 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-4 py-2 text-center mr-3 md:mr-0">
                            <svg class="w-6 h-6 fill-current inline-block" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                                <path d="M5 3a2 2 0 00-2 2v2a2 2 0 002 2h2a2 2 0 002-2V5a2 2 0 00-2-2H5zM5 11a2 2 0 00-2 2v2a2 2 0 002 2h2a2 2 0 002-2v-2a2 2 0 00-2-2H5zM11 5a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V5zM11 13a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z"></path>
                            </svg>

                        </button>
                    </a>
                    <button data-collapse-toggle="navbar-cta" type="button" class=" hidden inline-flex items-center p-2 w-10 h-10 justify-center text-sm text-gray-500 rounded-lg md:hidden hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-gray-200 dark:text-gray-400 dark:hover:bg-gray-700 dark:focus:ring-gray-600" aria-controls="navbar-cta" aria-expanded="false">
                        <span class="sr-only">Open main menu</span>
                        <svg class="w-5 h-5" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 17 14">
                            <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M1 1h15M1 7h15M1 13h15" />
                        </svg>
                    </button>
                </div>
                <div class=" items-center justify-between hidden w-full md:flex md:w-auto md:order-1" id="navbar-cta">
                    <ul class="flex flex-col font-medium p-4 md:p-0 mt-4 border md:flex-row md:space-x-8 md:mt-0 md:border-0">
                        <li>
                            <a href="../index.php#home" class="block py-2 pl-3 pr-4 text-gray-800 rounded hover:bg-gray-100 md:hover:bg-transparent md:hover:text-teal-700 md:p-0" aria-current="page">Home</a>
                        </li>
                        <li>
                            <a href="../index.php#menu" class="block py-2 pl-3 pr-4 text-gray-800 rounded hover:bg-gray-100 md:hover:bg-transparent md:hover:text-teal-700 md:p-0">Menu</a>
                        </li>
                        <li>
                            <a href="#about" class="block py-2 pl-3 pr-4 text-gray-800 rounded hover:bg-gray-100 md:hover:bg-transparent md:hover:text-teal-700 md:p-0">About</a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    </section>

  <section>
    <div class="flex items-center justify-center h-screen">
      <!-- Login Container -->

      <form action="" method="post">
        <div class="min-w-fit flex-col border bg-white px-6 py-14 shadow-md rounded-[4px] ">
          <div class="mb-8 flex justify-center">
            <img class="w-24" src="../../images/green scansavor logo.png" alt="" />
          </div>

          <?php if ($errorMessage != '') { ?>
            <div class="mb-4 rounded-lg bg-success-100 px-6 py-5 text-base text-success-700" role="alert">
              <?php echo $errorMessage; ?></div>
          <?php } ?>


          <div class="flex flex-col text-sm rounded-md">
            <input class="mb-5 rounded-[4px] border p-3 hover:outline-none focus:outline-none hover:border-teal-800 " type="text" placeholder="Username" name="loginUsername" value="<?php if(isset($_COOKIE["loginUsername"])) { echo $_COOKIE["loginUsername"]; } ?>"/>

            <input class="border rounded-[4px] p-3 hover:outline-none focus:outline-none hover:border-teal-800" type="password" placeholder="Password" name="loginPass" <?php if(isset($_COOKIE["loginPass"])) { echo $_COOKIE["loginPass"]; } ?>/>
          </div>

          <button class="mt-5 w-full border p-2 bg-gradient-to-r from-teal-800 bg-teal-500 text-white rounded-[4px] hover:bg-teal-300 scale-105 duration-300" type="submit" name="login" value="login">
            <a href="../view/userDashboard.php"></a>
            Sign in
          </button>
          <div class="mt-5 flex justify-end text-sm text-gray-600">
            <a href="../forms/forgetpassword.php" class="hover:text-teal-600 ">Forgot password?</a>
            <!-- <a href="../view/signup.php" class="hover:text-teal-500">Sign up</a> -->
          </div>
          <div class="mt-5 flex text-center text-sm text-gray-400">
            <p>
              This site is protected by reCAPTCHA and the Google <br />
              <a class="underline" href="">Privacy Policy</a> and <a class="underline" href="">Terms of Service</a> apply.
            </p>
          </div>
        </div>
      </form>
    </div>
  </section>

  <?php
  include 'footer.php';
  ?>

</body>

</html>