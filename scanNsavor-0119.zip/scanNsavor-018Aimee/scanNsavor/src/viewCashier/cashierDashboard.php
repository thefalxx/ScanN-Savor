

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="../../dist/output.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/flowbite/1.8.0/flowbite.min.css" rel="stylesheet" />
    <title>Cashier | Scan N Savor</title>
</head>

<?php
include '../viewCashier/sidenavCashier.php';
?>


<body>
    <div class="mx-auto max-w-5xl py-10 pl-6">
        <!-- Start Second Row -->
        <div class="col-span-1 md:col-span-2 lg:col-span-4 flex justify-between">
            <h2 class="text-xs md:text-sm text-gray-700 font-bold tracking-wide md:tracking-wider pb-10">
               Cashier Dashboard</h2>
            <!-- <a href="#" class="text-xs text-gray-800 font-semibold uppercase">More</a> -->
        </div>
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 px-4 xl:p-0 gap-4 xl:gap-6">
            <div class="bg-white p-6 rounded-xl border border-gray-200 shadow">
                <div class="flex justify-between items-start">
                    <div class="flex flex-col">
                        <p class="text-xs text-gray-600 tracking-wide">Pending Payments</p>
                        <h3 class="mt-1 text-lg text-yellow-400 font-bold"><?php echo $payment->totalPayments("pending") ?></h3>
                        <span class="mt-4 text-xs text-gray-500">Last Updated 1 minute ago</span>
                    </div>
                    <div class="bg-yellow-400 p-2 md:p-1 xl:p-2 rounded-md">
                    </div>
                </div>
            </div>
            <div class="bg-white p-6 rounded-xl border border-gray-200 shadow">
                <div class="flex justify-between items-start">
                    <div class="flex flex-col">
                        <p class="text-xs text-gray-600 tracking-wide">Total Payments</p>
                        <h3 class="mt-1 text-lg text-green-400 font-bold"><?php echo $payment->totalPayments("confirmed") ?></h3>
                        <span class="mt-4 text-xs text-gray-400">Last Updated 30 minutes ago</span>
                    </div>
                    <div class="bg-green-500 p-2 md:p-1 xl:p-2 rounded-md">
                        <!-- <img src="https://atom.dzulfarizan.com/assets/grocery.png" alt="icon" class="w-auto h-8 md:h-6 xl:h-8 object-cover"> -->
                    </div>
                </div>
            </div>
        </div>
    </div>

</body>

<script src="https://cdnjs.cloudflare.com/ajax/libs/flowbite/1.8.0/flowbite.min.js"></script>

</html>