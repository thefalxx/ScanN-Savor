<?php

$host = 'localhost';
$user = 'root';
$pwd = '';
$dbname = 'scannsavor';

$conn = new mysqli($host, $user, $pwd, $dbname);
if ($conn->connect_error) {
    die("Error failed to connect to MySQL: " . $conn->connect_error);
}
