

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="../../dist/output.css" rel="stylesheet">
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/flowbite/1.8.0/flowbite.min.css" rel="stylesheet" />
    <title>Waiter Dashboard | Scan N Savor</title>
</head>

<?php
include '../viewWaiter/sidenavwaiter.php';

?>

<body class="pl-20">
    <div class="mx-auto max-w-5xl py-10 pl-6">
        <!-- Start Second Row -->
        <div class="col-span-1 md:col-span-2 lg:col-span-4 flex justify-between">
            <h2 class="text-xs md:text-sm text-gray-700 font-bold tracking-wide md:tracking-wider pb-10">
                Waiter's Dashboard</h2>
            <!-- <a href="#" class="text-xs text-gray-800 font-semibold uppercase">More</a> -->
        </div>
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 px-4 xl:p-0 gap-4 xl:gap-6">
            <div class="bg-white p-6 rounded-xl border border-gray-200 shadow">
                <div class="flex justify-between items-start">
                    <div class="flex flex-col">
                        <p class="text-xs text-gray-600 tracking-wide">Orders to Confirm</p>
                        <h3 class="mt-1 text-lg text-yellow-400 font-bold"><?php echo $order->getOrdersCount("ForApproval")?></h3>
                    </div>
                    <div class="bg-yellow-400 p-2 md:p-1 xl:p-2 rounded-md">
                    </div>
                </div>
            </div>
            <div class="bg-white p-6 rounded-xl border border-gray-200 shadow">
                <div class="flex justify-between items-start">
                    <div class="flex flex-col">
                        <p class="text-xs text-gray-600 tracking-wide">Served Orders</p>
                        <h3 class="mt-1 text-lg text-green-400 font-bold"><?php echo $order->getOrdersCount("Completed") ?></h3>
                    </div>
                    <div class="bg-green-400 p-2 md:p-1 xl:p-2 rounded-md">
                        <!-- <img src="https://atom.dzulfarizan.com/assets/grocery.png" alt="icon" class="w-auto h-8 md:h-6 xl:h-8 object-cover"> -->
                    </div>
                </div>
            </div>
            <div class="bg-white p-6 rounded-xl border border-gray-200 shadow">
                <div class="flex justify-between items-start">
                    <div class="flex flex-col">
                        <p class="text-xs text-gray-600 tracking-wide">Waiting List</p>
                        <h3 class="mt-1 text-lg text-yellow-500 font-bold">0<?php  ?></h3>
                    </div>
                    <div class="bg-yellow-500 p-2 md:p-1 xl:p-2 rounded-md">
                        <!-- <img src="https://atom.dzulfarizan.com/assets/gaming.png" alt="icon" class="w-auto h-8 md:h-6 xl:h-8 object-cover"> -->
                    </div>
                </div>
            </div>
            <div class="bg-white p-6 rounded-xl border border-gray-200 shadow">
                <div class="flex justify-between items-start">
                    <div class="flex flex-col">
                        <p class="text-xs text-gray-600 tracking-wide">Requests</p>
                        <h3 class="mt-1 text-lg text-indigo-500 font-bold">0<?php $customer->totalWaitingCustomers("Waiting") ?></h3>
                    </div>
                    <div class="bg-indigo-500 p-2 md:p-1 xl:p-2 rounded-md">
                        <!-- <img src="https://atom.dzulfarizan.com/assets/holiday.png" alt="icon" class="w-auto h-8 md:h-6 xl:h-8 object-cover"> -->
                    </div>
                </div>
            </div>
        </div>
    </div>

    <section>
        <div class="mx-auto max-w-5xl py-10 pl-10">
            <div>
                <div class=" pl-5 pb-10 col-span-1 md:col-span-2 lg:col-span-4 flex justify-between">
                    <h2 class="text-lg md:text-xl text-gray-700 font-bold tracking-wide md:tracking-wider">
                        Ready to Serve Orders
                    </h2>
                </div>
            </div>
        </div>
        <div class=' mb-5 max-w-5xl mx-auto grid grid-cols-2 px-5 pl-11 xl:p-0 gap-4 xl:gap-6'>
            <?php if ($CompleteOrders) :
                // Initialize an array to store orders grouped by table
                $ordersByTable = array();

                // Group orders by table
                foreach ($CompleteOrders as $order) {
                    $tableNo = $order['tableNo'];

                    if (!isset($ordersByTable[$tableNo])) {
                        $ordersByTable[$tableNo] = array();
                    }

                    $ordersByTable[$tableNo][] = $order;
                }

                // Display orders grouped by table
                foreach ($ordersByTable as $tableNo => $orders) :
            ?>
                    <div class='p-4 max-w-md bg-white rounded-lg border shadow-md sm:p-8 dark:bg-gray-800 dark:border-gray-700'>
                        <div class='flex justify-between items-center mb-4'>
                            <h3 class='text-xl font-bold leading-none text-gray-900 dark:text-white'>Table <?= $tableNo ?></h3>
                            <!-- Display ⓘ icon if special request is not empty
                            <?php if (!empty($order['specialRequest'])) : ?>
                                <span class='text-2xl text-red-500 mr-2 cursor-pointer cursor-help' title='<?= htmlspecialchars($order['specialRequest']) ?>'>ⓘ </span>
                            <?php endif; ?> -->
                        </div>
                        <div class='flow-root'>
                            <ul role='list' class='order-list divide-y divide-gray-200 dark:divide-gray-700 overflow-y-auto max-h-72' style='padding-right: 30px;'>
                                <li class='py-3 sm:py-4'>
                                    <div class='flex items-center space-x-4'>
                                        <div class='flex-1 min-w-0'>
                                            <p class='text-base font-semibold text-gray-900 truncate dark:text-white'>
                                                Dish
                                            </p>
                                        </div>
                                        <div class='inline-flex items-center text-base font-semibold text-gray-900 dark:text-white'>
                                            Quantity
                                        </div>
                                        <div class='inline-flex items-center text-base font-semibold text-gray-900 dark:text-white'>
                                            Status
                                        </div>
                                    </div>
                                </li>
                                <?php
                        $packages = array();

                        foreach ($orders as $order) : ?>
                            <li class='py-3 sm:py-4'>
                                <?php
                                $isProcessed = isset($packages[$order['packageID']]);
                                ?>

                                <?php if (!$isProcessed) : ?>
                                    <div class='flex items-center space-x-4'>
                                        <div class='flex-1 min-w-0'>
                                            <p class='text-sm font-medium text-gray-900 truncate dark:text-white'>
                                                <?php
                                                if (!empty($order['itemID'])) {
                                                    echo $order['itemName'];
                                                } elseif (!empty($order['packageID'])) {
                                                    echo $order['packageName'];
                                                }

                                                if (isset($order['preferences']) && $order['preferences'] === "Take-out") {
                                                    echo " (Take-out)";
                                                }
                                                ?>
                                            </p>
                                        </div>
                                        <div class='inline-flex items-center text-base font-semibold text-gray-900 dark:text-white'>
                                            <?= $order['itemQuantity'] ?><span>x</span>
                                        </div>
                                            <div class='inline-flex items-center text-base font-semibold text-gray-900 dark:text-white'>
                                                <button class='inline-flex items-center text-base font-semibold text-gray-900 dark:text-white'>
                                                    <svg height='15px' version='1.1' viewBox='0 0 18 15' width='50px' xmlns='http://www.w3.org/2000/svg' xmlns:sketch='http://www.bohemiancoding.com/sketch/ns' xmlns:xlink='http://www.w3.org/1999/xlink'>
                                                        <title></title>
                                                        <desc></desc>
                                                        <defs></defs>
                                                        <g fill='none' fill-rule='evenodd' id='Page-1' stroke='none' stroke-width='1'>
                                                            <g fill='#000000' id='Core' transform='translate(-423.000000, -47.000000)'>
                                                                <g id='check' transform='translate(423.000000, 47.500000)'>
                                                                    <path d='M6,10.2 L1.8,6 L0.4,7.4 L6,13 L18,1 L16.6,-0.4 L6,10.2 Z' id='Shape'></path>
                                                                </g>
                                                            </g>
                                                        </g>
                                                    </svg>
                                                </button>
                                                <span></span>
                                            </div>
                                            </div>
                                <?php endif; ?>

                                <!-- Additional information section -->
                                <div>
                                    <?php if (!empty($order['packageID'])) : ?>
                                        <!-- Display itemName of the packageName as additional information -->
                                        <?php
                                        if (!$isProcessed) {
                                            $packageID = $order['packageID'];
                                            $packageItemsQuery = "SELECT itemName FROM tblmenupackageitems WHERE packageID = '$packageID'";
                                            $packageItemsResult = mysqli_query($conn, $packageItemsQuery);

                                            if ($packageItemsResult) {
                                                $packageItems = mysqli_fetch_all($packageItemsResult, MYSQLI_ASSOC);

                                                if (!empty($packageItems)) {
                                                    echo "<ul class='text-sm text-gray-500 pl-4'>";
                                                    foreach ($packageItems as $item) {
                                                        echo "<li>{$item['itemName']}</li>";
                                                    }
                                                    echo "</ul>";
                                                }
                                            }
                                            $packages[$order['packageID']] = true;
                                        }
                                        ?>
                                    <?php endif; ?>
                                </div>
                            </li>
                        <?php endforeach; ?>

                                <li class='pt-3 pb-0 sm:pt-4'>
                                    <div class='flex items-center space-x-4'>
                                        <div class='flex-1 min-w-0'>
                                        </div>
                                    </div>
                                </li>
                            </ul>
                            <!-- Display specialRequest -->
                            <?php if (!empty($order['specialRequest'])) : ?>
                                                <div class='text-sm text-gray-500 pl-4'>
                                                    <strong>Special Request:</strong> <?= htmlspecialchars($order['specialRequest']) ?>
                                                </div>
                                            <?php endif; ?>
                            <!--
                            <form method='POST' class='bg-gray-700 border-teal-900 transition-colors focus:outline-none focus:ring block mt-10 w-full px-4 py-3 font-medium tracking-wide text-center capitalize border'>
                                <input type='hidden' name='order_id' value='<?= $tableNo ?>'>
                                <button class='bg-gray-700 border-teal-900 focus:outline-none focus:ring text-xs text-white px-2 py-1' type='submit' name='served' value='1'>Serve</button>
                            </form>
                            -->
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php else : ?>
                <span class='mt-5 text-xs text-gray-500'>No Served Orders.</span>
            <?php endif; ?>
        </div>
    </section>

</body>

</html>

<script src="https://cdn.jsdelivr.net/npm/apexcharts"></script>