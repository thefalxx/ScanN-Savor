<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="../../dist/output.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/flowbite/1.8.1/flowbite.min.css" rel="stylesheet" />
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <script src="https://cdn.tailwindcss.com"></script>
    <title>Merge Orders | Scan N' Savor</title>
</head>

<?php
include './sidenavwaiter.php';
include '../connection/config.php';

global $conn;

// Fetch merge order requests from the database
$mergeOrderQuery = "SELECT * FROM tblmergeorder WHERE status = 'Pending'";
$mergeOrderResult = $conn->query($mergeOrderQuery);

// Initialize arrays to store order details for orderIDs and currentOrderIDs
$orderDetailsOrderIDs = array();
$orderDetailsCurrentOrderIDs = array();

// Check if there are merge order requests
if ($mergeOrderResult->num_rows > 0) {
    $mergeOrders = $mergeOrderResult->fetch_all(MYSQLI_ASSOC);

    // Loop through each merge order
    foreach ($mergeOrders as $mergeOrder) {
        // Split orderIDs into an array
        $orderIDs = explode(',', $mergeOrder['orderIDs']);
        $currentOrderID = $mergeOrder['currentOrderID'];

        // Fetch order details for each orderID
        foreach ($orderIDs as $orderID) {
            $orderDetailsQuery = "SELECT * FROM tblorders WHERE orderID = ? AND orderStatus = 'Completed'";
            $stmtOrderDetails = $conn->prepare($orderDetailsQuery);
            $stmtOrderDetails->bind_param("i", $orderID);
            $stmtOrderDetails->execute();
            $orderDetailsResult = $stmtOrderDetails->get_result();

            if ($orderDetailsResult->num_rows > 0) {
                $orderDetailsOrderIDs[$orderID][] = $orderDetailsResult->fetch_assoc();
            }

            $stmtOrderDetails->close();
        }

        // Fetch order details for currentOrderID
        $orderDetailsQuery = "SELECT * FROM tblorders WHERE orderID = ?";
        $stmtOrderDetails = $conn->prepare($orderDetailsQuery);
        $stmtOrderDetails->bind_param("i", $currentOrderID);
        $stmtOrderDetails->execute();
        $orderDetailsResult = $stmtOrderDetails->get_result();

        if ($orderDetailsResult->num_rows > 0) {
            $orderDetailsCurrentOrderIDs[$currentOrderID] = $orderDetailsResult->fetch_assoc();
        }

        $stmtOrderDetails->close();
    }
}
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['processMerge'])) {
    foreach ($mergeOrders as $mergeOrder) {
        $orderIDsArray = explode(',', $mergeOrder['orderIDs']);
        $currentOrderID = $mergeOrder['currentOrderID'];

        // Convert the array to a comma-separated string
        $orderIDToMerge = implode(',', $orderIDsArray);

        try {
            // Start a transaction
            $conn->begin_transaction();

            // 1. Update tblorderdetails to set the new orderID
            $updateOrderDetailsQuery = "UPDATE tblorderdetails SET orderID = ? WHERE orderID IN ($orderIDToMerge)";
            $stmtUpdateOrderDetails = $conn->prepare($updateOrderDetailsQuery);
            $stmtUpdateOrderDetails->bind_param("i", $currentOrderID);
            $stmtUpdateOrderDetails->execute();
            $stmtUpdateOrderDetails->close();

            // 2. Calculate the sum of totalAmount from tblorderdetails for the currentOrderID
            $orderDetailsQuery = "SELECT SUM(Amount) AS totalOrderAmount FROM tblorderdetails WHERE orderID = ?";
            $stmtOrderDetails = $conn->prepare($orderDetailsQuery);
            $stmtOrderDetails->bind_param("i", $currentOrderID);
            $stmtOrderDetails->execute();
            $resultOrderDetails = $stmtOrderDetails->get_result();

            if ($resultOrderDetails->num_rows > 0) {
                $dataOrderDetails = $resultOrderDetails->fetch_assoc();
                $totalOrderAmount = $dataOrderDetails['totalOrderAmount'];

                // 3. Update tblorders to set the totalAmount
                $updateOrderQuery = "UPDATE tblorders SET isMerged = 1, totalAmount = ? WHERE orderID = ?";
                $stmtUpdateOrder = $conn->prepare($updateOrderQuery);
                $stmtUpdateOrder->bind_param("di", $totalOrderAmount, $currentOrderID);
                $stmtUpdateOrder->execute();
                $stmtUpdateOrder->close();
            }

            // 4. Update tblmergeorder to mark the order as approved
            $updateMergeOrderRequestQuery = "UPDATE tblmergeorder SET status = 'Approved' WHERE orderIDs = ?";
            $stmtUpdateMergeOrderRequest = $conn->prepare($updateMergeOrderRequestQuery);
            $stmtUpdateMergeOrderRequest->bind_param("i", $orderIDToMerge);
            $stmtUpdateMergeOrderRequest->execute();
            $stmtUpdateMergeOrderRequest->close();

            // 5. Update tblorders to change the status of the orderIDToMerge to 'Merged'
            $updateOrderStatusQuery = "UPDATE tblorders SET orderStatus = 'Merged' WHERE orderID IN ($orderIDToMerge)";
            $stmtUpdateOrderStatus = $conn->prepare($updateOrderStatusQuery);
            $stmtUpdateOrderStatus->execute();
            $stmtUpdateOrderStatus->close();

            // 6. Update tbltable to set isOccupied = 0 for the table numbers associated with orderIDToMerge
            $updateTableQuery = "UPDATE tbltable SET isOccupied = 0 WHERE tableNo IN (SELECT tableNo FROM tblorders WHERE orderID IN ($orderIDToMerge))";
            $stmtUpdateTable = $conn->prepare($updateTableQuery);
            $stmtUpdateTable->execute();
            $stmtUpdateTable->close();

            // Commit the transaction
            $conn->commit();

            echo '<script>alert("Request approved.");</script>';
        } catch (Exception $e) {
            // Rollback the transaction if an error occurs
            $conn->rollback();
            echo "Error: " . $e->getMessage();
        } finally {
            // Close the database connection
            $conn->close();
        }
        exit();
    }
}


// Check if cancellation button is clicked
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['cancelMerge'])) {
    // Assuming you have a unique identifier for each merge order, for example, mergeOrderID
    $mergeOrderIDToCancel = $_POST['mergeOrderID']; // Replace 'mergeOrderID' with your actual field name

    try {
        // Start a transaction
        $conn->begin_transaction();

        // Update tblmergeorder to mark the order as canceled
        $cancelMergeOrderQuery = "UPDATE tblmergeorder SET status = 'Declined' WHERE requestID = ?";
        $stmtCancelMergeOrder = $conn->prepare($cancelMergeOrderQuery);
        $stmtCancelMergeOrder->bind_param("i", $mergeOrderIDToCancel);
        $stmtCancelMergeOrder->execute();
        $stmtCancelMergeOrder->close();

        // Commit the transaction
        $conn->commit();

        echo '<script>alert("Merge request declined.");</script>';
    } catch (Exception $e) {
        // Rollback the transaction if an error occurs
        $conn->rollback();
        echo "Error: " . $e->getMessage();
    }
    exit();
}
?>

<body>
    <section>
        <form action="" method="post">
            <div class="mx-auto max-w-5xl py-10 pl-10">
                <div class="pt-5 pl-5 pb-10 col-span-1 md:col-span-2 lg:col-span-4">
                    <h2 class="text-lg md:text-xl text-gray-700 font-bold tracking-wide md:tracking-wider">
                        Merge Order Requests
                    </h2>
                </div>
            </div>

            <?php
            // Check if there are merge order requests
            if ($mergeOrderResult->num_rows > 0) {
                // Initialize the total amount variable
                $totalMergedAmount = 0;

                foreach ($mergeOrders as $mergeOrder) {
                    // Split orderIDs into an array
                    $totalMergedAmount = 0;
                    $orderIDsArray = explode(',', $mergeOrder['orderIDs']);

                    // Initialize the amount for the merged orders
                    $mergedOrderAmount = 0;

                    // Initialize an array to store table numbers
                    $tableNumbers = [];

                    // Sum up the totalAmount for each order in $orderIDsArray
                    foreach ($orderIDsArray as $orderID) {
                        $orderDetailsQuery = "SELECT * FROM tblorders WHERE orderID = ?";
                        $stmtOrderDetails = $conn->prepare($orderDetailsQuery);
                        $stmtOrderDetails->bind_param("i", $orderID);
                        $stmtOrderDetails->execute();
                        $orderDetailsResult = $stmtOrderDetails->get_result();

                        if ($orderDetailsResult->num_rows > 0) {
                            $orderDetails = $orderDetailsResult->fetch_assoc();
                            $mergedOrderAmount += $orderDetails['totalAmount']; // Add to the merged order amount
                            $tableNumbers[] = $orderDetails['tableNo']; // Store table number
                        }

                        $stmtOrderDetails->close();
                    }

                    // Add the totalAmount of $currentOrderDetails to the merged order amount
                    $currentOrderDetails = $orderDetailsCurrentOrderIDs[$mergeOrder['currentOrderID']] ?? null;
                    if ($currentOrderDetails) {
                        $totalMergedAmount += $mergedOrderAmount + $currentOrderDetails['totalAmount'];
                    }
            ?>

                    <!-- Your HTML for displaying order details goes here -->
                    <div class="mt-5 max-w-2xl mx-auto">
                        <div class=" max-w-md bg-white rounded-lg border shadow-md sm:p-8 dark:bg-gray-800 dark:border-gray-700">
                            <div class="flex justify-between items-center mb-4"> To be Merged:
                                <h3 class="text-lg font-medium leading-none text-gray-900 dark:text-white">
                                    Order # <?php echo implode(', ', $orderIDsArray); ?>
                                </h3>
                                <h3 class="text-lg font-normal leading-none text-gray-900 dark:text-white">
                                    Table <?php echo implode(', ', $tableNumbers); ?>
                                </h3>
                            </div>
                            <div class="flex justify-between items-center mb-4">Current Order:
                                <?php
                                $currentOrderDetails = $orderDetailsCurrentOrderIDs[$mergeOrder['currentOrderID']] ?? null;
                                if ($currentOrderDetails) :
                                ?>
                                    <h3 class="text-lg font-medium leading-none text-gray-900 dark:text-white">
                                        Order # <?php echo $currentOrderDetails['orderID'] ?? ''; ?>
                                    </h3>
                                    <h3 class="text-lg font-normal leading-none text-gray-900 dark:text-white">
                                        Table <?php echo $currentOrderDetails['tableNo'] ?? ''; ?>
                                    </h3>
                                    <input type="hidden" name="tableNum" value="">
                                <?php endif; ?>
                            </div>
                            <div class="grid place-items-center">
                                <div class="lg:p-5 md:p-5 lg:mx-3">
                                    <div class="sm:p-5 pt-3">
                                        Amount
                                        <label for="" class="flex text-xl ml-20 font-bold leading-none text-gray-900 dark:text-white">
                                            ₱ <?php echo number_format($totalMergedAmount, 2)  ?>
                                        </label>

                                        <div class="mt-20">
                                            <button type="submit" class="hover:shadow-form w-72 rounded-md bg-gray-800 py-3 px-8 text-center text-base font-semibold text-white outline-none" id="processMerge" name="processMerge">
                                                Approve
                                            </button>
                                            <div class="py-2">
                                                <input type="hidden" name="mergeOrderID" value="<?php echo $mergeOrder['requestID']; ?>">
                                                <button type="submit" class="hover:shadow-form w-72 rounded-md bg-gray-800 py-3 px-8 text-center text-base font-semibold text-white outline-none" id="cancelMerge" name="cancelMerge">
                                                    Decline
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

            <?php
                } // end foreach
            } else {
                // No merge order requests
                echo '<p class="text-sm text-gray-500 mx-52 pl-72 mt-2">No merge order requests</p>';
            }
            ?>
        </form>
    </section>
</body>


</html>

<script src="https://cdn.tailwindcss.com"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/flowbite/1.8.0/flowbite.min.js"></script>