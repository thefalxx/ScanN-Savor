<?php
include('../class/User.php');
include('../class/Orders.php');
include('../class/Customer.php');
$order = new Order();
/// Handle button click for confirming orders (assuming you have a form)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['confirm_order'])) {
    // Assuming you have a form input named 'order_id' to identify the order
    $orderID = $_POST['order_id'];

    // Update order status to "InProgress"
    $confirmMessage = $order->updateOrderStatusToPending($orderID);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['served'])) {
    // Assuming you have a form input named 'order_id' to identify the order
    $orderID = $_POST['order_id'];

    // Update order status to "Served"
    $confirmMessage = $order->updateOrderStatusToServed($orderID);
}

// // Check if the Cancel Order button is clicked
// if (isset($_POST['cancel_order']) && $_POST['cancel_order'] == 1) {
//     $tableNoToCancel = mysqli_real_escape_string($conn, $_POST['order_id']);

//     // Call a function to cancel the order
//     $cancelResult = $order->cancelOrder($tableNoToCancel);

//     // Output the result
//     echo "<p class='text-red-500'>$cancelResult</p>";

//     // Optional: Refresh the page or redirect as needed
//     // header("Refresh:0");
// }
// // Assuming $orderDetailsID is available
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['cancelOrder'])) {
    $orderDetailsID = $_POST['cancelOrder'];

    // Call the function to cancel the order item
    $result = $order->cancelOrderItem($orderDetailsID);

    // Redirect back to orderConfirmation.php
    header("Location: orderConfirmation.php");
    exit();
}

$confirmOrders = $order->getforApprovalOrders();
//$pendingOrders = $order->getPendingOrders();

$customer = new Customer();

// Check if the delete button is clicked
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_customer'])) {
    $waitingIDToDelete = $_POST['waiting_id'];

    // Call the deleteCustomer method
    $deleteResult = $customer->deleteCustomer($waitingIDToDelete);

    // Output the result
    // echo "<p class='text-red-500'>" . ($deleteResult ? 'Customer deleted successfully.' : 'Error deleting customer.') . "</p>";
}

$user = new User();
$user->loginStatus();
$user->reload();
$userDetail = $user->userDetails();

$pendingOrders = $order->getPendingOrders();
$CompleteOrders = $order->getCompleteOrders();


?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="../../dist/output.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/flowbite/2.2.0/flowbite.min.css" rel="stylesheet" />
    <title>Document</title>
    <style>
        /* @media screen and (max-width: 1024px) {
            #default-sidebar {
                display: none;
            }

            #default-sidebar.open {
                display: block;
            }
        } */

        @media screen and (min-width: 1025px) {
            #default-sidebar {
                display: block;
            }
        }

        @media screen and (max-width: 1024px) {
            #default-sidebar {
                display: none;
            }

            #default-sidebar.open {
                display: block;
            }
        }
    </style>
</head>

<body>

    <!-- hamburger -->
    <!-- <button data-drawer-target="default-sidebar" data-drawer-toggle="default-sidebar" aria-controls="default-sidebar" type="button" class="inline-flex items-center p-2 mt-2 ml-3 text-sm text-gray-500 rounded-lg sm:hidden hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-gray-200">
        <span class="sr-only">Open sidebar</span>
        <svg class="w-6 h-6" aria-hidden="true" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
            <path clip-rule="evenodd" fill-rule="evenodd" d="M2 4.75A.75.75 0 012.75 4h14.5a.75.75 0 010 1.5H2.75A.75.75 0 012 4.75zm0 10.5a.75.75 0 01.75-.75h7.5a.75.75 0 010 1.5h-7.5a.75.75 0 01-.75-.75zM2 10a.75.75 0 01.75-.75h14.5a.75.75 0 010 1.5H2.75A.75.75 0 012 10z"></path>
        </svg>
    </button> -->
    <button data-drawer-target="default-sidebar" data-drawer-toggle="default-sidebar" aria-controls="default-sidebar" type="button" class="inline-flex items-center p-2 mt-2 ml-3 text-sm text-gray-500 rounded-lg sm:hidden hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-gray-200">
        <span class="sr-only">Open sidebar</span>
        <svg class="w-6 h-6" aria-hidden="true" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
            <path clip-rule="evenodd" fill-rule="evenodd" d="M2 4.75A.75.75 0 012.75 4h14.5a.75.75 0 010 1.5H2.75A.75.75 0 012 4.75zm0 10.5a.75.75 0 01.75-.75h7.5a.75.75 0 010 1.5h-7.5a.75.75 0 01-.75-.75zM2 10a.75.75 0 01.75-.75h14.5a.75.75 0 010 1.5H2.75A.75.75 0 012 10z"></path>
        </svg>
    </button>

    <aside id="default-sidebar" class="fixed top-0 left-0 z-40 w-64 h-screen transition-transform -translate-x-full sm:translate-x-0" aria-label="Sidenav">

        <div class="overflow-y-auto py-5 px-3 h-full bg-white border-r border-gray-200">

            <div class="space-y-6 md:space-y-10 mt-10">

                <h1 class="md:block font-bold text-sm md:text-xl text-center">
                    <span class="text-teal-800 text-3xl">Scan N' Savor</span>
                </h1>

                <div id="profile" class="space-y-3">
                    <img src="../../images/green scansavor logo.png" alt="logo" class="w-14 h-14 md:w-16 rounded-full mx-auto" />
                    <div>
                        <h2 class="font-medium text-s md:text-sm text-center text-teal-500">
                            <?php echo strtoupper($_SESSION['name']); ?>
                        </h2>
                        <p class="pb-10 text-xs text-gray-500 text-center">Waiter / Waitress</p>
                    </div>
                </div>
            </div>

            <!-- dashboard -->
            <ul class="space-y-2">
                <li>
                    <a href="../viewWaiter/ordersDashboard.php" class="flex items-center p-2 text-base font-normal text-gray-900 rounded-lg hover:bg-teal-800 group">
                        <svg class="w-6 h-6 text-gray-400 transition duration-75 group-hover:text-white" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                            <path d="M5 3a2 2 0 00-2 2v2a2 2 0 002 2h2a2 2 0 002-2V5a2 2 0 00-2-2H5zM5 11a2 2 0 00-2 2v2a2 2 0 002 2h2a2 2 0 002-2v-2a2 2 0 00-2-2H5zM11 5a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V5zM11 13a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z"></path>
                        </svg>
                        <span class="ml-3 group-hover:text-white">Dashboard</span>
                    </a>
                </li>

                <!-- create order -->
                <li>
                    <a href="../viewWaiter/orderpage.php" class="flex items-center p-2 text-base font-normal text-gray-900 rounded-lg hover:bg-teal-800 group">
                        <svg aria-hidden="true" class="w-6 h-6 text-gray-400 transition duration-75 group-hover:text-white" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                            <path d="M2 10a8 8 0 018-8v8h8a8 8 0 11-16 0z"></path>
                            <path d="M12 2.252A8.014 8.014 0 0117.748 8H12V2.252z"></path>
                        </svg>
                        <span class="ml-3 group-hover:text-white">Create Order</span>
                    </a>
                </li>

                <!-- orders -->
                <li>
                    <button type="button" class="flex items-center p-2 w-full text-base font-normal text-gray-900 rounded-lg transition duration-75 group hover:bg-teal-800" aria-controls="dropdown-pages" data-collapse-toggle="dropdown-pages">
                        <svg aria-hidden="true" class="flex-shrink-0 w-6 h-6 text-gray-400 transition duration-75 group-hover:text-white" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                            <path fill-rule="evenodd" d="M4 4a2 2 0 012-2h4.586A2 2 0 0112 2.586L15.414 6A2 2 0 0116 7.414V16a2 2 0 01-2 2H6a2 2 0 01-2-2V4zm2 6a1 1 0 011-1h6a1 1 0 110 2H7a1 1 0 01-1-1zm1 3a1 1 0 100 2h6a1 1 0 100-2H7z" clip-rule="evenodd"></path>
                        </svg>
                        <span class="flex-1 ml-3 text-left whitespace-nowrap  group-hover:text-white">Orders</span>
                        <svg aria-hidden="true" class="w-6 h-6" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                            <path fill-rule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clip-rule="evenodd"></path>
                        </svg>
                    </button>
                    <ul id="dropdown-pages" class="hidden py-2 space-y-2">
                        <li>
                            <a href="../viewWaiter/orderConfirmation.php" class="flex items-center p-2 pl-11 w-full text-base font-normal text-gray-900 rounded-lg transition duration-75 group hover:bg-teal-800 hover:text-white">Order Confirmation</a>
                        </li>
                        <li>
                            <a href="../viewWaiter/pending.php" class="flex items-center p-2 pl-11 w-full text-base font-normal text-gray-900 rounded-lg transition duration-75 group hover:bg-teal-800 hover:text-white">Pending Orders</a>
                        </li>
                        <li>
                            <a href="../viewWaiter/serve.php" class="flex items-center p-2 pl-11 w-full text-base font-normal text-gray-900 rounded-lg transition duration-75 group hover:bg-teal-800 hover:text-white">Complete Orders</a>
                        </li>
                    </ul>
                </li>

                <!-- waiting -->
                <li>
                    <a href="../viewWaiter/waitCustomer.php" class="flex items-center p-2 text-base font-normal text-gray-900 rounded-lg transition duration-75 hover:bg-teal-800 group">
                        <svg aria-hidden="true" class="flex-shrink-0 w-6 h-6 text-gray-400 transition duration-75 group-hover:text-white" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                            <path d="M9 2a1 1 0 000 2h2a1 1 0 100-2H9z"></path>
                            <path fill-rule="evenodd" d="M4 5a2 2 0 012-2 3 3 0 003 3h2a3 3 0 003-3 2 2 0 012 2v11a2 2 0 01-2 2H6a2 2 0 01-2-2V5zm3 4a1 1 0 000 2h.01a1 1 0 100-2H7zm3 0a1 1 0 000 2h3a1 1 0 100-2h-3zm-3 4a1 1 0 100 2h.01a1 1 0 100-2H7zm3 0a1 1 0 100 2h3a1 1 0 100-2h-3z" clip-rule="evenodd"></path>

                        </svg>
                        <span class="ml-3 group-hover:text-white">Waiting List</span>
                    </a>
                </li>

                <!-- merge -->

                <li>
                    <a href="../viewWaiter/mergeorders.php" class="flex items-center p-2 text-base font-normal text-gray-900 rounded-lg transition duration-75 hover:bg-teal-800 group">
                        <svg aria-hidden="true" class="flex-shrink-0 w-6 h-6 text-gray-400 transition duration-75 group-hover:text-white" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                        <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M1 8h11m0 0L8 4m4 4-4 4m4-11h3a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2h-3"/>
                        </svg>
                        <span class="ml-3 group-hover:text-white">Merge Orders </span>
                    </a>
                </li>
            </ul>

            <ul class="pt-5 mt-5 space-y-2 border-t border-gray-200">

                <!-- settings -->
                <li>
                    <a href="../viewWaiter/waitersetting.php" class="flex items-center p-2 text-base font-normal text-gray-900 rounded-lg transition duration-75 hover:bg-teal-800 group">
                        <svg aria-hidden="true" class="flex-shrink-0 w-6 h-6 text-gray-400 transition duration-75 group-hover:text-white" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                            <path fill-rule="evenodd" d="M11.49 3.17c-.38-1.56-2.6-1.56-2.98 0a1.532 1.532 0 01-2.286.948c-1.372-.836-2.942.734-2.106 2.106.54.886.061 2.042-.947 2.287-1.561.379-1.561 2.6 0 2.978a1.532 1.532 0 01.947 2.287c-.836 1.372.734 2.942 2.106 2.106a1.532 1.532 0 012.287.947c.379 1.561 2.6 1.561 2.978 0a1.533 1.533 0 012.287-.947c1.372.836 2.942-.734 2.106-2.106a1.533 1.533 0 01.947-2.287c1.561-.379 1.561-2.6 0-2.978a1.532 1.532 0 01-.947-2.287c.836-1.372-.734-2.942-2.106-2.106a1.532 1.532 0 01-2.287-.947zM10 13a3 3 0 100-6 3 3 0 000 6z" clip-rule="evenodd"></path>
                        </svg>
                        <span class="ml-3 group-hover:text-white">Settings</span>
                    </a>
                </li>

                <!-- logout -->
                <li>
                    <a href="../../src/index.php" class="flex items-center p-2 text-base font-normal text-gray-900 rounded-lg transition duration-75 hover:bg-teal-800 group">
                        <svg aria-hidden="true" class="flex-shrink-0 w-6 h-6 text-gray-400 transition duration-75 group-hover:text-white" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                            <path fill-rule="evenodd" d="M5 9V7a5 5 0 0110 0v2a2 2 0 012 2v5a2 2 0 01-2 2H5a2 2 0 01-2-2v-5a2 2 0 012-2zm8-2v2H7V7a3 3 0 016 0z" clip-rule="evenodd"></path>
                        </svg>
                        <span class="ml-3 group-hover:text-white">Log Out</span>
                    </a>
                </li>
            </ul>
        </div>
    </aside>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/flowbite/2.2.0/flowbite.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const sidebar = document.getElementById('default-sidebar');
            const hamburgerButton = document.querySelector('[data-drawer-target="default-sidebar"]');

            hamburgerButton.addEventListener('click', function() {
                sidebar.classList.toggle('open');
            });

            // Close the sidebar when clicking outside of it
            document.addEventListener('click', function(event) {
                if (!sidebar.contains(event.target) && !hamburgerButton.contains(event.target)) {
                    sidebar.classList.remove('open');
                }
            });
        });
    </script>
</body>

</html>