

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="../../dist/output.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/flowbite/1.8.0/flowbite.min.css" rel="stylesheet" />
    <script src="https://cdn.tailwindcss.com"></script>
    <title>Wait List | Scan N Savor</title>
</head>

<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
include('../viewWaiter/sidenavwaiter.php');
include('../forms/addWaitingList.php');
include('../forms/sendMessageModal.php');
// include('../class/Customer.php');
// $customer = new Customer();
$searchTerm = '';
$customer = new Customer(); // Instantiate the Customer class
$waitCustomer = $customer->getAllCustomer($searchTerm);
$vacant = getVacantTables();

if ($_SERVER['REQUEST_METHOD'] == "POST") {
    $searchTerm = isset($_POST['simple-search']) ? $_POST['simple-search'] : '';

    // Check if the sendSMS button is clicked
    // if (isset($_POST['sendSMS'])) {
    //     $apiKey = 'b777acf5366b88c52f3ea56938ece85b';
    //     $message = "We now have a table ready for you! If you'd like to dine at our restaurant, feel free to visit, and we'll be delighted to serve you! - Scan N' Savor";
    //     $contactNumber = $_POST["contactNumber"];

    //     // Validate and send SMS
    //     if (!empty($message) && !empty($contactNumber)) {
    //        // sendSemaphoreMessage($apiKey, $message, $contactNumber);
    //     } else {
    //         echo "Please fill in both Message and Contact Number fields.";
    //     }
    // }
}

function getVacantTables()
{
    global $conn;
    $sqlQuery = "SELECT * FROM tbltable WHERE isOccupied = 0";
    $result = mysqli_query($conn, $sqlQuery);

    $vacant = array();

    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $vacant[] = $row;
        }
    } else {
        // Handle the error here
        die("Error: " . mysqli_error($conn));
    }

    return $vacant;
}

// Function to send SMS using Semaphore API
// function sendSemaphoreMessage($apiKey, $message, $contactNumber)
// {
//     $ch = curl_init();
//     $apiUrl = "https://semaphore.co/api/v4/messages";
//     $parameters = array(
//         'apikey' => $apiKey,
//         'number' => $contactNumber,
//         'message' => $message,
//         'sendername' => 'SEMAPHORE'
//     );

//     curl_setopt($ch, CURLOPT_URL, $apiUrl);
//     curl_setopt($ch, CURLOPT_POST, 1);
//     curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($parameters));
//     curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

//     $output = curl_exec($ch);

//     if ($output === false) {
//         echo "cURL error: " . curl_error($ch);
//     } else {
//         echo "Server Response: " . $output;
//     }

//     curl_close($ch);
// }


global $conn;

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["updateWaitStatus"])) {
    $waitingId = $_POST["waitingId"];
    $newStatus = $_POST["waitStatus"];

    // Update the status using the global connection
    $stmt = $conn->prepare("UPDATE tblwaitingcustomer SET status = ? WHERE waitingID = ?");
    $stmt->bind_param('si', $newStatus, $waitingId);
    $stmt->execute();
    //  header("refresh:5;url=" . $_SERVER['PHP_SELF']);
}

?>

<body>
    <section class="px-20">
        <div class="flex lg:ml-64">
            <div class="overflow-y-auto overflow-x-hidden max-h-[350px] mt-12" id="tableContainer">
                <table class="w-full px-5 text-sm text-left text-gray-500 border" id="tablesTable">
                    <h3 class="font-medium text-center text-gray-500 text-md py-1">VACANT TABLES</h3>
                    <thead class="text-xs text-gray-600 uppercase bg-gray-50">
                        <tr>
                            <th scope="col" class="px-4 py-4 font-medium">Table No.</th>
                            <th scope="col" class="px-4 py-4 font-medium">Seats</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($vacant as $vacantTables) :
                        ?>
                            <tr class="border-b hover:bg-gray-100">
                                <td class="px-4 py-3 text-gray-500 whitespace-nowrap"><?php echo $vacantTables['tableNo'];
                                                                                        ?></td>
                                <td class="px-4 py-3"><?php echo $vacantTables['noOfSeats'];
                                                        ?></td>
                            </tr>
                        <?php endforeach;
                        ?>
                    </tbody>
                </table>
            </div>
            <div class="py-10">
                <!-- <section class="py-3"> -->
                <div class="mx-auto">
                    <div class="px-4 mx-auto max-w-screen max-h-screen-xl lg:px-8 xl:px-10">
                        <div class="relative overflow-hidden bg-white shadow-md sm:rounded-lg">
                            <div class="flex flex-col items-stretch py-4 mx-4 space-y-3 border-t md:flex-row md:items-center md:space-x-3 md:space-y-0">
                                <div class="w-full">
                                    <form class="flex items-center" method="post">
                                        <label for="simple-search" class="sr-only">Search</label>
                                        <div class="relative w-full">
                                            <div class="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                                                <svg aria-hidden="true" class="w-5 h-5 text-gray-500" fill="currentColor" viewbox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                                                    <path fill-rule="evenodd" clip-rule="evenodd" d="M8 4a4 4 0 100 8 4 4 0 000-8zM2 8a6 6 0 1110.89 3.476l4.817 4.817a1 1 0 01-1.414 1.414l-4.816-4.816A6 6 0 012 8z" />
                                                </svg>
                                            </div>
                                            <input type="text" id="simple-search" name="simple-search" class="block w-full p-2 pl-10 text-sm text-gray-900 border border-gray-300 rounded-lg bg-gray-50 focus:ring-teal-800" placeholder="Search" value="<?php echo htmlspecialchars($searchTerm); ?>">
                                        </div>
                                    </form>
                                </div>
                                <div class="flex flex-col items-stretch justify-end flex-shrink-0 w-full space-y-2 md:w-auto md:flex-row md:space-y-0 md:items-center md:space-x-3">
                                    <button type="button" id="createWaitList" data-modal-toggle="createWaitListModal" class="flex items-center justify-center px-4 py-2 text-sm font-medium text-teal-800 border border-gray-200 rounded-lg hover:bg-teal-800 hover:text-white focus:ring-2 focus:ring-teal-200">
                                        <svg class="h-3.5 w-3.5 mr-1.5 -ml-1" fill="currentColor" viewbox="0 0 20 20" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
                                            <path clip-rule="evenodd" fill-rule="evenodd" d="M10 3a1 1 0 011 1v5h5a1 1 0 110 2h-5v5a1 1 0 11-2 0v-5H4a1 1 0 110-2h5V4a1 1 0 011-1z" />
                                        </svg>
                                        Add Waiting List
                                    </button>
                                </div>
                            </div>

                            <div class="overflow-x-auto ">
                                <table class="w-full text-sm text-left text-gray-500 ">
                                    <thead class="text-xs text-gray-700 uppercase bg-gray-50">
                                        <tr>
                                            <th scope="col" class="px-4 py-4 text-center">Name</th>
                                            <th scope="col" class="px-4 py-4 text-center">Contact Number</th>
                                            <th scope="col" class="px-4 py-4 text-center">No. of Seats</th>
                                            <th scope="col" class="px-4 py-4 text-center">Waiting Time</th>
                                            <th scope="col" class="px-4 py-4 text-center">Status</th>
                                            <th scope="col" class="px-4 py-4 text-center"></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($waitCustomer as $customer) { ?>
                                            <tr class="border-b">
                                                <!-- <td class="px-6 py-3"></td> -->
                                                <td class="px-6 py-3 text-center"> <?php echo $customer['name'] ?> </td>
                                                <td class="px-6 py-3 text-center"> <?php echo $customer['contactNo']; ?> </td>
                                                <td class="px-6 py-3 text-center"> <?php echo $customer['noOfSeats']; ?> </td>
                                                <td class="px-6 py-3 text-center">
                                                    <?php
                                                    // Assuming $customer['waiting_time'] contains a timestamp
                                                    $timestamp = strtotime($customer['waiting_time']);
                                                    $formattedTime = date("H:i", $timestamp);
                                                    echo $formattedTime;
                                                    ?>
                                                </td>
                                                <td class="px-6 py-3 text-center">
                                                    <div class="flex items-center">
                                                        <span class="flex-grow text-center"><?php echo $customer['status']; ?></span>
                                                        <button type="button" data-modal-toggle="updateWaitListStatus" data-waiting-id="<?php echo $customer['waitingID']; ?>" data-status="<?php echo $customer['status']; ?>" class="px-2 py-1 ml-2 text-xs font-medium text-teal-600 underline rounded-lg hover:text-white hover:bg-teal-500 hover:opacity-75 focus:ring-2 focus:outline-none focus:ring-teal-300 dark:bg-teal-600 dark:hover:bg-teal-700 dark:focus:ring-teal-800">
                                                            Edit
                                                        </button>
                                                    </div>
                                                </td>
                                                <!-- <td class="px-6 py-3"></td> -->
                                                <td class="px-6 py-3 font-medium text-center text-gray-900 whitespace-nowrap">
                                                    <form method="post" class="flex justify-center">
                                                        <input type="hidden" name="waiting_id" value="<?php echo $customer['waitingID']; ?>">
                                                        <div class="mx-2">
                                                            <button type="button" name="messageModal" onclick="retrieveWaitListModal(this)" data-waiting-id="<?php echo $customer['waitingID']; ?>" data-name="<?php echo $customer['name']; ?>" data-contact-no="<?php echo $customer['contactNo']; ?>" data-no-of-seats="<?php echo $customer['noOfSeats']; ?>" data-status="<?php echo $customer['status']; ?>" class="flex items-center text-teal-700 border focus:ring-2 focus:outline-none focus:ring-teal-300 font-medium rounded-lg text-sm px-3 py-2 <?php echo ($customer['status'] === 'Dine') ? 'disabled' : 'hover:bg-teal-800 hover:text-white'; ?>" data-modal-toggle="retrieveWaitListModal" <?php echo ($customer['status'] === 'Dine') ? 'disabled' : ''; ?>>
                                                                Message
                                                            </button>
                                                        </div>
                                                        <button type="submit" name="delete_customer" class="flex items-center px-3 py-2 text-sm font-medium text-red-700 border rounded-lg hover:text-white hover:bg-red-800 focus:ring-2 focus:outline-none focus:ring-red-300">
                                                            <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 mr-2 -ml-0.5" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                                                                <path fill-rule="evenodd" d="M9 2a1 1 0 00-.894.553L7.382 4H4a1 1 0 000 2v10a2 2 0 002 2h8a2 2 0 002-2V6a1 1 0 100-2h-3.382l-.724-1.447A1 1 0 0011 2H9zM7 8a1 1 0 012 0v6a1 1 0 11-2 0V8zm5-1a1 1 0 00-1 1v6a1 1 0 102 0V8a1 1 0 00-1-1z" clip-rule="evenodd" />
                                                            </svg>
                                                            Delete
                                                        </button>
                                                    </form>
                                                </td>
                                            </tr>
                                        <?php } ?>
                                    </tbody>
                                </table>
                            </div>
                            <?php
                            include '../view/pagination/waitingPagination.php';
                            ?>
                        </div>
                    </div>
                </div>
            </div>
    </section>

    <div id="updateWaitListStatus" tabindex="-1" aria-hidden="true" class="hidden overflow-y-auto overflow-x-hidden fixed top-0 right-0 left-0 z-50 justify-center items-center w-full md:inset-0 h-[calc(100%-1rem)] md:h-full">
        <div id="overlay"></div>
        <div class="relative w-full h-full max-w-lg p-4 md:h-auto">
            <!-- Modal content -->
            <div class="relative p-4 bg-white rounded-lg shadow">
                <!-- Modal header -->
                <div class="flex items-center justify-between pb-4 mb-4 border-b rounded-t sm:mb-5">
                    <h3 class="text-lg font-semibold text-gray-900">Wait Status</h3>
                    <button type="button" class="text-gray-400 bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm p-1.5 ml-auto inline-flex items-center" data-modal-toggle="updateWaitListStatus">
                        <svg aria-hidden="true" class="w-5 h-5" fill="currentColor" viewbox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                            <path fill-rule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clip-rule="evenodd" />
                        </svg>
                        <span class="sr-only">Close modal</span>
                    </button>
                </div>
                <!-- Modal body -->
                <form method="post" action="" id="updateWaitListStatusForm">
                    <div>
                        <label for="waitStatus" class="block mb-2 text-sm font-medium text-gray-900">Status</label>
                        <select id="waitStatus" name="waitStatus" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-green-200 focus:border-green-200 block w-full p-2.5" placeholder="" required="">
                            <option selected=""></option>
                            <option value="Waiting">Waiting</option>
                            <option value="Dine">Dine</option>
                        </select>
                    </div>
                    <input type="hidden" id="waitingId" name="waitingId" value="">

                    <div class="items-center my-2 space-y-4 sm:flex sm:space-y-4 sm:space-x-4">
                        <button type="submit" name="updateWaitStatus" value="updateWaitStatus" id="updateWaitStatus" class="w-full sm:w-auto justify-center text-teal-800 inline-flex border border-gray-300 bg-teal-700 hover:bg-teal-800 hover:text-white focus:ring-2 focus:outline-none focus:ring-green-200 font-medium rounded-lg text-sm px-5 py-2.5 text-center">
                            Submit
                        </button>
                    </div>
                </form>

            </div>
        </div>
    </div>

</body>

</html>

<script src="https://cdnjs.cloudflare.com/ajax/libs/flowbite/1.8.0/flowbite.min.js"></script>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        document.querySelectorAll('[data-modal-toggle="updateWaitListStatus"]').forEach(function(button) {
            button.addEventListener('click', function() {
                var waitingId = button.getAttribute('data-waiting-id');
                var status = button.getAttribute('data-status');

                // Fill the form fields in the modal
                document.getElementById('waitingId').value = waitingId;
                document.getElementById('waitStatus').value = status;

                // Open the modal
                // Adjust this part based on how you handle modals in your code
                document.getElementById('updateWaitListStatus').classList.remove('hidden');
            });
        });

        // Add logic to close the modal when the close button is clicked
        document.querySelector('[data-modal-toggle="updateWaitListStatus"]').addEventListener('click', function() {
            document.getElementById('updateWaitListStatus').classList.add('hidden');
        });
    });
</script>




<script>
    function retrieveWaitListModal(button) {
        // Retrieve data from the clicked button
        var waitingId = button.getAttribute("data-waiting-id");
        var name = button.getAttribute("data-name");
        var contactNo = button.getAttribute("data-contact-no");
        var noOfSeats = button.getAttribute("data-no-of-seats");
        var status = button.getAttribute("data-status");

        // Show the modal
        var modal = document.getElementById("retrieveWaitListModal");
        modal.classList.remove("hidden");

        // Populate the input fields in the modal with the retrieved data
        document.getElementById("retName").value = name;
        document.getElementById("retcontactNumber").value = contactNo;
        document.getElementById("retnoOfSeats").value = noOfSeats;

        // Additional actions if needed
        // ...

        // You can customize this part based on your modal implementation
    }
</script>