
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="../../dist/output.css" rel="stylesheet">
    <title>Create Order | Scan N Savor</title>
</head>

<body>

    <?php
    include '../viewCustomer/viewMenu.php';
    include '../viewCustomer/takeoutcart.php';
    ?>
    </body>

    </html>



</body>

</html>