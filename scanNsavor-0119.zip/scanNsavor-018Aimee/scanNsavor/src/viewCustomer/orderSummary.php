<?php
// Include your database connection code here if not already included
include('../connection/config.php');
include('../forms/splitBillModal.php');

global $conn;

$tableNo = '';
$orderID = '';
$totalAmount = '';
$result = '';
$isDineIn = '';

if (isset($_GET['orderID'])) {
    $currentOrderID = $_GET['orderID'];

    // Your SQL query
    $sql = "SELECT * FROM tblorderdetails 
    INNER JOIN tblorders ON tblorders.orderID = tblorderdetails.orderID 
    LEFT JOIN tblfooditems ON tblfooditems.itemID = tblorderdetails.itemID 
    LEFT JOIN tblmenupackage ON tblmenupackage.packageID = tblorderdetails.packageID
    WHERE tblorderdetails.orderID = $currentOrderID";


    // Prepare and execute the query
    $result = $conn->query($sql);

    // Check if there are any results
    if ($result && $result->num_rows > 0) {
        foreach ($result as $data) {
            $tableNo = $data['tableNo'];
            $orderID = $data['orderID'];
            $totalAmount = $data['totalAmount'];
            $orderStatus = $data['orderStatus'];
            $isDineIn = $data['isDineIn'];
            // Process data as needed
        }
    } else {
    }
} else {
    // Handle the case where orderID is not set, e.g., redirect or show an error message.
    echo "OrderID is not set.";
}

// Query to select only the orderStatus column
$sqlstatus = "SELECT orderStatus FROM tblorders WHERE orderID = $currentOrderID";

// Execute the query
$results = $conn->query($sqlstatus);

// Check if the query was successful
if ($results === false) {
    die("Error: " . $conn->error);
}

// Fetch the result
while ($row = $results->fetch_assoc()) {
    // Access the orderStatus column
    $statusoforder = $row['orderStatus'];
}

?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="refresh" content="40">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="../../dist/output.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/flowbite/1.8.1/flowbite.min.css" rel="stylesheet">
    <script src="https://cdn.tailwindcss.com"></script>
    <title>order Summary</title>
</head>

<body>
    <div class="justify-center items-center">
        <!-- Modal body -->
        <section class="h-screen bg-gray-100 px-4 text-gray-600 antialiased" x-data="app">
            <div class="flex h-full flex-col justify-center">
                <!-- Table -->
                <div class="mx-auto w-full max-w-2xl border px-12 py-8 border-gray-200 bg-white shadow-lg rounded-2xl">
                    <header class=" text-center px-5 py-4">
                        <div class="flex items-center">
                            <div class="grow border-b border-teal-700"></div>
                            <span class="shrink px-1 pb-1 text-teal-700 font-bold text-2xl">Order Summary</span>
                            <div class="grow border-b border-teal-700"></div>
                        </div>
                    </header>
                    <?php if (isset($_GET['orderID'])) : ?>
                        <div class="flex-col justify-between my-5 lg:mx-24">
                            <div class="font-semibold text-gray-800 text-center">Order #: <?php echo $_GET['orderID']; ?></div>
                            <?php if ($isDineIn == 1) : ?>
                                <div class="font-semibold text-gray-800 text-center">Table <?php echo $tableNo; ?></div>
                            <?php endif; ?>
                        </div>
                    <?php else : ?>
                        <div class="font-semibold text-red-500">Order ID not provided</div>
                    <?php endif; ?>

                    <!-- Table for order items -->
                    <div class="overflow-x-auto p-3 pb-10 mx-5" id="orderList" style="display: <?php echo $orderStatus === 'Merged' ? 'none' : 'block'; ?>;">
                        <table class="w-full table-auto">
                            <thead class="bg-gray-50 text-xs font-semibold uppercase text-gray-400">
                                <tr>
                                    <th></th>
                                    <th class="p-2">
                                        <div class="text-left font-semibold">Item Name</div>
                                    </th>
                                    <th class="p-2">
                                        <div class="text-center font-semibold">Quantity</div>
                                    </th>
                                    <th class="p-2">
                                        <div class="text-center font-semibold">Total</div>
                                    </th>
                                    <th class="p-2">
                                        <div class="text-center font-semibold">Status</div>
                                    </th>
                                </tr>
                            </thead>

                            <tbody class="divide-y divide-gray-100 text-sm">
                                <!-- item rows -->
                                <?php foreach ($result as $food) : ?>
                                    <tr>
                                        <td class="p-2"></td>
                                        <td class="p-2">
                                            <div class="font-medium text-gray-800">
                                                <?php
                                                if (!empty($food['packageID'])) {
                                                    echo $food['packageName']; // Display package name if it's a package
                                                } else {
                                                    echo $food['itemName']; // Display item name if it's a regular item
                                                }
                                                ?>
                                            </div>
                                            <div class="hidden font-medium text-gray-800 order-status"><?php echo $food['orderStatus']; ?></div>
                                        </td>
                                        <td class="p-2">
                                            <div class="text-center"><?php echo $food['itemQuantity']; ?></div>
                                        </td>
                                        <td class="p-2">
                                            <div class="text-center font-medium text-teal-800">₱<span><?php echo $food['Amount'] ?></span></div>
                                        </td>
                                        <td class="p-2">
                                            <div class="text-center font-normal text-teal-800"><?php echo $food['status'] ?></div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>

                            </tbody>
                        </table>

                        <div class="flex justify-between pt-7 lg:px-12">
                            <p class="text-gray-800 lg:pl-0 pl-10">TOTAL</p>
                            <div>
                                <?php
                                $formattedTotalAmount = isset($totalAmount) ? number_format(floatval($totalAmount), 2) : '0.00';
                                ?>
                                <p class="font-bold text-end justify-end lg:pl-0 pl-24">₱<?php echo $formattedTotalAmount; ?></p>
                            </div>
                        </div>
                    </div>

                    <!-- add-ons -->

                    <hr class="px-1 pt-3 pb-2 border-1 border-teal-700" />

                    <div class="flex justify-center items-center text-center pt-5" <?php echo $isDineIn == 0 ? 'style="pointer-events: none; opacity: 0.5;"' : ''; ?>>
                        <a href="../viewCustomer/additionalorders.php?orderID=<?php echo $orderID; ?>&tableNo=<?php echo $tableNo; ?>" id="addOnOrder">

                            <script>
                                console.log('<?php echo $statusoforder; ?>');
                            </script>
                            <button class="border border-teal-700 text-teal-700 hover:text-white hover:border-none duration-300 relative group cursor-pointer overflow-hidden h-12 w-60 rounded-3xl p-2 font-extrabold hover:bg-teal-700" id="addonsBtn" onclick="showAddons()" style="display: <?php echo ($isDineIn == 0 || $statusoforder === "Merged") ? 'none' : 'block'; ?>">
                                <div class="absolute group-hover:-top-1 group-hover:-right-2 z-10 w-16 h-16 rounded-full group-hover:scale-150  duration-700 right-12 top-12 bg-teal-500"></div>
                                <div class="absolute group-hover:-top-1 group-hover:-right-2 z-10 w-12 h-12 rounded-full group-hover:scale-150  duration-700 right-20 -top-6 bg-teal-300"></div>
                                <div class="absolute group-hover:-top-1 group-hover:-right-2 z-10 w-8 h-8   rounded-full group-hover:scale-150  duration-700 right-32 top-6 bg-teal-200"></div>
                                <div class="absolute group-hover:-top-1 group-hover:-right-2 z-10 w-4 h-4   rounded-full group-hover:scale-150  duration-700 right-2 top-12 bg-teal-100"></div>
                                <p class="z-10 absolute bottom-3 left-10 pl-4 text-center">BACK TO MENU</p>
                            </button>
                        </a>

                        <p id="orderStatusMessage" class="text-gray-800 text-center pt-3" style="display: <?php echo $statusoforder === 'Merged' ? 'block' : 'none'; ?>;">
                            Your order was merged. <br> Thank you!
                        </p>
                    </div>
                    <?php if ($isDineIn == 1) : ?>
                        <span style="display: <?php echo $orderStatus === 'Completed' ? 'block' : 'none'; ?>;">
                            <div class="w-full pb flex justify-center items-center">
                                <div class="pb-5 flex justify-center items-center text-center pt-5">
                                    <button class="border border-teal-700  text-teal-700 hover:text-white hover:border-none duration-300 relative group cursor-pointer overflow-hidden h-12 w-60 rounded-3xl p-2 font-extrabold hover:bg-teal-700" data-modal-toggle="splitBillModal">
                                        <div class="absolute group-hover:-top-1 group-hover:-right-2 z-10 w-16 h-16 rounded-full group-hover:scale-150  duration-700 right-12 top-12 bg-teal-500"></div>
                                        <div class="absolute group-hover:-top-1 group-hover:-right-2 z-10 w-12 h-12 rounded-full group-hover:scale-150  duration-700 right-20 -top-6 bg-teal-300"></div>
                                        <div class="absolute group-hover:-top-1 group-hover:-right-2 z-10 w-8 h-8   rounded-full group-hover:scale-150  duration-700 right-32 top-6 bg-teal-200"></div>
                                        <div class="absolute group-hover:-top-1 group-hover:-right-2 z-10 w-4 h-4   rounded-full group-hover:scale-150  duration-700 right-2 top-12 bg-teal-100"></div>
                                        <p class="z-10 absolute bottom-3 left-20 text-center">BILL OUT</p>
                                    </button>
                                </div>
                            </div>
                        </span>
                        <p id="orderStatusMessage" class="text-gray-800 text-center pt-3" style="display: <?php echo $orderStatus !== 'Completed' ? 'block' : 'none'; ?>;">
                            Your order is still in progress and not all items are ready. Cannot bill out yet.
                        </p>
                        <?php
                        include('../forms/selectTableForMerge.php');
                        ?>
                        <div class="w-full pt-7 flex justify-center items-center">
                            <button type="button" onclick="prepareMergeOrderData()" data-modal-toggle="tableForMergeModal" class="text-gray-500 background-transparent text-sm outline-none focus:outline-none mr-1 mb-1 ease-linear transition-all duration-150 text-center underline hover:text-teal-600 justify-center" style="display: <?php echo $orderStatus === 'Completed' ? 'block' : 'none'; ?>;">Request for Merge Order</button>
                        </div>

                    <?php elseif ($isDineIn == 0) : ?>
                        <div class="w-full pb flex justify-center items-center">
                            <div class="pb-5 flex justify-center items-center text-center pt-5">
                                <a href="../viewCustomer/nameForPaymentTakeout.php?orderID=<?php echo $orderID; ?>" id="billOutButton">
                                    <button class="border border-teal-700  text-teal-700 hover:text-white hover:border-none duration-300 relative group cursor-pointer overflow-hidden h-12 w-60 rounded-3xl p-2 font-extrabold hover:bg-teal-700">
                                        <div class="absolute group-hover:-top-1 group-hover:-right-2 z-10 w-16 h-16 rounded-full group-hover:scale-150  duration-700 right-12 top-12 bg-teal-500"></div>
                                        <div class="absolute group-hover:-top-1 group-hover:-right-2 z-10 w-12 h-12 rounded-full group-hover:scale-150  duration-700 right-20 -top-6 bg-teal-300"></div>
                                        <div class="absolute group-hover:-top-1 group-hover:-right-2 z-10 w-8 h-8   rounded-full group-hover:scale-150  duration-700 right-32 top-6 bg-teal-200"></div>
                                        <div class="absolute group-hover:-top-1 group-hover:-right-2 z-10 w-4 h-4   rounded-full group-hover:scale-150  duration-700 right-2 top-12 bg-teal-100"></div>
                                        <p class="z-10 absolute bottom-3 left-20 text-center">BILL OUT</p>
                                    </button>
                                </a>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </section>

    </div>


</body>

<script>
    function isDineInEnabled() {
        return <?php echo $isDineIn == 1 ? 'true' : 'false'; ?>;
    }
</script>

<script>
    document.addEventListener("DOMContentLoaded", function() {
        var orderStatus = "<?php echo $firstRow['orderStatus']; ?>";
        var billOutButton = document.getElementById("billOutButton");
        var orderStatusMessage = document.getElementById("orderStatusMessage");

        var orderList = document.getElementById("orderList");

        if (billOutButton) {
            if (orderStatus === "Completed") {
                billOutButton.style.display = "block";
            } else {
                orderStatusMessage.innerText = "Order status is not completed. Cannot bill out yet.";
            }
        }

        if (orderStatus === "Merged") {
            orderList.style.display = "none";
            orderStatusMessage.innerText = "Your order has been merged.";
        }
    });
</script>

<script>
    function prepareMergeOrderData() {
        var orderID = <?php echo json_encode($orderID); ?>;
        var tableNo = <?php echo json_encode($tableNo); ?>;

        // Pass the orderID and tableNo to the modal
        openMergeOrderModal(orderID, tableNo);
    }

    function openMergeOrderModal(orderID, tableNo) {
        // Update the modal content or perform any actions you need
        // For example, you can set the values of hidden inputs in the modal form
        document.getElementById('modalOrderID').value = orderID;
        document.getElementById('modalTableNo').value = tableNo;

        // Set the tableNo directly in your modal script
        document.getElementById('modalTableNoDisplay').textContent = "Table No: " + tableNo;

        // Toggle the modal visibility
        toggleModal('tableForMergeModal');
    }

    function toggleModal(modalId) {
        var modal = document.getElementById(modalId);
        modal.classList.toggle('hidden');
    }
</script>

<script>
    // Function to reload the page after 10 seconds
    function reloadPage() {
        location.reload();
    }

    // Set the timeout for the first reload
    setTimeout(reloadPage, 40000);
</script>

</html>


<script src="https://cdnjs.cloudflare.com/ajax/libs/flowbite/1.8.0/flowbite.min.js"></script>