<?php
session_start();

include '../connection/config.php';

// Check if the session variable exists
if (isset($_SESSION['orderID'])) {
    // Retrieve the session variable
    $orderID = $_SESSION['orderID'];

    //print_r($orderID);
} else {
    echo "Session variable 'orderID' is not set.";
    exit;  // Exit the script if 'orderID' is not set
}

// Fetch data for a specific paymentID
$orderQuery = "SELECT
    o.isDineIn AS type,
    o.orderID AS order_number,
    o.orderDateTime AS order_date,
    p.customerName AS customer,
    p.paymentMethod AS payment,
    p.status AS payment_status,
    p.amount AS payment_amount,
    p.amountPaid AS amount_Paid,
    fi.itemName AS item_name,
    fi.price AS item_price,
    pt.packageName AS package_name,
    od.itemID as item_id,
    od.itemQuantity AS quantity,
    od.Amount AS amount,
    o.totalAmount AS total_payment,
    mp.packagePrice AS package_price,
    pd.paymentID  -- Include paymentID for grouping
FROM
    tblorders o
    JOIN tblpaymentdetails pd ON o.orderID = pd.orderID
    JOIN tblpayment p ON pd.paymentID = p.paymentID
    JOIN tblorderdetails od ON o.orderID = od.orderID
    LEFT JOIN tblfooditems fi ON od.itemID = fi.itemID
    LEFT JOIN tblmenupackage pt ON od.packageID = pt.packageID
    LEFT JOIN tblmenupackage mp ON od.packageID = mp.packageID
WHERE pd.paymentID IS NOT NULL AND o.orderID = $orderID 
ORDER BY pd.paymentID, od.itemID DESC ";

$stmt = $conn->prepare($orderQuery);
$stmt->execute();

$result = $stmt->get_result();

// Fetch the data
$dataArray = [];
$paymentID = null;
$paymentData = [];

while ($row = $result->fetch_assoc()) {
    if ($paymentID !== $row['paymentID']) {
        // If a new paymentID is encountered, process the previous payment data
        if (!empty($paymentData)) {
            $dataArray[] = $paymentData;
        }
        $paymentStatus = $row['payment_status'];
        // Initialize data for the new paymentID
        $paymentID = $row['paymentID'];
        $paymentData = [
            'type' => $row['type'],
            'order_number' => $row['order_number'],
            'order_date' => $row['order_date'],
            'customer' => $row['customer'],
            'payment_amount' => $row['payment_amount'],
            'payment' => $row['payment'],
            'amount_Paid' => $row['amount_Paid'],
            'total_payment' => $row['total_payment'],
            'items' => [],
        ];
    }

    // Add food item details to the current payment data
    $paymentData['items'][] = [
        'item_name' => $row['item_name'],
        'item_price' => $row['item_price'],
        'package_name' => $row['package_name'],
        'quantity' => $row['quantity'],
        'amount' => $row['amount'],
        'package_price' => $row['package_price'],
    ];
}

// Process the last payment data
if (!empty($paymentData)) {
    $dataArray[] = $paymentData;
}

$stmt->close();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="refresh" content="60">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="../../dist/output.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/flowbite/1.8.1/flowbite.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/daisyui@4.4.24/dist/full.min.css" rel="stylesheet" type="text/css" />
    <script src="https://cdn.jsdelivr.net/npm/alpinejs@2.8.2/dist/alpine.min.js" defer></script>
    <script src="https://cdn.tailwindcss.com"></script>
    <title>E-Receipt</title>
</head>

<body>
    <!-- component -->
    <div class="w-full flex flex-col items-center justify-center">
        <div class="h-screen w-full absolute flex items-center justify-center bg-modal -top-0.5">
            <div class=" rounded-lg shadow-lg shadow-gray-300 p-8 m-5 max-w-md max-h-full text-center" id="messageContainer">
                <div class="m-8">
                    <p id="paymentStatusMessage" class="text-gray-800 text-xl text-center font-semibold">Please wait for the payment confirmation and your e-receipt.</p>
                </div>
                <div class="flex justify-center items-center text-center pt-5 pb-8">
                    <button class="border border-teal-700  text-teal-700 hover:text-white hover:border-none duration-300 relative group cursor-pointer overflow-hidden h-12 w-60 rounded-3xl p-2 font-extrabold hover:bg-teal-700" id="viewReceiptButton" onclick="toggleReceiptView()">
                        <div class="absolute group-hover:-top-1 group-hover:-right-2 z-10 w-16 h-16 rounded-full group-hover:scale-150  duration-700 right-12 top-12 bg-teal-500"></div>
                        <div class="absolute group-hover:-top-1 group-hover:-right-2 z-10 w-12 h-12 rounded-full group-hover:scale-150  duration-700 right-20 -top-6 bg-teal-300"></div>
                        <div class="absolute group-hover:-top-1 group-hover:-right-2 z-10 w-8 h-8   rounded-full group-hover:scale-150  duration-700 right-32 top-6 bg-teal-200"></div>
                        <div class="absolute group-hover:-top-1 group-hover:-right-2 z-10 w-4 h-4   rounded-full group-hover:scale-150  duration-700 right-2 top-12 bg-teal-100"></div>
                        <p class="z-10 absolute bottom-3 left-10 pl-5 text-center">VIEW RECEIPT</p>
                    </button>
                </div>
            </div>
        </div>

        <!-- e-receipt -->
        <div class="hidden my-20" id="ereceiptContainer">
            <!-- Original Receipt -->
            <!-- <div class="w-80 rounded bg-gray-50 px-6 pt-8 shadow-lg border-l-2 border-gray-100">
                <div class="flex flex-col justify-center items-center gap-2">
                    <h4 class="font-semibold text-teal-600 text-xl">Scan N' Savor</h4>
                    <p class="text-xs"></p>
                </div>
                <?php if (!empty($dataArray)) : ?>
                    <div class="flex flex-col gap-3 border-b pt-2 pb-5 text-xs">
                        <div class="flex items-center opacity-80">
                            <div class="grow border-b border-dashed border-gray-800"></div>
                            <span class="shrink px-1 pb-1 text-gray-800 font-semibold uppercase"><?php echo ($recData['type'] == 1 ? 'Dine-in' : 'Take-out'); ?></span>
                            <div class="grow border-b border-dashed border-gray-800"></div>
                        </div>
                        <p class="flex justify-between">
                            <span class="text-gray-400">Order #:</span>
                            <span><?php echo $recData['order_number']; ?></span>
                        </p>
                        <p class="flex justify-between">
                            <span class="text-gray-400">Date/Time:</span>
                            <span><?php echo $recData['order_date']; ?></span>
                        </p>
                        <p class="flex justify-between">
                            <span class="text-gray-400">Customer:</span>
                            <span><?php echo $recData['customer']; ?></span>
                        </p>
                        <p class="flex justify-between">
                            <span class="text-gray-400">Payment:</span>
                            <span><?php echo $recData['payment']; ?></span>
                        </p>
                    </div>
                    <div class="flex flex-col gap-3 py-2 text-xs">
                        <table class="w-full text-left">
                            <thead>
                                <tr>
                                    <th></th>
                                    <th class="py-2">
                                        <div class="text-left font-light">Item Name</div>
                                    </th>
                                    <th class="py-2">
                                        <div class="text-center font-light">Quantity</div>
                                    </th>
                                    <th class="py-2">
                                        <div class="text-center font-light pl-2">Total</div>
                                    </th>
                                </tr>
                            </thead>

                            <tbody>
                                <?php foreach ($recData['items'] as $item) : ?>
                                    <tr>
                                        <td class="py-2"></td>
                                        <td class="py-2">
                                            <div class="font-medium text-gray-800">
                                                <?php echo isset($item['package_name']) ? $item['package_name'] . ' - ₱' . $item['package_price'] : $item['item_name']; ?>
                                            </div>
                                        </td>
                                        <td class="py-2">
                                            <div class="text-center"><?php echo $item['quantity']; ?></div>
                                        </td>
                                        <td class="py-2">
                                            <div class="text-center pl-2 font-medium text-teal-700">₱<span><?php echo $item['amount']; ?></span></div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>

                    <?php
                    $totalPrice = 0;

                    foreach ($recData['items'] as $item) {
                        $totalPrice += $item['amount'];
                    }

                    $vatAmount = $recData['payment_amount'] * 0.12;
                    $totalPayment = $recData['total_payment'];

                    // Calculate the total price minus VAT
                    $totalPriceMinusVAT = $recData['payment_amount'] - $vatAmount;
                    ?>

                    <div class="flex flex-col gap-2 border-b pt-3 pb-6">
                        <div class="border-dashed border"></div>

                        <p class="flex justify-between font-bold text-md pt-3">
                            <span>TOTAL</span>
                            <span class="text-left">₱<?php echo number_format($recData['total_payment'], 2); ?></span>
                        </p>

                        <?php if ($recData['payment_amount'] != $recData['total_payment']) : ?>
                            <p class="flex justify-between font-bold text-md text-teal-600">
                                <span>SPLIT BILL</span>
                                <span class="text-left">₱<?php echo number_format($recData['payment_amount'], 2); ?></span>
                            </p>
                        <?php endif; ?>

                        <?php if ($recData['payment'] == 'Cash') : ?>
                            <p class="flex justify-between text-xs pt-3">
                                <span class="text-gray-400">CASH:</span>
                                <span class="text-center">₱ <?php echo number_format($recData['amount_Paid'], 2); ?></span>
                            </p>

                            <p class="flex justify-between text-xs">
                                <span class="text-gray-400">Change:</span>
                                <span class="text-center">₱ <?php echo number_format($recData['amount_Paid'] - $recData['payment_amount'], 2); ?></span>
                            </p>
                        <?php endif; ?>

                        <p class="flex justify-between text-xs pt-3">
                            <span class="text-gray-400">VATable Sales:</span>
                            <span class="text-center">₱<?php echo number_format($totalPriceMinusVAT, 2) ?></span>
                        </p>
                        <p class="flex justify-between text-xs pb-5">
                            <span class="text-gray-400">VAT (12%):</span>
                            <span class="text-left">₱<?php echo number_format($vatAmount, 2)  ?></span>
                        </p>
                        <div class="border-double border-spacing-2 border-2"></div>
                        <p class="justify-center items-center text-center font-semibold py-3">
                            THANK YOU & HAVE A GOOD DAY!
                        </p>
                    </div>
                <?php endif; ?>
            </div> -->


            <!-- ------ E RECEIPT ----- -->

            <div class="gap-8 justify-center">
                <?php foreach ($dataArray as $recData) : ?>
                    <div class="py-5">
                        <!-- Separate Receipt for Split Bill -->
                        <?php if ($recData['payment_amount'] != $recData['total_payment']) : ?>
                            <div class="w-80 rounded bg-gray-50 px-6 pt-8 shadow-lg border-l-2 border-gray-100">
                                <div class="flex flex-col justify-center items-center gap-2">
                                    <h4 class="font-semibold text-teal-600 text-xl">Scan N' Savor</h4>
                                    <p class="text-xs"></p>
                                </div>

                                <div class="flex items-center opacity-80">
                                    <div class="grow border-b border-dashed border-gray-800"></div>
                                    <span class="shrink px-1 pb-1 text-gray-800 font-semibold uppercase"><?php echo ($recData['type'] == 1 ? 'Dine-in' : 'Take-out'); ?></span>
                                    <div class="grow border-b border-dashed border-gray-800"></div>
                                </div>

                                <div class="flex flex-col gap-3 border-b pt-2 pb-5 text-xs">
                                    <p class="flex justify-between">
                                        <span class="text-gray-400">Order #:</span>
                                        <span><?php echo $recData['order_number'] . ' (Split Bill)'; ?></span>
                                    </p>
                                    <p class="flex justify-between">
                                        <span class="text-gray-400">Date/Time:</span>
                                        <span><?php echo $recData['order_date']; ?></span>
                                    </p>
                                    <p class="flex justify-between">
                                        <span class="text-gray-400">Customer:</span>
                                        <span><?php echo $recData['customer']; ?></span>
                                    </p>
                                    <p class="flex justify-between">
                                        <span class="text-gray-400">Payment:</span>
                                        <span><?php echo $recData['payment']; ?></span>
                                    </p>
                                </div>
                                <div class="flex flex-col gap-3 py-2 text-xs">
                                    <table class="w-full text-left">
                                        <thead>
                                            <tr>
                                                <th class="py-2">
                                                    <div class="text-left font-light">Item Name</div>
                                                </th>
                                                <th class="py-2">
                                                    <div class="text-center font-light">Quantity</div>
                                                </th>
                                                <th class="py-2">
                                                    <div class="text-center font-light pl-2">Total</div>
                                                </th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td class="py-2">
                                                    <div class="font-medium text-gray-800">Meals</div>
                                                </td>
                                                <td class="py-2">
                                                    <div class="text-center">1</div>
                                                </td>
                                                <td class="py-2">
                                                    <div class="text-center pl-2 font-medium text-teal-700">₱<?php echo number_format($recData['payment_amount'], 2); ?></div>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>

                                <?php
                                $totalPrice = 0;

                                foreach ($recData['items'] as $item) {
                                    $totalPrice += $item['amount'];
                                }

                                $vatAmount = $recData['payment_amount'] * 0.12;
                                $totalPayment = $recData['total_payment'];

                                // Calculate the total price minus VAT
                                $totalPriceMinusVAT = $recData['payment_amount'] - $vatAmount;
                                ?>

                                <div class="flex flex-col gap-2 border-b pt-3 pb-6">
                                    <div class="border-dashed border"></div>

                                    <?php if ($recData['payment_amount'] != $recData['total_payment']) : ?>
                                        <p class="flex justify-between font-bold text-md text-teal-600">
                                            <span>BILL</span>
                                            <span class="text-left">₱<?php echo number_format($recData['payment_amount'], 2); ?></span>
                                        </p>
                                    <?php endif; ?>

                                    <?php if ($recData['payment'] == 'Cash') : ?>
                                        <p class="flex justify-between text-xs pt-3">
                                            <span class="text-gray-400">CASH:</span>
                                            <span class="text-center">₱ <?php echo number_format($recData['amount_Paid'], 2); ?></span>
                                        </p>

                                        <p class="flex justify-between text-xs">
                                            <span class="text-gray-400">Change:</span>
                                            <span class="text-center">₱ <?php echo number_format($recData['amount_Paid'] - $recData['payment_amount'], 2); ?></span>
                                        </p>
                                    <?php endif; ?>



                                    <!-- Display total price and VAT -->
                                    <p class="flex justify-between text-xs pt-3">
                                        <span class="text-gray-400">VATable Sales:</span>
                                        <span class="text-center">₱<?php echo number_format($totalPriceMinusVAT, 2) ?></span>
                                    </p>
                                    <p class="flex justify-between text-xs pb-5">
                                        <span class="text-gray-400">VAT (12%):</span>
                                        <span class="text-left">₱<?php echo number_format($vatAmount, 2)  ?></span>
                                    </p>
                                    <div class="border-double border-spacing-2 border-2"></div>
                                    <p class="justify-center items-center text-center font-semibold py-3">
                                        THANK YOU & HAVE A GOOD DAY!
                                    </p>
                                </div>

                            </div>

                        <?php else : ?>
                            <div class="w-80 rounded bg-gray-50 px-6 pt-8 shadow-lg border-l-2 border-gray-100">
                                <!-- Display code for original receipt when the bill is not split -->
                                <div class="flex flex-col justify-center items-center gap-2">
                                    <h4 class="font-semibold text-teal-600 text-xl">Scan N' Savor</h4>
                                    <p class="text-xs"></p>
                                </div>
                                <?php if (!empty($dataArray)) : ?>
                                    <div class="flex flex-col gap-3 border-b pt-2 pb-5 text-xs">
                                        <div class="flex items-center opacity-80">
                                            <div class="grow border-b border-dashed border-gray-800"></div>
                                            <span class="shrink px-1 pb-1 text-gray-800 font-semibold uppercase"><?php echo ($recData['type'] == 1 ? 'Dine-in' : 'Take-out'); ?></span>
                                            <div class="grow border-b border-dashed border-gray-800"></div>
                                        </div>
                                        <p class="flex justify-between">
                                            <span class="text-gray-400">Order #:</span>
                                            <span><?php echo $recData['order_number']; ?></span>
                                        </p>
                                        <p class="flex justify-between">
                                            <span class="text-gray-400">Date/Time:</span>
                                            <span><?php echo $recData['order_date']; ?></span>
                                        </p>
                                        <p class="flex justify-between">
                                            <span class="text-gray-400">Customer:</span>
                                            <span><?php echo $recData['customer']; ?></span>
                                        </p>
                                        <p class="flex justify-between">
                                            <span class="text-gray-400">Payment:</span>
                                            <span><?php echo $recData['payment']; ?></span>
                                        </p>
                                    </div>
                                    <div class="flex flex-col gap-3 py-2 text-xs">
                                        <table class="w-full text-left">
                                            <thead>
                                                <tr>
                                                    <th></th>
                                                    <th class="py-2">
                                                        <div class="text-left font-extralight">Item Name</div>
                                                    </th>
                                                    <th class="py-2">
                                                        <div class="text-left font-extralight pl-4 pr-1">Price</div>
                                                    </th>
                                                    <th class="py-2">
                                                        <div class="text-center font-extralight">Quantity</div>
                                                    </th>
                                                    <th class="py-2">
                                                        <div class="text-center font-extralight pl-2">Total</div>
                                                    </th>
                                                </tr>
                                            </thead>

                                            <!-- . ' - ₱' . $item['package_price'] -->

                                            <tbody>
                                                <?php foreach ($recData['items'] as $item) : ?>
                                                    <tr>
                                                        <td class="py-2"></td>
                                                        <td class="py-2">
                                                            <div class="font-normal text-gray-800 pr-1">
                                                                <?php echo isset($item['package_name']) ? $item['package_name'] : $item['item_name']; ?>
                                                            </div>
                                                        </td>
                                                        <td class="py-2">
                                                            <div class="font-light text-gray-800 text-center px-1">
                                                                <?php echo isset($item['package_name']) ?  ' ₱ ' . $item['package_price'] : ' ₱ ' . $item['item_price']; ?>
                                                            </div>
                                                        </td>
                                                        <td class="py-2">
                                                            <div class="text-center pl-2 font-normal"><?php echo $item['quantity']; ?></div>
                                                        </td>
                                                        <td class="py-2">
                                                            <div class="text-center pl-2 font-semibold text-teal-700">₱ <span><?php echo $item['amount']; ?></span></div>
                                                        </td>
                                                    </tr>
                                                <?php endforeach; ?>
                                            </tbody>
                                        </table>
                                    </div>

                                    <!-- Additional information for the original receipt -->
                                    <?php
                                    $totalPrice = 0;

                                    foreach ($recData['items'] as $item) {
                                        $totalPrice += $item['amount'];
                                    }

                                    $vatAmount = $recData['payment_amount'] * 0.12;
                                    $totalPayment = $recData['total_payment'];

                                    // Calculate the total price minus VAT
                                    $totalPriceMinusVAT = $recData['payment_amount'] - $vatAmount;
                                    ?>

                                    <div class="flex flex-col gap-2 border-b pt-3 pb-6">
                                        <div class="border-dashed border"></div>

                                        <p class="flex justify-between font-bold text-md pt-3">
                                            <span>TOTAL</span>
                                            <span class="text-left">₱<?php echo number_format($recData['total_payment'], 2); ?></span>
                                        </p>

                                        <?php if ($recData['payment_amount'] != $recData['total_payment']) : ?>
                                            <p class="flex justify-between font-bold text-md text-teal-600">
                                                <span>SPLIT BILL</span>
                                                <span class="text-left">₱<?php echo number_format($recData['payment_amount'], 2); ?></span>
                                            </p>
                                        <?php endif; ?>

                                        <?php if ($recData['payment'] == 'Cash') : ?>
                                            <p class="flex justify-between text-xs pt-3">
                                                <span class="text-gray-400">CASH:</span>
                                                <span class="text-center">₱ <?php echo number_format($recData['amount_Paid'], 2); ?></span>
                                            </p>

                                            <p class="flex justify-between text-xs">
                                                <span class="text-gray-400">Change:</span>
                                                <span class="text-center">₱ <?php echo number_format($recData['amount_Paid'] - $recData['payment_amount'], 2); ?></span>
                                            </p>
                                        <?php endif; ?>

                                        <p class="flex justify-between text-xs pt-3">
                                            <span class="text-gray-400">VATable Sales:</span>
                                            <span class="text-center">₱<?php echo number_format($totalPriceMinusVAT, 2) ?></span>
                                        </p>
                                        <p class="flex justify-between text-xs pb-5">
                                            <span class="text-gray-400">VAT (12%):</span>
                                            <span class="text-left">₱<?php echo number_format($vatAmount, 2)  ?></span>
                                        </p>
                                        <div class="border-double border-spacing-2 border-2"></div>
                                        <p class="justify-center items-center text-center font-semibold py-3">
                                            THANK YOU & HAVE A GOOD DAY!
                                        </p>
                                    </div>
                                <?php endif; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>

                <a href="../view/ratings.php">
                    <div class=" flex lg:justify-start justify-center lg:pl-10 items-center text-center pt-5">
                        <button class="border border-teal-700  text-teal-700 hover:text-white hover:border-none duration-300 relative group cursor-pointer overflow-hidden h-12 w-60 rounded-3xl p-2 font-extrabold hover:bg-teal-700" id="addonsBtn" onclick="showAddons()">
                            <div class="absolute group-hover:-top-1 group-hover:-right-2 z-10 w-16 h-16 rounded-full group-hover:scale-150  duration-700 right-12 top-12 bg-teal-500"></div>
                            <div class="absolute group-hover:-top-1 group-hover:-right-2 z-10 w-12 h-12 rounded-full group-hover:scale-150  duration-700 right-20 -top-6 bg-teal-300"></div>
                            <div class="absolute group-hover:-top-1 group-hover:-right-2 z-10 w-8 h-8   rounded-full group-hover:scale-150  duration-700 right-32 top-6 bg-teal-200"></div>
                            <div class="absolute group-hover:-top-1 group-hover:-right-2 z-10 w-4 h-4   rounded-full group-hover:scale-150  duration-700 right-2 top-12 bg-teal-100"></div>
                            <p class="z-10 absolute bottom-3 text-center">We'd like to hear from you!</p>
                        </button>
                        <!-- <button class="rounded-xl bg-teal-800 hover:bg-teal-600 focus:outline-none focus:ring-2 focus:ring-offset-2  py-5 md:w-full w-2 text-base font-medium text-white" id="addonsBtn" onclick="showAddons()">Add-ons</button> -->
                    </div>
                </a>

                <a href="./landingpage.php">
                    <div class=" flex lg:justify-start justify-center lg:pl-10 items-center text-center pt-5">
                        <button class="border border-teal-700  text-teal-700 hover:text-white hover:border-none duration-300 relative group cursor-pointer overflow-hidden h-12 w-60 rounded-3xl p-2 font-extrabold hover:bg-teal-700" id="addonsBtn" onclick="showAddons()">
                            <div class="absolute group-hover:-top-1 group-hover:-right-2 z-10 w-16 h-16 rounded-full group-hover:scale-150  duration-700 right-12 top-12 bg-teal-500"></div>
                            <div class="absolute group-hover:-top-1 group-hover:-right-2 z-10 w-12 h-12 rounded-full group-hover:scale-150  duration-700 right-20 -top-6 bg-teal-300"></div>
                            <div class="absolute group-hover:-top-1 group-hover:-right-2 z-10 w-8 h-8   rounded-full group-hover:scale-150  duration-700 right-32 top-6 bg-teal-200"></div>
                            <div class="absolute group-hover:-top-1 group-hover:-right-2 z-10 w-4 h-4   rounded-full group-hover:scale-150  duration-700 right-2 top-12 bg-teal-100"></div>
                            <p class="z-10 absolute bottom-3 left-10 pl-4 text-center">BACK TO HOME</p>
                        </button>
                        <!-- <button class="rounded-xl bg-teal-800 hover:bg-teal-600 focus:outline-none focus:ring-2 focus:ring-offset-2  py-5 md:w-full w-2 text-base font-medium text-white" id="addonsBtn" onclick="showAddons()">Add-ons</button> -->
                    </div>
                </a>
            </div>
        </div>
    </div>


    <script>
        function toggleReceiptView() {
            var messageContainer = document.getElementById('messageContainer');
            var viewReceiptButton = document.getElementById('viewReceiptButton');
            var ereceiptContainer = document.getElementById('ereceiptContainer');

            // Toggle visibility of payment status message and view receipt button
            messageContainer.style.display = messageContainer.style.display === 'none' ? 'block' : 'none';
            viewReceiptButton.style.display = viewReceiptButton.style.display === 'none' ? 'block' : 'none';

            // Toggle visibility of e-receipt container
            ereceiptContainer.classList.toggle('hidden');
        }
    </script>

    <script>
        document.addEventListener("DOMContentLoaded", function() {
            var viewReceiptButton = document.getElementById("viewReceiptButton");
            var paymentStatusMessage = document.getElementById("paymentStatusMessage");

            // Check if payment status is confirmed
            if ("<?php echo $paymentStatus; ?>" === "confirmed") {
                viewReceiptButton.style.display = "block";
            } else {
                viewReceiptButton.style.display = "none";
            }
        });
    </script>

    <script>
        function reloadPage() {
            location.reload();
        }

        // Set the timeout for the first reload
        setTimeout(reloadPage, 60000);
    </script>


</body>

</html>