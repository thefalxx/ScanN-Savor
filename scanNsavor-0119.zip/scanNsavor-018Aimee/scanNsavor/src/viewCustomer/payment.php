<?php
include '../connection/config.php';

session_start();
global $conn;

// $totalAmount = $_SESSION["totalAmount"];
$orderID = $_SESSION["orderID"];
$orderStatus = '';  // Initialize $orderStatus


if (isset($_SESSION["orderID"])) {
    $orderID = $_SESSION["orderID"];
    // Prepare your SQL query

    $orderQuery = " SELECT  * FROM  tblorders WHERE  orderID = ? AND orderStatus = 'Completed'";

    // Prepare the statement
    if ($stmt = $conn->prepare($orderQuery)) {
        // Bind the parameters
        $stmt->bind_param("i", $orderID);
        // Execute the statement
        $stmt->execute();
        // Get the result
        $result = $stmt->get_result();

        // Check if any rows were returned
        if ($result->num_rows > 0) {
            // Fetch the data
            while ($data = $result->fetch_assoc()) {

                $orderID = $data['orderID'];
                $orderStatus = $data['orderStatus'];
                $totalAmount = $data['totalAmount'];
                $processedBy = $data['processedBy'];


                if ($orderStatus == 'Completed') {

                    $_SESSION['orderID'] = $orderID;
                }
            }
        } else {
            // No rows were returned, set default values
            $orderID = '';
            $orderStatus = '';
            $totalAmount = '';
            $processedBy = '';
        }
    } else {
        // Prepare failed, handle the error
        echo "Error: " . $conn->error;
    }
}



if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $custName = $_POST['custName'];
    $modeOfPayment = $_POST['modeOfPayment'];
    $totalAmount = $_POST['totalAmount'];
    $employeeID = $_SESSION['userid'];

    // Check if the variables are not empty
    if (!empty($custName) && !empty($modeOfPayment) && !empty($totalAmount) && !empty($employeeID)) {
        $sql = "INSERT INTO tblpayment (customerName, paymentMethod, totalAmount, status, processedBy) VALUES (?, ?, ?, 'pending', ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssdi", $custName, $modeOfPayment, $totalAmount, $employeeID);

        if ($stmt->execute()) {
            echo "New record created successfully";
            $paymentID = $conn->insert_id;

            $_SESSION['paymentID'] = $paymentID;
            $sqlDetails = "INSERT INTO tblpaymentdetails (paymentID, orderID, amount) VALUES (?, ?, ?)";
            $stmtDetails = $conn->prepare($sqlDetails);
            $stmtDetails->bind_param("iid", $paymentID, $orderID, $totalAmount);

            if ($stmtDetails->execute()) {
                echo "New record created successfully in tblpaymentdetails";
            } else {
                echo "Error: " . $sqlDetails . "<br>" . $conn->error;
            }
            $stmtDetails->close();
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
        $stmt->close();
    } else {
        echo "Please fill in all fields.";
    }
}

?>



<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="../../dist/output.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/flowbite/1.8.1/flowbite.min.css" rel="stylesheet">
    <title>ScanNSavor | Payment</title>
</head>

<body>
    <form action="" method="post">
        <!-- Modal body -->
        <div class="w-1/2 h-screen bg-grey-lighter">
            <form class="container flex flex-col lg:flex-row justify-center lg:justify-between font-sans mx-auto py-8">
                <div class="w-full lg:w-1/3 px-2 mb-6 lg:mb-0">
                    <div class="bg-white shadow rounded-lg">
                        <div class="text-center border-b border-grey-lighter p-4">
                            <h3 class="font-semibold text-lg text-gray-800">
                                Payment
                            </h3>
                            <h3 class="font-semibold text-gray-800">
                                Order # : <?php echo $orderID; ?>
                            </h3>
                        </div>
                        <div class="p-4">
                            <div class="mb-4">
                                <label for="custName" class="uppercase text-sm tracking-wide font-semibold text-grey-darker px-2">
                                    customer Name
                                </label>
                                <input type="text" id="custName" name="custName" class="no-appearance bg-grey-lighter w-full leading-normal py-2 px-3 rounded border-b border-red-light mt-2 focus:outline-none">
                            </div>

                            <div class="mb-4">
                                <div class="flex justify-between items-center px-2">
                                    <label for="modeOfPayment" class="uppercase text-sm tracking-wide font-semibold text-grey-darker">
                                        Payment Method
                                    </label>
                                </div>
                                <div class="relative mt-2">
                                    <select class="block appearance-none w-full bg-grey-lighter border-b border-grey-light text-grey-darker py-3 px-4 pr-8 rounded leading-tight focus:outline-none" id="modeOfPayment" name="modeOfPayment">
                                    <option selected="" disabled><span class="text-sm">Choose a Payment Method</span></option>
                                        <option value="Cash">Cash</option>
                                        <option value="Card">Card</option>
                                        <option value="E-Wallet">E-Wallet</option>
                                    </select>

                                </div>
                            </div>

                            <!-- input field for cash -->
                            <div class="mb-4" id="cashAmountField" style="display: none;">
                                <label for="cashAmount" class="uppercase text-sm tracking-wide font-semibold text-grey-darker px-2">
                                    Cash Amount
                                </label>
                                <input type="text" id="cashAmount" name="cashAmount" class="no-appearance bg-grey-lighter w-full leading-normal py-2 px-3 rounded border-b border-red-light mt-2 focus:outline-none" value="">
                            </div>
                            
                            <div class="mb-4">
                                <label for="totalAmount" class="uppercase text-sm tracking-wide font-semibold text-grey-darker px-2">
                                    total Amount
                                </label>
                                <input type="text" id="totalAmount" name="totalAmount" class="no-appearance bg-grey-lighter w-full leading-normal py-2 px-3 rounded border-b border-red-light mt-2 focus:outline-none" value="<?php echo $totalAmount; ?>" readonly>
                            </div>
                            <!-- <div class="mb-4">
                                <label for="ProcessedBy" class="uppercase text-sm tracking-wide font-semibold text-grey-darker px-2">
                                    Processed By
                                </label>
                                <input type="text" id="ProcessedBy" class="no-appearance bg-grey-lighter w-full leading-normal py-2 px-3 rounded border-b border-red-light mt-2 focus:outline-none" value="<?php echo $processedBy; ?>" readonly>
                            </div> -->

                            <div class="mb-4" hidden>
                                <label for="orderStatus" class="uppercase text-sm tracking-wide font-semibold text-grey-darker px-2">
                                    Status
                                </label>
                                <input type="text" id="orderStatus" class="no-appearance bg-grey-lighter w-full leading-normal py-2 px-3 rounded border-b border-red-light mt-2 focus:outline-none" value="<?php echo $orderStatus; ?>" readonly>
                            </div>

                        </div>
                        <div class="w-full pb flex justify-center items-center">
                            <button type="submit" class=" bg-teal-800 hover:bg-teal-600 hover:text-white focus:outline-none focus:ring-2 focus:ring-offset-2  py-5 w-96 md:w-full  text-base font-medium leading-10 text-teal-600">Payment</button>
                        </div>
                        <a href="../viewCustomer/eReceipt.php">
                            <div class="w-full pb flex justify-center items-center">
                                <button type="button" class="bg-teal-800  hover:bg-teal-600 hover:text-white focus:outline-none focus:ring-2 focus:ring-offset-2  py-5 w-96 md:w-full  text-base font-medium leading-10 text-teal-600" id="viewReceiptButton">View Receipt</button>
                            </div>
                        </a>
                        
                        <p id="paymentStatusMessage" class="text-gray-800 text-center" style="display: <?php echo $paymentStatus !== 'confirmed' ? 'block' : 'none'; ?>;">
                        Please wait for the payment confirmation.
                    </p>
                    </div>
                </div>
        </div>
    </form>
</body>
<script>
    document.getElementById('modeOfPayment').addEventListener('change', function() {
        var cashAmountField = document.getElementById('cashAmountField');
        if (this.value === 'Cash') {
            cashAmountField.style.display = 'block';
        } else {
            cashAmountField.style.display = 'none';
        }
    });
</script>

<?php
// Fetch the payment status from the database
$paymentStatusQuery = "SELECT status FROM tblpayment WHERE paymentID = ?";
$paymentStatusStmt = $conn->prepare($paymentStatusQuery);
$paymentStatusStmt->bind_param("i", $_SESSION['paymentID']);
$paymentStatusStmt->execute();
$paymentStatusResult = $paymentStatusStmt->get_result();
$paymentStatusRow = $paymentStatusResult->fetch_assoc();
$paymentStatus = $paymentStatusRow['status'];
$paymentStatusStmt->close();
?>

<script>
    document.addEventListener("DOMContentLoaded", function() {
        var viewReceiptButton = document.getElementById("viewReceiptButton");
        var paymentStatusMessage = document.getElementById("paymentStatusMessage");

        // Check if payment status is confirmed
        if ("<?php echo $paymentStatus; ?>" === "confirmed") {
            viewReceiptButton.style.display = "block";
            paymentStatusMessage.style.display = "none";
        } else {
            paymentStatusMessage.innerText = "Please wait for the payment confirmation.";
            viewReceiptButton.style.display = "none";
        }
    });
</script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/flowbite/1.8.0/flowbite.min.js"></script>