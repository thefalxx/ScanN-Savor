<?php

require '../class/Menu.php';
//include '../forms/itemAdded.php';

$menu = new Menu();
$message = $menu->addCategories();
$fooditems = $menu->getAllItemsDetails();
$catMappings = $menu->fetchCategoryMappings();
$category = $menu->getCategories();
$packageMenu = $menu->getmenuPackageDetails();
// $packageMenu = $menu->getPackages();

global $conn;

session_start();

if (!isset($_SESSION['cartID'])) {
    $tableNo = '1';  // Example value, replace it with your logic to get the table number
    $diningChoice = $_SESSION['diningChoice'];

    // Use prepared statement to prevent SQL injection
    $sql = "INSERT INTO tblcart (orderType) VALUES (?)";
    $stmt = $conn->prepare($sql);

    if ($stmt) {
        $stmt->bind_param("s", $diningChoice);
        $stmt->execute();

        // Check if the insertion was successful
        if ($stmt->affected_rows > 0) {
            $_SESSION['cartID'] = $conn->insert_id;
            // echo "Data inserted successfully!";
        } else {
            echo "Error: " . $stmt->error;
        }

        $stmt->close();
    } else {
        echo "Error in prepared statement: " . $conn->error;
    }
}

$message = '';
//$diningChoice = $_SESSION['diningChoice'];

if (isset($_POST['addToCart'])) {
    $cartID = $_SESSION['cartID'];
    $itemID = $_POST['itemID'];
    $orderQuantity = $_POST['orderQuantity'];

    // Check if it's an item or a menu package
    if (isset($_POST['isMenuPackage']) && $_POST['isMenuPackage'] == 1) {
        // It's a menu package
        $getPackageInfoQuery = "SELECT mi.packageID, mi.packageName, mi.packagePrice, fi.itemName 
                                FROM tblmenupackage mi
                                INNER JOIN tblfooditems fi ON mi.packageID = fi.itemID
                                WHERE mi.packageID = ?";
        $getPackageInfoStmt = $conn->prepare($getPackageInfoQuery);
        $getPackageInfoStmt->bind_param("i", $itemID);
        $getPackageInfoStmt->execute();
        $getPackageInfoResult = $getPackageInfoStmt->get_result();

        if ($getPackageInfoResult->num_rows === 1) {
            $packageData = $getPackageInfoResult->fetch_assoc();
            $packagePrice = $packageData['packagePrice'];
        } else {
            // Handle error if the package is not found
            echo "Error: Package not found.";
            exit();
        }

        $getPackageInfoStmt->close();

        $insertQuery = "INSERT INTO tblcartdetails (cartID, packageID, orderQuantity, price) 
                        VALUES (?, ?, ?, ?)";
        $insertStmt = $conn->prepare($insertQuery);
        $insertStmt->bind_param("iiid", $cartID, $packageData['packageID'], $orderQuantity, $packagePrice);

        // Deduct servings for each item inside the package
        $deductPackageServingsQuery = "UPDATE tblfooditems SET serving = serving - ? WHERE itemID IN 
                                        (SELECT itemID FROM tblmenupackageitems WHERE packageID = ?)";
        $deductPackageServingsStmt = $conn->prepare($deductPackageServingsQuery);
        $deductPackageServingsStmt->bind_param("ii", $orderQuantity, $packageData['packageID']);

        if ($deductPackageServingsStmt->execute()) {
            // Update availability for each item inside the package
            $updatePackageAvailabilityQuery = "UPDATE tblfooditems SET availability = 
                                                CASE WHEN serving <= 0 THEN 'Unavailable' ELSE availability END,
                                                dishStatus = CASE WHEN serving <= 0 THEN 'Out of Stock' ELSE dishStatus END
                                                WHERE itemID IN (SELECT itemID FROM tblmenupackageitems WHERE packageID = ?)";
            $updatePackageAvailabilityStmt = $conn->prepare($updatePackageAvailabilityQuery);
            $updatePackageAvailabilityStmt->bind_param("i", $packageData['packageID']);
            $updatePackageAvailabilityStmt->execute();
        }

        $deductPackageServingsStmt->close();
        $updatePackageAvailabilityStmt->close();
    } else {
        // It's a regular item
        $checkAvailabilityQuery = "SELECT serving FROM tblfooditems WHERE itemID = ?";
        $checkAvailabilityStmt = $conn->prepare($checkAvailabilityQuery);
        $checkAvailabilityStmt->bind_param("i", $itemID);
        $checkAvailabilityStmt->execute();
        $checkAvailabilityResult = $checkAvailabilityStmt->get_result();

        if ($checkAvailabilityResult->num_rows === 1) {
            $availabilityData = $checkAvailabilityResult->fetch_assoc();
            $remainingServings = $availabilityData['serving'];

            if ($remainingServings - $orderQuantity <= 0) {
                // Update availability and dishStatus if serving is zero or less
                $updateAvailabilityQuery = "UPDATE tblfooditems SET availability = 'Unavailable', dishStatus = 'Out of Stock' WHERE itemID = ?";
                $updateAvailabilityStmt = $conn->prepare($updateAvailabilityQuery);
                $updateAvailabilityStmt->bind_param("i", $itemID);
                $updateAvailabilityStmt->execute();

                // Check if the item is part of any menu package
                $checkMenuPackageItemQuery = "SELECT packageID FROM tblmenupackageitems WHERE itemID = ?";
                $checkMenuPackageItemStmt = $conn->prepare($checkMenuPackageItemQuery);
                $checkMenuPackageItemStmt->bind_param("i", $itemID);
                $checkMenuPackageItemStmt->execute();
                $checkMenuPackageItemResult = $checkMenuPackageItemStmt->get_result();

                if ($checkMenuPackageItemResult->num_rows > 0) {
                    // If the item is part of any menu package, update availability in tblmenupackage
                    while ($row = $checkMenuPackageItemResult->fetch_assoc()) {
                        $updateMenuPackageAvailabilityQuery = "UPDATE tblmenupackage SET availability = 'Unavailable' WHERE packageID = ?";
                        $updateMenuPackageAvailabilityStmt = $conn->prepare($updateMenuPackageAvailabilityQuery);
                        $updateMenuPackageAvailabilityStmt->bind_param("i", $row['packageID']);
                        $updateMenuPackageAvailabilityStmt->execute();
                        $updateMenuPackageAvailabilityStmt->close();
                    }
                }

                $checkMenuPackageItemStmt->close();

                // Handle a message or action if needed
            }
        }

        $checkAvailabilityStmt->close();

        $insertQuery = "INSERT INTO tblcartdetails (cartID, itemID, packageID, orderQuantity, price) 
                        SELECT ?, ?, '', ?, price FROM tblfooditems WHERE itemID = ?";
        $insertStmt = $conn->prepare($insertQuery);
        $insertStmt->bind_param("iiii", $cartID, $itemID, $orderQuantity, $itemID);

        // Deduct servings for the item
        $deductServingsQuery = "UPDATE tblfooditems SET serving = serving - ? WHERE itemID = ?";
        $deductServingsStmt = $conn->prepare($deductServingsQuery);
        $deductServingsStmt->bind_param("ii", $orderQuantity, $itemID);
        $deductServingsStmt->execute();
        $deductServingsStmt->close();
    }

    if ($insertStmt->execute()) {
        // Item added to cart successfully
        $message = "Item added to cart.";
    } else {
        // Error occurred while adding to cart
        $message = "Error adding item to cart: " . $insertStmt->error;
    }

    $insertStmt->close();
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="../../dist/output.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/flowbite/1.8.1/flowbite.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <script src="https://cdn.tailwindcss.com"></script>
    <title>Menu</title>
</head>

<body class="px-5">
    <nav class="pt-5 bg-white border-gray-200">
        <div class="flex flex-wrap items-center justify-between max-w-screen-xl p-4 mx-auto">
            <a href="../index.php" class="flex items-center">
                <img src="../../images/green scansavor logo.png" class="h-10 mr-3" alt="scannsavorlogo" />
                <span class="self-center text-2xl font-semibold text-teal-700 whitespace-nowrap">Scan N' Savor</span>
            </a>

            <div class="flex md:order-2">
                <button type="button" id="viewCartButton" data-modal-toggle="viewCartModal" class="px-2 py-1 mr-3 text-xs font-medium text-center text-white bg-green-800 border border-teal-700 rounded-full hover:bg-teal-600 focus:ring-4 focus:outline-none focus:ring-teal-200 w-11 h-11 md:mr-0">
                    <svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="w-6 h-6 mt-1 feather feather-shopping-cart">
                        <circle cx="9" cy="21" r="1"></circle>
                        <circle cx="20" cy="21" r="1"></circle>
                        <path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"></path>
                    </svg>
                    <!-- cart -->
                </button>

                <div class="px-2">
                    <button id="dropdownUserAvatarButton" data-dropdown-toggle="dropdownAvatar" class="px-2 py-1 mr-3 text-xs font-medium text-center text-white bg-green-800 border border-teal-700 rounded-full hover:bg-teal-600 focus:ring-4 focus:outline-none focus:ring-teal-200 w-11 h-11 md:mr-0" type="button">
                        <span class="sr-only">Open user menu</span>
                        <!-- <img class="w-8 h-8 rounded-full" src="/docs/images/people/profile-picture-3.jpg" alt=""> -->
                        <svg class="inline-block w-6 h-6 fill-current" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                            <path d="M5 3a2 2 0 00-2 2v2a2 2 0 002 2h2a2 2 0 002-2V5a2 2 0 00-2-2H5zM5 11a2 2 0 00-2 2v2a2 2 0 002 2h2a2 2 0 002-2v-2a2 2 0 00-2-2H5zM11 5a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V5zM11 13a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z"></path>
                        </svg>
                    </button>

                    <!-- Dropdown menu -->
                    <div id="dropdownAvatar" class="z-10 hidden bg-white divide-y divide-gray-100 rounded-lg shadow w-44 dark:bg-gray-700 dark:divide-gray-600">
                        <!-- <div class="px-4 py-3 text-sm text-gray-900 dark:text-white">
                        <div>Bonnie Green</div>
                        <div class="font-medium truncate">name@flowbite.com</div>
                    </div> -->
                        <ul class="py-2 text-sm text-gray-700 dark:text-gray-200" aria-labelledby="dropdownUserAvatarButton">
                            <li>
                                <a href="#" class="block px-4 py-2 text-center rounded hover:bg-teal-800 hover:text-white">Call for a waiter</a>
                            </li>
                            <li>
                                <a href="#" class="block px-4 py-2 text-center rounded hover:bg-teal-800 hover:text-white">Request for merge orders</a>
                            </li>
                        </ul>
                    </div>
                </div>

            </div>
        </div>
    </nav>

    <section id="next" class="">
        <div class="overflow-x-auto max-w-screen pt-10 lg:px-48">
            <div class="flex gap-2">
                <!-- All button -->
                <a href="#all" class="category-link">
                    <div class="flex items-center justify-center py-10 pt-2 text-center lg:justify-start lg:pl-10">
                        <button class="relative w-32 h-12 p-2 overflow-hidden font-bold text-teal-700 duration-300 border border-teal-700 cursor-pointer hover:text-white hover:border-none group rounded-3xl hover:bg-teal-700">
                            <p class="z-10 text-center">All</p>
                        </button>
                    </div>
                </a>

                <!-- best seller button -->
                <!-- <a href="#bestseller" class="category-link">
                    <div class="flex items-center justify-center py-10 pt-2 text-center lg:justify-start lg:pl-10">
                        <button class="relative w-32 h-12 p-2 overflow-hidden font-extrabold text-teal-700 duration-300 border border-teal-700 cursor-pointer hover:text-white hover:border-none group rounded-3xl hover:bg-teal-700">
                            <p class="z-10 text-center">Best Sellers</p>
                        </button>
                    </div>
                </a> -->

                <?php foreach ($category as $categoryData) : ?>
                    <a href="#<?php echo $categoryData['categoryID']; ?>" class="category-link">
                        <div class="flex items-center justify-center py-10 pt-2 text-center lg:justify-start pl-5">
                            <button class="relative w-32 h-12 p-2 overflow-hidden font-bold text-teal-700 duration-300 border border-teal-700 cursor-pointer hover:text-white hover:border-none group rounded-3xl hover:bg-teal-700">
                                <p class="z-10 text-center"><?php echo $categoryData['categoryName']; ?></p>
                            </button>
                        </div>
                    </a>
                <?php endforeach; ?>
            </div>
        </div>
    </section>


    <section class="h-full lg:px-10 px-5  bg-[#ebf7f3] rounded-3xl lg:my-14 lg:mx-24 lg:mt-7 pb-20">
        <div class="px-4 sm:ml-0 lg:ml-10">
            <div class="flex justify-center col-span-2 pb-10 text-center md:col-span-2 lg:col-span-4 lg:pt-20 pt-14 lg:mb-5">
                <h2 class="font-extrabold tracking-wide text-gray-800 lg:text-5xl md:text-xl md:tracking-wider">
                    Menu
                </h2>
            </div>
        </div>
        <div class="flex items-center justify-center">
            <div class="grid grid-cols-1 gap-8 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-3 lg:gap-14">
                <?php foreach ($fooditems as $item) : ?>
                    <div class="max-w-sm bg-white border border-gray-200 shadow-lg rounded-xl category-<?php echo $item['categoryID']; ?>">
                        <?php if (isset($item)) { ?>
                            <div class="relative">
                                <div class="px-4 pt-4 pb-2">
                                    <img class="w-full h-64 rounded-xl" src="<?php echo $item['itemImage']; ?>" alt="<?php echo $item['itemName']; ?>" />
                                </div>
                                <?php
                                $itemAvailability = $item['availability'] === 'Available';
                                $textClass = $itemAvailability ? 'bg-[#c7dec1]' : 'bg-[#A4ABB6]';
                                $displayText = $itemAvailability ? 'Available' : 'Unavailable';
                                ?>
                                <p class="absolute top-0 <?php echo $textClass; ?> text-gray-800 font-semibold py-1 px-3 rounded-br-lg rounded-tl-lg"><?php echo $displayText; ?></p>

                            </div>
                        <?php } ?>

                        <form id="addToCartForm_<?php echo $item['itemID']; ?>" method="POST" action="" onsubmit="addToCart('<?php echo $item['itemID']; ?>'); return false;">
                            <div class="flex justify-between px-6 pb-2">
                                <p class="text-xs tracking-tight text-gray-500 text-start" id="pax" name="pax">Available items : <?php echo $item['serving']; ?></p>
                                <p class="text-xs tracking-tight text-gray-500 text-end" id="pax" name="pax">*Good for <?php echo $item['pax']; ?></p>
                            </div>
                            <div class="px-5 pt-0.5">
                                <p class="text-xl font-semibold tracking-tight text-slate-700 " id="itemName" name="itemName"><?php echo $item['itemName']; ?></p>
                            </div>

                            <div class="px-5">
                                <h5 class="h-16 pt-1 pb-3 text-sm tracking-tight text-gray-900"><?php echo $item['description']; ?></h5>
                            </div>
                            <div class="flex items-center justify-between px-5 pb-5">
                                <span class="w-12 text-xl font-bold text-gray-900 lg:w-14" name="price" id="price">₱<?php echo $item['price']; ?></span>
                                <input type="hidden" name="itemID" value="<?php echo $item['itemID']; ?>">
                                <input type="number" name="orderQuantity" value="1" min="1" max="<?php echo $item['serving']; ?>" class="h-10 ml-3 mr-3 text-sm text-center text-gray-900 border border-teal-700 lg:ml-20 w-14 outline-teal-700 focus:ring-2 focus:ring-green-200 rounded-xl" oninput="checkQuantity(this)">

                                <button class="cursor-pointer font-semibold overflow-hidden relative z-100 border border-teal-700 group px-4 py-2 rounded-full <?php echo $itemAvailability ? 'hover:bg- hover:border-none hover:text-white' : 'cursor-not-allowed opacity-40'; ?>" name="addToCart" id="addToCart" type="submit" onclick="showItemAddedMessageModal()" <?php echo !$itemAvailability ? 'disabled' : ''; ?>>
                                    <span class="relative z-10 text-teal-700 duration-500 group-hover:text-white">Add to Cart</span>
                                    <span class="absolute top-0 w-full h-full duration-500 -rotate-45 bg-teal-700 -left-32 group-hover:rotate-0 group-hover:left-0"></span>
                                    <span class="absolute top-0 w-full h-full duration-500 -rotate-45 bg-teal-700 -right-32 group-hover:rotate-0 group-hover:right-0"></span>
                                </button>
                            </div>
                        </form>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>

    </section>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const categoryLinks = document.querySelectorAll('.category-link');
            const foodItems = document.querySelectorAll('.max-w-sm');
            const packageHeading = document.querySelector('.package-heading');

            categoryLinks.forEach(link => {
                link.addEventListener('click', function(event) {
                    event.preventDefault();
                    const selectedCategory = this.getAttribute('href').substring(1);

                    // Remove 'selected' class from all buttons
                    categoryLinks.forEach(btn => {
                        btn.classList.remove('selected');
                    });

                    // Add 'selected' class to the clicked button
                    this.classList.add('selected');

                    // Hide all food items
                    foodItems.forEach(item => {
                        item.style.display = 'none';
                    });

                    // Show all food items if "All" is selected
                    if (selectedCategory === 'all') {
                        foodItems.forEach(item => {
                            item.style.display = 'block';
                        });
                    } else {
                        // Show food items for the selected category
                        const selectedCategoryItems = document.querySelectorAll('.category-' + selectedCategory);
                        selectedCategoryItems.forEach(item => {
                            item.style.display = 'block';
                        });
                    }

                    // Toggle the visibility of the Package heading
                    packageHeading.style.display = selectedCategory === 'all' ? 'block' : 'none';
                });
            });
        });
    </script>



    <section class="h-full px-5 pb-20 lg:px-10 rounded-3xl lg:my-14 lg:mx-24 lg:mt-10">
        <div class="px-4 sm:ml-0 lg:ml-10">
            <div class="flex justify-center col-span-2 pb-10 text-center md:col-span-2 lg:col-span-4 lg:pt-20 pt-14 lg:mb-5">
                <h2 class="font-extrabold tracking-wide text-gray-800 package-heading lg:text-5xl md:text-xl md:tracking-wider">
                    Package
                </h2>
            </div>
        </div>
        <div class="flex items-center justify-center">
            <div class="grid grid-cols-1 gap-8 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-3 lg:gap-14">
                <?php
                $groupedPackages = [];
                foreach ($packageMenu as $packageData) {
                    $packageID = $packageData['packageID'];
                    $groupedPackages[$packageID][] = $packageData;
                }
                ?>
                <?php foreach ($groupedPackages as $packageID => $packageGroup) : ?>
                    <div class="max-w-sm border border-gray-200 shadow-lg rounded-xl">
                        <?php $firstPackage = $packageGroup[0]; ?>
                        <button type="button" id="preview" name="previewPackage" data-modal-toggle="previewPackageModal_<?php echo $firstPackage['packageID']; ?>" onclick="previewPackageModal('<?php echo $firstPackage['packageID']; ?>','<?php echo $firstPackage['packageName']; ?>','<?php echo $firstPackage['itemNames']; ?>')">
                            <?php if (isset($firstPackage)) { ?>
                                <div class="relative">
                                    <img class="w-full h-60 rounded-xl" src="<?php echo $firstPackage['packageImage']; ?>" alt="image" />
                                    <?php
                                    $packageAvailability = $firstPackage['availability'] === 'Available';
                                    $textClass = $packageAvailability ? 'bg-[#c7dec1]' : 'bg-[#A4ABB6]';
                                    $displayText = $packageAvailability ? 'Available' : 'Unavailable';
                                    ?>
                                    <!-- <p class="absolute top-0 px-3 py-1 font-semibold text-gray-800 bg-[#c7dec1] rounded-tl-lg rounded-br-lg"><?php echo $firstPackage['availability']; ?></p> -->

                                    <p class="absolute top-0 <?php echo $textClass; ?> text-gray-800 font-semibold py-1 px-3 rounded-br-lg rounded-tl-lg"><?php echo $displayText; ?></p>
                                </div>
                            <?php } ?>
                        </button>
                        <form id="addToCartForm_<?php echo $packageData['packageID']; ?>" method="POST" action="" onsubmit="addToCart('<?php echo $packageData['packageID']; ?>'); return false;">
                            <div class="px-3 pt-5">
                                <p class="text-xl font-semibold tracking-tight text-slate-700 " id="itemName" name="itemName"><?php echo $firstPackage['packageName']; ?></p>
                            </div>

                            <div class="px-3">
                                <h5 class="h-16 pt-3 pb-3 text-sm tracking-tight text-gray-900"><?php echo $firstPackage['packageDescription']; ?></h5>
                            </div>

                            <div class="flex items-center justify-between px-3 pb-5">
                                <span class="w-12 text-xl font-bold text-gray-900 lg:w-14" name="price" id="price">₱<?php echo $firstPackage['packagePrice']; ?></span>
                                <input type="hidden" name="itemID" value="<?php echo $firstPackage['packageID']; ?>">
                                <input type="number" name="orderQuantity" value="1" min="1" class="h-10 ml-3 text-sm text-center text-gray-900 border border-teal-300 outline-none lg:ml-20 w-14 rounded-xl">
                                <input type="hidden" name="isMenuPackage" value="1">

                                <button class="cursor-pointer font-semibold overflow-hidden relative z-100 border border-teal-700 group px-4 py-2 rounded-full <?php echo $packageAvailability ? 'hover:bg- hover:border-none hover:text-white' : 'cursor-not-allowed opacity-40'; ?>" name="addToCart" id="addToCart" type="submit" onclick="showItemAddedMessageModal()" <?php echo !$packageAvailability ? 'disabled' : ''; ?>>
                                    <span class="relative z-10 text-teal-700 duration-500 group-hover:text-white">Add to Cart</span>
                                    <span class="absolute top-0 w-full h-full duration-500 -rotate-45 bg-teal-700 -left-32 group-hover:rotate-0 group-hover:left-0"></span>
                                    <span class="absolute top-0 w-full h-full duration-500 -rotate-45 bg-teal-700 -right-32 group-hover:rotate-0 group-hover:right-0"></span>
                                </button>
                            </div>
                        </form>
                    </div>

                    <div id="previewPackageModal_<?php echo $firstPackage['packageID']; ?>" tabindex="-1" aria-hidden="true" class="hidden overflow-y-auto overflow-x-hidden fixed top-0 right-0 left-0 z-50 justify-center items-center w-full md:inset-0 h-[calc(100%-1rem)] md:h-full">
                        <div class="relative w-full h-full max-w-2xl p-4 md:h-auto">
                            <!-- Modal content -->
                            <div class="relative p-4 bg-transparent rounded-lg shadow">
                                <!-- Modal header -->
                                <div class="flex items-center justify-between pb-4 mb-4 rounded-t sm:mb-5">
                                    <h3 class="text-lg font-semibold text-gray-900">Package Preview</h3>
                                    <button type="button" class="text-gray-400 bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm p-1.5 ml-auto inline-flex items-center" data-modal-hide="previewPackageModal">
                                        <svg aria-hidden="true" class="w-5 h-5" fill="currentColor" viewbox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                                            <path fill-rule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clip-rule="evenodd" />
                                        </svg>
                                        <span class="sr-only">Close modal</span>
                                    </button>
                                </div>
                                <!-- Modal body -->
                                <div class='flex items-center justify-center min-h-screen px-2'>
                                    <div class='w-full max-w-md p-8 mx-auto overflow-hidden bg-white shadow-xl rounded-3xl'>
                                        <div class='max-w-md mx-auto'>
                                            <img class="object-contain w-full rounded-xl" src="<?php echo $firstPackage['packageImage']; ?>" alt="image" />
                                        </div>
                                        <form method="post">
                                            <div class='p-4 text-center sm:p-6'>
                                                <p class="py-1 text-xl font-semibold tracking-tight uppercase text-slate-700" id="itemName" name="itemName"><?php echo $firstPackage['packageName']; ?></p>
                                                <ul>
                                                    <?php foreach ($packageGroup as $item) : ?>
                                                        <?php
                                                        $itemNames = explode(', ', $item['itemNames']);
                                                        foreach ($itemNames as $itemName) :
                                                        ?>
                                                            <li class="text-lg font-normal tracking-tight text-slate-700" id="itemName" name="itemName">
                                                                <?php echo $itemName; ?>
                                                            </li>
                                                        <?php endforeach; ?>
                                                    <?php endforeach; ?>
                                                </ul>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>



    <?php if ($message != '') { ?>
        <div id="ItemAddedMessageModal" class="relative items-center justify-center px-4 py-10 text-center text-black bg-white border border-gray-300 rounded-lg shadow w-80 h-52" role="alert" style="position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%); z-index: 999;">
            <svg aria-hidden="true" class="w-12 h-12 mx-auto mt-5 mb-3 text-gray-500" stroke="currentColor" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <g id="SVGRepo_bgCarrier" stroke-width="0"></g>
                <g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g>
                <g id="SVGRepo_iconCarrier">
                    <path d="M21 5L19 12H7.37671M20 16H8L6 3H3M11.5 7L13.5 9M13.5 9L15.5 7M13.5 9V3M9 20C9 20.5523 8.55228 21 8 21C7.44772 21 7 20.5523 7 20C7 19.4477 7.44772 19 8 19C8.55228 19 9 19.4477 9 20ZM20 20C20 20.5523 19.5523 21 19 21C18.4477 21 18 20.5523 18 20C18 19.4477 18.4477 19 19 19C19.5523 19 20 19.4477 20 20Z" stroke="" stroke-width="1.6799999999999997" stroke-linecap="round" stroke-linejoin="round"></path>
                </g>
            </svg>
            <h3 class="mb-2 text-lg font-medium text-gray-500"><?php echo $message; ?></h3>
            <span class="absolute top-0 bottom-0 right-0 px-4 py-3" onclick="closeItemAddedMessageModal()">
                <svg class="w-6 h-6 text-gray-500 fill-current" role="button" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20">
                    <title>Close</title>
                    <path d="M14.348 14.849a1.2 1.2 0 0 1-1.697 0L10 11.819l-2.651 3.029a1.2 1.2 0 1 1-1.697-1.697l2.758-3.15-2.759-3.152a1.2 1.2 0 1 1 1.697-1.697L10 8.183l2.651-3.031a1.2 1.2 0 1 1 1.697 1.697l-2.758 3.152 2.758 3.15a1.2 1.2 0 0 1 0 1.698z" />
                </svg>
            </span>
        </div>
        <script>
            function showMessageModal() {
                var modal = document.getElementById('ItemAddedMessageModal');
                modal.style.display = 'block';
                setTimeout(function() {
                    modal.style.display = 'none';
                }, 1000); // Adjust the duration (in milliseconds) as needed
            }
            // Call the function to show the modal
            showMessageModal();
        </script>
    <?php } ?>

    <script>
        function showItemAddedMessageModal() {
            var modal = document.getElementById('ItemAddedMessageModal');
            modal.style.display = 'block';
        }
    </script>

    <script>
        function closeItemAddedMessageModal() {
            var modal = document.getElementById('ItemAddedMessageModal');
            modal.style.display = 'none';
        }
    </script>

</body>

</html>
<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>

<script>
    function addToCart() {
        $.ajax({
            url: "/additionalorders.php?tableNo=<?php echo $tableNo; ?>&orderID=<?php echo $orderID; ?>",
            type: "post",
            data: $("#addToCartForm").serialize(), // Serialize form data
            success: function(data) {
                // Handle success response if needed
                alert("Item added to cart successfully!");
            },
            error: function(xhr, status, error) {
                // Handle error response if needed
                alert("Error adding item to cart: " + error);
            }
        });
    }
</script>

<script>
    function checkQuantity(input) {
        var serving = <?php echo $item['serving']; ?>;
        var quantity = parseInt(input.value, 10);

        if (quantity > serving) {
            alert('Quantity cannot exceed the serving value.');
            input.value = serving; // Set the input value back to the maximum serving value
        }
    }
</script>




<script src="https://cdnjs.cloudflare.com/ajax/libs/flowbite/1.8.0/flowbite.min.js"></script>