<?php
session_start();

include '../connection/config.php';

// Check if the session variable exists
if (isset($_SESSION['orderID'])) {
    // Retrieve the session variable
    $orderID = $_SESSION['orderID'];
} else {
    echo "Session variable 'orderID' is not set.";
    exit;  // Exit the script if 'orderID' is not set
}

$orderQuery = "SELECT
o.orderID AS order_number,
p.paymentID,
o.isDineIn AS type,
o.orderDateTime AS order_date,
p.customerName AS customer,
p.paymentMethod AS payment,
p.amountPaid AS amount_Paid,
GROUP_CONCAT(fi.itemName SEPARATOR ', ') AS item_names, -- Concatenate item names
GROUP_CONCAT(pt.packageName SEPARATOR ', ') AS package_names, -- Concatenate package names
GROUP_CONCAT(od.itemQuantity SEPARATOR ', ') AS quantities, -- Concatenate quantities
GROUP_CONCAT(od.Amount SEPARATOR ', ') AS amounts, -- Concatenate amounts
o.totalAmount AS total_payment,
mp.packagePrice AS package_price
FROM
tblorders o
JOIN tblpaymentdetails pd ON o.orderID = pd.orderID
JOIN tblpayment p ON pd.paymentID = p.paymentID
JOIN tblorderdetails od ON o.orderID = od.orderID
LEFT JOIN tblfooditems fi ON od.itemID = fi.itemID
LEFT JOIN tblmenupackage pt ON od.packageID = pt.packageID
LEFT JOIN tblmenupackage mp ON od.packageID = mp.packageID
WHERE p.paymentID = ? 
GROUP BY o.orderID, p.paymentID";


$stmt = $conn->prepare($orderQuery);
$stmt->bind_param("i", $orderID);
$stmt->execute();

$result = $stmt->get_result();

// Fetch the data
$dataArray = [];
while ($row = $result->fetch_assoc()) {
    $dataArray[] = $row;
}

$stmt->close();

?>

<!-- Your HTML code here -->
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="../../dist/output.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/flowbite/1.8.1/flowbite.min.css" rel="stylesheet">
    <script src="https://cdn.tailwindcss.com"></script>
    <title>E-Receipt</title>
</head>

<body>
    <div class="flex h-screen w-full items-center justify-center bg-white-600">
        <div class="w-80 rounded bg-gray-50 px-6 pt-8 shadow-lg">

            <div class="flex flex-col justify-center items-center gap-2">
                <h4 class="font-semibold text-teal-800 text-xl">Scan N' Savor</h4>
                <p class="text-xs"></p>
            </div>
            <?php if (!empty($dataArray)) : ?>
                <div class="flex flex-col gap-3 border-b pt-2 pb-5 text-xs">
                    <div class="flex items-center opacity-80">
                        <div class="grow border-b border-dashed border-gray-800"></div>
                        <span class="shrink px-1 pb-1 text-gray-800 font-semibold uppercase"><?php echo ($dataArray[0]['type'] == 1 ? 'Dine-in' : 'Take-out'); ?></span>
                        <div class="grow border-b border-dashed border-gray-800"></div>
                    </div>
                    <!-- <p class="flex justify-between">
                    <span class="text-gray-400">Type:</span>
                        <span><?php echo ($dataArray[0]['type'] == 1 ? 'Dine-in' : 'Take-out'); ?></span>
                    </p> -->
                    <p class="flex justify-between">
                        <span class="text-gray-400">Order #:</span>
                        <span><?php echo $dataArray[0]['order_number']; ?></span>
                    </p>
                    <p class="flex justify-between">
                        <span class="text-gray-400">Date/Time:</span>
                        <span><?php echo $dataArray[0]['order_date']; ?></span>
                    </p>
                    <p class="flex justify-between">
                        <span class="text-gray-400">Customer:</span>
                        <span><?php echo $dataArray[0]['customer']; ?></span>
                    </p>
                    <p class="flex justify-between">
                        <span class="text-gray-400">Payment:</span>
                        <span><?php echo $dataArray[0]['payment']; ?></span>
                    </p>
                </div>
                <div class="flex flex-col gap-3 py-2 text-xs">
                    <table class="w-full text-left">
                        <thead>
                            <tr>
                                <th></th>
                                <th class="py-2">
                                    <div class="text-left font-light">Item Name</div>
                                </th>
                                <th class="py-2">
                                    <div class="text-center font-light">Quantity</div>
                                </th>
                                <th class="py-2">
                                    <div class="text-center font-light pl-2">Total</div>
                                </th>
                            </tr>
                        </thead>

                        <tbody>
                            <?php
                            $totalPrice = 0;

                            foreach ($dataArray as $recData) :
                                $totalPrice += $recData['amount'];

                                // Display package information if available
                                $packageInfo = $recData['package_name'] ? $recData['package_name'] . ' - ₱' . $recData['package_price'] : $recData['item_name'];
                            ?>
                                <tr>
                                    <td class="py-2"></td>
                                    <td class="py-2">
                                        <div class="font-medium text-gray-800"><?php echo $packageInfo; ?></div>
                                    </td>
                                    <td class="py-2">
                                        <div class="text-center"><?php echo $recData['quantity']; ?></div>
                                    </td>
                                    <td class="py-2">
                                        <div class="text-center pl-2 font-medium text-teal-800">₱<span><?php echo $recData['amount']; ?></span></div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>

                <?php
                $vatAmount = $totalPrice * 0.12;
                $totalPayment = $recData['total_payment'];

                // Calculate the total price minus VAT
                $totalPriceMinusVAT = $totalPrice - $vatAmount;
                ?>
                <div class="flex flex-col gap-2 border-b pt-3 pb-6">
                    <div class="border-dashed border"></div>
                    <p class="flex justify-between font-bold text-md pb-3">
                        <span>TOTAL</span>
                        <span class="text-left">₱<?php echo number_format($recData['total_payment'], 2); ?></span>
                    </p>


                    <?php if ($recData['payment'] == 'Cash') : ?>
                        <p class="flex justify-between text-xs">
                            <span class="text-gray-400">CASH:</span>
                            <span class="text-center">₱ <?php echo number_format( $recData['amount_Paid'], 2); 
                                                            ?></span>
                        </p>

                        <p class="flex justify-between text-xs">
                            <span class="text-gray-400">Change:</span>
                            <span class="text-center">₱ <?php echo number_format($recData['amount_Paid'] - $recData['total_payment'], 2); 
                                                            ?></span>
                        </p>
                        <?php endif; ?>

                    <!-- Display total price and VAT -->
                    <p class="flex justify-between text-xs">
                        <span class="text-gray-400">VATable Sales:</span>
                        <span class="text-center">₱<?php echo $totalPriceMinusVAT; ?></span>
                    </p>
                    <p class="flex justify-between text-xs">
                        <span class="text-gray-400">VAT (12%):</span>
                        <span class="text-left">₱<?php echo $vatAmount ?></span>
                    </p>
                    <div class="border-double border-spacing-2 border-2"></div>
                    <p class="justify-center items-center text-center font-semibold py-3">
                        THANK YOU & HAVE A GOOD DAY!
                    </p>

                </div>
            <?php endif; ?>
        </div>
    </div>
</body>

</html>