<?php

include '../forms/cancel.php';

global $conn;

$orderID = isset($_GET['orderID']) ? intval($_GET['orderID']) : 0;
$tableNum = isset($_GET['tableNo']) ? intval($_GET['tableNo']) : 0;

// Check if both orderID and tableNo are provided
if ($orderID > 0 && $tableNum > 0) {

    // Use the retrieved orderID and tableNo in your SQL queries
    $orderQuery = "SELECT * FROM tblorders WHERE orderID = $orderID AND tableNo = $tableNum";
    $orderResult = mysqli_query($conn, $orderQuery);

    // Check if the order is found
    if ($orderResult && mysqli_num_rows($orderResult) > 0) {
        // Fetch order details
        $orderDetails = mysqli_fetch_assoc($orderResult);

        // Now you can use $orderDetails['orderID'], $orderDetails['tableNo'], etc.
        // in your page to display order information or process additional orders.

        //Example: Display order information
        // echo "Order ID: " . $orderDetails['orderID'] . "<br>";
        // echo "Table No: " . $orderDetails['tableNo'] . "<br>";
        // echo "Total Amount: $" . $orderDetails['totalAmount'] . "<br>";

        // Example: Additional SQL query using orderID
        $additionalQuery = "SELECT * FROM tblorderdetails WHERE orderID = $orderID";
        $additionalResult = mysqli_query($conn, $additionalQuery);

        // Process additional results as needed
    } else {
        echo "Order not found.";
    }
} else {
    echo "Invalid orderID or tableNo.";
}

// Close the database connection when done


if (isset($_POST['addToCart'])) {
    $itemID = $_POST['itemID'];
    $orderQuantity = $_POST['orderQuantity'];

    // Check if it's an item or a menu package
    if (isset($_POST['isMenuPackage']) && $_POST['isMenuPackage'] == 1) {
        // It's a menu package
        $getPackageInfoQuery = "SELECT mi.packageID, mi.packageName, mi.packagePrice
        FROM tblmenupackage mi
        WHERE mi.packageID = ?";
        $getPackageInfoStmt = $conn->prepare($getPackageInfoQuery);
        $getPackageInfoStmt->bind_param("i", $itemID);
        $getPackageInfoStmt->execute();
        $getPackageInfoResult = $getPackageInfoStmt->get_result();

        if ($getPackageInfoResult->num_rows === 1) {
            $packageData = $getPackageInfoResult->fetch_assoc();
            $packageID = $itemID;
            $packageName = $packageData['packageName'];
            $packagePrice = $packageData['packagePrice'];

            // Add menu package to cart
            addPackageToCart($packageID, $packageName, $orderQuantity, $packagePrice);
        } else {
            // Handle error if the package is not found
            echo "Error: Package not found.";
            exit();
        }

        $getPackageInfoStmt->close();
    } else {
        // It's a regular item
        // Retrieve the selected item details from tblfooditems
        $query = "SELECT * FROM tblfooditems WHERE itemID = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("i", $itemID);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows === 1) {
            $item = $result->fetch_assoc();

            // Add regular item to cart
            addons($itemID, $item['itemName'], $orderQuantity, $item['price']);
        } else {
            // Item not found in the database
            echo "Error: Item not found in the database.";
        }

        $stmt->close();
    }
}
function addPackageToCart($packageID, $packageName, $orderQuantity, $packagePrice)
{
    // Create or update the user's cart in the session
    if (!isset($_SESSION['cart'])) {
        $_SESSION['cart'] = [];
    }

    // Check if the package is already in the cart
    $packageIndex = -1;
    foreach ($_SESSION['cart'] as $index => $cartItem) {
        if (isset($cartItem['packageID']) && $cartItem['packageID'] == $packageID) {
            // Package already exists in the cart, update the quantity
            $_SESSION['cart'][$index]['orderQuantity'] += $orderQuantity;
            $packageIndex = $index;
            break;
        }
    }

    if ($packageIndex === -1) {
        // Package is not in the cart, add it
        $cartItem = [
            'packageID' => $packageID,
            'packageName' => $packageName,
            'packagePrice' => $packagePrice,
            'orderQuantity' => $orderQuantity,
            'price' => $packagePrice,
            'itemName' => $packageName,
        ];

        $_SESSION['cart'][] = $cartItem;
    }

    // Package added to cart successfully or quantity updated
    // You can add an alert or other feedback here
}

// function addons($itemID, $itemName, $orderQuantity, $price)
// {
//     // Create or update the user's cart in the session
//     if (!isset($_SESSION['cart'])) {
//         $_SESSION['cart'] = [];
//     }
//     // Check if the item is already in the cart
//     $itemIndex = -1;
//     foreach ($_SESSION['cart'] as $index => $cartItem) {
//         if ($cartItem['itemID'] == $itemID) {
//             // Item already exists in the cart, update the quantity
//             $_SESSION['cart'][$index]['orderQuantity'] += $orderQuantity;
//             $itemIndex = $index;
//             break;
//         }
//     }
//     if ($itemIndex === -1) {
//         // Item is not in the cart, add it
//         $cartItem = [
//             'itemID' => $itemID,
//             'itemName' => $itemName,
//             'price' => $price,
//             'orderQuantity' => $orderQuantity,
//         ];

//         $_SESSION['cart'][] = $cartItem;
//     }
// }

function addons($itemID, $itemName, $orderQuantity, $price)
{
    // Create or update the user's cart in the session
    if (!isset($_SESSION['cart'])) {
        $_SESSION['cart'] = [];
    }
    // Check if the item is already in the cart
    $itemIndex = -1;
    foreach ($_SESSION['cart'] as $index => $cartItem) {
        if (isset($cartItem['itemID']) && $cartItem['itemID'] == $itemID) {
            // Item already exists in the cart, update the quantity
            $_SESSION['cart'][$index]['orderQuantity'] += $orderQuantity;
            $itemIndex = $index;
            break;
        }
    }
    if ($itemIndex === -1) {
        // Item is not in the cart, add it
        $cartItem = [
            'itemID' => $itemID,
            'itemName' => $itemName,
            'price' => $price,
            'orderQuantity' => $orderQuantity,
        ];

        $_SESSION['cart'][] = $cartItem;
    }
}

// Function to process the order and update totalAmount
function processOrder($conn, $orderID)
{
    // Calculate the total amount from the tblorderdetails table
    $totalAmountQuery = "SELECT SUM(Amount) AS totalAmount FROM tblorderdetails WHERE orderID = ?";
    $totalAmountStmt = $conn->prepare($totalAmountQuery);
    $totalAmountStmt->bind_param("i", $orderID);
    $totalAmountStmt->execute();
    $totalAmountResult = $totalAmountStmt->get_result();

    if ($totalAmountResult->num_rows > 0) {
        $totalAmountData = $totalAmountResult->fetch_assoc();
        $totalAmount = $totalAmountData['totalAmount'];

        // Update the tblorders table with the calculated total amount
        $updateOrderQuery = "UPDATE tblorders SET totalAmount = ? WHERE orderID = ?";
        $updateOrderStmt = $conn->prepare($updateOrderQuery);
        $updateOrderStmt->bind_param("di", $totalAmount, $orderID);
        $updateOrderStmt->execute();
    }
}

if (isset($_POST['addOnOrder'])) {
    // Check if the session has started
    if (session_status() == PHP_SESSION_ACTIVE) {
        // Get the table number from POST data
        $tableNumber = $_POST['tableNum'];

        // Check if the table exists
        $tableCheckQuery = "SELECT * FROM tbltable WHERE tableNo = ?";
        $tableCheckStmt = $conn->prepare($tableCheckQuery);
        $tableCheckStmt->bind_param("i", $tableNumber);
        $tableCheckStmt->execute();
        $tableCheckResult = $tableCheckStmt->get_result();

        if ($tableCheckResult->num_rows > 0) {
            $tableData = $tableCheckResult->fetch_assoc();

            if ($tableData['isOccupied'] == 1) {
                $conn->begin_transaction();

                try {
                    // Calculate the total amount
                    $totalPrice = 0;

                    foreach ($_SESSION['cart'] as $cartItem) {
                        $itemTotalPrice = $cartItem['price'] * $cartItem['orderQuantity'];
                        $totalPrice += $itemTotalPrice;
                    }

                    // Get the cartID from the session
                    $cartSession = $_SESSION['cartID'];

                    // Query to retrieve cart details using cartID
                    $cartDetailsQuery = "SELECT * FROM tblcartdetails WHERE cartID = ?";
                    $cartDetailsStmt = $conn->prepare($cartDetailsQuery);
                    $cartDetailsStmt->bind_param("i", $cartSession);
                    $cartDetailsStmt->execute();
                    $cartDetailsResult = $cartDetailsStmt->get_result();

                    if ($cartDetailsResult->num_rows > 0) {
                        // Check if there is an existing order
                        if ($orderID > 0 && $tableNumber > 0) {
                            // Use the existing orderID and tableNo to perform the checks
                            $orderCheckQuery = "SELECT * FROM tblOrders WHERE orderID = ? AND tableNo = ?";
                            $orderCheckStmt = $conn->prepare($orderCheckQuery);
                            $orderCheckStmt->bind_param("ii", $orderID, $tableNumber);
                            $orderCheckStmt->execute();
                            $orderCheckResult = $orderCheckStmt->get_result();

                            if ($orderCheckResult->num_rows > 0) {
                                // Order exists, proceed to add order details
                                while ($row = $orderCheckResult->fetch_assoc()) {
                                    $orderID = $row['orderID'];

                                    // Insert each item in the cart into tblOrderDetails
                                    while ($cartItem = $cartDetailsResult->fetch_assoc()) {
                                        $itemID = $cartItem['itemID'];
                                        $packageID = $cartItem['packageID'];
                                        $itemQuantity = $cartItem['orderQuantity'];
                                        $itemTotalPrice = $cartItem['price'] * $cartItem['orderQuantity'];

                                        // Determine whether the item is a regular item or a menu package
                                        if (!empty($itemID)) {
                                            // Regular item
                                            $orderDetailsQuery = "INSERT INTO tblorderdetails (orderID, itemID, itemQuantity, Amount, status) VALUES (?, ?, ?, ?, 'ForApproval')";
                                            $orderDetailsStmt = $conn->prepare($orderDetailsQuery);
                                            $orderDetailsStmt->bind_param("iiid", $orderID, $itemID, $itemQuantity, $itemTotalPrice);
                                        } elseif (!empty($packageID)) {
                                            // Menu package
                                            $orderDetailsQuery = "INSERT INTO tblorderdetails (orderID, packageID, itemQuantity, Amount, status) VALUES (?, ?, ?, ?, 'ForApproval')";
                                            $orderDetailsStmt = $conn->prepare($orderDetailsQuery);
                                            $orderDetailsStmt->bind_param("iiid", $orderID, $packageID, $itemQuantity, $itemTotalPrice);
                                        } else {
                                            // Handle the case where neither itemID nor packageID is set (an error condition)
                                            echo "Error: Invalid cart item.";
                                            exit();
                                        }

                                        // Execute the order details query
                                        if (!$orderDetailsStmt->execute()) {
                                            throw new Exception("Failed to insert item into tblorderdetails. Error: " . $orderDetailsStmt->error);
                                        }
                                    }
                                }
                            } else {
                                echo "Order not found for orderID: $orderID and tableNo: $tableNumber";
                            }
                        } else {
                            echo "Invalid orderID or tableNumber.";
                        }

                        // Commit the transaction
                        $conn->commit();

                        processOrder($conn, $orderID);

                        // Unset or destroy the cart session
                        unset($_SESSION['cart']);

                        // Get the cartID from the session (after unsetting cart session)
                        $cartSession = $_SESSION['cartID'];

                        // Query to retrieve order data using cartID
                        $orderDataQuery = "SELECT * FROM tblOrders WHERE cartID = ?";
                        $orderDataStmt = $conn->prepare($orderDataQuery);
                        $orderDataStmt->bind_param("i", $cartSession);
                        $orderDataStmt->execute();
                        $orderDataResult = $orderDataStmt->get_result();

                        $_SESSION['cartID'] = NULL; // replace this with your actual function to generate a new cartID

                        if ($orderDataResult->num_rows > 0) {
                            // Fetch and display order data
                            while ($row = $orderDataResult->fetch_assoc()) {
                                // Store order details in variables
                                $orderID = $row['orderID'];
                                $_SESSION['orderID'] = $orderID;
                                $_cartID = $row['cartID'];
                                $SESSION['cartID'] = $cartID;
                                $tableNo = $row['tableNo'];
                                $totalAmount = $row['totalAmount'];
                                $orderStatus = $row['orderStatus'];
                                $processedBy = $row['processedBy'];

                                // Query to retrieve order details data using orderID
                                $orderDetailsDataQuery = "SELECT * FROM tblorderdetails WHERE orderID = ?";
                                $orderDetailsDataStmt = $conn->prepare($orderDetailsDataQuery);
                                $orderDetailsDataStmt->bind_param("i", $orderID);
                                $orderDetailsDataStmt->execute();
                                $orderDetailsDataResult = $orderDetailsDataStmt->get_result();

                                if ($orderDetailsDataResult->num_rows > 0) {
                                    // Fetch and display order details data
                                    while ($rowDetails = $orderDetailsDataResult->fetch_assoc()) {
                                        // Store order details in variables
                                        $itemID = $rowDetails['itemID'];
                                        $packageID = $rowDetails['packageID'];
                                        $itemQuantity = $rowDetails['itemQuantity'];
                                        $Amount = $rowDetails['Amount'];

                                        // Query to retrieve food items data using itemID
                                        $foodItemsDataQuery = "SELECT * FROM tblfooditems WHERE itemID = ?";
                                        $foodItemsDataStmt = $conn->prepare($foodItemsDataQuery);
                                        $foodItemsDataStmt->bind_param("i", $itemID);
                                        $foodItemsDataStmt->execute();
                                        $foodItemsDataResult = $foodItemsDataStmt->get_result();

                                        $mergedData = array();

                                        if ($foodItemsDataResult->num_rows > 0) {
                                            // Fetch and display food items data
                                            while ($rowFoodItems = $foodItemsDataResult->fetch_assoc()) {
                                                // Store food items details in variables
                                                $foodItemName = $rowFoodItems['itemName'];
                                                $foodItemPrice = $rowFoodItems['price'];
                                                $foodItemImage = $rowFoodItems['itemImage'];

                                                // Merge the food item and order details into the mergedData array
                                                $mergedData[] = array(
                                                    'processedBy' => $processedBy,
                                                    'packageID' => $packageID,
                                                    'orderID' => $orderID,
                                                    'tableNo' => $tableNo,
                                                    'itemName' => $foodItemName,
                                                    'price' => $foodItemPrice,
                                                    'itemQuantity' => $itemQuantity,
                                                    'MaxAmount' => $Amount,
                                                    'orderStatus' => $orderStatus,
                                                    'itemImage' => $foodItemImage,
                                                    'itemID' => $itemID,
                                                    'packageID' => $packageID,
                                                    'totalAmount' => $totalAmount
                                                );
                                            }
                                        } else {
                                            echo "No food items data found for itemID: " . $itemID;
                                        }
                                    }
                                } else {
                                    echo "No order details data found for orderID: " . $orderID;
                                }
                            }
                        } else {
                            echo "No order data found for cartID: " . $cartSession;
                        }

                        $_SESSION['cartID'] = NULL; // replace this with your actual function to generate a new cartID

                        // Unset or destroy the cart session after retrieving order data
                        unset($_SESSION['cart']);

                        $message = "Order placed successfully!";
                    } else {
                        // Handle the case where no cart details are found
                        echo "Error: No cart details found.";
                        exit();
                    }

                    $cartDetailsStmt->close();
                } catch (Exception $e) {
                    // Roll back the transaction in case of an error
                    $conn->rollback();
                    echo "Transaction failed: " . $e->getMessage();
                }
            } else {
                echo "<script>
                    alert('The table is occupied.');
                </script>";
            }
        } else {
            // The table does not exist, handle the error
            echo "<script>
                alert('The table is non-existent.');
            </script>";
        }
    } else {
        echo "Session not active.";
    }
}

if (isset($_POST['updateQuantity'])) {
    if (isset($_POST['itemIndex'])) {
        $itemIndex = $_POST['itemIndex'];
        $currentQuantity = $_SESSION['cart'][$itemIndex]['orderQuantity'];

        if ($_POST['updateQuantity'] == 'decrease') {
            // Decrease quantity
            $newQuantity = max(0, $currentQuantity - 1);

            $itemID = isset($_SESSION['cart'][$itemIndex]['itemID']) ? $_SESSION['cart'][$itemIndex]['itemID'] : null;

            // Update the item's quantity in the session cart
            $_SESSION['cart'][$itemIndex]['orderQuantity'] = $newQuantity;

            // Update the item's quantity in the database
            $itemID = isset($_SESSION['cart'][$itemIndex]['itemID']) ? $_SESSION['cart'][$itemIndex]['itemID'] : null;
            $packageID = isset($_SESSION['cart'][$itemIndex]['packageID']) ? $_SESSION['cart'][$itemIndex]['packageID'] : null;

            // Use a single query with a condition for both itemID and packageID
            $updateQuantityQuery = "UPDATE tblcartdetails SET orderQuantity = ? WHERE ";
            if ($itemID !== null) {
                $updateQuantityQuery .= "itemID = ?";
            } elseif ($packageID !== null) {
                $updateQuantityQuery .= "packageID = ?";
            }

            $updateQuantityStmt = $conn->prepare($updateQuantityQuery);

            // Bind parameters based on whether it's an item or a package
            if ($itemID !== null) {
                $updateQuantityStmt->bind_param("ii", $newQuantity, $itemID);
            } elseif ($packageID !== null) {
                $updateQuantityStmt->bind_param("ii", $newQuantity, $packageID);
            }

            if ($updateQuantityStmt->execute()) {
                // Update the serving in tblfooditems for items only
                if ($itemID !== null) {
                    $updateServingQuery = "UPDATE tblfooditems SET serving = serving + 1 WHERE itemID = ?";
                    $updateServingStmt = $conn->prepare($updateServingQuery);
                    $updateServingStmt->bind_param("i", $itemID);
                
                    if ($updateServingStmt->execute()) {
                        // Check if serving is greater than 0, set availability and dishStatus
                        $checkServingQuery = "SELECT serving FROM tblfooditems WHERE itemID = ?";
                        $checkServingStmt = $conn->prepare($checkServingQuery);
                        $checkServingStmt->bind_param("i", $itemID);
                        $checkServingStmt->execute();
                        $checkServingResult = $checkServingStmt->get_result();
                
                        if ($checkServingResult->num_rows === 1) {
                            $servingData = $checkServingResult->fetch_assoc();
                            $currentServing = $servingData['serving'];
                        
                            if ($currentServing > 0) {
                                // Serving is greater than 0, set availability to Available and dishStatus to In Stock
                                $updateStatusQuery = "UPDATE tblfooditems SET availability = 'Available', dishStatus = 'In Stock' WHERE itemID = ?";
                                $updateStatusStmt = $conn->prepare($updateStatusQuery);
                                $updateStatusStmt->bind_param("i", $itemID);
                        
                                if (!$updateStatusStmt->execute()) {
                                    // Log error to a server log for further analysis
                                    error_log('Failed to update status in tblfooditems. Error: ' . $updateStatusStmt->error);
                                    echo "<script>alert('Failed to update status in tblfooditems. Please try again.');</script>";
                                } else {
                                    // Check if the item is part of any menu package
                                    $checkMenuPackageItemQuery = "SELECT packageID FROM tblmenupackageitems WHERE itemID = ?";
                                    $checkMenuPackageItemStmt = $conn->prepare($checkMenuPackageItemQuery);
                                    $checkMenuPackageItemStmt->bind_param("i", $itemID);
                                    $checkMenuPackageItemStmt->execute();
                                    $checkMenuPackageItemResult = $checkMenuPackageItemStmt->get_result();
                        
                                    if ($checkMenuPackageItemResult->num_rows > 0) {
                                        // If the item is part of any menu package, fetch all related packageIDs
                                        $packageIDsQuery = "SELECT DISTINCT packageID FROM tblmenupackageitems WHERE itemID = ?";
                                        $packageIDsStmt = $conn->prepare($packageIDsQuery);
                                        $packageIDsStmt->bind_param("i", $itemID);
                                        $packageIDsStmt->execute();
                                        $packageIDsResult = $packageIDsStmt->get_result();
                                        $packageIDsStmt->close();
                                    
                                        while ($packageRow = $packageIDsResult->fetch_assoc()) {
                                            $packageID = $packageRow['packageID'];
                                    
                                            // Check the availability of all items in the package
                                            $checkPackageAvailabilityQuery = "SELECT COUNT(fi.itemID) AS unavailable_items
                                                                              FROM tblfooditems fi
                                                                              INNER JOIN tblmenupackageitems mpi ON fi.itemID = mpi.itemID
                                                                              WHERE mpi.packageID = ? AND fi.availability = 'Unavailable'";
                                            $checkPackageAvailabilityStmt = $conn->prepare($checkPackageAvailabilityQuery);
                                            $checkPackageAvailabilityStmt->bind_param("i", $packageID);
                                            $checkPackageAvailabilityStmt->execute();
                                            $unavailableItemsCount = $checkPackageAvailabilityStmt->get_result()->fetch_assoc()['unavailable_items'];
                                            $checkPackageAvailabilityStmt->close();
                                    
                                            if ($unavailableItemsCount === 0) {
                                                // If all items in the package are available, set the package availability to Available
                                                $updateMenuPackageAvailabilityQuery = "UPDATE tblmenupackage SET availability = 'Available' WHERE packageID = ?";
                                                $updateMenuPackageAvailabilityStmt = $conn->prepare($updateMenuPackageAvailabilityQuery);
                                                $updateMenuPackageAvailabilityStmt->bind_param("i", $packageID);
                                    
                                                if (!$updateMenuPackageAvailabilityStmt->execute()) {
                                                    // Log error to a server log for further analysis
                                                    error_log('Failed to update status in tblmenupackage. Error: ' . $updateMenuPackageAvailabilityStmt->error);
                                                    echo "<script>alert('Failed to update status in tblmenupackage. Please try again.');</script>";
                                                }
                                    
                                                $updateMenuPackageAvailabilityStmt->close();
                                            }
                                        }
                                    }                                    
                        
                                    $checkMenuPackageItemStmt->close();
                                }
                        
                                $updateStatusStmt->close();
                            }
                        }                                   
                
                        $checkServingStmt->close();
                    } else {
                        error_log('Failed to update serving in tblfooditems. Error: ' . $updateServingStmt->error);
                        echo "<script>alert('Failed to update serving in tblfooditems. Please try again.');</script>";
                    }
                }

                // Check if the new quantity is zero, and delete the order
                if ($newQuantity === 0) {
                    // Get the item details
                    $itemID = isset($_SESSION['cart'][$itemIndex]['itemID']) ? $_SESSION['cart'][$itemIndex]['itemID'] : null;
                    $packageID = isset($_SESSION['cart'][$itemIndex]['packageID']) ? $_SESSION['cart'][$itemIndex]['packageID'] : null;

                    // Delete the item from the session cart
                    unset($_SESSION['cart'][$itemIndex]);

                    // Delete the item from the database
                    $deleteOrderQuery = "DELETE FROM tblcartdetails WHERE ";
                    if ($itemID !== null) {
                        $deleteOrderQuery .= "itemID = ?";
                    } elseif ($packageID !== null) {
                        $deleteOrderQuery .= "packageID = ?";
                    }

                    $deleteOrderStmt = $conn->prepare($deleteOrderQuery);

                    // Bind parameters based on whether it's an item or a package
                    if ($itemID !== null) {
                        $deleteOrderStmt->bind_param("i", $itemID);
                    } elseif ($packageID !== null) {
                        $deleteOrderStmt->bind_param("i", $packageID);
                    }

                    if ($deleteOrderStmt->execute()) {
                        // echo "<script>alert('Order deleted successfully!');</script>";
                    } else {
                        // Log error to a server log for further analysis
                        error_log('Failed to delete order from the database. Error: ' . $deleteOrderStmt->error);
                        echo "<script>alert('Failed to delete order from the database. Please try again.');</script>";
                    }
                }
            } else {
                // Log error to a server log for further analysis
                error_log('Failed to update quantity in the database. Error: ' . $updateQuantityStmt->error);
                echo "<script>alert('Failed to update quantity in the database. Please try again.');</script>";
            }
        } elseif ($_POST['updateQuantity'] == 'increase') {
            // Increase quantity
            $newQuantity = $currentQuantity + 1;
        
            $itemID = isset($_SESSION['cart'][$itemIndex]['itemID']) ? $_SESSION['cart'][$itemIndex]['itemID'] : null;
            $packageID = isset($_SESSION['cart'][$itemIndex]['packageID']) ? $_SESSION['cart'][$itemIndex]['packageID'] : null;
        
            // Check if serving is greater than 0 in tblfooditems
            $checkServingQuery = "SELECT serving FROM tblfooditems WHERE itemID = ?";
            $checkServingStmt = $conn->prepare($checkServingQuery);
            $checkServingStmt->bind_param("i", $itemID);
            $checkServingStmt->execute();
            $checkServingResult = $checkServingStmt->get_result();
        
            if ($checkServingResult->num_rows === 1) {
                $servingData = $checkServingResult->fetch_assoc();
                $currentServing = $servingData['serving'];
        
                // Check if serving is greater than 0 before updating orderQuantity
                if ($currentServing > 0) {
                    // Update the item's quantity in the session cart
                    $_SESSION['cart'][$itemIndex]['orderQuantity'] = $newQuantity;
        
                    // Update the item's quantity in the database
                    $updateQuantityQuery = "UPDATE tblcartdetails SET orderQuantity = ? WHERE ";
                    if ($itemID !== null) {
                        $updateQuantityQuery .= "itemID = ?";
                    } elseif ($packageID !== null) {
                        $updateQuantityQuery .= "packageID = ?";
                    }
        
                    $updateQuantityStmt = $conn->prepare($updateQuantityQuery);
        
                    // Bind parameters based on whether it's an item or a package
                    if ($itemID !== null) {
                        $updateQuantityStmt->bind_param("ii", $newQuantity, $itemID);
                    } elseif ($packageID !== null) {
                        $updateQuantityStmt->bind_param("ii", $newQuantity, $packageID);
                    }
        
                    if ($updateQuantityStmt->execute()) {
                        if ($itemID !== null) {
                            $updateServingQuery = "UPDATE tblfooditems SET serving = serving - 1 WHERE itemID = ?";
                            $updateServingStmt = $conn->prepare($updateServingQuery);
                            $updateServingStmt->bind_param("i", $itemID);
        
                            if ($updateServingStmt->execute()) {
                                // Check if serving is equal to or less than 0, set availability and dishStatus
                                $checkServingQuery = "SELECT serving FROM tblfooditems WHERE itemID = ?";
                                $checkServingStmt = $conn->prepare($checkServingQuery);
                                $checkServingStmt->bind_param("i", $itemID);
                                $checkServingStmt->execute();
                                $checkServingResult = $checkServingStmt->get_result();
        
                                if ($checkServingResult->num_rows === 1) {
                                    $servingData = $checkServingResult->fetch_assoc();
                                    $currentServing = $servingData['serving'];
        
                                    if ($currentServing <= 0) {
                                        // Serving is equal to or less than 0, set availability to Unavailable and dishStatus to Out of Stock
                                        $updateStatusQuery = "UPDATE tblfooditems SET availability = 'Unavailable', dishStatus = 'Out of Stock' WHERE itemID = ?";
                                        $updateStatusStmt = $conn->prepare($updateStatusQuery);
                                        $updateStatusStmt->bind_param("i", $itemID);
        
                                        if (!$updateStatusStmt->execute()) {
                                            // Log error to a server log for further analysis
                                            error_log('Failed to update status in tblfooditems. Error: ' . $updateStatusStmt->error);
                                            echo "<script>alert('Failed to update status in tblfooditems. Please try again.');</script>";
                                        } else {
                                            // Check if the item is part of any menu package
                                            $checkMenuPackageItemQuery = "SELECT packageID FROM tblmenupackageitems WHERE itemID = ?";
                                            $checkMenuPackageItemStmt = $conn->prepare($checkMenuPackageItemQuery);
                                            $checkMenuPackageItemStmt->bind_param("i", $itemID);
                                            $checkMenuPackageItemStmt->execute();
                                            $checkMenuPackageItemResult = $checkMenuPackageItemStmt->get_result();
        
                                            if ($checkMenuPackageItemResult->num_rows > 0) {
                                                // If the item is part of any menu package, update availability in tblmenupackage
                                                while ($row = $checkMenuPackageItemResult->fetch_assoc()) {
                                                    $updateMenuPackageAvailabilityQuery = "UPDATE tblmenupackage SET availability = 'Unavailable' WHERE packageID = ?";
                                                    $updateMenuPackageAvailabilityStmt = $conn->prepare($updateMenuPackageAvailabilityQuery);
                                                    $updateMenuPackageAvailabilityStmt->bind_param("i", $row['packageID']);
                                                    $updateMenuPackageAvailabilityStmt->execute();
                                                    $updateMenuPackageAvailabilityStmt->close();
                                                }
                                            }
        
                                            $checkMenuPackageItemStmt->close();
                                        }
        
                                        $updateStatusStmt->close();
                                    }
                                }
        
                                $checkServingStmt->close();
                            } else {
                                error_log('Failed to update serving in tblfooditems. Error: ' . $updateServingStmt->error);
                                echo "<script>alert('Failed to update serving in tblfooditems. Please try again.');</script>";
                            }
                        }
                    } else {
                        // Log error to a server log for further analysis
                        error_log('Failed to update quantity in the database. Error: ' . $updateQuantityStmt->error);
                        echo "<script>alert('Failed to update quantity in the database. Please try again.');</script>";
                    }
        
                    $updateQuantityStmt->close();
                } else {
                    $message = "Cannot increase quantity. Item is out of stock.";
                }
            } else {
                // Handle the case where the item is not found in tblfooditems
                echo "<script>alert('Error: Item not found.');</script>";
            }
        
        }        
    }
}

if (isset($_POST['removeItem'])) {
    if (isset($_POST['itemIndex'])) {
        $itemIndex = filter_var($_POST['itemIndex'], FILTER_VALIDATE_INT, array('options' => array('min_range' => 0)));

        // Check if the itemIndex is valid
        if (isset($_SESSION['cart'][$itemIndex])) {
            $cart = $_SESSION['cart']; // Read the cart from the session

            // Check if 'itemID' and 'packageID' keys are set, and assign them accordingly
            $itemID = isset($cart[$itemIndex]['itemID']) ? $cart[$itemIndex]['itemID'] : null;
            $packageID = isset($cart[$itemIndex]['packageID']) ? $cart[$itemIndex]['packageID'] : null;
            $orderQuantity = isset($cart[$itemIndex]['orderQuantity']) ? $cart[$itemIndex]['orderQuantity'] : 0;

            // Determine whether it's an item or package and get the corresponding ID
            $IDToDelete = isset($itemID) ? $itemID : (isset($packageID) ? $packageID : null);

            if ($IDToDelete !== null) {
                // Create a DELETE query to remove the item or package from tblcartdetails
                $deleteQuery = "DELETE FROM tblcartdetails WHERE itemID = ? OR packageID = ?";
                $deleteStmt = $conn->prepare($deleteQuery);
                $deleteStmt->bind_param("ii", $IDToDelete, $IDToDelete);

                if ($deleteStmt->execute()) {
                    // Update serving quantity in tblfooditems
                    $updateServingQuery = "UPDATE tblfooditems SET serving = serving + ? WHERE itemID = ?";
                    $updateServingStmt = $conn->prepare($updateServingQuery);
                    $updateServingStmt->bind_param("ii", $orderQuantity, $IDToDelete);
                    $updateServingStmt->execute();

                    // Update availability and dishStatus if serving is greater than 0
                    if ($orderQuantity > 0) {
                        $updateAvailabilityQuery = "UPDATE tblfooditems SET availability = 'Available', dishStatus = 'In Stock' WHERE itemID = ?";
                        $updateAvailabilityStmt = $conn->prepare($updateAvailabilityQuery);
                        $updateAvailabilityStmt->bind_param("i", $IDToDelete);
                        $updateAvailabilityStmt->execute();

                        // Check if the item is part of any menu package
                        $checkMenuPackageItemQuery = "SELECT packageID FROM tblmenupackageitems WHERE itemID = ?";
                        $checkMenuPackageItemStmt = $conn->prepare($checkMenuPackageItemQuery);
                        $checkMenuPackageItemStmt->bind_param("i", $IDToDelete);
                        $checkMenuPackageItemStmt->execute();
                        $checkMenuPackageItemResult = $checkMenuPackageItemStmt->get_result();

                        while ($row = $checkMenuPackageItemResult->fetch_assoc()) {
                            // Check if all items in the menu package are 'Available'
                            $checkPackageAvailabilityQuery = "SELECT COUNT(fi.itemID) AS unavailable_items
                                                              FROM tblfooditems fi
                                                              INNER JOIN tblmenupackageitems mpi ON fi.itemID = mpi.itemID
                                                              WHERE mpi.packageID = ? AND fi.availability = 'Unavailable'";
                            $checkPackageAvailabilityStmt = $conn->prepare($checkPackageAvailabilityQuery);
                            $checkPackageAvailabilityStmt->bind_param("i", $row['packageID']);
                            $checkPackageAvailabilityStmt->execute();
                            $unavailableItemsCount = $checkPackageAvailabilityStmt->get_result()->fetch_assoc()['unavailable_items'];
                            $checkPackageAvailabilityStmt->close();

                            if ($unavailableItemsCount === 0) {
                                // If all items in the package are 'Available', set the package availability to 'Available'
                                $updateMenuPackageAvailabilityQuery = "UPDATE tblmenupackage SET availability = 'Available' WHERE packageID = ?";
                                $updateMenuPackageAvailabilityStmt = $conn->prepare($updateMenuPackageAvailabilityQuery);
                                $updateMenuPackageAvailabilityStmt->bind_param("i", $row['packageID']);
                                $updateMenuPackageAvailabilityStmt->execute();
                                $updateMenuPackageAvailabilityStmt->close();
                            }
                        }

                        $checkMenuPackageItemStmt->close();
                    }

                    // Remove the item or package from the session cart
                    unset($cart[$itemIndex]);

                    // Reindex the session cart array
                    $cart = array_values($cart);
                    $_SESSION['cart'] = $cart;

                    //  echo "<script>alert('Item removed successfully!');</script>";
                } else {
                    echo "<script>alert('Failed to remove item or package from the database.');</script>";
                }
            }
        }
    }
}


$totalPrice = 0;
?>


<div id="viewCartModal" tabindex="-1" aria-hidden="true" class="hidden overflow-y-auto overflow-x-hidden fixed top-0 right-0 left-0 z-50 justify-center items-center w-full md:inset-0 h-[calc(100%-1rem)] md:h-full">
    <div class="relative w-full h-full max-w-xl p-4 md:h-auto">
        <!-- Modal content -->
        <div class="relative p-4 bg-white rounded-lg shadow">
            <!-- Modal header -->
            <div class="flex items-center justify-between pb-4 mb-4 border-b rounded-t sm:mb-5">
                <h3 class="text-lg font-semibold text-gray-900">Add-ons Cart</h3>
                <button type="button" class="text-gray-400 bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm p-1.5 ml-auto inline-flex items-center" data-modal-toggle="viewCartModal">
                    <svg aria-hidden="true" class="w-5 h-5" fill="currentColor" viewbox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                        <path fill-rule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clip-rule="evenodd" />
                    </svg>
                    <span class="sr-only">Close modal</span>
                </button>
            </div>
            <!-- Modal body -->
            <section>
                <form form id="addToCartForm" method="POST" action="">
                    <div class="max-w-5xl px-14 py-5 mx-auto">
                        <div class="flex justify-center pb-5">
                            <label for="tableNum" class="text-lg font-medium text-gray-900">Table Number</label>
                            <div class="flex items-center">
                                <input type="text" id="tableNum" name="tableNum" class="text-lg font-bold text-teal-800 border-0 outline-none w-12 h-7 focus:ring-green-300" value="<?php echo $tableNum; ?>" readonly>
                            </div>
                            <div class="hidden">
                                <label for="orderID" class="text-lg font-medium text-gray-900">Order ID</label>
                                <input type="text" id="orderID" name="orderID" class="text-lg font-bold text-teal-800 border-0 outline-none w-12 h-7 focus:ring-green-300" value="<?php echo $orderID; ?>" readonly>
                            </div>
                        </div>

                        <!-- <div class="">
                            <div class="flex flex-row justify-between px-5">
                                <div>
                                    <label for="tableNum" class="text-lg font-medium text-gray-900">Table Number</label>
                                    <input class="text-lg font-bold text-teal-800 border-0 outline-none w-12 h-7 focus:ring-green-300" id="tableNum" name="tableNum" value="<?php echo $tableNum; ?>" readonly>
                                </div>
                                <div class="hidden">
                                    <label for="orderID" class="text-lg font-medium text-gray-900">Order ID</label>
                                    <input type="text" id="orderID" name="orderID" class="text-lg font-bold text-teal-800 border-0 outline-none w-12 h-7 focus:ring-green-300" value="<?php echo $orderID; ?>" readonly>
                                </div>
                            </div>
                        </div> -->

                        <div class="pt-5 overflow-y-auto overflow-x-hidden max-h-[400px]">
                            <!-- Display items in the cart with Remove and Quantity input fields -->
                            <?php
                            $cart = isset($_SESSION['cart']) ? $_SESSION['cart'] : [];
                            foreach ($cart as $index => $cartItem) :
                                $itemTotalPrice = $cartItem['price'] * $cartItem['orderQuantity'];
                            ?>

                                <div class="flex flex-col p-4 text-lg font-semibold border rounded-sm shadow-md">
                                    <div class="flex flex-col justify-between gap-3 md:flex-row">

                                        <div class="flex flex-row items-center gap-6">

                                            <div class="w-28 h-28">
                                                <img class="w-full h-full rounded-xl" src="../../images/green scansavor logo.png" alt="images">
                                            </div>

                                            <div class="flex flex-col ">
                                                <p class="text-lg font-semibold text-gray-800"><?php echo $cartItem['itemName']; ?></p>
                                                <p class="text-xs font-semibold text-gray-600">Quantity: <span><?php echo $cartItem['orderQuantity']; ?></span></p>
                                                <p class="text-xs font-bold text-gray-600">₱<span class="font-bold"><?php echo $cartItem['price']; ?></span></p>

                                                <!-- quantity -->


                                                <div class="flex flex-row self-center gap-1">
                                                    <!-- <form method="POST" action="<?php echo $_SERVER["PHP_SELF"]; ?>">
                                                        <button class="self-center w-5 h-5 border border-gray-300 rounded-full" name="updateQuantity" value="decrease" data-index="<?php echo $index; ?>">
                                                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="#d1d5db" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                                                <path d="M5 12h14" />
                                                            </svg>
                                                        </button>

                                                        <input type="hidden" name="itemIndex" value="<?php echo $index; ?>">
                                                        <input type="text" readonly="readonly" min="1" name="quantity" value="<?php echo $cartItem['orderQuantity']; ?>" class="w-8 h-8 text-sm text-center text-gray-900 border border-gray-300 rounded-sm outline-none">

                                                        <button class="self-center w-5 h-5 border border-gray-300 rounded-full" name="updateQuantity" value="increase" data-index="<?php echo $index; ?>">
                                                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="" stroke="#9ca3af" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                                                <path d="M12 5v14M5 12h14" />
                                                            </svg>
                                                        </button>
                                                    </form> -->

                                                    <form id="updateQuantityform" method="POST" action="" onsubmit="updateQuantity(); return false;">
                                                        <button class="self-center w-5 h-5 border border-gray-300 rounded-full" name="updateQuantity" value="decrease">
                                                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="#d1d5db" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                                                <path d="M5 12h14" />
                                                            </svg>
                                                        </button>

                                                        <input type="hidden" name="itemIndex" value="<?php echo $index; ?>">
                                                        <input type="text" name="quantity" value="<?php echo $cartItem['orderQuantity']; ?>" class="w-8 h-8 text-sm text-center text-gray-900 border border-gray-300 rounded-sm outline-none">

                                                        <button class="self-center w-5 h-5 border border-gray-300 rounded-full" name="updateQuantity" value="increase">
                                                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="" stroke="#9ca3af" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                                                <path d="M12 5v14M5 12h14" />
                                                            </svg>
                                                        </button>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>

                                        <form id="removeForm" method="POST" action="" onsubmit="removeItem(); return false;">
                                            <div class="flex flex-col justify-between flex-grow ml-4">
                                                <input type="hidden" name="itemIndex" value="<?php echo $index; ?>">
                                                <button type="submit" name="removeItem" value="removeItem">
                                                    <svg class="w-8 h-8 p-1 rounded-full hover:bg-gray-100 hover:text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path>
                                                    </svg>
                                                </button>
                                                <span class="w-1/5 text-sm font-semibold text-center">₱<?php echo $itemTotalPrice; ?></span>
                                            </div>
                                        </form>
                                    </div>
                                </div>

                            <?php
                                $totalPrice += $itemTotalPrice;
                            endforeach;
                            ?>
                            <hr class="bg-gray-200 h-0.5">


                        </div>
                        <div class="flex justify-between py-3 lg:px-24">
                            <p class="text-gray-800">TOTAL</p>
                            <div>
                                <p class="font-bold text-end">₱<?php echo $totalPrice; ?></p>
                            </div>
                        </div>
                        <div class="flex gap-2">
                            <button type="submit" class="w-full p-2 py-3 text-sm font-semibold text-gray-700 uppercase bg-white border border-gray-200 rounded shadow-md hover:bg-teal-800 hover:text-white" name="addOnOrder" id="addOnOrder" value="addOnOrder" onclick="getData()">
                                Add Order
                            </button>

                            <button type="button" class="w-full p-2 py-3 text-sm font-semibold text-gray-700 uppercase bg-white border border-gray-200 rounded shadow-md hover:bg-teal-400" id="cancelButton" data-modal-toggle="cancelModal" data-modal-hide="viewCartModal">
                                Cancel Order
                            </button>
                        </div>

                        <a href="../viewCustomer/orderSummary.php?orderID=<?php echo $_SESSION['orderID']; ?>">
                            <button type="button" class="w-full p-2 py-3 text-sm font-semibold text-gray-700 uppercase bg-white border border-gray-200 rounded shadow-md hover:bg-teal-800 hover:text-white">View Summary</button>
                        </a>
                </form>
            </section>
        </div>
    </div>
</div>
<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>

<script>
    function getData() {
        $.ajax({
            url: "/additionalorders.php?tableNo=<?php echo $tableNo; ?>&orderID=<?php echo $orderID; ?>",
            type: "post",
            success: function(data) {
                alert("success");
            }
        });
    }
</script>

<script>
    function updateQuantity() {
        var formData = $('#updateQuantityform').serialize(); // Serialize the form data

        $.ajax({
            type: 'POST',
            url: "/additionalorders.php?tableNo=<?php echo $tableNo; ?>&orderID=<?php echo $orderID; ?>",
            data: formData,
            dataType: 'json',
            success: function(response) {
                if (response.status === 'success') {
                    alert(response.message);

                    // Optionally, update any UI elements on the page
                    // For example, you can update the displayed quantity without reloading the page
                    // $('.quantity-display').text(response.newQuantity);
                } else {
                    alert(response.message);
                }
            },
            error: function(xhr, status, error) {
                console.error('AJAX error: ' + status + ', ' + error);
            }

        });
    }
</script>

<script>
    function removeItem() {
        var formData = $('#removeForm').serialize(); // Serialize the form data

        $.ajax({
            type: 'POST',
            url: "/additionalorders.php?tableNo=<?php echo $tableNo; ?>&orderID=<?php echo $orderID; ?>",
            data: formData,
            dataType: 'json',
            success: function(response) {
                if (response.status === 'success') {
                    alert(response.message);

                    // Optionally, update any UI elements on the page
                    // For example, you can update the displayed quantity without reloading the page
                    // $('.quantity-display').text(response.newQuantity);
                } else {
                    alert(response.message);
                }
            },
            error: function(xhr, status, error) {
                console.error('AJAX error: ' + status + ', ' + error);
            }

        });
    }
</script>