<?php
//include '../forms/continue.php';
include '../forms/cancel.php';
include '../forms/remove.php';
// include '../forms/scanner.php';


global $conn;

$tableNumbers = [];
$tableQuery = "SELECT tableNo FROM tbltable WHERE isOccupied = 0"; // Assuming you want to fetch only unoccupied tables
$tableResult = $conn->query($tableQuery);

$_SESSION['orderID'] = '';

$tableNo = '';
$orderID = '';
$cartID = '';
$itemID = '';


if (isset($_POST['tableNo'])) {
    $tableNum = $_POST['tableNo'];

    if ($tableResult->num_rows > 0) {
        while ($row = $tableResult->fetch_assoc()) {
            $tableNumbers[] = $row['tableNo'];
        }
    }
}

//Check if the diningChoice is set in the session
if (!isset($_SESSION['diningChoice'])) {
    // Handle the case where the dining choice is not set (perhaps redirect or show an error message)
    echo '<alert>alert("Dining choice not set. Please make a selection.");</alert>';
    echo "Error: Dining choice not set.";
    exit();
}

// Access the dining choice
$diningChoice = $_SESSION['diningChoice'];



if (isset($_POST['addToCart'])) {
    $itemID = $_POST['itemID'];
    $orderQuantity = $_POST['orderQuantity'];

    // Check if it's an item or a menu package
    if (isset($_POST['isMenuPackage']) && $_POST['isMenuPackage'] == 1) {
        // It's a menu package
        $getPackageInfoQuery = "SELECT mi.packageID, mi.packageName, mi.packagePrice
        FROM tblmenupackage mi
        WHERE mi.packageID = ?";
        $getPackageInfoStmt = $conn->prepare($getPackageInfoQuery);
        $getPackageInfoStmt->bind_param("i", $itemID);
        $getPackageInfoStmt->execute();
        $getPackageInfoResult = $getPackageInfoStmt->get_result();

        if ($getPackageInfoResult->num_rows === 1) {
            $packageData = $getPackageInfoResult->fetch_assoc();
            $packageID = $itemID;
            $packageName = $packageData['packageName'];
            $packagePrice = $packageData['packagePrice'];

            // Add menu package to cart
            addPackageToCart($packageID, $packageName, $orderQuantity, $packagePrice);
        } else {
            // Handle error if the package is not found
            echo "Error: Package not found.";
            exit();
        }

        $getPackageInfoStmt->close();
    } else {
        // It's a regular item
        // Retrieve the selected item details from tblfooditems
        $query = "SELECT * FROM tblfooditems WHERE itemID = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("i", $itemID);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows === 1) {
            $item = $result->fetch_assoc();

            // Add regular item to cart
            addToCart($itemID, $item['itemName'], $orderQuantity, $item['price']);
        } else {
            // Item not found in the database
            echo "Error: Item not found in the database.";
        }

        $stmt->close();
    }
}

// Function to add items to the cart

function addPackageToCart($packageID, $packageName, $orderQuantity, $packagePrice)
{
    // Create or update the user's cart in the session
    if (!isset($_SESSION['cart'])) {
        $_SESSION['cart'] = [];
    }

    // Check if the package is already in the cart
    $packageIndex = -1;
    foreach ($_SESSION['cart'] as $index => $cartItem) {
        if (isset($cartItem['packageID']) && $cartItem['packageID'] == $packageID) {
            // Package already exists in the cart, update the quantity
            $_SESSION['cart'][$index]['orderQuantity'] += $orderQuantity;
            $packageIndex = $index;
            break;
        }
    }

    if ($packageIndex === -1) {
        // Package is not in the cart, add it
        $cartItem = [
            'packageID' => $packageID,
            'packageName' => $packageName,
            'packagePrice' => $packagePrice,
            'orderQuantity' => $orderQuantity,
            'price' => $packagePrice,
            'itemName' => $packageName,
        ];

        $_SESSION['cart'][] = $cartItem;
    }

    // Package added to cart successfully or quantity updated
    // You can add an alert or other feedback here
}

function addToCart($itemID, $itemName, $orderQuantity, $price)
{
    // Create or update the user's cart in the session
    if (!isset($_SESSION['cart'])) {
        $_SESSION['cart'] = [];
    }

    // Check if the item is already in the cart
    $itemIndex = -1;
    foreach ($_SESSION['cart'] as $index => $cartItem) {
        if (isset($cartItem['itemID']) && $cartItem['itemID'] == $itemID) {
            // Item already exists in the cart, update the quantity
            $_SESSION['cart'][$index]['orderQuantity'] += $orderQuantity;
            $itemIndex = $index;
            break;
        }
    }

    if ($itemIndex === -1) {
        // Item is not in the cart, add it
        $cartItem = [
            'itemID' => $itemID,
            'itemName' => $itemName,
            'price' => $price,
            'orderQuantity' => $orderQuantity,
        ];

        $_SESSION['cart'][] = $cartItem;
    }

    // Item added to cart successfully or quantity updated
    // You can add an alert or other feedback here
}


$totalPrice = 0;
$message = '';

if (isset($_POST['saveOrderCustomer'])) {
    // Check if the session has started
    if (session_status() == PHP_SESSION_ACTIVE) {
        // Get the table number from POST data
        $tableNumber = $_POST['tableNum'];

        // Check if the table exists
        $tableCheckQuery = "SELECT * FROM tbltable WHERE tableNo = ?";
        $tableCheckStmt = $conn->prepare($tableCheckQuery);
        $tableCheckStmt->bind_param("i", $tableNumber);
        $tableCheckStmt->execute();
        $tableCheckResult = $tableCheckStmt->get_result();

        if ($tableCheckResult->num_rows > 0) {
            $tableData = $tableCheckResult->fetch_assoc();

            if ($tableData['isOccupied'] == 0) {
                $conn->begin_transaction();

                try {
                    // Calculate the total amount
                    $totalPrice = 0;

                    foreach ($_SESSION['cart'] as $cartItem) {
                        $itemTotalPrice = $cartItem['price'] * $cartItem['orderQuantity'];
                        $totalPrice += $itemTotalPrice;
                    }

                    // Get the cartID from the session
                    $cartSession = $_SESSION['cartID'];

                    // // Get special request from POST data
                    // $specialRequest = $_POST['specialReqs'];

                    // Query to retrieve cart details using cartID
                    $cartDetailsQuery = "SELECT * FROM tblcartdetails WHERE cartID = ?";
                    $cartDetailsStmt = $conn->prepare($cartDetailsQuery);
                    $cartDetailsStmt->bind_param("i", $cartSession);
                    $cartDetailsStmt->execute();
                    $cartDetailsResult = $cartDetailsStmt->get_result();

                    $specialRequest = isset($_POST['specialReqs']) ? $_POST['specialReqs'] : '';

                    if ($cartDetailsResult->num_rows > 0) {
                        // Insert the order into the database
                        $orderQuery = "INSERT INTO tblOrders (isDineIn, orderStatus, totalAmount, tableNo, cartID, specialRequest) VALUES (1, 'ForApproval', ?, ?, ?, ?)";
                        $orderStmt = $conn->prepare($orderQuery);
                        $orderStmt->bind_param("diis", $totalPrice, $tableNumber, $cartSession, $specialRequest);

                        $updateTableQuery = "UPDATE tbltable SET isOccupied = 1 WHERE tableNo = ?";
                        $updateTableStmt = $conn->prepare($updateTableQuery);
                        $updateTableStmt->bind_param("i", $tableNumber);
                        $updateTableStmt->execute();

                        // Execute the order query
                        if ($orderStmt->execute()) {
                            $orderID = $orderStmt->insert_id;

                            // Insert each item in the cart into tblOrderDetails
                            while ($cartItem = $cartDetailsResult->fetch_assoc()) {
                                $itemID = $cartItem['itemID'];
                                $packageID = $cartItem['packageID'];
                                $itemQuantity = $cartItem['orderQuantity'];
                                $itemTotalPrice = $cartItem['price'] * $cartItem['orderQuantity'];

                                // Determine whether the item is a regular item or a menu package
                                if (!empty($itemID)) {
                                    // Regular item
                                    $orderDetailsQuery = "INSERT INTO tblorderdetails (orderID, itemID, itemQuantity, Amount, status) VALUES (?, ?, ?, ?, 'ForApproval')";
                                    $orderDetailsStmt = $conn->prepare($orderDetailsQuery);
                                    $orderDetailsStmt->bind_param("iiid", $orderID, $itemID, $itemQuantity, $itemTotalPrice);
                                } elseif (!empty($packageID)) {
                                    // Menu package
                                    $orderDetailsQuery = "INSERT INTO tblorderdetails (orderID, packageID, itemQuantity, Amount, status) VALUES (?, ?, ?, ?, 'ForApproval')";
                                    $orderDetailsStmt = $conn->prepare($orderDetailsQuery);
                                    $orderDetailsStmt->bind_param("iiid", $orderID, $packageID, $itemQuantity, $itemTotalPrice);
                                } else {
                                    // Handle the case where neither itemID nor packageID is set (an error condition)
                                    echo "Error: Invalid cart item.";
                                    exit();
                                }

                                // Execute the order details query
                                if (!$orderDetailsStmt->execute()) {
                                    throw new Exception("Failed to insert item into tblorderdetails. Error: " . $orderDetailsStmt->error);
                                }
                            }

                            // Commit the transaction
                            $conn->commit();

                            // Unset or destroy the cart session
                            unset($_SESSION['cart']);

                            // Get the cartID from the session (after unsetting cart session)
                            $cartSession = $_SESSION['cartID'];

                            // Query to retrieve order data using cartID
                            $cartSession = $_SESSION['cartID'];

                            // Query to retrieve order data using cartID
                            $orderDataQuery = "SELECT * FROM tblOrders WHERE cartID = ?";
                            $orderDataStmt = $conn->prepare($orderDataQuery);
                            $orderDataStmt->bind_param("i", $cartSession);
                            $orderDataStmt->execute();
                            $orderDataResult = $orderDataStmt->get_result();

                            $_SESSION['cartID'] = NULL; // replace this with your actual function to generate a new cartID

                            if ($orderDataResult->num_rows > 0) {
                                // Fetch and display order data
                                while ($row = $orderDataResult->fetch_assoc()) {
                                    // Store order details in variables
                                    $orderID = $row['orderID'];
                                    $_SESSION['orderID'] = $orderID;
                                    $_cartID = $row['cartID'];
                                    $SESSION['cartID'] = $cartID;
                                    $tableNo = $row['tableNo'];
                                    $totalAmount = $row['totalAmount'];
                                    $orderStatus = $row['orderStatus'];
                                    $processedBy = $row['processedBy'];

                                    // Query to retrieve order details data using orderID
                                    $orderDetailsDataQuery = "SELECT * FROM tblorderdetails WHERE orderID = ?";
                                    $orderDetailsDataStmt = $conn->prepare($orderDetailsDataQuery);
                                    $orderDetailsDataStmt->bind_param("i", $orderID);
                                    $orderDetailsDataStmt->execute();
                                    $orderDetailsDataResult = $orderDetailsDataStmt->get_result();

                                    if ($orderDetailsDataResult->num_rows > 0) {
                                        // Fetch and display order details data
                                        while ($rowDetails = $orderDetailsDataResult->fetch_assoc()) {
                                            // Store order details in variables
                                            $itemID = $rowDetails['itemID'];
                                            $packageID = $rowDetails['packageID'];
                                            $itemQuantity = $rowDetails['itemQuantity'];
                                            $Amount = $rowDetails['Amount'];

                                            // Query to retrieve food items data using itemID
                                            $foodItemsDataQuery = "SELECT * FROM tblfooditems WHERE itemID = ?";
                                            $foodItemsDataStmt = $conn->prepare($foodItemsDataQuery);
                                            $foodItemsDataStmt->bind_param("i", $itemID);
                                            $foodItemsDataStmt->execute();
                                            $foodItemsDataResult = $foodItemsDataStmt->get_result();

                                            $mergedData = array();

                                            if ($foodItemsDataResult->num_rows > 0) {
                                                // Fetch and display food items data
                                                while ($rowFoodItems = $foodItemsDataResult->fetch_assoc()) {
                                                    // Store food items details in variables
                                                    $foodItemName = $rowFoodItems['itemName'];
                                                    $foodItemPrice = $rowFoodItems['price'];
                                                    $foodItemImage = $rowFoodItems['itemImage'];

                                                    // Merge the food item and order details into the mergedData array
                                                    $mergedData[] = array(
                                                        'processedBy' => $processedBy,
                                                        'packageID' => $packageID,
                                                        'orderID' => $orderID,
                                                        'tableNo' => $tableNo,
                                                        'itemName' => $foodItemName,
                                                        'price' => $foodItemPrice,
                                                        'itemQuantity' => $itemQuantity,
                                                        'MaxAmount' => $Amount,
                                                        'orderStatus' => $orderStatus,
                                                        'itemImage' => $foodItemImage,
                                                        'itemID' => $itemID,
                                                        'totalAmount' => $totalAmount
                                                    );
                                                }
                                            } else {
                                                echo "No food items data found for itemID: " . $itemID;
                                            }
                                        }
                                    } else {
                                        echo "No order details data found for orderID: " . $orderID;
                                    }
                                }
                            } else {
                                echo "No order data found for cartID: " . $cartSession;
                            }

                            $_SESSION['cartID'] = NULL; // replace this with your actual function to generate a new cartID

                            // Unset or destroy the cart session after retrieving order data
                            unset($_SESSION['cart']);

                            $message = "Order placed successfully!";
                            echo '<script>window.location.href = "../viewCustomer/orderSummary.php?orderID=' . $orderID . '&tableNo=' . $tableNo . '";</script>';
                        } else {
                            throw new Exception("Failed to insert order into tblOrders.");
                        }
                    } else {
                        // Handle the case where no cart details are found
                        echo "Error: No cart details found.";
                        exit();
                    }

                    $cartDetailsStmt->close();
                } catch (Exception $e) {
                    // Roll back the transaction in case of an error
                    $conn->rollback();
                    echo "Transaction failed: " . $e->getMessage();
                }
            } else {
                echo "<script>
                    alert('The table is occupied.');
                </script>";
            }
        } else {
            // The table does not exist, handle the error
            echo "<script>
                alert('The table is non-existent.');
            </script>";
        }
    } else {
        echo "Session not active.";
    }
}

if (isset($_POST['updateQuantity'])) {
    if (isset($_POST['itemIndex'])) {
        $itemIndex = $_POST['itemIndex'];
        $currentQuantity = $_SESSION['cart'][$itemIndex]['orderQuantity'];

        if ($_POST['updateQuantity'] == 'decrease') {
            // Decrease quantity
            $newQuantity = max(0, $currentQuantity - 1);

            $itemID = isset($_SESSION['cart'][$itemIndex]['itemID']) ? $_SESSION['cart'][$itemIndex]['itemID'] : null;

            // Update the item's quantity in the session cart
            $_SESSION['cart'][$itemIndex]['orderQuantity'] = $newQuantity;

            // Update the item's quantity in the database
            $itemID = isset($_SESSION['cart'][$itemIndex]['itemID']) ? $_SESSION['cart'][$itemIndex]['itemID'] : null;
            $packageID = isset($_SESSION['cart'][$itemIndex]['packageID']) ? $_SESSION['cart'][$itemIndex]['packageID'] : null;

            // Use a single query with a condition for both itemID and packageID
            $updateQuantityQuery = "UPDATE tblcartdetails SET orderQuantity = ? WHERE ";
            if ($itemID !== null) {
                $updateQuantityQuery .= "itemID = ?";
            } elseif ($packageID !== null) {
                $updateQuantityQuery .= "packageID = ?";
            }

            $updateQuantityStmt = $conn->prepare($updateQuantityQuery);

            // Bind parameters based on whether it's an item or a package
            if ($itemID !== null) {
                $updateQuantityStmt->bind_param("ii", $newQuantity, $itemID);
            } elseif ($packageID !== null) {
                $updateQuantityStmt->bind_param("ii", $newQuantity, $packageID);
            }

            if ($updateQuantityStmt->execute()) {
                // Update the serving in tblfooditems for items only
                if ($itemID !== null) {
                    $updateServingQuery = "UPDATE tblfooditems SET serving = serving + 1 WHERE itemID = ?";
                    $updateServingStmt = $conn->prepare($updateServingQuery);
                    $updateServingStmt->bind_param("i", $itemID);
                
                    if ($updateServingStmt->execute()) {
                        // Check if serving is greater than 0, set availability and dishStatus
                        $checkServingQuery = "SELECT serving FROM tblfooditems WHERE itemID = ?";
                        $checkServingStmt = $conn->prepare($checkServingQuery);
                        $checkServingStmt->bind_param("i", $itemID);
                        $checkServingStmt->execute();
                        $checkServingResult = $checkServingStmt->get_result();
                
                        if ($checkServingResult->num_rows === 1) {
                            $servingData = $checkServingResult->fetch_assoc();
                            $currentServing = $servingData['serving'];
                        
                            if ($currentServing > 0) {
                                // Serving is greater than 0, set availability to Available and dishStatus to In Stock
                                $updateStatusQuery = "UPDATE tblfooditems SET availability = 'Available', dishStatus = 'In Stock' WHERE itemID = ?";
                                $updateStatusStmt = $conn->prepare($updateStatusQuery);
                                $updateStatusStmt->bind_param("i", $itemID);
                        
                                if (!$updateStatusStmt->execute()) {
                                    // Log error to a server log for further analysis
                                    error_log('Failed to update status in tblfooditems. Error: ' . $updateStatusStmt->error);
                                    echo "<script>alert('Failed to update status in tblfooditems. Please try again.');</script>";
                                } else {
                                    // Check if the item is part of any menu package
                                    $checkMenuPackageItemQuery = "SELECT packageID FROM tblmenupackageitems WHERE itemID = ?";
                                    $checkMenuPackageItemStmt = $conn->prepare($checkMenuPackageItemQuery);
                                    $checkMenuPackageItemStmt->bind_param("i", $itemID);
                                    $checkMenuPackageItemStmt->execute();
                                    $checkMenuPackageItemResult = $checkMenuPackageItemStmt->get_result();
                        
                                    if ($checkMenuPackageItemResult->num_rows > 0) {
                                        // If the item is part of any menu package, fetch all related packageIDs
                                        $packageIDsQuery = "SELECT DISTINCT packageID FROM tblmenupackageitems WHERE itemID = ?";
                                        $packageIDsStmt = $conn->prepare($packageIDsQuery);
                                        $packageIDsStmt->bind_param("i", $itemID);
                                        $packageIDsStmt->execute();
                                        $packageIDsResult = $packageIDsStmt->get_result();
                                        $packageIDsStmt->close();
                                    
                                        while ($packageRow = $packageIDsResult->fetch_assoc()) {
                                            $packageID = $packageRow['packageID'];
                                    
                                            // Check the availability of all items in the package
                                            $checkPackageAvailabilityQuery = "SELECT COUNT(fi.itemID) AS unavailable_items
                                                                              FROM tblfooditems fi
                                                                              INNER JOIN tblmenupackageitems mpi ON fi.itemID = mpi.itemID
                                                                              WHERE mpi.packageID = ? AND fi.availability = 'Unavailable'";
                                            $checkPackageAvailabilityStmt = $conn->prepare($checkPackageAvailabilityQuery);
                                            $checkPackageAvailabilityStmt->bind_param("i", $packageID);
                                            $checkPackageAvailabilityStmt->execute();
                                            $unavailableItemsCount = $checkPackageAvailabilityStmt->get_result()->fetch_assoc()['unavailable_items'];
                                            $checkPackageAvailabilityStmt->close();
                                    
                                            if ($unavailableItemsCount === 0) {
                                                // If all items in the package are available, set the package availability to Available
                                                $updateMenuPackageAvailabilityQuery = "UPDATE tblmenupackage SET availability = 'Available' WHERE packageID = ?";
                                                $updateMenuPackageAvailabilityStmt = $conn->prepare($updateMenuPackageAvailabilityQuery);
                                                $updateMenuPackageAvailabilityStmt->bind_param("i", $packageID);
                                    
                                                if (!$updateMenuPackageAvailabilityStmt->execute()) {
                                                    // Log error to a server log for further analysis
                                                    error_log('Failed to update status in tblmenupackage. Error: ' . $updateMenuPackageAvailabilityStmt->error);
                                                    echo "<script>alert('Failed to update status in tblmenupackage. Please try again.');</script>";
                                                }
                                    
                                                $updateMenuPackageAvailabilityStmt->close();
                                            }
                                        }
                                    }                                    
                        
                                    $checkMenuPackageItemStmt->close();
                                }
                        
                                $updateStatusStmt->close();
                            }
                        }                                   
                
                        $checkServingStmt->close();
                    } else {
                        error_log('Failed to update serving in tblfooditems. Error: ' . $updateServingStmt->error);
                        echo "<script>alert('Failed to update serving in tblfooditems. Please try again.');</script>";
                    }
                }

                // Check if the new quantity is zero, and delete the order
                if ($newQuantity === 0) {
                    // Get the item details
                    $itemID = isset($_SESSION['cart'][$itemIndex]['itemID']) ? $_SESSION['cart'][$itemIndex]['itemID'] : null;
                    $packageID = isset($_SESSION['cart'][$itemIndex]['packageID']) ? $_SESSION['cart'][$itemIndex]['packageID'] : null;

                    // Delete the item from the session cart
                    unset($_SESSION['cart'][$itemIndex]);

                    // Delete the item from the database
                    $deleteOrderQuery = "DELETE FROM tblcartdetails WHERE ";
                    if ($itemID !== null) {
                        $deleteOrderQuery .= "itemID = ?";
                    } elseif ($packageID !== null) {
                        $deleteOrderQuery .= "packageID = ?";
                    }

                    $deleteOrderStmt = $conn->prepare($deleteOrderQuery);

                    // Bind parameters based on whether it's an item or a package
                    if ($itemID !== null) {
                        $deleteOrderStmt->bind_param("i", $itemID);
                    } elseif ($packageID !== null) {
                        $deleteOrderStmt->bind_param("i", $packageID);
                    }

                    if ($deleteOrderStmt->execute()) {
                        // echo "<script>alert('Order deleted successfully!');</script>";
                    } else {
                        // Log error to a server log for further analysis
                        error_log('Failed to delete order from the database. Error: ' . $deleteOrderStmt->error);
                        echo "<script>alert('Failed to delete order from the database. Please try again.');</script>";
                    }
                }
            } else {
                // Log error to a server log for further analysis
                error_log('Failed to update quantity in the database. Error: ' . $updateQuantityStmt->error);
                echo "<script>alert('Failed to update quantity in the database. Please try again.');</script>";
            }
        } elseif ($_POST['updateQuantity'] == 'increase') {
            // Increase quantity
            $newQuantity = $currentQuantity + 1;
        
            $itemID = isset($_SESSION['cart'][$itemIndex]['itemID']) ? $_SESSION['cart'][$itemIndex]['itemID'] : null;
            $packageID = isset($_SESSION['cart'][$itemIndex]['packageID']) ? $_SESSION['cart'][$itemIndex]['packageID'] : null;
        
            // Check if serving is greater than 0 in tblfooditems
            $checkServingQuery = "SELECT serving FROM tblfooditems WHERE itemID = ?";
            $checkServingStmt = $conn->prepare($checkServingQuery);
            $checkServingStmt->bind_param("i", $itemID);
            $checkServingStmt->execute();
            $checkServingResult = $checkServingStmt->get_result();
        
            if ($checkServingResult->num_rows === 1) {
                $servingData = $checkServingResult->fetch_assoc();
                $currentServing = $servingData['serving'];
        
                // Check if serving is greater than 0 before updating orderQuantity
                if ($currentServing > 0) {
                    // Update the item's quantity in the session cart
                    $_SESSION['cart'][$itemIndex]['orderQuantity'] = $newQuantity;
        
                    // Update the item's quantity in the database
                    $updateQuantityQuery = "UPDATE tblcartdetails SET orderQuantity = ? WHERE ";
                    if ($itemID !== null) {
                        $updateQuantityQuery .= "itemID = ?";
                    } elseif ($packageID !== null) {
                        $updateQuantityQuery .= "packageID = ?";
                    }
        
                    $updateQuantityStmt = $conn->prepare($updateQuantityQuery);
        
                    // Bind parameters based on whether it's an item or a package
                    if ($itemID !== null) {
                        $updateQuantityStmt->bind_param("ii", $newQuantity, $itemID);
                    } elseif ($packageID !== null) {
                        $updateQuantityStmt->bind_param("ii", $newQuantity, $packageID);
                    }
        
                    if ($updateQuantityStmt->execute()) {
                        if ($itemID !== null) {
                            $updateServingQuery = "UPDATE tblfooditems SET serving = serving - 1 WHERE itemID = ?";
                            $updateServingStmt = $conn->prepare($updateServingQuery);
                            $updateServingStmt->bind_param("i", $itemID);
        
                            if ($updateServingStmt->execute()) {
                                // Check if serving is equal to or less than 0, set availability and dishStatus
                                $checkServingQuery = "SELECT serving FROM tblfooditems WHERE itemID = ?";
                                $checkServingStmt = $conn->prepare($checkServingQuery);
                                $checkServingStmt->bind_param("i", $itemID);
                                $checkServingStmt->execute();
                                $checkServingResult = $checkServingStmt->get_result();
        
                                if ($checkServingResult->num_rows === 1) {
                                    $servingData = $checkServingResult->fetch_assoc();
                                    $currentServing = $servingData['serving'];
        
                                    if ($currentServing <= 0) {
                                        // Serving is equal to or less than 0, set availability to Unavailable and dishStatus to Out of Stock
                                        $updateStatusQuery = "UPDATE tblfooditems SET availability = 'Unavailable', dishStatus = 'Out of Stock' WHERE itemID = ?";
                                        $updateStatusStmt = $conn->prepare($updateStatusQuery);
                                        $updateStatusStmt->bind_param("i", $itemID);
        
                                        if (!$updateStatusStmt->execute()) {
                                            // Log error to a server log for further analysis
                                            error_log('Failed to update status in tblfooditems. Error: ' . $updateStatusStmt->error);
                                            echo "<script>alert('Failed to update status in tblfooditems. Please try again.');</script>";
                                        } else {
                                            // Check if the item is part of any menu package
                                            $checkMenuPackageItemQuery = "SELECT packageID FROM tblmenupackageitems WHERE itemID = ?";
                                            $checkMenuPackageItemStmt = $conn->prepare($checkMenuPackageItemQuery);
                                            $checkMenuPackageItemStmt->bind_param("i", $itemID);
                                            $checkMenuPackageItemStmt->execute();
                                            $checkMenuPackageItemResult = $checkMenuPackageItemStmt->get_result();
        
                                            if ($checkMenuPackageItemResult->num_rows > 0) {
                                                // If the item is part of any menu package, update availability in tblmenupackage
                                                while ($row = $checkMenuPackageItemResult->fetch_assoc()) {
                                                    $updateMenuPackageAvailabilityQuery = "UPDATE tblmenupackage SET availability = 'Unavailable' WHERE packageID = ?";
                                                    $updateMenuPackageAvailabilityStmt = $conn->prepare($updateMenuPackageAvailabilityQuery);
                                                    $updateMenuPackageAvailabilityStmt->bind_param("i", $row['packageID']);
                                                    $updateMenuPackageAvailabilityStmt->execute();
                                                    $updateMenuPackageAvailabilityStmt->close();
                                                }
                                            }
        
                                            $checkMenuPackageItemStmt->close();
                                        }
        
                                        $updateStatusStmt->close();
                                    }
                                }
        
                                $checkServingStmt->close();
                            } else {
                                error_log('Failed to update serving in tblfooditems. Error: ' . $updateServingStmt->error);
                                echo "<script>alert('Failed to update serving in tblfooditems. Please try again.');</script>";
                            }
                        }
                    } else {
                        // Log error to a server log for further analysis
                        error_log('Failed to update quantity in the database. Error: ' . $updateQuantityStmt->error);
                        echo "<script>alert('Failed to update quantity in the database. Please try again.');</script>";
                    }
        
                    $updateQuantityStmt->close();
                } else {
                    $message = "Cannot increase quantity. Item is out of stock.";
                }
            } else {
                // Handle the case where the item is not found in tblfooditems
                echo "<script>alert('Error: Item not found.');</script>";
            }
        
        }        
    }
}

if (isset($_POST['removeItem'])) {
    if (isset($_POST['itemIndex'])) {
        $itemIndex = filter_var($_POST['itemIndex'], FILTER_VALIDATE_INT, array('options' => array('min_range' => 0)));

        // Check if the itemIndex is valid
        if (isset($_SESSION['cart'][$itemIndex])) {
            $cart = $_SESSION['cart']; // Read the cart from the session

            // Check if 'itemID' and 'packageID' keys are set, and assign them accordingly
            $itemID = isset($cart[$itemIndex]['itemID']) ? $cart[$itemIndex]['itemID'] : null;
            $packageID = isset($cart[$itemIndex]['packageID']) ? $cart[$itemIndex]['packageID'] : null;
            $orderQuantity = isset($cart[$itemIndex]['orderQuantity']) ? $cart[$itemIndex]['orderQuantity'] : 0;

            // Determine whether it's an item or package and get the corresponding ID
            $IDToDelete = isset($itemID) ? $itemID : (isset($packageID) ? $packageID : null);

            if ($IDToDelete !== null) {
                // Create a DELETE query to remove the item or package from tblcartdetails
                $deleteQuery = "DELETE FROM tblcartdetails WHERE itemID = ? OR packageID = ?";
                $deleteStmt = $conn->prepare($deleteQuery);
                $deleteStmt->bind_param("ii", $IDToDelete, $IDToDelete);

                if ($deleteStmt->execute()) {
                    // Update serving quantity in tblfooditems
                    $updateServingQuery = "UPDATE tblfooditems SET serving = serving + ? WHERE itemID = ?";
                    $updateServingStmt = $conn->prepare($updateServingQuery);
                    $updateServingStmt->bind_param("ii", $orderQuantity, $IDToDelete);
                    $updateServingStmt->execute();

                    // Update availability and dishStatus if serving is greater than 0
                    if ($orderQuantity > 0) {
                        $updateAvailabilityQuery = "UPDATE tblfooditems SET availability = 'Available', dishStatus = 'In Stock' WHERE itemID = ?";
                        $updateAvailabilityStmt = $conn->prepare($updateAvailabilityQuery);
                        $updateAvailabilityStmt->bind_param("i", $IDToDelete);
                        $updateAvailabilityStmt->execute();

                        // Check if the item is part of any menu package
                        $checkMenuPackageItemQuery = "SELECT packageID FROM tblmenupackageitems WHERE itemID = ?";
                        $checkMenuPackageItemStmt = $conn->prepare($checkMenuPackageItemQuery);
                        $checkMenuPackageItemStmt->bind_param("i", $IDToDelete);
                        $checkMenuPackageItemStmt->execute();
                        $checkMenuPackageItemResult = $checkMenuPackageItemStmt->get_result();

                        while ($row = $checkMenuPackageItemResult->fetch_assoc()) {
                            // Check if all items in the menu package are 'Available'
                            $checkPackageAvailabilityQuery = "SELECT COUNT(fi.itemID) AS unavailable_items
                                                              FROM tblfooditems fi
                                                              INNER JOIN tblmenupackageitems mpi ON fi.itemID = mpi.itemID
                                                              WHERE mpi.packageID = ? AND fi.availability = 'Unavailable'";
                            $checkPackageAvailabilityStmt = $conn->prepare($checkPackageAvailabilityQuery);
                            $checkPackageAvailabilityStmt->bind_param("i", $row['packageID']);
                            $checkPackageAvailabilityStmt->execute();
                            $unavailableItemsCount = $checkPackageAvailabilityStmt->get_result()->fetch_assoc()['unavailable_items'];
                            $checkPackageAvailabilityStmt->close();

                            if ($unavailableItemsCount === 0) {
                                // If all items in the package are 'Available', set the package availability to 'Available'
                                $updateMenuPackageAvailabilityQuery = "UPDATE tblmenupackage SET availability = 'Available' WHERE packageID = ?";
                                $updateMenuPackageAvailabilityStmt = $conn->prepare($updateMenuPackageAvailabilityQuery);
                                $updateMenuPackageAvailabilityStmt->bind_param("i", $row['packageID']);
                                $updateMenuPackageAvailabilityStmt->execute();
                                $updateMenuPackageAvailabilityStmt->close();
                            }
                        }

                        $checkMenuPackageItemStmt->close();
                    }

                    // Remove the item or package from the session cart
                    unset($cart[$itemIndex]);

                    // Reindex the session cart array
                    $cart = array_values($cart);
                    $_SESSION['cart'] = $cart;

                    //  echo "<script>alert('Item removed successfully!');</script>";
                } else {
                    echo "<script>alert('Failed to remove item or package from the database.');</script>";
                }
            }
        }
    }
}

?>

<div id="viewCartModal" tabindex="-1" aria-hidden="true" class="hidden overflow-y-auto overflow-x-hidden fixed top-0 right-0 left-0 z-50 justify-center items-center w-full md:inset-0 h-[calc(100%-1rem)] md:h-full">
    <div class="relative w-full h-full max-w-xl p-4 md:h-auto">
        <!-- Modal content -->
        <div class="relative p-4 bg-white rounded-2xl shadow">
            <!-- Modal header -->
            <div class="flex items-center justify-between pb-4 mb-4 border-b rounded-t sm:mb-5">
                <h3 class="text-lg font-semibold text-gray-900">Cart</h3>
                <button type="button" class="text-gray-400 bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm p-1.5 ml-auto inline-flex items-center" data-modal-toggle="viewCartModal">
                    <svg aria-hidden="true" class="w-5 h-5" fill="currentColor" viewbox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                        <path fill-rule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1s 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clip-rule="evenodd" />
                    </svg>
                    <span class="sr-only">Close modal</span>
                </button>
            </div>
            <!-- Modal body -->
            <section>
                <form method="POST" action="<?php echo $_SERVER["PHP_SELF"]; ?>">
                    <div class="max-w-5xl px-8 py-5 mx-auto">
                        <!-- <div class="lg:ml-20 lg:py-3">
                            <div id="qr-reader" class=" lg:w-80"></div>
                            <button id="start-scan" name="start-scan">Start QR Scan</button>
                        </div> -->
                        <div class="flex justify-center pb-5 hidden">
                            <label for="tableNum" class="text-lg font-medium text-gray-900">Table Number</label>
                            <div class="flex items-center">
                                <input type="text" id="tableNum" name="tableNum" class="text-lg font-bold text-teal-800 border-0 outline-none w-12 h-7 focus:ring-green-300" value="<?php echo $tableNo; ?>" readonly>
                            </div>
                        </div>
                        <!-- <button class="justify-center items-center text-center text-xs pl-32">Click this to scan the table side QR Code</button> -->

                        <div class="pt-1 rounded-xl overflow-y-auto overflow-x-hidden max-h-[400px]">
                            <!-- <p class="text-xl font-bold text-gray-500">Order Cart</p> -->

                            <!-- <hr class="bg-gray-200 h-0.5"> -->
                            <!-- Display items in the cart with Remove and Quantity input fields -->
                            <?php
                            $cart = isset($_SESSION['cart']) ? $_SESSION['cart'] : [];
                            foreach ($cart as $index => $cartItem) :
                                $itemTotalPrice = $cartItem['price'] * $cartItem['orderQuantity'];
                            ?>
                                <div class="">
                                    <div class="flex flex-col p-4 text-lg font-semibold">
                                        <div class="flex flex-col justify-between gap-3 md:flex-row">
                                            <div class="flex flex-row items-center gap-6">
                                                <!-- <div class="w-28 h-28">
                                                    <img class="w-full h-full rounded-xl" src="../../images/green scansavor logo.png" alt="images">
                                                </div> -->
                                                <div class="max-h-40 overflow-y-auto scrollbar-thin scrollbar-thumb-gray-300 scrollbar-track-gray-100">
                                                    <div class="flex flex-col ">
                                                        <p class="text-lg font-semibold text-gray-800"><?php echo $cartItem['itemName']; ?></p>
                                                        <p class="text-xs font-semibold text-gray-600">Quantity: <span><?php echo $cartItem['orderQuantity']; ?></span></p>
                                                        <p class="text-xs font-bold text-gray-600">₱<span class="font-bold"><?php echo $cartItem['price']; ?></span></p>

                                                        <!-- quantity -->

                                                        <div class="flex flex-row self-center gap-1">
                                                            <form method="POST" action="<?php echo $_SERVER["PHP_SELF"]; ?>">
                                                                <button class="self-center w-5 h-5 border border-gray-300 rounded-full" name="updateQuantity" value="decrease" data-index="<?php echo $index; ?>">
                                                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="#d1d5db" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                                                        <path d="M5 12h14" />
                                                                    </svg>
                                                                </button>

                                                                <input type="hidden" name="itemIndex" value="<?php echo $index; ?>">
                                                                <input type="text" readonly="readonly" min="1" name="quantity" value="<?php echo $cartItem['orderQuantity']; ?>" class="w-8 h-8 text-sm text-center text-gray-900 border border-gray-300 rounded-sm outline-none">

                                                                <button class="self-center w-5 h-5 border border-gray-300 rounded-full" name="updateQuantity" value="increase" data-index="<?php echo $index; ?>">
                                                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="" stroke="#9ca3af" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                                                        <path d="M12 5v14M5 12h14" />
                                                                    </svg>
                                                                </button>
                                                            </form>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <form id="removeForm" method="POST" action="" onsubmit="removeItem(); return false;">
                                                <div class="flex flex-col justify-between flex-grow ml-4">
                                                    <input type="hidden" name="itemIndex" value="<?php echo $index; ?>">
                                                    <button type="submit" name="removeItem" value="removeItem">
                                                        <svg class="w-8 h-8 p-1 rounded-full hover:bg-gray-100 hover:text-teal-800" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path>
                                                        </svg>
                                                    </button>
                                                    <span class="w-1/5 text-sm font-semibold text-center text-teal-900">₱<?php echo $itemTotalPrice; ?></span>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>

                            <?php
                                $totalPrice += $itemTotalPrice;
                            endforeach;
                            ?>
                        </div>
                        <hr class="bg-gray-200 h-0.5">
                        <div class="flex justify-between py-3 lg:px-24">
                            <p class="text-gray-800">TOTAL</p>
                            <div>
                                <p class="font-bold text-end">₱<?php echo number_format($totalPrice, 2) ?></p>
                            </div>
                        </div>

                        <!-- textarea for instructions -->
                        <div class="my-6">
                            <label for="specialReqs" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Special Instructions/Requests:</label>
                            <p class="visible mx-0 mb-0 text-xs leading-relaxed text-left text-slate-400">
                                (Please let us know if you are allergic to anything or provide alternatives.)
                            </p>
                            <div class="relative">
                                <textarea
                                    type="text"
                                    name="specialReqs"
                                    id="specialReqs"
                                    class="block w-full p-4 text-gray-900 border border-gray-300 rounded-lg bg-gray-50 sm:text-md focus:ring-teal-500 focus:border-teal-500 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white"
                                    placeholder="e.g. no nuts"
                                    maxlength="1000"
                                    oninput="updateCharCount(this)"
                                ></textarea>
                                <span id="charCount" class="absolute bottom-2 right-2 text-gray-400 text-sm">0/1000</span>
                            </div>
                        </div>

                        <div class="grid grid-cols-2 ">
                            <div class="col-span-1 px-2">
                                <button type="submit" class="hidden w-full p-2 py-3 text-sm font-semibold text-gray-700 uppercase bg-white border border-gray-200 rounded shadow-md hover:bg-teal-800 hover:text-white" name="saveOrderCustomer" id="saveOrderCustomer" value="saveOrderCustomer" onclick="showPlaceOrderMessageModal()">
                                    Place Order Button Function
                                </button>

                                <button data-modal-target="default-modal" data-modal-toggle="default-modal" data-modal-hide="viewCartModal" class="w-full p-2 py-3 text-sm font-semibold uppercase text-gray-700 bg-white border border-gray-200 rounded shadow-md hover:bg-teal-800 hover:text-white" type="button" name="scanButton" id="scanButton" value="scanButton">
                                    Place Order
                                </button>
                                <div class="absolute z-10 hidden text-[10px] text-gray-500 p-1 rounded mt-1 mb-5 ml-2" id="tooltip">
                                    Add items to your cart first to place the order.
                                </div>

                            </div>

                            <div class="col-span-1">
                                <button type="button" class="w-full p-2 py-3 text-sm font-semibold text-gray-700 uppercase bg-white border border-gray-200 rounded shadow-md hover:bg-teal-400" id="cancelButton" data-modal-toggle="cancelModal" data-modal-hide="viewCartModal">
                                    Cancel Order
                                </button>
                            </div>

                            <!-- <a href="../viewCustomer/orderSummary.php?orderID=<?php echo $_SESSION['orderID']; ?>">
                                <button type="button" class="w-full p-2 py-3 text-sm font-semibold text-gray-700 uppercase bg-white border border-gray-200 rounded shadow-md hover:bg-teal-800 hover:text-white">View Summary</button>
                            </a> -->

                        </div>
                    </div>
                </form>
            </section>
        </div>
    </div>
</div>

<!-- scanner modal -->
<div id="default-modal" tabindex="-1" aria-hidden="true" class="hidden overflow-y-auto overflow-x-hidden fixed top-0 right-0 left-0 z-50 justify-center items-center w-full md:inset-0 h-[calc(100%-1rem)] max-h-full">
    <div class="relative p-4 w-full max-w-md max-h-full">
        <!-- Modal content -->
        <div class="relative bg-white rounded-lg shadow dark:bg-gray-700">
            <!-- Modal header -->
            <div class="flex items-center justify-between p-2 md:p-3 border-b rounded-t dark:border-gray-600">
                <h3 class="text-xl font-semibold text-gray-900 dark:text-white">
                    Scan to Place Order
                </h3>
                <button type="button" class="end-2.5 text-gray-400 bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm w-8 h-8 ms-auto inline-flex justify-center items-center dark:hover:bg-gray-600 dark:hover:text-white" data-modal-hide="default-modal">
                    <svg class="w-3 h-3" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 14 14">
                        <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m1 1 6 6m0 0 6 6M7 7l6-6M7 7l-6 6" />
                    </svg>
                    <span class="sr-only">Close modal</span>
                </button>
            </div>
            <!-- Modal body -->
            <div class="p-4 md:p-5 flex items-center justify-center">
                <div class="lg:w-full">
                    <div id="qr-reader" class="mx-auto"></div>
                    <!-- <button id="start-scan" name="start-scan">Start QR Scan</button> -->
                </div>
            </div>
        </div>
    </div>
</div>


<?php if ($message != '') { ?>
    <div id="placeOrderMessageModal" class="bg-white border-2 border-black text-black w-80 h-32 px-4 py-14 rounded-lg relative justify-center items-center text-center" role="alert" style="position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%); z-index: 999;">
        <strong class="font-bold"> <?php echo $message; ?></strong>
        <span class="absolute top-0 bottom-0 right-0 px-4 py-3" onclick="closePlaceOrderMessageModal()">
            <svg class="fill-current h-6 w-6 text-teal-800" role="button" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20">
                <title>Close</title>
                <path d="M14.348 14.849a1.2 1.2 0 0 1-1.697 0L10 11.819l-2.651 3.029a1.2 1.2 0 1 1-1.697-1.697l2.758-3.15-2.759-3.152a1.2 1.2 0 1 1 1.697-1.697L10 8.183l2.651-3.031a1.2 1.2 0 1 1 1.697 1.697l-2.758 3.152 2.758 3.15a1.2 1.2 0 0 1 0 1.698z" />
            </svg>
        </span>
    </div>
    <script>
            function showMessageModal() {
                var modal = document.getElementById('placeOrderMessageModal');
                modal.style.display = 'block';
                setTimeout(function() {
                    modal.style.display = 'none';
                }, 2000); // Adjust the duration (in milliseconds) as needed
            }
            // Call the function to show the modal
            showMessageModal();
        </script>
<?php } ?>

<script>
    function showPlaceOrderMessageModal() {
        var modal = document.getElementById('placeOrderMessageModal');
        modal.style.display = 'block';
    }
</script>

<script>
    function closePlaceOrderMessageModal() {
        var modal = document.getElementById('placeOrderMessageModal');
        modal.style.display = 'none';
    }
</script>

<script>
    // Check if the diningChoice is set in the session
    <?php if (isset($_SESSION['diningChoice'])) : ?>
        var diningChoiceFromSession = <?php echo json_encode($_SESSION['diningChoice']); ?>;
        console.log('Dining choice from session:', diningChoiceFromSession);
    <?php endif; ?>

    // Rest of your JavaScript code...
</script>


<script src="https://unpkg.com/html5-qrcode" type="text/javascript"></script>


<script>
    // Get the cart data from PHP and parse it to a JavaScript variable
    var cartItems = <?php echo json_encode($cart); ?>;

    // Function to enable/disable the button based on cart items and show/hide the tooltip
    function updateScanButtonStatus() {
        var scanButton = document.getElementById("scanButton");
        var tooltip = document.getElementById("tooltip");

        if (cartItems.length > 0) {
            scanButton.removeAttribute("disabled");
            tooltip.classList.add("hidden");
        } else {
            scanButton.setAttribute("disabled", "disabled");
            tooltip.classList.remove("hidden");
        }
    }

    // Call the function when the page loads
    document.addEventListener("DOMContentLoaded", function() {
        updateScanButtonStatus();
    });
</script>



<script>
    function onScanSuccess(decodedText, decodedResult) {
        // handle the scanned code as you like, for example:
        console.log(`Code matched = ${decodedText}`, decodedResult);

        // Find the input field
        var inputField = document.getElementById("tableNum");

        // Set its value to the decoded text
        inputField.value = decodedText;

        document.getElementById("saveOrderCustomer").click();

    }

    // Square QR box with edge size = 70% of the smaller edge of the viewfinder.
    let qrboxFunction = function(viewfinderWidth, viewfinderHeight) {
        let minEdgePercentage = 0.7; // 70%
        // let minEdgeSize = Math.min(viewfinderWidth, viewfinderHeight);
        // let qrboxSize = Math.floor(minEdgeSize * minEdgePercentage);
        return {
            width: 150,
            height: 150
        };
    }

    let html5QrcodeScanner = new Html5QrcodeScanner("qr-reader", {
        fps: 10,
        qrbox: qrboxFunction
    }, /* verbose= */ false);
    html5QrcodeScanner.render(onScanSuccess);

    // Store orderID and tableNo in local storage
    localStorage.setItem('orderID', <?php echo json_encode($orderID); ?>);
    localStorage.setItem('tableNo', <?php echo json_encode($tableNo); ?>);
</script>

<script>
    function updateCharCount(textarea) {
        const charCountElement = document.getElementById('charCount');
        const currentCharCount = textarea.value.length;
        charCountElement.textContent = `${currentCharCount}/1000`;
    }
</script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/flowbite/1.8.0/flowbite.min.js"></script>