<?php
include '../connection/config.php';

session_start();
global $conn;

$orderID = $_SESSION["orderID"];
$orderStatus = '';

if (isset($_SESSION["orderID"])) {
    $orderID = $_SESSION["orderID"];

    // Select order details from tblorders
    $orderQuery = "SELECT * FROM tblorders WHERE orderID = ? AND orderStatus = 'Completed'";

    if ($stmt = $conn->prepare($orderQuery)) {
        $stmt->bind_param("i", $orderID);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            while ($data = $result->fetch_assoc()) {
                $tableNo = $data['tableNo'];
                $orderID = $data['orderID'];
                $orderStatus = $data['orderStatus'];
                $totalAmount = $data['totalAmount'];
                $processedBy = $data['processedBy'];

                if ($orderStatus == 'Completed') {
                    $_SESSION['orderID'] = $orderID;

                    // Select order details from tblorderdetails
                    $orderDetailsQuery = "SELECT SUM(Amount) AS totalOrderAmount FROM tblorderdetails WHERE orderID = ?";
                    $stmtOrderDetails = $conn->prepare($orderDetailsQuery);
                    $stmtOrderDetails->bind_param("i", $orderID);
                    $stmtOrderDetails->execute();
                    $resultOrderDetails = $stmtOrderDetails->get_result();

                    if ($resultOrderDetails->num_rows > 0) {
                        $dataOrderDetails = $resultOrderDetails->fetch_assoc();
                        $totalOrderAmount = $dataOrderDetails['totalOrderAmount'];

                        // Now $totalOrderAmount contains the total amount from tblorderdetails
                        // Use $totalOrderAmount as needed
                    }

                    $stmtOrderDetails->close();
                }
            }
        } else {
            $tableNo = '';
            $orderID = '';
            $orderStatus = '';
            $totalAmount = '';
            $processedBy = '';
        }
    } else {
        echo "Error: " . $conn->error;
    }
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['submitName'])) {
    // Validate that the necessary fields are set
    if (isset($_POST['personName'], $_POST['totalAmount'], $_POST['tableNo'], $_POST['orderID'])) {

        $personNames = $_POST['personName'];

        $amountPerPerson = $totalAmount / count($personNames);

        foreach ($personNames as $personName) {
            $sqlPayment = "INSERT INTO tblpayment (customerName, amount, status) VALUES (?, ?, 'pending')";
            $stmtPayment = $conn->prepare($sqlPayment);
            $stmtPayment->bind_param("sd", $personName, $amountPerPerson);

            if ($stmtPayment->execute()) {
                $paymentID = $conn->insert_id;

                $_SESSION['paymentID'] = $paymentID;

                $sqlPersonName = "INSERT INTO tblpaymentdetails (paymentID, orderID,  totalAmount) VALUES (?, ?, ?)";
                $stmtPersonName = $conn->prepare($sqlPersonName);
                $stmtPersonName->bind_param("iid", $paymentID, $orderID, $totalAmount);

                if ($stmtPersonName->execute()) {
                    // Successfully inserted person's name
                } else {
                    echo "Error: " . $sqlPersonName . "<br>" . $conn->error;
                }
                $stmtPersonName->close();
            } else {
                echo "Error: " . $sqlPayment . "<br>" . $conn->error;
            }

            $stmtPayment->close();
        }

        // Get the number of people from the form or set a default value
        $noOfPeople = isset($_POST['noOfPeople']) && is_numeric($_POST['noOfPeople']) ? (int)$_POST['noOfPeople'] : 1;

        header('Location: ../viewCustomer/viewEReceipt.php');
    } else {
        echo "Please fill in all required fields.";
    }
} else {
    // Default value for the number of people 
    $noOfPeople = isset($_GET['noOfPeople']) && is_numeric($_GET['noOfPeople']) ? (int)$_GET['noOfPeople'] : 1;
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="../../dist/output.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/flowbite/1.8.1/flowbite.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <script src="https://cdn.tailwindcss.com"></script>
    <title>Payment</title>
</head>

<body>
    <section class="h-screen bg-gray-100 px-4 text-gray-600 antialiased" x-data="app">
        <div class="flex h-full flex-col justify-center items-center">
            <div class="mx-auto w-full max-w-2xl border px-12 py-8 border-gray-200 bg-white shadow-lg rounded-2xl">
                <form method="post">
                    <?php //if (isset($_GET['orderID'])) : 
                    ?>
                    <div class="font-semibold text-gray-800 m-5 text-center" hidden>Order #<?php echo $orderID ?>:</div>
                    <div class="font-semibold text-gray-800 mt-5 my-5 mb-3 text-center">Table #: <?php echo $tableNo ?></div>
                    <?php //else : 
                    ?>
                    <!-- <div class="font-semibold text-red-500">Order ID not provided</div> -->
                    <?php //endif; 
                    ?>

                    <!-- Table for order items -->
                    <div class="overflow-x-auto p-3 pb-10 mx-5 ">
                        <div class="flex flex-col justify-center items-center">
                            <div class="justify-center items-center text-center pb-5">
                                <svg xmlns="http://www.w3.org/2000/svg" class="text-teal-700 w-20 h-20 justify-center" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                                </svg>
                            </div>
                            <div class="text-center">
                                <h1 class="text-2xl font-bold">Thank you for dining with us! <br> We hope you enjoyed your meal. </h1>
                                <h3 class="lg:p-3 p-1">To complete the payment process, kindly enter your name below. Head to the cashier at your convenience, and our staff will assist you with the payment. We appreciate your visit and look forward to serving you again soon!</h3>
                            </div>
                            <div class="flex flex-col justify-center items-center pt-5">
                                <?php
                                for ($i = 1; $i <= $noOfPeople; $i++) {
                                ?>
                                    <div class="py-1"></div>
                                    <input type="text" name="personName[]" placeholder="Customer <?= $i ?> Name" class="bg-gray-50 border border-teal-700 text-teal-700 text-md font-medium rounded-lg focus:ring-teal-200 focus:border-teal-600 block w-full p-2.5 placeholder-teal-700" required>
                                <?php
                                }
                                ?>
                            </div>
                        </div>

                        <input type="hidden" name="totalAmount" value="<?php echo $totalOrderAmount; ?>">
                        <input type="hidden" name="tableNo" value="<?php echo $tableNo; ?>">
                        <input type="hidden" name="orderID" value="<?php echo $orderID; ?>">
                        <input type="hidden" name="noOfPeople" value="<?php echo $noOfPeople; ?>">

                        <div class="flex justify-between pt-7 px-8">
                            <p class="text-gray-800">TOTAL DUE</p>
                            <div>
                                <p class="font-bold text-end">₱<?php echo number_format((float)$totalOrderAmount, 2) ?></p>
                            </div>
                        </div>

                        <div class="w-full pb flex justify-center items-center">
                            <div class="pb-3 flex justify-center items-center text-center pt-5">
                                <a href="./viewEReceipt.php" id="submitName" name="submitName">
                                    <button type="submit" name="submitName" class="border border-teal-700 text-teal-700 hover:text-white hover:border-none duration-300 relative group cursor-pointer overflow-hidden h-12 w-60 rounded-3xl p-2 font-extrabold hover:bg-teal-700">
                                        <div class="absolute group-hover:-top-1 group-hover:-right-2 z-10 w-16 h-16 rounded-full group-hover:scale-150 duration-700 right-12 top-12 bg-teal-500"></div>
                                        <div class="absolute group-hover:-top-1 group-hover:-right-2 z-10 w-16 h-16 rounded-full group-hover:scale-150  duration-700 right-12 top-12 bg-teal-500"></div>
                                        <div class="absolute group-hover:-top-1 group-hover:-right-2 z-10 w-12 h-12 rounded-full group-hover:scale-150  duration-700 right-20 -top-6 bg-teal-300"></div>
                                        <div class="absolute group-hover:-top-1 group-hover:-right-2 z-10 w-8 h-8   rounded-full group-hover:scale-150  duration-700 right-32 top-6 bg-teal-200"></div>
                                        <div class="absolute group-hover:-top-1 group-hover:-right-2 z-10 w-4 h-4   rounded-full group-hover:scale-150  duration-700 right-2 top-12 bg-teal-100"></div>
                                        <p class="z-10 absolute bottom-3 left-20 pl-2 text-center">SUBMIT</p>
                                    </button>
                                </a>
                            </div>
                        </div>
                    </div>
                </form>
                <!-- <?php
                        //include('../forms/selectTableForMerge.php');
                        ?>
                <div class="w-full pt-2 flex justify-center items-center">
                    <button type="button" onclick="prepareMergeOrderData()" class="text-gray-500 background-transparent text-sm outline-none focus:outline-none mr-1 mb-1 ease-linear transition-all duration-150 justify-center text-center underline hover:text-teal-600">Request for Merge Order</button>
                </div> -->
            </div>
    </section>
</body>
<script src="https://cdnjs.cloudflare.com/ajax/libs/flowbite/1.8.0/flowbite.min.js"></script>

<script>
    function prepareMergeOrderData() {

        var orderID = <?php echo json_encode($orderID); ?>;
        var tableNo = <?php echo json_encode($tableNo); ?>;

        // Pass the orderID and tableNo to the modal
        openMergeOrderModal(orderID, tableNo);
    }

    function openMergeOrderModal(orderID, tableNo) {
        // Update the modal content or perform any actions you need
        // For example, you can set the values of hidden inputs in the modal form
        document.getElementById('modalOrderID').value = orderID;
        document.getElementById('modalTableNo').value = tableNo;

        // Toggle the modal visibility
        toggleModal('tableForMergeModal');
    }

    function toggleModal(modalId) {
        var modal = document.getElementById(modalId);
        modal.classList.toggle('hidden');
    }
</script>

</html>