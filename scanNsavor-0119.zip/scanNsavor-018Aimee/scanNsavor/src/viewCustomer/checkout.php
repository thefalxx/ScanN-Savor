<?php
// Include your database connection code here if not already included


$mergedData = $_SESSION["mergedData"];
$totalAmount = $_SESSION["totalAmount"];


foreach ($mergedData as $data) {

    $orderID = $data['orderID'];
    $itemName = $data['itemName'];
    $price = $data['price'];
    $itemQuantity = $data['itemQuantity'];
    $totalAmount = $data['totalAmount'];
    $processedBy = $data['processedBy'];
}
?>



<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="../../dist/output.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/flowbite/1.8.0/flowbite.min.css" rel="stylesheet" />
    <title>Document</title>
</head>

<body>

    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link href="../../dist/output.css" rel="stylesheet">
        <link href="https://cdnjs.cloudflare.com/ajax/libs/flowbite/1.8.1/flowbite.min.css" rel="stylesheet">
        <title>Menu</title>
    </head>
    <!-- component -->

    <style>
        @layer utilities {

            input[type="number"]::-webkit-inner-spin-button,
            input[type="number"]::-webkit-outer-spin-button {
                -webkit-appearance: none;
                margin: 0;
            }
        }
    </style>

    <body>
        <div class="py-14 px-4 md:px-6 xl:px-20 xl:container xl:mx-auto mx-32" id="checkoutPage">

            <div class="flex justify-start item-start space-y-2 flex-col">
                <h1 class="text-3xl dark:text-white lg:text-4xl font-semibold leading-7 lg:leading-9 
                text-gray-800">Table Number : <?php echo $tableNo; ?></h1>
                <h1 class="text-3xl dark:text-white lg:text-4xl font-semibold leading-7 lg:leading-9 
                text-gray-800">Order ID : <?php echo $orderID; ?></h1>

                <?php foreach ($mergedData as $food) : ?>


            </div>
            <div class="mt-10 flex flex-col xl:flex-row jusitfy-center items-stretch w-full xl:space-x-8 space-y-4 md:space-y-6 xl:space-y-0">
                <div class="flex flex-col justify-start items-start w-full space-y-4 md:space-y-6 xl:space-y-8">
                    <div class="pb-10 flex flex-col justify-start items-start dark:bg-gray-800 bg-gray-50 px-4 py-4 md:py-6 md:p-6 xl:p-8 w-full">
                        <!-- item -->
                        <div class="mt-6 md:mt-0 flex justify-start flex-col md:flex-row items-start md:items-center space-y-4 md:space-x-6 xl:space-x-8 w-full">

                            <div class="w-full h-full">
                            </div>
                            <div class="flex justify-between items-start w-full flex-row md:flex-row space-y-4 md:space-y-0">
                                <div class="w-full flex flex-col justify-start items-start space-y-8">
                                    <h3 class="pl-3 text-xl dark:text-white xl:text-2xl font-semibold leading-6 text-gray-800"><?php echo $food['itemName']; ?></h3>
                                    <div class="pl-3 flex justify-start items-start flex-col space-y-2">
                                        <p class="text-sm dark:text-white leading-none text-gray-800"><span class="dark:text-gray-400 text-gray-300">₱ <?php echo $food['price']; ?></span></p>
                                    </div>

                                    <p class="text-sm dark:text-white leading-none text-gray-800"><span class="dark:text-gray-400 text-gray-300">Quantity: </span><?php echo $food['itemQuantity']; ?></p>
                                </div>
                            </div>
                            <div class="flex justify-between space-x-8 items-start w-full">
                                <p class="text-base dark:text-white xl:text-lg leading-6"><span class="text-red-300 line-through"></span></p>
                                <p class="text-base dark:text-white xl:text-lg leading-6 text-gray-800"></p>
                                <p class="text-base dark:text-white xl:text-lg font-semibold leading-6 text-gray-800">₱<span><?php echo $food['totalAmount'] ?></span></p>
                            </div>
                        <?php endforeach; ?>
                        </div>
                    </div>
                </div>

                <div class="flex justify-center flex-col md:flex-row items-stretch w-full space-y-4 md:space-y-0 md:space-x-6 xl:space-x-8">
                    <div class="flex flex-col px-4 py-6 md:p-6 xl:p-8 w-full bg-gray-50 dark:bg-gray-800 space-y-6">
                        <h3 class="text-xl dark:text-white font-semibold leading-5 text-gray-800">Summary</h3>
                        <div class="flex justify-center items-center w-full space-y-4 flex-col border-gray-200 border-b pb-4">
                            <div class="flex justify-between w-full">
                                <p class="text-base dark:text-white leading-4 text-gray-800">Subtotal</p>
                                <p class="text-base dark:text-gray-300 leading-4 text-gray-600">₱<span>50000</span></p>
                            </div>
                        </div>
                        <div class="flex justify-between items-center w-full">
                            <p class="text-base dark:text-white font-semibold leading-4 text-gray-800">Total</p>
                            <p class="text-base dark:text-gray-300 font-semibold leading-4 text-gray-600">₱<span><?php echo $totalAmount; ?></span></p>
                        </div>
                        <div class="w-full flex justify-center items-center">
                            <a href="../viewCustomer/payment.php"><button type="submit" name="checkout" class="text-teal-800 inline-flex justify-center hover:text-white border border-teal-800 hover:bg-teal-800 focus:ring-4 focus:outline-none focus:ring-teal-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center uppercase w-full">
                                    Checkout
                                </button></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </body>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/flowbite/1.8.0/flowbite.min.js"></script>
    <!-- <form method="post" action="">
        <label for="orderID" class="px-56">Order ID</label><br>
        <p id="orderID" name="orderID" class="px-56"></p><br>
        <label for="customerName" class="px-56">Customer Name:</label><br>
        <input type="text" id="customerName" name="customerName" class="px-56"><br>
        <label for="paymentMethod" class="px-56">Payment Method:</label><br>
        <input type="text" id="paymentMethod" name="paymentMethod" class="px-56"><br>
        <label for="totalAmount" class="px-56">Total Amount:</label><br>
        <input type="text" id="totalAmount" name="totalAmount" class="px-56" value=""><br>
        <label for="processedBy" class="px-56">Processed By:</label><br>
        <input type="text" id="processedBy" name="processedBy" class="px-56"><br>
        <label for="orderStatus" class="px-56">Order Status:</label><br>
        <input type="text" id="orderStatus" name="orderStatus" class="px-56" value=""><br>
        <input type="submit" name="checkout" value="Checkout" class="bg-teal-700">
    </form> -->


    </html>