<?php
include '../class/Menu.php';
$menu = new Menu();
$catMappings = $menu->fetchCategoryMappings();
$category = $menu->getCategories();

session_start();

global $conn;



// Check if it's an asynchronous request to set diningChoice
if (isset($_POST['setDiningChoice']) && $_POST['setDiningChoice'] === 'true') {
    // Set the diningChoice as a session variable
    $_SESSION['diningChoice'] = $_POST['diningChoice'];
    //$pref = $_SESSION['diningChoice'];

    //echo '<script> alert("' . $pref . '") </script>';

    // You can send a response back to the JavaScript if needed
    echo json_encode(['success' => true]);

    exit;
}



// Fetch food items from the database
$sql = "SELECT f.itemID, f.itemName, f.price, f.description, f.itemImage, SUM(od.itemQuantity) AS totalOrdered FROM tblorderdetails od INNER JOIN tblfooditems f ON od.itemID = f.itemID WHERE od.status = 'Done' GROUP BY f.itemID, f.itemName ORDER BY totalOrdered DESC LIMIT 3";
$result = mysqli_query($conn, $sql);



// Check for query success
if ($result) {
    $fooditems = array();

    // Loop through the results and populate $fooditems array
    while ($item = mysqli_fetch_assoc($result)) {
        $fooditems[] = $item;
    }

    // Close the database connection
    mysqli_close($conn);
} else {
    // Handle the case where the query fails
    echo 'Error: ' . mysqli_error($conn);
}


?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="dist/output.css" rel="stylesheet">
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/flowbite/1.8.0/flowbite.min.css" rel="stylesheet" />
    <script src="https://cdn.jsdelivr.net/npm/alpinejs@2.8.2/dist/alpine.min.js" defer></script>
    <title>Scan N' Savor</title>
</head>

<body>
    <div x-data="{ open: false }" x-init="open = true" id="diningChoice">
        <!-- Modal overlay -->
        <div x-show="open" class="fixed inset-0  bg-gray-500 bg-opacity-75 flex items-center justify-center">
            <!-- Modal content -->
            <div class="justify-center bg-white p-6 rounded-xl shadow-lg lg:w-[580px] lg:mx-0 mx-5">
                <header class=" text-center px-10 py-8">
                    <div class="flex items-center">
                        <div class="grow border-b border-teal-700"></div>
                        <span class="shrink px-1 pb-1 text-teal-700 font-bold lg:text-2xl text-xl">&nbsp; W E L C O M E &nbsp;</span>
                        <div class="grow border-b border-teal-700"></div>
                    </div>
                </header>
                <p class="text-center lg:px-24 px-8 text-xs text-gray-500">Flexibility at your fingertips: <br> Whether you choose to dine in or take out, it's always a celebration of flavors with Scan N' Savor.</p>
                <div class="lg:flex justify-between px-14 pt-8">
                    <div class="justify-center items-center text-center pt-5">
                        <button @click="setChoice('dineIn')" class="border border-teal-700  text-teal-700 hover:text-white hover:border-none duration-300 relative group cursor-pointer overflow-hidden h-20 w-48 rounded-3xl p-2 font-extrabold hover:bg-teal-700" id="dineIn">
                            <div class="absolute group-hover:-top-1 group-hover:-right-2 z-10 w-16 h-16 rounded-full group-hover:scale-150  duration-700 right-12 top-12 bg-teal-500"></div>
                            <div class="absolute group-hover:-top-1 group-hover:-right-2 z-10 w-12 h-12 rounded-full group-hover:scale-150  duration-700 right-20 -top-6 bg-teal-300"></div>
                            <div class="absolute group-hover:-top-1 group-hover:-right-2 z-10 w-8 h-8   rounded-full group-hover:scale-150  duration-700 right-32 top-6 bg-teal-200"></div>
                            <div class="absolute group-hover:-top-1 group-hover:-right-2 z-10 w-4 h-4   rounded-full group-hover:scale-150  duration-700 right-2 top-12 bg-teal-100"></div>
                            <p class="z-10 absolute bottom-7 left-10 pl-6 text-center">DINE IN</p>
                        </button>
                    </div>
                    <div class="justify-center items-center text-center pt-5">
                        <button @click="setChoice('takeOut')" class="border border-teal-700 text-teal-700 hover:text-white hover:border-none duration-300 relative group cursor-pointer overflow-hidden h-20 w-48 rounded-3xl p-2 font-extrabold hover:bg-teal-700" id="takeOut">
                            <div class="absolute group-hover:-top-1 group-hover:-right-2 z-10 w-16 h-16 rounded-full group-hover:scale-150  duration-700 right-12 top-12 bg-teal-500"></div>
                            <div class="absolute group-hover:-top-1 group-hover:-right-2 z-10 w-12 h-12 rounded-full group-hover:scale-150  duration-700 right-20 -top-6 bg-teal-300"></div>
                            <div class="absolute group-hover:-top-1 group-hover:-right-2 z-10 w-8 h-8   rounded-full group-hover:scale-150  duration-700 right-32 top-6 bg-teal-200"></div>
                            <div class="absolute group-hover:-top-1 group-hover:-right-2 z-10 w-4 h-4   rounded-full group-hover:scale-150  duration-700 right-2 top-12 bg-teal-100"></div>
                            <p class="z-10 absolute bottom-7 left-10 pl-5 text-center">TAKE OUT</p>
                        </button>
                    </div>
                </div>
                <!-- Close button -->
                <button @click="open = false" class="mt-4 text-gray-400 px-4 py-2">Close</button>
            </div>
        </div>
    </div>

    <div class="px-5">
        <section>
            <nav class="bg-white border-gray-200">
                <div class="max-w-screen-xl flex flex-wrap items-center justify-between mx-auto p-4">
                    <a href="#" class="flex items-center">
                        <img src="../../images/green scansavor logo.png" class="h-12 mr-3" alt="scannsavorlogo" />
                        <span class="self-center text-2xl font-semibold whitespace-nowrap text-teal-700">Scan N' Savor</span>
                    </a>
                </div>
            </nav>
        </section>

        <section class="lg:h-screen h-full lg:px-10 px-5 bg-[#e6e8dd] rounded-3xl lg:my-14 lg:mx-24 lg:mt-5 pb-20">
            <div class="flex flex-col items-center justify-center px-10 py-10 mx-auto space-y-6 lg:h-[32rem] lg:py-16 lg:flex-row lg:items-center">
                <div class="w-full lg:w-1/2">
                    <div class="lg:max-w-lg">
                        <h1 class="text-5xl lg:pl-24 font-bold tracking-wide text-gray-800 xs:text-center sm:text-center md:text-center sm:text-3xl md:text-4xl lg:text-5xl">
                        Savor the Flavor: <br>Click, Order, and Enjoy!
                        </h1>

                    </div>
                </div>
                <div class="flex items-center justify-center lg:pt-96 pt-20 mt-1 w-full h-96 lg:w-1/2">
                    <img src="../../images/hero-bg.png" class="block max-w-full h-auto lg:pr-12 lg:h-auto md:h-96 align-middle lg:max-w-lg lg:pb-20">
                </div>
            </div>
        </section>
    </div>

    <section class="h-full lg:px-10 px-5 lg:my-14 lg:mx-24 lg:mt-10 pb-20">
        <div class="sm:ml-0 lg:ml-10 px-4 pb-10">
            <div class="col-span-2 md:col-span-2 lg:col-span-4 flex justify-center text-center lg:pt-20 pt-14 lg:mb-5">
                <h2 class="lg:text-5xl text-3xl md:text-3xl text-gray-800 font-extrabold tracking-wide md:tracking-wider">
                    Our Best Dishes
                </h2>
            </div>
            <h4 class="text-black text-center font-normal px-10 text-xs lg:text-lg pt-3 lg:pt-1">
            Savor the extraordinary on our menu, a curated selection of culinary masterpieces that promises a journey of taste and delight. 
            <br>
            Our special dishes are crafted with passion, offering a harmonious blend of innovation and tradition on every plate.
            </h4>
        </div>


        <div class="flex items-center justify-center">
            <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-3 lg:gap-14 gap-8 ">
                <?php
                $counter = 0;
                foreach ($fooditems as $item) :
                    if ($counter >= 3) {
                        break; // Break the loop if three products are already displayed
                    }
                ?>
                    <div class="max-w-sm border border-gray-200 rounded-xl shadow-lg shadow-gray-400 bg-white">
                        <div class="relative">
                            <div class="p-4">
                                <?php if (isset($item['itemImage'])) { ?>
                                    <!-- Retrieve and display the image -->
                                    <img class="w-full h-60 rounded-xl" src="../images/<?php echo $item['itemImage']; ?>" alt="<?php echo $item['itemName']; ?>" />
                                <?php } ?>
                            </div>
                        </div>

                        <form id="addToCartForm_<?php echo $item['itemID']; ?>" method="POST" action="" onsubmit="addToCart('<?php echo $item['itemID']; ?>'); return false;">
                            <div class="px-5 pt-2">
                                <p class="text-xl font-semibold tracking-tight text-slate-700 " id="itemName" name="itemName"><?php echo $item['itemName']; ?></p>
                            </div>

                            <div class="px-5">
                                <h5 class="pt-3 pb-3 text-sm tracking-tight text-gray-900"><?php echo $item['description']; ?></h5>
                            </div>

                            <div class="px-5 pb-5 flex items-center justify-between">
                                <span class="text-xl font-bold text-gray-900 lg:w-14 w-3" name="price" id="price">₱<?php echo $item['price']; ?></span>
                                <input type="hidden" name="itemID" value="<?php echo $item['itemID']; ?>">
                                <!-- <input type="number" name="orderQuantity" value="1" min="1" class="ml-20 w-14 h-10 text-center text-gray-900 text-sm outline-none border border-teal-700 focus:ring-2  focus:ring-green-200 rounded-xl mr-3"> -->
                                <div class="ml-20 w-14 h-10 mr-3"></div>
                                <div class="ml-8 w-14 h-10 mr-3"></div>
                            </div>
                        </form>
                    </div>
                <?php
                    $counter++;
                endforeach;
                ?>
            </div>
        </div>


        <div id="menu" class="w-full pb flex justify-center items-center pt-20">
            <div class="pb-5 flex justify-center items-center text-center pt-5">
                <a id="menuLink" href='#'>
                    <button class="border border-teal-700  text-teal-700 hover:text-white hover:border-none duration-300 relative group cursor-pointer overflow-hidden h-12 w-60 rounded-3xl p-2 font-extrabold hover:bg-teal-700">
                        <div class="absolute group-hover:-top-1 group-hover:-right-2 z-10 w-16 h-16 rounded-full group-hover:scale-150  duration-700 right-12 top-12 bg-teal-500"></div>
                        <div class="absolute group-hover:-top-1 group-hover:-right-2 z-10 w-12 h-12 rounded-full group-hover:scale-150  duration-700 right-20 -top-6 bg-teal-300"></div>
                        <div class="absolute group-hover:-top-1 group-hover:-right-2 z-10 w-8 h-8   rounded-full group-hover:scale-150  duration-700 right-32 top-6 bg-teal-200"></div>
                        <div class="absolute group-hover:-top-1 group-hover:-right-2 z-10 w-4 h-4   rounded-full group-hover:scale-150  duration-700 right-2 top-12 bg-teal-100"></div>
                        <p class="z-10 absolute bottom-3 left-10 text-center">EXPLORE ALL MENU</p>
                    </button>
                </a>
            </div>
        </div>
    </section>

    <?php
    include '../view/footer.php';

    ?>

    <script>
        function setChoice(choice) {
            // Use JavaScript to send an asynchronous request to the server
            fetch('landingpage.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: 'setDiningChoice=true&diningChoice=' + encodeURIComponent(choice),
                })
                .then(response => response.json())
                .then(data => {
                    // Handle the response if needed
                    console.log(data);

                    // Dynamically set the link based on the diningChoice
                    var menuLink = document.getElementById('menuLink');
                    if (choice === 'dineIn') {
                        menuLink.href = '../viewCustomer/customerOrder.php';
                    } else if (choice === 'takeOut') {
                        menuLink.href = '../viewCustomer/takeoutOrders.php';
                    }

                    // Close the modal
                    document.getElementById('diningChoice').style.display = 'none';
                })
                .catch((error) => {
                    console.error('Error:', error);
                });
        }
    </script>
</body>

</html>