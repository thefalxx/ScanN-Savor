

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="../../dist/output.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/flowbite//flowbite.min.css" rel="stylesheet" />
    <title>Tableside QR Codes | Scan N' Savor</title>
</head>

<?php
//include('../viewAdmin/sidenav.php');
include('../viewManager/sidenavmanager.php');
include('../forms/qrformcreate.php');
// include("../class/tableQRCode.php");
/// include ('./layouts/usersidebar.php');
// $qrTable = new tableQRCode();

$searchTerm = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $searchTerm = isset($_POST['simple-search']) ? $_POST['simple-search'] : '';
}

$qrtable = $tableQR->getAllTableQR($searchTerm);


// $query = "SELECT * FROM tblemployeeacc";
// $result = mysqli_query($conn, $query);
?>

<body>

    <section class="pl-20 ml-20 pt-10">
        <div class="mx-auto pl-20 ml-20">
            <div class="mx-auto max-w-screen-xl max-h-screen-xl px-4 lg:px-12  xl:px-14">
                <div class="bg-white relative shadow-md sm:rounded-lg overflow-hidden">
                    <div class="flex flex-col md:flex-row items-stretch md:items-center md:space-x-3 space-y-3 md:space-y-0 mx-4 py-4 border-t">
                        <div class="w-full">
                        <form class="flex items-center" method="post">
                                <label for="simple-search" class="sr-only">Search</label>
                                <div class="relative w-full">
                                    <div class="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                                        <svg aria-hidden="true" class="w-5 h-5 text-gray-500" fill="currentColor" viewbox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                                            <path fill-rule="evenodd" clip-rule="evenodd" d="M8 4a4 4 0 100 8 4 4 0 000-8zM2 8a6 6 0 1110.89 3.476l4.817 4.817a1 1 0 01-1.414 1.414l-4.816-4.816A6 6 0 012 8z" />
                                        </svg>
                                    </div>
                                    <input type="text" id="simple-search" name="simple-search" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-teal-800 block w-full pl-10 p-2" placeholder="Search" value="<?php echo htmlspecialchars($searchTerm); ?>">
                                </div>
                            </form>
                        </div>
                        <div class="w-full md:w-auto flex flex-col md:flex-row space-y-2 md:space-y-0 items-stretch md:items-center justify-end md:space-x-3 flex-shrink-0">
                            <button type="button" id="createQRButton" data-modal-toggle="createQRModal" data-modal-target="createQRModal" class="flex items-center justify-center text-teal-800 bg-primary-700 hover:bg-teal-800 hover:text-white focus:ring-4 focus:ring-primary-300 border border-gray-200 font-medium rounded-lg text-sm px-4 py-2">
                                <svg class="h-3.5 w-3.5 mr-1.5 -ml-1" fill="currentColor" viewbox="0 0 20 20" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
                                    <path clip-rule="evenodd" fill-rule="evenodd" d="M10 3a1 1 0 011 1v5h5a1 1 0 110 2h-5v5a1 1 0 11-2 0v-5H4a1 1 0 110-2h5V4a1 1 0 011-1z" />
                                </svg>
                                Generate QR Code
                            </button>
                        </div>
                    </div>
                    <div class="overflow-x-auto ">
                        <table class="w-full text-sm text-left text-gray-500 ">
                            <thead class="text-xs text-gray-700 uppercase bg-gray-50">
                                <tr>
                                    <th></th>
                                    <th scope="col" class="px-10 py-4">QR Image</th>
                                    <th scope="col" class="px-10 py-4 text-center">Table Number</th>
                                    <th scope="col" class="px-10 py-4 text-center">Number of Seats</th>
                                    <th scope="col" class="px-8 py-4"></th>
                                    <th scope="col" class="px-8 py-4"></th>
                                    <!-- <th scope="col" class="px-8 py-4"></th>
                                    <th scope="col" class="px-8 py-4"></th> -->
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($qrtable as $tableqr) { ?>
                                    <tr class="border-b">
                                        <td class="px-6 py-3"></td>
                                        <td class="px-6 py-3">
                                            <div id="qrImage" class="w-14 h-14 ml-4"> <img src="<?php echo $tableqr['tableQRCode']; ?>" alt=""></div>
                                        </td>
                                        <td id="tableNumber" class="px-6 py-3 text-center"> <?php echo $tableqr['tableNo'] ?> </td>
                                        <td class="px-6 py-3 text-center"> <?php echo $tableqr['noOfSeats']; ?> </td>
                                        <td class="px-2 py-3">
                                            <a href="<?php echo $tableqr['tableQRCode']; ?>" download="Table <?php echo $tableqr['tableNo'] ?>">
                                                <button id="downloadButton" class="py-2 px-3 flex items-center text-sm font-medium text-center text-teal-800 focus:outline-none bg-white rounded-lg border border-gray-200 hover:bg-teal-800 hover:text-white focus:z-10 focus:ring-4 focus:ring-green-200" onclick="" Download>
                                                    <svg class="h-4 w-4 mr-2 -ml-0.5" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 20 20">
                                                        <path d="M14.707 7.793a1 1 0 0 0-1.414 0L11 10.086V1.5a1 1 0 0 0-2 0v8.586L6.707 7.793a1 1 0 1 0-1.414 1.414l4 4a1 1 0 0 0 1.416 0l4-4a1 1 0 0 0-.002-1.414Z" />
                                                        <path d="M18 12h-2.55l-2.975 2.975a3.5 3.5 0 0 1-4.95 0L4.55 12H2a2 2 0 0 0-2 2v4a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-4a2 2 0 0 0-2-2Zm-3 5a1 1 0 1 1 0-2 1 1 0 0 1 0 2Z" />
                                                    </svg>
                                                    Download
                                                </button>
                                            </a>
                                        </td>
                                        <td class="px-2 py-3">
                                            <button id="printButton" class="py-2 px-3 flex items-center text-sm font-medium text-center text-teal-800 focus:outline-none bg-white rounded-lg border border-gray-200 hover:bg-teal-800 hover:text-white focus:z-10 focus:ring-4 focus:ring-green-200" onclick="printQRCode('<?php echo $tableqr['tableNo'] ?>', '<?php echo $tableqr['tableQRCode']; ?>')">
                                                <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 mr-2 -ml-0.5" viewbox="0 0 20 20" fill="currentColor" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 20 20">
                                                    <path d="M5 20h10a1 1 0 0 0 1-1v-5H4v5a1 1 0 0 0 1 1Z" />
                                                    <path d="M18 7H2a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2v-3a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v3a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2Zm-1-2V2a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v3h14Z" />
                                                </svg>
                                                Print
                                            </button>
                                        </td>
                                    </tr>
                                <?php } ?>
                            </tbody>
                            </table>
                        </div>
                    <?php
                    include '../view/pagination/qrPagination.php';
                    ?>
                </div>
            </div>
        </div>
    </section>

</body>

</html>

<script>
    function printQRCode(tableNo, qrCode) {
        var mywindow = window.open();

        // mywindow.document.write('<html><head><title>' + document.title + '</title>');

        mywindow.document.write('<style>');
        mywindow.document.write('body { text-align: center; margin-top: 35px; }'); 
        mywindow.document.write('img { display: block; margin: 0 auto; }');
        mywindow.document.write('</style>');
        mywindow.document.write('</head><body>');
        mywindow.document.write('<img src="' + qrCode + '">');
        mywindow.document.write('<h1>Table Number: ' + tableNo + '</h1>');
        mywindow.document.write('</body></html>');

        mywindow.document.close(); // necessary for IE >= 10
        mywindow.focus(); // necessary for IE >= 10

        mywindow.print();
        mywindow.close();
        return true;
    }
</script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/flowbite/2.2.1/flowbite.min.js"></script>