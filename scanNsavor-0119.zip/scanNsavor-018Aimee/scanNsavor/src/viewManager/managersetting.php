
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="../../dist/output.css" rel="stylesheet">
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css">

    <title>Manager Setting | Scan N Savr</title>
</head>

<?php

include './sidenavmanager.php';

include '../forms/profileformupdate.php';

$userDetail = $user->userDetails();
$userRole = $user->fetchRoleMappings();

// Assuming $userDetail['status'] contains the user's status ('active' or 'inactive')
$status = $userDetail['status'];

// Determine the text color class based on the status
$textColorClass = ($status === 'active') ? 'text-green-400' : 'text-red-400';


// Fetch the position from tblroles based on roleID
$roleID = $userDetail['roleID'];
$getPositionQuery = "SELECT position FROM tblroles WHERE roleID = ?";
$getPositionStmt = $conn->prepare($getPositionQuery);
$getPositionStmt->bind_param("i", $roleID);
$getPositionStmt->execute();
$getPositionStmt->bind_result($position);

// Initialize a variable to store the role description
$roleDescription = "";

// Check if a row is fetched
if ($getPositionStmt->fetch()) {
    // $position now contains the position from tblroles
    $roleDescription = ucfirst(strtolower($position));
}

$getPositionStmt->close();
?>


<body>
    <div class="pl-20">
        <section>
            <div class="mx-auto max-w-5xl py-5 md:py-5 pl-3 md:pl-6 md:w-1/2">
                <div class="container mx-auto">
                    <div class="flex justify-center">
                        <div class="flex flex-col gap-5 text-center pb-5">
                            <img class="rounded-full bg-gray-50 h-30 w-36 mx-auto" src="../../images/green scansavor logo.png" alt="profile picture" />
                            <div class="flex flex-col gap-3">
                                <h1 class="font-bold text-4xl"><?php echo strtoupper($_SESSION['name']); ?></h1>
                                <p class="text-gray-500 text-sm"><?php echo $roleDescription; ?></p>
                            </div>
                            <div class="pt-10 pb-5 flex justify-center">
                                <button data-modal-target="authentication-modal" data-modal-toggle="authentication-modal" class="flex items-center justify-center px-4 py-2 text-sm font-medium text-teal-800 border border-gray-200 rounded-lg bg-primary-700 hover:bg-teal-800 hover:text-white focus:ring-4 focus:ring-green-200">
                                    Update Profile
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
        </section>

        <section id="about" class="sm:p-10 lg:p-20 justify-left">
            <div class="w-full mx-auto max-w-screen-md h-64 ml-20 pl-20">
                <div class="bg-white p-3 shadow-sm rounded-sm">
                    <div class="flex items-center space-x-2 font-semibold text-gray-900 leading-8">
                        <span class="text-green-500">
                            <svg class="h-5" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                            </svg>
                        </span>
                        <span class="tracking-wide text-2xl">About</span>
                    </div>


                    <div class="pb-20">
                        <h2 class="text-bold text-xl mb-3">General Information</h2>

                        <div class="flex mb-5 items-center">
                            <p class="mr-3 text-lg text-gray-400">Status:</p>
                            <p class="<?php echo $textColorClass; ?> text-center text-justify leading-10">
                                <?php echo $userDetail['status'] ?>
                            </p>
                        </div>
                        
                        <div class="flex mb-5 items-center">
                            <p class="mr-3 text-lg text-gray-400">First Name:</p>
                            <p class="text-center text-justify leading-10">
                                <?php echo $userDetail['firstName'] ?>
                            </p>
                        </div>

                        <div class="flex mb-5 items-center">
                            <p class="mr-3 text-lg text-gray-400">Last Name:</p>
                            <p class="text-center text-justify leading-10">
                                <?php echo $userDetail['lastName'] ?>
                            </p>
                        </div>

                        <div class="flex mb-5 items-center">
                            <p class="mr-3 text-lg text-gray-400">Username:</p>
                            <p class="text-center text-justify leading-10">
                                <?php echo $userDetail['username'] ?>
                            </p>
                        </div>

                        <div class="flex mb-5 items-center">
                            <p class="mr-3 text-lg text-gray-400">User Type:</p>
                            <p class="text-center text-justify leading-10">
                                <?php echo $userDetail['type'] ?>
                            </p>
                        </div>
                    </div>


                </div>
            </div>


        </section>


    </div>


</body>

</html>