-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 27, 2023 at 03:17 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `scannsavor`
--

-- --------------------------------------------------------

--
-- Table structure for table `tblcart`
--

CREATE TABLE `tblcart` (
  `cartID` int(11) NOT NULL,
  `tableNo` int(11) NOT NULL,
  `status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tblcartdetails`
--

CREATE TABLE `tblcartdetails` (
  `cartID` int(11) NOT NULL,
  `itemID` int(11) NOT NULL,
  `itemName` varchar(100) NOT NULL,
  `packageID` int(11) NOT NULL,
  `packageName` varchar(100) NOT NULL,
  `orderQuantity` int(11) NOT NULL,
  `price` double(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tblcategories`
--

CREATE TABLE `tblcategories` (
  `categoryID` int(11) NOT NULL,
  `categoryName` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tblcategories`
--

INSERT INTO `tblcategories` (`categoryID`, `categoryName`) VALUES
(1, 'Appetizer'),
(2, 'Main Course'),
(3, 'Side Dish'),
(4, 'Salad'),
(5, 'Soup'),
(6, 'Desserts'),
(7, 'Drinks'),
(8, 'Pasta');

-- --------------------------------------------------------

--
-- Table structure for table `tblemployeeacc`
--

CREATE TABLE `tblemployeeacc` (
  `empAccID` int(11) NOT NULL,
  `firstName` varchar(50) NOT NULL,
  `lastName` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(150) NOT NULL,
  `status` varchar(50) NOT NULL,
  `type` varchar(50) NOT NULL,
  `roleID` int(11) NOT NULL,
  `restaurantID` int(11) NOT NULL,
  `authtoken` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tblemployeeacc`
--

INSERT INTO `tblemployeeacc` (`empAccID`, `firstName`, `lastName`, `email`, `password`, `status`, `type`, `roleID`, `restaurantID`, `authtoken`) VALUES
(6, 'Admin', 'Administrator', 'admin@gmail.com', '$2y$10$4nH/HLAJBHJOoP3GPELBGO1ToLJlHmHiYFFw.hbeM7FeiQYn6pk4y', 'active', 'Admin', 1, 1, '73f66749989c7b09389894f1b27daa7375d23af433e0cea4c0'),
(7, 'Taylor', 'Swift', 'swiftie@gmail.com', '$2y$10$eqteVNtXGjiDTdOFTNX8z.wIGEbPKEB8MIk1JaCLd6RJ4KmuPEJpu', 'active', 'General', 2, 1, '73f66749989c7b09389894f1b27daa73c5bfd7985fef4a7f47'),
(8, 'Megan', 'Trainor', 'megan@gmail.com', '$2y$10$L1U7XTTd4KAJkFr.7BBv/uKrWqZFYdKlfZmN.RgCTOZjuEzjXtTP6', 'active', 'General', 3, 1, '73f66749989c7b09389894f1b27daa7302538da916a9976ad2'),
(9, 'Ariana', 'Grande', 'grande@gmail.com', '$2y$10$IUxqQJkdlikIAhW.nOgYbOe/VhWzt3GsfEd01qSDwqIDrxJ.zZmEq', 'pending', 'General', 4, 1, '73f66749989c7b09389894f1b27daa73ef495b570eaa1a7545'),
(10, 'Swift', 'Acer', 'acerswift@gmail.com', '$2y$10$jL7KcY6DueMjTI5sHbxn6.lfWLF6o3TBxQ4Lo0QlwGmGHGK5iCOLS', 'pending', 'General', 3, 1, '73f66749989c7b09389894f1b27daa73b2312de3373bfbd18e'),
(11, 'Sza', 'Sza', 'sza@gmail.com', '$2y$10$wCTvXmB0nXG5wQVFRZGcaeGpHfKXR3G0/n3/BhoTtjCgGkYFXjQlK', 'inactive', 'General', 5, 1, '73f66749989c7b09389894f1b27daa73c8eb6780abc2fe33d4'),
(12, 'Bruno', 'Mars', 'mars@gmail.com', '$2y$10$fDJPFFOsR/txzhhoXOYygusr53CPCcRbE5LSRVBAOPSHDgVmb2DIm', 'active', 'General', 4, 1, '73f66749989c7b09389894f1b27daa732ccdbd5067ea7942d3'),
(13, 'Sam', 'Smith', 'smith@gmail.com', '$2y$10$GBey75YTKJYfX3s1JcAfyOdzhB9kD40WrledKUBhtxuRB/fx1g0yi', 'active', 'General', 2, 1, '73f66749989c7b09389894f1b27daa7300740959b42692bf9d'),
(14, 'Fred', 'Mercury', 'queen@gmail.com', '$2y$10$jqsevAq6tTQ3VmvauhgkHePwWpGbBkUde6Tvp8K05ApEFX8mYgiwe', 'active', 'General', 2, 1, '73f66749989c7b09389894f1b27daa7361e8f2660eebb1be71'),
(15, 'Charlie', 'Puth', 'charlie@gmail.com', '$2y$10$7RlpTE9yRdHyM1e0aSnwr.sxaHlQN3FxCXI9o7FZyBVWxtyLfYbJC', 'pending', 'General', 5, 1, '73f66749989c7b09389894f1b27daa73d47cb09f6c4edf706d'),
(16, 'John', 'Legend', 'legend@gmail.com', '$2y$10$CxYNhrChKcEQpa6pLwA4Pu9RL7kF5T6jFhyMKGhRV4qHQxC1OUo2y', 'active', 'General', 4, 1, '73f66749989c7b09389894f1b27daa73869196a3fdecc037c1'),
(17, 'Ryzen', 'Five', 'five@gmail.com', '$2y$10$SD0s3bg8XikvkbfLieSwvuaCvhtpWbnCGwkYPUCJrHDbcYFZ/MPi2', 'active', 'General', 5, 1, '73f66749989c7b09389894f1b27daa735499abe119ec0d7562'),
(18, 'Justin', 'Bieber', 'baby@gmail.com', '$2y$10$LjfGf2hL/f4VwmXuybweUe09z.unalLhHQE.vbrjCQZTKe6fW/el.', 'pending', 'General', 2, 1, '73f66749989c7b09389894f1b27daa73a61029d203c75b1ff2'),
(19, 'Tony', 'Parker', 'parker@gmail.com', '$2y$10$D/N1ZEyF3d6icdZFV2jF9.8irx4.JvXgjBpZu7ISwGW2e5HCFBqb6', 'active', 'General', 2, 1, '73f66749989c7b09389894f1b27daa73a806d07acd09228a86'),
(20, 'Michael', 'Jackson', 'jackson@gmail.com', '$2y$10$Jc18ZEMSe6nd74hzZq8Xhu7f3qWzkdHyDXu1KQesxcoPXN3TG25U2', 'active', 'General', 3, 1, '73f66749989c7b09389894f1b27daa737a8504801f9ae569c1'),
(21, 'Tony', 'Forces', 'waiter@gmail.com', '$2y$10$ccg.0SownrafUCZGxqZebOcUlBDSDBb4eqHXQUwc1wkSLZKavwOZ2', 'active', 'General', 5, 1, '73f66749989c7b09389894f1b27daa7381d104c9b12ed72648'),
(22, 'Christian', 'Magday', 'magday@gmail.com', '$2y$10$e.1jGtL58kUQsfpdfmLO1u5VyzipjTD2hg2luvKtLEgp2iFP5.YxO', 'active', 'General', 3, 1, '73f66749989c7b09389894f1b27daa7347d2f471e0d4655f27'),
(23, 'Chris', 'Mags', 'mags@gmail.com', '$2y$10$U7vx2uLlsSiIM0E71SXnZe.swXHGoBhznPx1K5cib0mvE8vVypLpa', 'active', 'General', 4, 1, '73f66749989c7b09389894f1b27daa735714b8d84fab2d93ef');

-- --------------------------------------------------------

--
-- Table structure for table `tblfooditems`
--

CREATE TABLE `tblfooditems` (
  `itemID` int(11) NOT NULL,
  `menuID` int(11) NOT NULL,
  `categoryID` int(11) NOT NULL,
  `itemName` varchar(50) NOT NULL,
  `price` double NOT NULL,
  `description` varchar(150) NOT NULL,
  `pax` varchar(50) NOT NULL,
  `availability` varchar(50) NOT NULL,
  `dishStatus` varchar(50) NOT NULL,
  `itemImage` longblob NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tblfooditems`
--

INSERT INTO `tblfooditems` (`itemID`, `menuID`, `categoryID`, `itemName`, `price`, `description`, `pax`, `availability`, `dishStatus`, `itemImage`) VALUES
(1, 1, 6, 'Blueberry Cheesecake', 95, 'made with fresh blueberries', '1', '1', 'Out of Stock', ''),
(2, 1, 4, 'Caesar Salad', 200, 'made with fresh veggies', '2', '1', 'Out of Stock', ''),
(3, 1, 7, 'Coke', 90, 'coca cola      ', '2', '1', 'Out of Stock', ''),
(4, 1, 2, 'Penne Tuna Pasta', 99, 'Made with Tuna and Mayo', '1', '1', 'In Stock', ''),
(5, 1, 2, 'Ribeye Steak', 9000, 'steak steak lang', '1', '1', 'Out of Stock', ''),
(6, 1, 5, 'Egg Drop Soup', 540, 'soupah hot soup', '4', '1', 'Out of Stock', ''),
(7, 1, 1, 'Sisig', 250, 'sisig na mekus mekus', '2', '1', 'In Stock', ''),
(8, 1, 7, 'Red Wine', 5000, 'pula nga ilimnon ', '2', '1', 'In Stock', ''),
(9, 1, 7, 'White Wine', 4000, 'puti nga wine', '1', '1', 'In Stock', ''),
(10, 1, 3, 'Kimchi ', 100, 'bawal lumabas by kimchi', '2', '1', 'In Stock', ''),
(11, 1, 5, 'Chicken Soup', 80, 'Chicken with Soup', '2', 'Available', 'Out of Stock', 0x2e2e2f2e2e2f696d616765732f313430383036373434363330372e6a706567);

-- --------------------------------------------------------

--
-- Table structure for table `tblmenu`
--

CREATE TABLE `tblmenu` (
  `menuID` int(11) NOT NULL,
  `menuTypeID` int(11) NOT NULL,
  `menuName` varchar(50) NOT NULL,
  `price` double NOT NULL,
  `menuStatus` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tblmenupackage`
--

CREATE TABLE `tblmenupackage` (
  `packageID` int(11) NOT NULL,
  `packageName` varchar(50) NOT NULL,
  `price` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tblmenupackage`
--

INSERT INTO `tblmenupackage` (`packageID`, `packageName`, `price`) VALUES
(1, 'Package 1', 290),
(2, 'Package 1', 250);

-- --------------------------------------------------------

--
-- Table structure for table `tblmenupackageitems`
--

CREATE TABLE `tblmenupackageitems` (
  `packageID` int(11) NOT NULL,
  `itemID` int(11) NOT NULL,
  `itemName` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tblmenupackageitems`
--

INSERT INTO `tblmenupackageitems` (`packageID`, `itemID`, `itemName`) VALUES
(2, 2, ' Caesar Salad'),
(2, 3, ' Coke');

-- --------------------------------------------------------

--
-- Table structure for table `tblmenutype`
--

CREATE TABLE `tblmenutype` (
  `menuTypeID` int(11) NOT NULL,
  `menuType` varchar(50) NOT NULL,
  `status` varchar(50) NOT NULL,
  `restaurantID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tblorderdetails`
--

CREATE TABLE `tblorderdetails` (
  `orderID` int(11) NOT NULL,
  `itemID` int(11) NOT NULL,
  `packageID` int(11) NOT NULL,
  `itemQuantity` int(11) NOT NULL,
  `Amount` double(10,2) NOT NULL,
  `status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tblorders`
--

CREATE TABLE `tblorders` (
  `orderID` int(11) NOT NULL,
  `isDineIn` tinyint(1) NOT NULL DEFAULT 1,
  `orderDateTime` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `orderStatus` varchar(100) NOT NULL,
  `totalAmount` double(10,2) NOT NULL,
  `tableNo` int(11) NOT NULL,
  `cartID` int(11) NOT NULL,
  `processedBy` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tblpayment`
--

CREATE TABLE `tblpayment` (
  `paymentID` int(11) NOT NULL,
  `customerName` varchar(50) NOT NULL,
  `paymentMethod` varchar(50) NOT NULL,
  `totalAmount` decimal(10,2) NOT NULL,
  `status` varchar(50) NOT NULL,
  `processedBy` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tblpaymentdetails`
--

CREATE TABLE `tblpaymentdetails` (
  `paymentID` int(11) NOT NULL,
  `orderID` int(11) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `paymentDateTime` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tblprivileges`
--

CREATE TABLE `tblprivileges` (
  `privilegeID` int(11) NOT NULL,
  `privileges` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tblroles`
--

CREATE TABLE `tblroles` (
  `roleID` int(11) NOT NULL,
  `position` varchar(50) NOT NULL,
  `privilegeID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tblroles`
--

INSERT INTO `tblroles` (`roleID`, `position`, `privilegeID`) VALUES
(1, 'Administrator', 0),
(2, 'Chef', 0),
(3, 'Kitchen Staff', 0),
(4, 'Restaurant Manager', 0),
(5, 'Waiter', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbltable`
--

CREATE TABLE `tbltable` (
  `tableNo` int(11) NOT NULL,
  `tableQRCode` longblob NOT NULL,
  `noOfSeats` int(11) NOT NULL,
  `isOccupied` int(11) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbltable`
--

INSERT INTO `tbltable` (`tableNo`, `tableQRCode`, `noOfSeats`, `isOccupied`) VALUES
(1, '', 2, 1),
(2, '', 2, 1),
(3, '', 2, 1),
(4, '', 2, 1),
(5, '', 2, 1),
(6, '', 4, 1),
(7, '', 4, 1),
(8, '', 4, 1),
(9, '', 4, 1),
(10, '', 5, 1),
(11, 0x313639383938363437352e706e67, 4, 1),
(12, 0x2e2e2f2e2e2f696d616765732f363535623463353832666532382e706e67, 4, 1),
(13, 0x2e2e2f2e2e2f696d616765732f363535623465363665626134372e706e67, 5, 1),
(14, 0x2e2e2f2e2e2f696d616765732f363536333964353330326638362e706e67, 4, 1),
(15, 0x2e2e2f2e2e2f696d616765732f363536336230383261306363362e706e67, 5, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tblcart`
--
ALTER TABLE `tblcart`
  ADD PRIMARY KEY (`cartID`),
  ADD KEY `tableNo` (`tableNo`);

--
-- Indexes for table `tblcartdetails`
--
ALTER TABLE `tblcartdetails`
  ADD KEY `cartID` (`cartID`),
  ADD KEY `itemID` (`itemID`),
  ADD KEY `packageID` (`packageID`);

--
-- Indexes for table `tblcategories`
--
ALTER TABLE `tblcategories`
  ADD PRIMARY KEY (`categoryID`);

--
-- Indexes for table `tblemployeeacc`
--
ALTER TABLE `tblemployeeacc`
  ADD PRIMARY KEY (`empAccID`),
  ADD KEY `roleID` (`roleID`);

--
-- Indexes for table `tblfooditems`
--
ALTER TABLE `tblfooditems`
  ADD PRIMARY KEY (`itemID`);

--
-- Indexes for table `tblmenu`
--
ALTER TABLE `tblmenu`
  ADD PRIMARY KEY (`menuID`);

--
-- Indexes for table `tblmenupackage`
--
ALTER TABLE `tblmenupackage`
  ADD PRIMARY KEY (`packageID`);

--
-- Indexes for table `tblmenupackageitems`
--
ALTER TABLE `tblmenupackageitems`
  ADD KEY `packageID` (`packageID`),
  ADD KEY `itemID` (`itemID`);

--
-- Indexes for table `tblmenutype`
--
ALTER TABLE `tblmenutype`
  ADD PRIMARY KEY (`menuTypeID`);

--
-- Indexes for table `tblorderdetails`
--
ALTER TABLE `tblorderdetails`
  ADD KEY `itemID` (`itemID`),
  ADD KEY `orderID` (`orderID`),
  ADD KEY `packageID` (`packageID`);

--
-- Indexes for table `tblorders`
--
ALTER TABLE `tblorders`
  ADD PRIMARY KEY (`orderID`),
  ADD KEY `tableNo` (`tableNo`),
  ADD KEY `cartID` (`cartID`),
  ADD KEY `processedBy` (`processedBy`);

--
-- Indexes for table `tblpayment`
--
ALTER TABLE `tblpayment`
  ADD PRIMARY KEY (`paymentID`),
  ADD KEY `processedBy` (`processedBy`);

--
-- Indexes for table `tblpaymentdetails`
--
ALTER TABLE `tblpaymentdetails`
  ADD KEY `tblpaymentdetails_ibfk_1` (`orderID`),
  ADD KEY `tblpaymentdetails_ibfk_2` (`paymentID`);

--
-- Indexes for table `tblprivileges`
--
ALTER TABLE `tblprivileges`
  ADD PRIMARY KEY (`privilegeID`);

--
-- Indexes for table `tblroles`
--
ALTER TABLE `tblroles`
  ADD PRIMARY KEY (`roleID`);

--
-- Indexes for table `tbltable`
--
ALTER TABLE `tbltable`
  ADD PRIMARY KEY (`tableNo`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tblcart`
--
ALTER TABLE `tblcart`
  MODIFY `cartID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tblcategories`
--
ALTER TABLE `tblcategories`
  MODIFY `categoryID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `tblemployeeacc`
--
ALTER TABLE `tblemployeeacc`
  MODIFY `empAccID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `tblfooditems`
--
ALTER TABLE `tblfooditems`
  MODIFY `itemID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `tblmenu`
--
ALTER TABLE `tblmenu`
  MODIFY `menuID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tblmenupackage`
--
ALTER TABLE `tblmenupackage`
  MODIFY `packageID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tblmenutype`
--
ALTER TABLE `tblmenutype`
  MODIFY `menuTypeID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tblorders`
--
ALTER TABLE `tblorders`
  MODIFY `orderID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tblprivileges`
--
ALTER TABLE `tblprivileges`
  MODIFY `privilegeID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tblroles`
--
ALTER TABLE `tblroles`
  MODIFY `roleID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tbltable`
--
ALTER TABLE `tbltable`
  MODIFY `tableNo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tblpaymentdetails`
--
ALTER TABLE `tblpaymentdetails`
  ADD CONSTRAINT `tblpaymentdetails_ibfk_1` FOREIGN KEY (`orderID`) REFERENCES `tblorders` (`orderID`),
  ADD CONSTRAINT `tblpaymentdetails_ibfk_2` FOREIGN KEY (`paymentID`) REFERENCES `tblpayment` (`paymentID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
