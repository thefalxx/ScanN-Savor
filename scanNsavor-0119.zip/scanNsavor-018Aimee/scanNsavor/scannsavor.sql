-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 19, 2023 at 06:16 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `scannsavor`
--

-- --------------------------------------------------------

--
-- Table structure for table `tblcategories`
--

CREATE TABLE `tblcategories` (
  `categoryID` int(11) NOT NULL,
  `categoryName` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tblcategories`
--

INSERT INTO `tblcategories` (`categoryID`, `categoryName`) VALUES
(1, 'Appetizer'),
(2, 'Main Course'),
(3, 'Side Dish'),
(4, 'Salad'),
(5, 'Soup'),
(6, 'Desserts');

-- --------------------------------------------------------

--
-- Table structure for table `tblemployeeacc`
--

CREATE TABLE `tblemployeeacc` (
  `empAccID` int(11) NOT NULL,
  `firstName` varchar(50) NOT NULL,
  `lastName` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(150) NOT NULL,
  `status` varchar(50) NOT NULL,
  `type` varchar(50) NOT NULL,
  `roleID` int(11) NOT NULL,
  `restaurantID` int(11) NOT NULL,
  `authtoken` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tblemployeeacc`
--

INSERT INTO `tblemployeeacc` (`empAccID`, `firstName`, `lastName`, `email`, `password`, `status`, `type`, `roleID`, `restaurantID`, `authtoken`) VALUES
(6, 'Admin', 'Administrator', 'admin@gmail.com', '$2y$10$4nH/HLAJBHJOoP3GPELBGO1ToLJlHmHiYFFw.hbeM7FeiQYn6pk4y', 'active', 'Admin', 1, 1, '73f66749989c7b09389894f1b27daa7375d23af433e0cea4c0'),
(7, 'Taylor', 'Swift', 'swiftie@gmail.com', '$2y$10$eqteVNtXGjiDTdOFTNX8z.wIGEbPKEB8MIk1JaCLd6RJ4KmuPEJpu', 'active', 'General', 2, 1, '73f66749989c7b09389894f1b27daa73c5bfd7985fef4a7f47'),
(8, 'Megan', 'Trainor', 'megan@gmail.com', '$2y$10$L1U7XTTd4KAJkFr.7BBv/uKrWqZFYdKlfZmN.RgCTOZjuEzjXtTP6', 'active', 'General', 3, 1, '73f66749989c7b09389894f1b27daa7302538da916a9976ad2'),
(9, 'Ariana', 'Grande', 'grande@gmail.com', '$2y$10$IUxqQJkdlikIAhW.nOgYbOe/VhWzt3GsfEd01qSDwqIDrxJ.zZmEq', 'pending', 'General', 4, 1, '73f66749989c7b09389894f1b27daa73ef495b570eaa1a7545'),
(10, 'Swift', 'Acer', 'acerswift@gmail.com', '$2y$10$jL7KcY6DueMjTI5sHbxn6.lfWLF6o3TBxQ4Lo0QlwGmGHGK5iCOLS', 'pending', 'General', 3, 1, '73f66749989c7b09389894f1b27daa73b2312de3373bfbd18e'),
(11, 'Sza', 'Sza', 'sza@gmail.com', '$2y$10$wCTvXmB0nXG5wQVFRZGcaeGpHfKXR3G0/n3/BhoTtjCgGkYFXjQlK', 'inactive', 'General', 5, 1, '73f66749989c7b09389894f1b27daa73c8eb6780abc2fe33d4'),
(12, 'Bruno', 'Mars', 'mars@gmail.com', '$2y$10$fDJPFFOsR/txzhhoXOYygusr53CPCcRbE5LSRVBAOPSHDgVmb2DIm', 'active', 'General', 4, 1, '73f66749989c7b09389894f1b27daa732ccdbd5067ea7942d3'),
(13, 'Sam', 'Smith', 'smith@gmail.com', '$2y$10$GBey75YTKJYfX3s1JcAfyOdzhB9kD40WrledKUBhtxuRB/fx1g0yi', 'active', 'General', 2, 1, '73f66749989c7b09389894f1b27daa7300740959b42692bf9d'),
(14, 'Fred', 'Mercury', 'queen@gmail.com', '$2y$10$jqsevAq6tTQ3VmvauhgkHePwWpGbBkUde6Tvp8K05ApEFX8mYgiwe', 'active', 'General', 2, 1, '73f66749989c7b09389894f1b27daa7361e8f2660eebb1be71'),
(15, 'Charlie', 'Puth', 'charlie@gmail.com', '$2y$10$7RlpTE9yRdHyM1e0aSnwr.sxaHlQN3FxCXI9o7FZyBVWxtyLfYbJC', 'pending', 'General', 5, 1, '73f66749989c7b09389894f1b27daa73d47cb09f6c4edf706d'),
(16, 'John', 'Legend', 'legend@gmail.com', '$2y$10$CxYNhrChKcEQpa6pLwA4Pu9RL7kF5T6jFhyMKGhRV4qHQxC1OUo2y', 'active', 'General', 4, 1, '73f66749989c7b09389894f1b27daa73869196a3fdecc037c1'),
(17, 'Ryzen', 'Five', 'five@gmail.com', '$2y$10$SD0s3bg8XikvkbfLieSwvuaCvhtpWbnCGwkYPUCJrHDbcYFZ/MPi2', 'pending', 'General', 5, 1, '73f66749989c7b09389894f1b27daa735499abe119ec0d7562'),
(18, 'Justin', 'Bieber', 'baby@gmail.com', '$2y$10$LjfGf2hL/f4VwmXuybweUe09z.unalLhHQE.vbrjCQZTKe6fW/el.', 'pending', 'General', 2, 1, '73f66749989c7b09389894f1b27daa73a61029d203c75b1ff2');

-- --------------------------------------------------------

--
-- Table structure for table `tblfooditems`
--

CREATE TABLE `tblfooditems` (
  `itemID` int(11) NOT NULL,
  `menuID` int(11) NOT NULL,
  `categoryID` int(11) NOT NULL,
  `itemName` varchar(50) NOT NULL,
  `price` double NOT NULL,
  `description` varchar(150) NOT NULL,
  `pax` varchar(50) NOT NULL,
  `availability` varchar(50) NOT NULL,
  `itemImage` longblob NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tblfooditems`
--

INSERT INTO `tblfooditems` (`itemID`, `menuID`, `categoryID`, `itemName`, `price`, `description`, `pax`, `availability`, `itemImage`) VALUES
(1, 1, 6, 'Blueberry Cheesecake', 95, 'made with fresh blueberries', '', '1', '');

-- --------------------------------------------------------

--
-- Table structure for table `tblmenu`
--

CREATE TABLE `tblmenu` (
  `menuID` int(11) NOT NULL,
  `menuTypeID` int(11) NOT NULL,
  `menuName` varchar(50) NOT NULL,
  `price` double NOT NULL,
  `menuStatus` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tblmenutype`
--

CREATE TABLE `tblmenutype` (
  `menuTypeID` int(11) NOT NULL,
  `menuType` varchar(50) NOT NULL,
  `status` varchar(50) NOT NULL,
  `restaurantID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tblprivileges`
--

CREATE TABLE `tblprivileges` (
  `privilegeID` int(11) NOT NULL,
  `privileges` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tblroles`
--

CREATE TABLE `tblroles` (
  `roleID` int(11) NOT NULL,
  `position` varchar(50) NOT NULL,
  `privilegeID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tblroles`
--

INSERT INTO `tblroles` (`roleID`, `position`, `privilegeID`) VALUES
(1, 'Administrator', 0),
(2, 'Chef', 0),
(3, 'Kitchen Staff', 0),
(4, 'Restaurant Manager', 0),
(5, 'Waiter', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tblusers`
--

CREATE TABLE `tblusers` (
  `id` int(11) NOT NULL,
  `firstName` varchar(50) NOT NULL,
  `lastName` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `type` varchar(50) NOT NULL,
  `position` varchar(50) NOT NULL,
  `status` varchar(50) NOT NULL DEFAULT 'active',
  `authtoken` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tblusers`
--

INSERT INTO `tblusers` (`id`, `firstName`, `lastName`, `email`, `password`, `type`, `position`, `status`, `authtoken`) VALUES
(2, 'Taylor', 'Swift', 'swiftie@gmail.com', '202cb962ac59075b964b07152d234b70', 'General', '', 'active', '73f66749989c7b09389894f1b27daa73c5bfd7985fef4a7f47'),
(3, 'admin', 'admin', 'admin@admin.com', '21232f297a57a5a743894a0e4a801fc3', 'Admin', 'Administrator', 'active', '73f66749989c7b09389894f1b27daa7364e1b8d34f425d19e1'),
(4, 'Megan', 'Trainor', 'megan@gmail.com', '202cb962ac59075b964b07152d234b70', 'General', '', 'active', '73f66749989c7b09389894f1b27daa7302538da916a9976ad2'),
(5, 'Sam Smith', 'Sam Smith', 'smith@gmail.com', '202cb962ac59075b964b07152d234b70', 'General', 'Manager', 'active', '73f66749989c7b09389894f1b27daa7300740959b42692bf9d'),
(6, 'Bey Once', 'Bey Once', 'beyonce@gmail.com', '202cb962ac59075b964b07152d234b70', 'General', 'Manager', 'active', '73f66749989c7b09389894f1b27daa731d3be3bbb53ed286e8'),
(7, 'Katy Perry', 'Katy Perry', 'perry@gmail.com', '202cb962ac59075b964b07152d234b70', 'General', 'Chef', 'active', '73f66749989c7b09389894f1b27daa7376ed1c62db0bdd927e'),
(8, 'Liv', 'Rodrigo', 'olivia@gmail.com', '202cb962ac59075b964b07152d234b70', 'General', 'Kitchen', 'active', '73f66749989c7b09389894f1b27daa7369603870efaa488f19'),
(9, 'Bruno', 'Mars', 'mars@gmail.com', '202cb962ac59075b964b07152d234b70', 'General', 'Kitchen', 'active', '73f66749989c7b09389894f1b27daa732ccdbd5067ea7942d3'),
(10, 'Ne', 'Yo', 'neyo@gmail.com', '202cb962ac59075b964b07152d234b70', 'General', 'Manager', 'active', '73f66749989c7b09389894f1b27daa73bdfbf8288239d433c6'),
(11, 'Ariana', 'Grande', 'grande@gmail.com', '202cb962ac59075b964b07152d234b70', 'General', 'Manager', 'active', '73f66749989c7b09389894f1b27daa73d41d8cd98f00b204e9'),
(12, 'Chris', 'Brown', 'brown@gmail.com', '202cb962ac59075b964b07152d234b70', 'General', 'Chef', 'active', '73f66749989c7b09389894f1b27daa73a425ca513b49ecc003'),
(14, 'Sza', 'Sza', 'sza@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', 'General', 'Kitchen', 'active', '73f66749989c7b09389894f1b27daa73c8eb6780abc2fe33d4'),
(15, 'Fred', 'Mercury', 'queen@gmail.com', '202cb962ac59075b964b07152d234b70', 'General', 'Manager', 'active', '73f66749989c7b09389894f1b27daa7361e8f2660eebb1be71'),
(16, 'Thor', 'Odinson', 'lightning@gmail.com', '202cb962ac59075b964b07152d234b70', 'General', 'Manager', 'active', '73f66749989c7b09389894f1b27daa73668eea161a8a2e4e7c'),
(17, 'Acer', 'Swift', 'acerswift@gmail.com', '202cb962ac59075b964b07152d234b70', 'General', 'Kitchen', 'inactive', '73f66749989c7b09389894f1b27daa73b2312de3373bfbd18e');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tblcategories`
--
ALTER TABLE `tblcategories`
  ADD PRIMARY KEY (`categoryID`);

--
-- Indexes for table `tblemployeeacc`
--
ALTER TABLE `tblemployeeacc`
  ADD PRIMARY KEY (`empAccID`),
  ADD KEY `roleID` (`roleID`);

--
-- Indexes for table `tblfooditems`
--
ALTER TABLE `tblfooditems`
  ADD PRIMARY KEY (`itemID`);

--
-- Indexes for table `tblmenu`
--
ALTER TABLE `tblmenu`
  ADD PRIMARY KEY (`menuID`);

--
-- Indexes for table `tblmenutype`
--
ALTER TABLE `tblmenutype`
  ADD PRIMARY KEY (`menuTypeID`);

--
-- Indexes for table `tblprivileges`
--
ALTER TABLE `tblprivileges`
  ADD PRIMARY KEY (`privilegeID`);

--
-- Indexes for table `tblroles`
--
ALTER TABLE `tblroles`
  ADD PRIMARY KEY (`roleID`);

--
-- Indexes for table `tblusers`
--
ALTER TABLE `tblusers`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tblcategories`
--
ALTER TABLE `tblcategories`
  MODIFY `categoryID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tblemployeeacc`
--
ALTER TABLE `tblemployeeacc`
  MODIFY `empAccID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `tblfooditems`
--
ALTER TABLE `tblfooditems`
  MODIFY `itemID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tblmenu`
--
ALTER TABLE `tblmenu`
  MODIFY `menuID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tblmenutype`
--
ALTER TABLE `tblmenutype`
  MODIFY `menuTypeID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tblprivileges`
--
ALTER TABLE `tblprivileges`
  MODIFY `privilegeID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tblroles`
--
ALTER TABLE `tblroles`
  MODIFY `roleID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tblusers`
--
ALTER TABLE `tblusers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
